﻿Imports BLUEVELVETCOMLib
Imports BLUEVELVETConstants
Imports System.IO

Module Module1

    Sub Main()

        Dim bluefishCOM As BlueVelvetInterface
        Dim cardtype As ECardType
        Dim devicecount As Integer
        Dim BufferForDMA As IntPtr
        Dim FieldCount As Integer
        Dim length As Integer

        bluefishCOM = New BlueVelvetInterface
        bluefishCOM.Initialize()
        devicecount = bluefishCOM.device_enumerate()

        If (devicecount > 0) Then
            bluefishCOM.device_attach(1, 0)
            cardtype = bluefishCOM.has_video_cardtype(1)

            bluefishCOM.SetCardPropertyUInt32(EBlueCardProperty.DEFAULT_VIDEO_OUTPUT_CHANNEL, BLUEVELVETConstants.EBlueVideoChannel.BLUE_VIDEO_OUTPUT_CHANNEL_A)

            bluefishCOM.SetCardPropertyUInt32(EBlueCardProperty.VIDEO_MODE, EVideoMode.VID_FMT_PAL)
            bluefishCOM.SetCardPropertyUInt32(EBlueCardProperty.VIDEO_MEMORY_FORMAT, EMemoryFormat.MEM_FMT_BGR)
            bluefishCOM.SetCardPropertyUInt32(EBlueCardProperty.VIDEO_UPDATE_TYPE, EUpdateMethod.UPD_FMT_FRAME)
            bluefishCOM.SetCardPropertyUInt32(EBlueCardProperty.VIDEO_OUTPUT_ENGINE, EEngineMode.VIDEO_ENGINE_FRAMESTORE)
            bluefishCOM.SetCardPropertyUInt32(EBlueCardProperty.VIDEO_BLACKGENERATOR, 0)

            bluefishCOM.system_buffer_map(BufferForDMA, EBufferId.BUFFER_ID_VIDEO0)

            length = 576 * 720 * 3
            Dim result(length) As Byte

            Dim a As Integer = 0
            For a = 0 To length
                result(a) = 200
            Next

            Dim i As Integer = 0
            For i = 0 To 250
                System.Runtime.InteropServices.Marshal.Copy(result, 0, (BufferForDMA), length)
                bluefishCOM.wait_output_video_synch(EUpdateMethod.UPD_FMT_FRAME, FieldCount)
                bluefishCOM.system_buffer_write_lng_ex(BufferForDMA, i Mod 4, length, 0)
                bluefishCOM.render_buffer_update(i Mod 4)
            Next

            bluefishCOM.SetCardPropertyUInt32(EBlueCardProperty.VIDEO_BLACKGENERATOR, 1)

            System.Threading.Thread.Sleep(200)

            bluefishCOM.system_buffer_unmap_lng(BufferForDMA)

            bluefishCOM.device_detach()
        End If

    End Sub

End Module
