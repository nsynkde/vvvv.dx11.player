// BlueFilterPlayback.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
using namespace std;

HRESULT AddToRot(IUnknown *pUnkGraph, DWORD *pdwRegister) 
{
	IMoniker * pMoniker = NULL;
	IRunningObjectTable *pROT = NULL;
	const size_t STRING_LENGTH = 256;

	if(FAILED(GetRunningObjectTable(0, &pROT))) 
		return E_FAIL;

	WCHAR wsz[STRING_LENGTH];
	StringCchPrintfW(wsz, STRING_LENGTH, L"FilterGraph %08x pid %08x", (DWORD_PTR)pUnkGraph, GetCurrentProcessId());
    
    HRESULT hr = CreateItemMoniker(L"!", wsz, &pMoniker);
    if (SUCCEEDED(hr)) 
    {
        hr = pROT->Register(ROTFLAGS_REGISTRATIONKEEPSALIVE, pUnkGraph, pMoniker, pdwRegister);
        pMoniker->Release();
    }
    pROT->Release();
    hr = S_OK;
    return hr;
}

void RemoveFromRot(DWORD pdwRegister)
{
    IRunningObjectTable *pROT;
    if(SUCCEEDED(GetRunningObjectTable(0, &pROT)))
	{
        pROT->Revoke(pdwRegister);
        pROT->Release();
    }
}

HRESULT RemoveOtherFilters(IFilterGraph *pGraph)
{
    ULONG dbg,n = 0;
	HRESULT hr = S_OK;
	IBaseFilter *pBF[20];
	IEnumFilters *pEF;

	if(!pGraph)
		return S_FALSE;

	pGraph->EnumFilters(&pEF);
	hr = pEF->Next(20,pBF,&n);
	pEF->Release();

	hr = S_OK;
	for (unsigned int i=0;i<n;i++)
	{
		hr = pGraph->RemoveFilter(pBF[i]);

		if(pBF[i] && (hr == S_OK))
		{
			dbg = pBF[i]->Release();
			pBF[i] = NULL;
		}
	}
	return hr;
}

int _tmain(int argc, _TCHAR* argv[])
{
	IBaseFilter*			pBFVideoRenderer = NULL; 
    IBFFilterControl*		pBFVideoRendererFilterControl = NULL;
    IBFPropertiesControl*	pBFVideoRendererPropertiesControl = NULL;
    IBFVideoRenderControl*	pBFVideoRendererControl = NULL;
	IBFScalerControl*		pBFScalerControl = NULL;

    IBaseFilter*			pBFAudioRenderer = NULL; 
    IBFFilterControl*		pBFAudioRendererFilterCtrl = NULL;

	IGraphBuilder*			pFilterGraph = NULL;
	IMediaControl*			pMediaControl = NULL;
	IMediaSeeking*			pMediaSeeking = NULL;

	HRESULT					hr = S_OK;
	DWORD					dw_register = 0;	//to register in ROT (running objects table)

	bool UseVideo			= true;
	bool UseAudio			= true;
	bool UseChannelA		= true;

//*********************************************************************************
	CoInitialize(NULL);
//*********************************************************************************

	//The following file is assumed to be PAL and the rest of this application relys on that
	char FileToRender[] = "C:\\TestFile.mpg";

	//This is just to check if the file actually exists
	FILE* fp = fopen(FileToRender, "rb");
	if(!fp)
	{
		printf("File does not exist!\n");
		system("pause");
		return 0;
	}
	else
	{
		printf("File found.\n");
		fclose(fp);
		fp = 0;
	}

	//Create Bluefish filter instances
	if(UseVideo)
	{
		if(UseChannelA)
			hr = CoCreateInstance ( __uuidof(CBFVideoRenderer), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoRenderer );
		else
			hr = CoCreateInstance ( __uuidof(CBFVideoRendererInstC1ChB), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoRenderer );
	}
	if(UseAudio)
	{
		if(UseChannelA) //CBFAudioRenderer provides AES/Analog audio/Embedded Audio channel A
			hr = CoCreateInstance ( __uuidof(CBFAudioRenderer), NULL, CLSCTX_INPROC_SERVER, IID_IBaseFilter, (void **) &pBFAudioRenderer );
		else	//CBFEmbAudioRendererInstC1ChB provides Embedded Audio channel B
			hr = CoCreateInstance ( __uuidof(CBFEmbAudioRendererInstC1ChB), NULL, CLSCTX_INPROC_SERVER, IID_IBaseFilter, (void **) &pBFAudioRenderer );
	}

	if(pBFVideoRenderer)
		printf("Video Filter created\n");
	if(pBFAudioRenderer)
		printf("Audio Filter created\n");
	if(!pBFVideoRenderer && !pBFAudioRenderer)
	{
		printf("Error: No BF filter created!\n");
		system("pause");
		return 0;
	}

	//Initialise filtergraph/filters/bluefish card
	if (hr == S_OK && pBFVideoRenderer)
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFVideoRendererFilterControl);

	if (hr == S_OK && pBFVideoRenderer)
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFPropertiesControl), (void **)&pBFVideoRendererPropertiesControl);

	if (hr == S_OK && pBFVideoRenderer)    
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFVideoRenderControl), (void **)&pBFVideoRendererControl);

	if (hr == S_OK && pBFAudioRenderer && UseAudio)
		hr = pBFAudioRenderer->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFAudioRendererFilterCtrl);

	if(hr == S_OK && pBFVideoRenderer)
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFScalerControl), (void **)&pBFScalerControl);
	if(hr != S_OK)
		cout << "No scaler interface!" << endl;

	if (hr == S_OK)
		hr = CoCreateInstance ( CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER,IID_IGraphBuilder, (void **)&pFilterGraph );

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface(IID_IMediaControl, (void **)&pMediaControl);

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface(IID_IMediaSeeking, (void **)&pMediaSeeking);

	if (hr == S_OK && (pFilterGraph))
		hr = AddToRot(pFilterGraph, &dw_register);

	//set pixel format (default is YUVS)
	if(hr == S_OK && pBFVideoRendererPropertiesControl)
	{
		VARIANT varVal;
		varVal.vt = VT_UI4;
		//varVal.ulVal = MEM_FMT_ARGB_PC;
		//varVal.ulVal = MEM_FMT_BGR;
		varVal.ulVal = MEM_FMT_YUVS;
		hr = pBFVideoRendererPropertiesControl->SetCardProperty(VIDEO_MEMORY_FORMAT,&varVal);
	}

	//set the video ouput mode to PAL
	if(hr == S_OK  && pBFVideoRendererControl)
		hr = pBFVideoRendererControl->put_VideoMode(VID_FMT_PAL);

	//set scaler
	LONG nAvailableScalers = 0;
	LONG ScalerID = 0;
	LONG ScalerToUse = 0;
	LONG VideoModeOnSdiInput = VID_FMT_INVALID;
	LONG ConvertFromPAL = 0;
	RECT SrcRect, DstRect;
	vector<LONG> vScalerIDs;
	if(hr == S_OK && pBFScalerControl && pBFVideoRendererControl)
	{
		pBFScalerControl->GetAvailableScalers(&nAvailableScalers);
		cout << "Available Scalers: " << nAvailableScalers << endl;

		for(LONG n=0; n<nAvailableScalers; n++)
		{
			pBFScalerControl->GetScalerID(n, &ScalerID);
			vScalerIDs.push_back(ScalerID);
			cout << "Available Scaler ID: " << ScalerID << endl;
		}
		if(!vScalerIDs.empty())
		{
			//just use the first scaler that's available
			ScalerToUse = vScalerIDs[0];
			cout << "Using scaler " << ScalerToUse << endl;

			//just in case the scaler is already connected we have to disconnect it in order to be able to use it
			pBFScalerControl->DisableScaler();

			//we have set the VideoRenderer output video mode to PAL and now we want the scaler to upscale it to 1080i
			//the VideoRenderer will entirely operate in PAL and won't know anything about upscaling; it's all the scaler doing that
			//but we do have to set up the scaler to do the upscale
			SrcRect.left = 0; SrcRect.right = 719;
			SrcRect.top = 0; SrcRect.bottom = 575;
			DstRect.left = 240; DstRect.right = 1440+240;
			DstRect.top = 0; DstRect.bottom = 1079;
			pBFScalerControl->SetScalerMode(ScalerToUse, VID_FMT_1080I_5000, &SrcRect, &DstRect);
			cout << "Scaling from PAL to 1080i" << endl;
		}
	}

	if(hr == S_OK && pFilterGraph && pBFVideoRenderer)
       hr = pFilterGraph->AddFilter(pBFVideoRenderer, L"BlueFish Video Renderer");

	if (hr == S_OK && pFilterGraph && pBFAudioRenderer)
	    hr = pFilterGraph->AddFilter ( pBFAudioRenderer, L"BlueFish Audio Renderer");

	if (hr == S_OK && pFilterGraph)
	{
		WCHAR wFileName[255];
		memset(wFileName, 0, 255 *sizeof(WCHAR));
		mbstowcs(wFileName, FileToRender, strlen(FileToRender));

		if(pBFVideoRendererControl)
			hr = pBFVideoRendererControl->setForceBFAllocator(false);// some filter combinations want to use their own allocator 

		hr = pFilterGraph->RenderFile(wFileName, NULL);

		if(hr != S_OK)
		{
			if(pBFVideoRendererControl)
				hr = pBFVideoRendererControl->setForceBFAllocator(true); // some filter combinations require our allocator

			if(hr == S_OK)
				hr = pFilterGraph->RenderFile(wFileName, NULL);
		}
	}

	if(hr == S_OK && pMediaControl)
	{
		pMediaControl->Run();
		printf("Press any key to stop playback!\n");
		getch();
	}
	else
		printf("An error occured during initialisation.\n");

	printf("Stopping filtergraph (might take up to 10 seconds).\n");
	if(pMediaControl)
		pMediaControl->Stop();

	hr = S_OK;
	RemoveFromRot(dw_register);

	if(hr == S_OK && pFilterGraph && pBFAudioRenderer)
        hr = pFilterGraph->RemoveFilter(pBFAudioRenderer);

	if(hr == S_OK && pFilterGraph && pBFVideoRenderer)
        hr = pFilterGraph->RemoveFilter(pBFVideoRenderer);

	if(hr != S_OK)
		printf("An ERROR occured (exit)!\n");

	ULONG ret;

	SAFE_RELEASE_RES(ret,pBFScalerControl)
	SAFE_RELEASE_RES(ret,pBFVideoRendererFilterControl)
	SAFE_RELEASE_RES(ret,pBFVideoRendererPropertiesControl)
	SAFE_RELEASE_RES(ret,pBFVideoRendererControl)
	SAFE_RELEASE_RES(ret,pBFVideoRenderer)
	
	SAFE_RELEASE_RES(ret,pBFAudioRendererFilterCtrl)
	SAFE_RELEASE_RES(ret,pBFAudioRenderer)

	RemoveOtherFilters(pFilterGraph);

	SAFE_RELEASE_RES(ret,pMediaControl)
	SAFE_RELEASE_RES(ret,pMediaSeeking)
	SAFE_RELEASE_RES(ret,pFilterGraph)

	vScalerIDs.clear();

//*********************************************************************************
	CoUninitialize();
//*********************************************************************************

	printf("Filters destroyed. Press any key to exit...\n");
	system("pause");

	return 0;
}

