// BlueFilterCaptureScaler.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
using namespace std;

HRESULT AddToRot(IUnknown *pUnkGraph, DWORD *pdwRegister) 
{
	IMoniker * pMoniker = NULL;
	IRunningObjectTable *pROT = NULL;
	const size_t STRING_LENGTH = 256;

	if(FAILED(GetRunningObjectTable(0, &pROT))) 
		return E_FAIL;

	WCHAR wsz[STRING_LENGTH];
	StringCchPrintfW(wsz, STRING_LENGTH, L"FilterGraph %08x pid %08x", (DWORD_PTR)pUnkGraph, GetCurrentProcessId());
    
    HRESULT hr = CreateItemMoniker(L"!", wsz, &pMoniker);
    if (SUCCEEDED(hr)) 
    {
        hr = pROT->Register(ROTFLAGS_REGISTRATIONKEEPSALIVE, pUnkGraph, pMoniker, pdwRegister);
        pMoniker->Release();
    }
    pROT->Release();
    hr = S_OK;
    return hr;
}

void RemoveFromRot(DWORD pdwRegister)
{
    IRunningObjectTable *pROT;
    if(SUCCEEDED(GetRunningObjectTable(0, &pROT)))
	{
        pROT->Revoke(pdwRegister);
        pROT->Release();
    }
}

IPin *GetPin(IBaseFilter *pBF, PIN_DIRECTION pinDir )
{
	IEnumPins *pEnumPins = 0;
	IPin *pTmpPin = 0;
    IPin *pRes = NULL;
	PIN_INFO pin_info;
	pBF->EnumPins(&pEnumPins);
	ULONG res;
	while((!pRes) && pEnumPins->Next(1, &pTmpPin, &res) == S_OK)
	{
		pTmpPin->QueryPinInfo(&pin_info);
		
        if (pin_info.dir == pinDir) 
			pRes = pTmpPin;
		else 
			pTmpPin->Release();	
        
        if(pin_info.pFilter)
            pin_info.pFilter->Release();
	}
	pEnumPins->Release();
	return pRes;
}

HRESULT RemoveOtherFilters(IFilterGraph *pGraph)
{
    ULONG dbg,n = 0;
	HRESULT hr = S_OK;
	IBaseFilter *pBF[20];
	IEnumFilters *pEF;

	if(!pGraph)
		return S_FALSE;

	pGraph->EnumFilters(&pEF);
	hr = pEF->Next(20,pBF,&n);
	pEF->Release();

	hr = S_OK;
	for (unsigned int i=0;i<n;i++)
	{
		hr = pGraph->RemoveFilter(pBF[i]);

		if(pBF[i] && (hr == S_OK))
		{
			dbg = pBF[i]->Release();
			pBF[i] = NULL;
		}
	}
	return hr;
}

int _tmain(int argc, _TCHAR* argv[])
{
	IBaseFilter*			pBFVideoSource = NULL; 
    IBFFilterControl*		pBFVideoSourceFilterControl = NULL;
    IBFPropertiesControl*	pBFVideoSourcePropertiesControl = NULL;
    IBFVideoSourceControl*	pBFVideoSourceControl = NULL;
	IBFScalerControl*		pBFScalerControl = NULL;
	IReferenceClock*		pRefClock = NULL;

    IBaseFilter*			pBFAudioSource = NULL; 
    IBFFilterControl*		pBFAudioSourceFilterControl = NULL;
	IBFAudioSourceControl*	pBFAudioSourceControl = NULL;
	IBFAudioSourcePropertyControl* pBFAudioSourcePropertyControl = NULL;

	IGraphBuilder*			pFilterGraph = NULL;
	IMediaControl*			pMediaControl = NULL;
	IMediaFilter*			pMediaFilter = NULL;
	IMediaSeeking*			pMediaSeeking = NULL;

	HRESULT					hr = S_OK;
	DWORD					dw_register = 0;	//to register in ROT (running objects table)

	bool UseVideo			= true;
	bool UseAudio			= true;
	bool IsEmbeddedAudio	= true;
	int CaptureVBI			= 0;	// 0 = no VBI; 1 = VBI
	bool UseChannelA		= true;
	bool bUseEpoch			= true;	//If we use an Epoch card and want embedded audio we have to use CBFAudioSourceInstC1ChA instead of CBFEmbAudioSourceInstC1ChA
									//and configure the audio source type

//*********************************************************************************
	CoInitialize(NULL);
//*********************************************************************************

	//Create Bluefish filter instances
	if(UseVideo)
	{
		if(UseChannelA)
			hr = CoCreateInstance ( __uuidof(CBFVideoSourceInstC1ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoSource );
		else
			hr = CoCreateInstance ( __uuidof(CBFVideoSourceInstC1ChB), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoSource );
	}
	if(UseAudio)
	{
		if(UseChannelA)
		{
			if(IsEmbeddedAudio && !bUseEpoch)
				hr = CoCreateInstance ( __uuidof(CBFEmbAudioSourceInstC1ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFAudioSource );
			else
				hr = CoCreateInstance ( __uuidof(CBFAudioSourceInstC1ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFAudioSource );
		}
		else
		{
			if(IsEmbeddedAudio && !bUseEpoch)
				hr = CoCreateInstance ( __uuidof(CBFEmbAudioSourceInstC1ChB), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFAudioSource );
			else
				hr = CoCreateInstance ( __uuidof(CBFAudioSourceInstC1ChB), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFAudioSource );
		}
	}

	if(pBFVideoSource)
		printf("Video Filter created\n");
	if(pBFAudioSource)
		printf("Audio Filter created\n");
	if(!pBFVideoSource && !pBFAudioSource)
	{
		printf("Error: No BF filter created!\n");
		system("pause");
		return 0;
	}

	//Initialise filtergraph/filters/bluefish card
	if (hr == S_OK)
		hr = CoCreateInstance ( CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER,IID_IGraphBuilder, (void **)&pFilterGraph );

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFVideoSourceControl), (void **)&pBFVideoSourceControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFPropertiesControl), (void **)&pBFVideoSourcePropertiesControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFVideoSourceFilterControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IReferenceClock), (void **)&pRefClock);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFScalerControl), (void **)&pBFScalerControl);

	if (hr == S_OK && pBFAudioSource)
		hr = pBFAudioSource->QueryInterface(__uuidof(IBFAudioSourceControl), (void **)&pBFAudioSourceControl);

	if (hr == S_OK && pBFAudioSource)
		hr = pBFAudioSource->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFAudioSourceFilterControl);

	if (hr == S_OK && pBFAudioSource)
		hr = pBFAudioSource->QueryInterface(__uuidof(IBFAudioSourcePropertyControl), (void **)&pBFAudioSourcePropertyControl);

	if (hr == S_OK)
		hr = CoCreateInstance ( CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER,IID_IGraphBuilder, (void **)&pFilterGraph );

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface(IID_IMediaControl, (void **)&pMediaControl);

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface( IID_IMediaFilter, (void**)&pMediaFilter);

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface(IID_IMediaSeeking, (void **)&pMediaSeeking);

	if (hr == S_OK && pFilterGraph)
		hr = AddToRot(pFilterGraph, &dw_register);

	//VBI setting
	if (hr == S_OK && pBFVideoSourceControl)
	{
		int VBISupported;
		int VBIState;

		hr = pBFVideoSourceControl->getCaptureVBI(&VBISupported, &VBIState);
		if(VBISupported)
		{
			hr = pBFVideoSourceControl->setCaptureVBI(CaptureVBI);
			hr = pBFVideoSourceControl->getCaptureVBI(&VBISupported, &VBIState);
		}
	}

	//Audio input type
	if(hr == S_OK && UseAudio && IsEmbeddedAudio && bUseEpoch && pBFAudioSourceControl)
	{
		int CardAudioType;
		int NewAudioType;
		hr = pBFAudioSourceControl->get_AudioInputType(&CardAudioType);

		if(UseChannelA)
			NewAudioType = BLUE_AUDIO_SDIA;
		else
			NewAudioType = BLUE_AUDIO_SDIB;

		if(NewAudioType != CardAudioType)
		{
			if(hr == S_OK)
				hr = pBFAudioSourceControl->put_AudioInputType(NewAudioType);

			if(hr == S_OK)
			{
				hr = pBFAudioSourceControl->get_AudioInputType(&CardAudioType);
				if(NewAudioType != CardAudioType)
				{
					hr = S_FALSE;
					printf("Can't set audio type\n");
				}
			}
		}
	}

	//set up which audio channels to capture
	if(hr == S_OK && UseAudio && bUseEpoch && pBFAudioSourcePropertyControl)
	{
		if(pBFAudioSourcePropertyControl)
			hr = pBFAudioSourcePropertyControl->setPropertyInt32(0, MONO_CHANNEL_1 | MONO_CHANNEL_2);
	}

	//set scaler
	LONG nAvailableScalers = 0;
	LONG ScalerID = 0;
	LONG ScalerToUse = 0;
	LONG VideoModeOnSdiInput = VID_FMT_INVALID;
	LONG ConvertFromPAL = 0;
	RECT SrcRect, DstRect;
	vector<LONG> vScalerIDs;
	if(hr == S_OK && pBFScalerControl && pBFVideoSourceControl)
	{
		pBFScalerControl->GetAvailableScalers(&nAvailableScalers);
		cout << "Available Scalers: " << nAvailableScalers << endl;

		for(LONG n=0; n<nAvailableScalers; n++)
		{
			pBFScalerControl->GetScalerID(n, &ScalerID);
			vScalerIDs.push_back(ScalerID);
			cout << "Available Scaler ID: " << ScalerID << endl;

			//IMPORTANT: we can use any scaler on the input except for EPOCH_SRC_DEST_VPIO_SCALER_0
			//in this sample app we only want to use either EPOCH_SRC_DEST_SCALER_0 or EPOCH_SRC_DEST_VPIO_SCALER_1
			if(ScalerID == EPOCH_SRC_DEST_SCALER_0 || ScalerID == EPOCH_SRC_DEST_VPIO_SCALER_1)
				ScalerToUse = ScalerID;
		}

		cout << "Using scaler " << ScalerToUse << endl;

		//just in case there is a scaler connected to SDI A already we have to disconnect it in order to retrieve the actual video mode on the
		//SDI input
		pBFScalerControl->DisableScaler();
		pBFVideoSourceControl->get_VideoMode(&VideoModeOnSdiInput);

		UINT32 ScaleTo720P = 0;

		//just a hack to only allow either PAL to 1080i or 1080i to PAL conversion
		if(VideoModeOnSdiInput == VID_FMT_PAL)
		{
			ConvertFromPAL = 1;
			cout << "Enter 0 for scaling to 1080i or enter 1 for scaling to 720P: ";
			cin >> ScaleTo720P;
		}
		else if(VideoModeOnSdiInput == VID_FMT_1080I_5000)
		{
			ConvertFromPAL = 0;
			cout << "Enter 0 for scaling to PAL or enter 1 for scaling to 720P: ";
			cin >> ScaleTo720P;
		}
		else
			ScalerToUse = 0;

		if(ScalerToUse)
		{
			if(ConvertFromPAL)
			{
				if(ScaleTo720P)
				{
					//keeping the aspect ratio and center the origianl PAL image in 720P
					SrcRect.left = 0; SrcRect.right = 719;
					SrcRect.top = 0; SrcRect.bottom = 575;
					DstRect.left = 160; DstRect.right = 960+160;
					DstRect.top = 0; DstRect.bottom = 719;
					pBFScalerControl->SetScalerMode(ScalerToUse, VID_FMT_720P_5000, &SrcRect, &DstRect);
					cout << "Scaling from PAL to 720P" << endl;
				}
				else
				{
					//keeping the aspect ratio and center the origianl PAL image in 1080i
					SrcRect.left = 0; SrcRect.right = 719;
					SrcRect.top = 0; SrcRect.bottom = 575;
					DstRect.left = 240; DstRect.right = 1440+240;
					DstRect.top = 0; DstRect.bottom = 1079;
					pBFScalerControl->SetScalerMode(ScalerToUse, VID_FMT_1080I_5000, &SrcRect, &DstRect);
					cout << "Scaling from PAL to 1080i" << endl;
				}
			}
			else
			{
				if(ScaleTo720P)
				{
					//keeping the aspect ratio and center the origianl 1080i image in 720P
					SrcRect.left = 0; SrcRect.right = 1919;
					SrcRect.top = 0; SrcRect.bottom = 1079;
					DstRect.left = 0; DstRect.right = 1279;
					DstRect.top = 0; DstRect.bottom = 719;
					pBFScalerControl->SetScalerMode(ScalerToUse, VID_FMT_720P_5000, &SrcRect, &DstRect);
					cout << "Scaling from 1080i to 720P" << endl;
				}
				else
				{
					//keeping the aspect ratio and center the origianl 1080i image in PAL
					SrcRect.left = 0; SrcRect.right = 1919;
					SrcRect.top = 0; SrcRect.bottom = 1079;
					DstRect.left = 0; DstRect.right = 719;
					DstRect.top = 85; DstRect.bottom = 405+85;
					pBFScalerControl->SetScalerMode(ScalerToUse, VID_FMT_PAL, &SrcRect, &DstRect);
					cout << "Scaling from 1080i to PAL" << endl;
				}
			}
		}
		else
			cout << "No suitable scaler found or video mode not allowed in this sample app" << endl;
	}

	//Add filters to filtergraph
	if (hr == S_OK && pFilterGraph)
	{
		//VIDEO
		if(hr == S_OK && pBFVideoSource)
		{
			hr = pFilterGraph->AddFilter(pBFVideoSource, L"BlueFish Video Source");

			if (hr == S_OK)
			{
				IPin *pOutPin = NULL;
				pOutPin = GetPin(pBFVideoSource,PINDIR_OUTPUT);
				if(pOutPin)
				{
					hr = pFilterGraph->Render(pOutPin);
					pOutPin->Release();
				}
			}
		}

		//AUDIO
		if(hr == S_OK && pBFAudioSource)
		{
			hr = pFilterGraph->AddFilter(pBFAudioSource, L"BlueFish Audio Source");

			if (hr == S_OK)
			{
				IPin *pOutPin = NULL;
				pOutPin = GetPin(pBFAudioSource,PINDIR_OUTPUT);
				if(pOutPin)
				{
					hr = pFilterGraph->Render(pOutPin);
					pOutPin->Release();
				}
			}
		}
	}

	if(pMediaFilter)
		pMediaFilter->SetSyncSource(pRefClock);

	if(pMediaControl)
	{
		pMediaControl->Run();
		printf("Press any key to stop capture!\n");
		getch();
	}
	else
		printf("An error occured during initialisation.\n");

	if(pMediaControl)
		pMediaControl->Stop();

	hr = S_OK;
	RemoveFromRot(dw_register);

	if(hr == S_OK && pFilterGraph && pBFAudioSource)
        hr = pFilterGraph->RemoveFilter(pBFAudioSource);

	if(hr == S_OK && pFilterGraph && pBFVideoSource)
        hr = pFilterGraph->RemoveFilter(pBFVideoSource);

	if(hr != S_OK)
		printf("An ERROR occured (exit)!\n");

	ULONG ret;

	if(pMediaFilter)
		pMediaFilter->SetSyncSource(NULL);

	SAFE_RELEASE_RES(ret,pRefClock)
	SAFE_RELEASE_RES(ret,pBFScalerControl)
	SAFE_RELEASE_RES(ret,pBFVideoSourceControl)
	SAFE_RELEASE_RES(ret,pBFVideoSourcePropertiesControl)
	SAFE_RELEASE_RES(ret,pBFVideoSourceFilterControl)
	SAFE_RELEASE_RES(ret,pBFVideoSource)
	
	SAFE_RELEASE_RES(ret,pBFAudioSourcePropertyControl)
	SAFE_RELEASE_RES(ret,pBFAudioSourceControl)
	SAFE_RELEASE_RES(ret,pBFAudioSourceFilterControl)
	SAFE_RELEASE_RES(ret,pBFAudioSource)

	RemoveOtherFilters(pFilterGraph);

	SAFE_RELEASE_RES(ret,pMediaFilter)
	SAFE_RELEASE_RES(ret,pMediaControl)
	SAFE_RELEASE_RES(ret,pMediaSeeking)
	SAFE_RELEASE_RES(ret,pFilterGraph)

	vScalerIDs.clear();

//*********************************************************************************
	CoUninitialize();
//*********************************************************************************
	printf("Filters destroyed.\n");
	system("pause");

	return 0;
}

