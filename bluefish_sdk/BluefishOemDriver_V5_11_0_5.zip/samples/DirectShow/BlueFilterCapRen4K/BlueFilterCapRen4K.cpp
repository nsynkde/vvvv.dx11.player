// BlueFilterCapRen.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


HRESULT AddToRot(IUnknown *pUnkGraph, DWORD *pdwRegister) 
{
	IMoniker * pMoniker = NULL;
	IRunningObjectTable *pROT = NULL;
	const size_t STRING_LENGTH = 256;

	if(FAILED(GetRunningObjectTable(0, &pROT))) 
		return E_FAIL;

	WCHAR wsz[STRING_LENGTH];
	StringCchPrintfW(wsz, STRING_LENGTH, L"FilterGraph %08x pid %08x", (DWORD_PTR)pUnkGraph, GetCurrentProcessId());
    
    HRESULT hr = CreateItemMoniker(L"!", wsz, &pMoniker);
    if (SUCCEEDED(hr)) 
    {
        hr = pROT->Register(ROTFLAGS_REGISTRATIONKEEPSALIVE, pUnkGraph, pMoniker, pdwRegister);
        pMoniker->Release();
    }
    pROT->Release();
    hr = S_OK;
    return hr;
}

void RemoveFromRot(DWORD pdwRegister)
{
    IRunningObjectTable *pROT;
    if(SUCCEEDED(GetRunningObjectTable(0, &pROT)))
	{
        pROT->Revoke(pdwRegister);
        pROT->Release();
    }
}

IPin *GetPin(IBaseFilter *pBF, PIN_DIRECTION pinDir, int iPinNumber=0)
{
	IEnumPins *pEnumPins = 0;
	IPin* pTmpPin = 0;
    IPin* pRes = NULL;
	PIN_INFO pin_info;
	pBF->EnumPins(&pEnumPins);
	ULONG res;
	int iPinsFound = 0;
	while((!pRes) && pEnumPins->Next(1, &pTmpPin, &res) == S_OK)
	{
		pTmpPin->QueryPinInfo(&pin_info);
		
        if(pin_info.dir == pinDir)
		{
			if(iPinsFound == iPinNumber)
				pRes = pTmpPin;
			else
				pTmpPin->Release();	
			iPinsFound++;
		}
		else 
			pTmpPin->Release();	
        
        if(pin_info.pFilter)
            pin_info.pFilter->Release();
	}
	pEnumPins->Release();
	return pRes;
}

HRESULT RemoveOtherFilters(IFilterGraph *pGraph)
{
    ULONG dbg,n = 0;
	HRESULT hr = S_OK;
	IBaseFilter *pBF[20];
	IEnumFilters *pEF;

	if(!pGraph)
		return S_FALSE;

	pGraph->EnumFilters(&pEF);
	hr = pEF->Next(20,pBF,&n);
	pEF->Release();

	hr = S_OK;
	for (unsigned int i=0;i<n;i++)
	{
		hr = pGraph->RemoveFilter(pBF[i]);

		if(pBF[i] && (hr == S_OK))
		{
			dbg = pBF[i]->Release();
			pBF[i] = NULL;
		}
	}
	return hr;
}

int _tmain(int argc, _TCHAR* argv[])
{
	IBaseFilter*			pBFVideoSource = NULL; 
    IBFFilterControl*		pBFVideoSourceFilterControl = NULL;
    IBFPropertiesControl*	pBFVideoSourcePropertiesControl = NULL;
    IBFVideoSourceControl*	pBFVideoSourceControl = NULL;
	IBFAdvancedFilterSettings* pBFAdvancedFilterSettingsSource = NULL;
	IBFAdvancedFilterSettings* pBFAdvancedFilterSettingsRender = NULL;

	IBaseFilter*			pBFVideoRenderer = NULL; 
    IBFFilterControl*		pBFVideoRendererFilterControl = NULL;
    IBFPropertiesControl*	pBFVideoRendererPropertiesControl = NULL;
    IBFVideoRenderControl*	pBFVideoRendererControl = NULL;

	IGraphBuilder*			pFilterGraph = NULL;
	IMediaControl*			pMediaControl = NULL;
	IMediaSeeking*			pMediaSeeking = NULL;
	IMediaFilter*			pMediaFilter = NULL;
	IReferenceClock*		pRefClock = NULL;

	HRESULT					hr = S_OK;
	DWORD					dw_register = 0;	//to register in ROT (running objects table)

//*********************************************************************************
	CoInitialize(NULL);
//*********************************************************************************

	hr = CoCreateInstance ( __uuidof(CBFVideoSourceInstC1ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoSource );
	hr = CoCreateInstance ( __uuidof(CBFVideoRendererInstC2ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoRenderer );

	if(pBFVideoSource)
		printf("Video Capture Filter created\n");

	if(pBFVideoRenderer)
		printf("Video Render Filter created\n");

	if(!pBFVideoSource && !pBFVideoRenderer)
	{
		printf("Error: No BF filter created!\n");
		return 0;
	}

	//init capture side
	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFVideoSourceControl), (void **)&pBFVideoSourceControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFPropertiesControl), (void **)&pBFVideoSourcePropertiesControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFVideoSourceFilterControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IReferenceClock), (void **)&pRefClock);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFAdvancedFilterSettings), (void **)&pBFAdvancedFilterSettingsSource);

	//init render side
	if (hr == S_OK && pBFVideoRenderer)
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFVideoRendererFilterControl);

	if (hr == S_OK && pBFVideoRenderer)
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFPropertiesControl), (void **)&pBFVideoRendererPropertiesControl);

	if (hr == S_OK && pBFVideoRenderer)    
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFVideoRenderControl), (void **)&pBFVideoRendererControl);

	if(hr == S_OK && pBFVideoRenderer)
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFAdvancedFilterSettings), (void **)&pBFAdvancedFilterSettingsRender);

	//Initialise filtergraph/filters/bluefish card
	if (hr == S_OK)
		hr = CoCreateInstance ( CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER,IID_IGraphBuilder, (void **)&pFilterGraph );

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface(IID_IMediaControl, (void **)&pMediaControl);

	if (hr == S_OK && pFilterGraph)
		pFilterGraph->QueryInterface(IID_IMediaFilter, (void**)&pMediaFilter);

	if(hr == S_OK && pFilterGraph && pMediaFilter && pRefClock)
		pMediaFilter->SetSyncSource(pRefClock);

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface(IID_IMediaSeeking, (void **)&pMediaSeeking);

	if(hr == S_OK && pBFVideoSource && pBFAdvancedFilterSettingsSource)
	{
		hr = pBFAdvancedFilterSettingsSource->SetAdvancedSettings(ADV_FILTER_SETTING_4K_MODE, MODE4K_ACTIVE);
		if(hr != S_OK)	//try again; this function will change the routing for all 4 input channels and the video input recognition might take a bit longer
		{
			hr = pBFAdvancedFilterSettingsSource->SetAdvancedSettings(ADV_FILTER_SETTING_4K_MODE, MODE4K_ACTIVE);
			printf("4K not available/supported\n");
			goto SampleExit;
		}
	}

	if(hr == S_OK && pBFVideoRenderer && pBFAdvancedFilterSettingsRender)
	{
		hr = pBFAdvancedFilterSettingsRender->SetAdvancedSettings(ADV_FILTER_SETTING_4K_MODE, MODE4K_ACTIVE);
		if(hr != S_OK)
		{
			printf("4K not available/supported\n");
			goto SampleExit;
		}
	}

	if (hr == S_OK && pFilterGraph)
		hr = AddToRot(pFilterGraph, &dw_register);


	//Add filters to filtergraph
	if (hr == S_OK && pFilterGraph)
	{
		//VIDEO
		if(pBFVideoSource && pBFVideoRenderer)
		{
			if(hr == S_OK)
				hr = pFilterGraph->AddFilter(pBFVideoSource, L"BlueFish Video Source");
			if(hr == S_OK)
				hr = pFilterGraph->AddFilter(pBFVideoRenderer, L"BlueFish Video Renderer");
			if (hr == S_OK)
			{
				IPin *pOutPin = NULL;
				pOutPin = GetPin(pBFVideoSource, PINDIR_OUTPUT);
				if(pOutPin)
				{
					hr = pFilterGraph->Render(pOutPin);
					pOutPin->Release();
				}
				pOutPin = GetPin(pBFVideoSource, PINDIR_OUTPUT, 1);	//VANC pin
				if(pOutPin)
				{
					hr = pFilterGraph->Render(pOutPin);
					pOutPin->Release();
				}
			}
		}
	}

	if(pMediaControl)
	{
		pMediaControl->Run();
		//Sleep(2000);
		printf("Press any key to stop capture!\n");
		getch();
	}
	else
		printf("An error occured during initialisation.\n");

	if(pMediaControl)
		hr = pMediaControl->Stop();
	//printf("Stopped: hr = %d\n", hr);
	//Sleep(2000);

	hr = S_OK;
	RemoveFromRot(dw_register);

	if(hr == S_OK && pFilterGraph && pBFVideoRenderer)
        hr = pFilterGraph->RemoveFilter(pBFVideoRenderer);

	if(hr == S_OK && pFilterGraph && pBFVideoSource)
        hr = pFilterGraph->RemoveFilter(pBFVideoSource);
	

	if(hr != S_OK)
		printf("An ERROR occured (exit)!\n");

	/*if(pMediaFilter)
		pMediaFilter->SetSyncSource(NULL);*/


SampleExit:
	ULONG ret;

	SAFE_RELEASE_RES(ret,pRefClock)
	SAFE_RELEASE_RES(ret,pMediaFilter)
	
	SAFE_RELEASE_RES(ret,pBFAdvancedFilterSettingsSource)
	SAFE_RELEASE_RES(ret,pBFVideoSourceControl)
	SAFE_RELEASE_RES(ret,pBFVideoSourcePropertiesControl)
	SAFE_RELEASE_RES(ret,pBFVideoSourceFilterControl)
	SAFE_RELEASE_RES(ret,pBFVideoSource)
	
	SAFE_RELEASE_RES(ret,pBFAdvancedFilterSettingsRender)
	SAFE_RELEASE_RES(ret,pBFVideoRendererFilterControl)
	SAFE_RELEASE_RES(ret,pBFVideoRendererPropertiesControl)
	SAFE_RELEASE_RES(ret,pBFVideoRendererControl)
	SAFE_RELEASE_RES(ret,pBFVideoRenderer)
	
	RemoveOtherFilters(pFilterGraph);

	SAFE_RELEASE_RES(ret,pMediaControl)
	SAFE_RELEASE_RES(ret,pMediaSeeking)
	SAFE_RELEASE_RES(ret,pFilterGraph)

//*********************************************************************************
	CoUninitialize();
//*********************************************************************************
	printf("Filters destroyed. Press any key to exit...\n");
	system("pause");

	return 0;
}

