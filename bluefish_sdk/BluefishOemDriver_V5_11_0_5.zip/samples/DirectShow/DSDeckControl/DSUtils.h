#ifndef _DSUTILS_H_
#define _DSUTILS_H_

#define SAFERELEASE(x) {if(x) x->Release(); x = NULL;}

IPin *GetPin(IBaseFilter *pBF, PIN_DIRECTION pinDir );
HRESULT ConnectFiltersDirect(IFilterGraph *pGraph, IBaseFilter * pOut,IBaseFilter *pIn );
HRESULT RemoveAllFilters( IFilterGraph *pGraph);
bool isZeroRect( const RECT &rect );
__int64 calcVideoRefTime( __int64 step , __int64 scale,double frameRate, __int64 tickNo);
HRESULT AddToROT(IUnknown *pUnkGraph, DWORD* pROTdwREG, int number);
void RemoveFromROT(DWORD ROTdwREG);


typedef struct _BFTimeCodePoint
{
	UINT32 TimeCodeBCD;
	BYTE HoursBCD;
	BYTE MinutesBCD;
	BYTE SecondsBCD;
	BYTE FramesBCD;

	UINT32 TimeCodeDEC;
	BYTE HoursDEC;
	BYTE MinutesDEC;
	BYTE SecondsDEC;
	BYTE FramesDEC;

	UINT32 TotalFrames;
}BFTimeCodePoint;

class BFClip
{
public:
	BFTimeCodePoint m_PreRollPoint;
	BFTimeCodePoint m_InPoint;
	BFTimeCodePoint m_OutPoint;
	bool m_bPointsSet;

public:
	BFClip();
	void ClearPoints();
	void SetPointsBCD(UINT32 InBCD, UINT32 OutBCD, UINT32 fps);
	void SetPointsDEC(UINT32 InDEC, UINT32 OutDEC, UINT32 fps);
	static BYTE ConvertToDEC(BYTE In);
	static BYTE ConvertToBCD(BYTE In);
};


#endif	//_DSUTILS_H_
