#ifndef _HDSINTERFACE_
#define _HDSINTERFACE_

#include <initguid.h>
#include <process.h>
#include "dshow.h"
#import <BlueFishFilters.tlb> no_namespace
#include "GMFBridge_h.h"
#include "DSUtils.h"


_COM_SMARTPTR_TYPEDEF(IBaseFilter, IID_IBaseFilter);
_COM_SMARTPTR_TYPEDEF(ICaptureGraphBuilder2, IID_ICaptureGraphBuilder2);
_COM_SMARTPTR_TYPEDEF(IPin, IID_IPin);


class CDSInterface
{
public:
	DWORD					m_dwROTRegPreview;
	DWORD					m_dwROTRegCapture;

	IBaseFilterPtr			m_pGMFBridgeSink;
	IBaseFilterPtr			m_pGMFBridgeSource;
	IBaseFilter				*m_pVideoSourceFilter;
	IBFFilterControl		*m_pVideoSourceFilterControl;
	IBFPropertiesControl	*m_pVideoSourcePropertyControl;
	IBFVideoSourceControl	*m_pVideoSourceControl;
	IAMExtTransport			*m_pIAMExtTransport;
	IAMTimecodeReader		*m_pIAMTimeCodeReader;
	IBFStreamControl		*m_pIBFStreamControl;

	IGMFBridgeController	*m_pIGMFBridgeController;

	IGraphBuilder			*m_pGraphPreview;
	IGraphBuilder			*m_pGraphCapture;
	IMediaEvent				*m_pIMediaEventPreview;
	IMediaControl			*m_pMediaControlPreview;
	IMediaEvent				*m_pIMediaEventCapture;
	IMediaControl			*m_pMediaControlCapture;

	UINT32	m_FPS;
	bool	m_bPreviewGraphRunning;
	bool	m_bCaptureGraphRunning;
	bool	m_bCaptureActive;
	bool	m_bIsSeeking;
	bool	m_bIsRolling;
	bool	m_bIsCapturing;
	BFClip	m_Clip;

	BYTE	m_PrivateHours;
	BYTE	m_PrivateMinutes;
	BYTE	m_PrivateSeconds;
	BYTE	m_PrivateFrames;

public:
	CDSInterface();
	~CDSInterface();

	INT32 InitFilters();
	INT32 ConnectToDeck();
	INT32 CreatePreviewGraph();
	INT32 StartPreview();

	bool CreateCaptureGraph(const _bstr_t bstrFile, UINT32 InPoint, UINT32 OutPoint);
	bool StartCapture();
	bool IsActive();
	bool IsSeeking();
	bool IsRolling();
	bool IsCapturing();

	unsigned int static __stdcall CaptureThread(void * pArg);
	int		StopCaptureThread();
	HANDLE	m_hCaptureThread;
	bool	m_bThreadStopped;

	INT32 GetTimeCode(BYTE* hours, BYTE* minutes, BYTE* seconds, BYTE* frames);
	INT32 GetPrivateTimeCode();
	bool GetDeckStatus(long* pStatus);

	void DeckPlay();
	void DeckStop();
	void DeckForward();
	void DeckRewind();

};



#endif //_HDSINTERFACE_
