#include "DSInterface.h"


CDSInterface::CDSInterface()
{
	m_pGMFBridgeSink = NULL;
	m_pGMFBridgeSource = NULL;
	m_pVideoSourceFilter = NULL;
	m_pVideoSourceFilterControl = NULL;
	m_pVideoSourcePropertyControl = NULL;
	m_pVideoSourceControl = NULL;
	m_pIAMExtTransport = NULL;
	m_pIAMTimeCodeReader = NULL;
	m_pIBFStreamControl = NULL;
	m_pIGMFBridgeController = NULL;
	m_pGraphPreview = NULL;
	m_pGraphCapture = NULL;
	m_pIMediaEventPreview = NULL;
	m_pMediaControlPreview = NULL;
	m_pIMediaEventCapture = NULL;
	m_pMediaControlCapture = NULL;

	m_hCaptureThread = NULL;
	m_bThreadStopped = true;

	m_bPreviewGraphRunning = false;
	m_bCaptureGraphRunning = false;
	m_bCaptureActive = false;
	m_bIsSeeking = false;
	m_bIsRolling = false;
	m_bIsCapturing = false;

	m_FPS = 25;

	CoInitialize(NULL);
}

CDSInterface::~CDSInterface()
{
	StopCaptureThread();

	if(m_dwROTRegPreview != 0)
		RemoveFromROT(m_dwROTRegPreview);

	if(m_dwROTRegCapture != 0)
		RemoveFromROT(m_dwROTRegCapture);

	if(m_pMediaControlPreview && m_bPreviewGraphRunning)
	{
		m_pMediaControlPreview->Stop();
		m_bPreviewGraphRunning = false;
	}

	if(m_pMediaControlCapture && m_bCaptureGraphRunning)
	{
		m_pMediaControlCapture->Stop();
		m_bCaptureGraphRunning = false;
	}

	if(m_pGraphPreview && m_pVideoSourceFilter)
		m_pGraphPreview->RemoveFilter(m_pVideoSourceFilter);

	SAFERELEASE(m_pIGMFBridgeController);
	SAFERELEASE(m_pIBFStreamControl);
	SAFERELEASE(m_pIAMTimeCodeReader);
	SAFERELEASE(m_pIAMExtTransport);
	SAFERELEASE(m_pVideoSourceFilterControl);
	SAFERELEASE(m_pVideoSourcePropertyControl);
	SAFERELEASE(m_pVideoSourceControl);
	SAFERELEASE(m_pVideoSourceFilter);

	RemoveAllFilters(m_pGraphPreview);
	RemoveAllFilters(m_pGraphCapture);

	SAFERELEASE(m_pMediaControlPreview);
	SAFERELEASE(m_pMediaControlCapture);
	SAFERELEASE(m_pIMediaEventPreview);
	SAFERELEASE(m_pIMediaEventCapture);
	SAFERELEASE(m_pGraphPreview);
	SAFERELEASE(m_pGraphCapture);


	CoUninitialize();
}

INT32 CDSInterface::InitFilters()
{
	HRESULT hr = S_OK;

	m_dwROTRegPreview = 0;
	m_dwROTRegCapture = 0;

	hr = CoCreateInstance ( __uuidof(CBFVideoSourceInstC1ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &m_pVideoSourceFilter );

	if(!m_pVideoSourceFilter)
		return -1;

	if (hr == S_OK)
		m_pVideoSourceFilter->QueryInterface(__uuidof(IBFVideoSourceControl), (void **)&m_pVideoSourceControl);
	if (hr == S_OK)
		hr = m_pVideoSourceFilter->QueryInterface(__uuidof(IBFPropertiesControl), (void **)&m_pVideoSourcePropertyControl);
	if (hr == S_OK)
		hr = m_pVideoSourceFilter->QueryInterface(__uuidof(IBFFilterControl), (void **)&m_pVideoSourceFilterControl);
	if (hr == S_OK)
		hr = m_pVideoSourceFilter->QueryInterface(__uuidof(IAMExtTransport), (void **)&m_pIAMExtTransport);
	if (hr == S_OK)
		hr = m_pVideoSourceFilter->QueryInterface(__uuidof(IAMTimecodeReader), (void **)&m_pIAMTimeCodeReader);
	if (hr == S_OK)
		hr = m_pVideoSourceFilter->QueryInterface(__uuidof(IBFStreamControl), (void **)&m_pIBFStreamControl);

	if (hr == S_OK)
		hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IGraphBuilder, (void **)&m_pGraphPreview);
	if (hr == S_OK && m_pGraphPreview)
		hr = m_pGraphPreview->QueryInterface(IID_IMediaControl, (void **) &m_pMediaControlPreview);
	if (hr == S_OK && m_pGraphPreview)
		hr = m_pGraphPreview->QueryInterface(IID_IMediaEvent, (void **) &m_pIMediaEventPreview);

	if (hr == S_OK)
		hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IGraphBuilder, (void **)&m_pGraphCapture);
	if (hr == S_OK && m_pGraphCapture)
		hr = m_pGraphCapture->QueryInterface(IID_IMediaControl, (void **) &m_pMediaControlCapture);
	if (hr == S_OK && m_pGraphCapture)
		hr = m_pGraphCapture->QueryInterface(IID_IMediaEvent, (void **) &m_pIMediaEventCapture);

	if (hr == S_OK)
		hr = CoCreateInstance(__uuidof(GMFBridgeController), NULL, CLSCTX_INPROC_SERVER, __uuidof(IGMFBridgeController), (void **)&m_pIGMFBridgeController);

	if(hr != S_OK)
		return -1;

	return 0;
}

INT32 CDSInterface::ConnectToDeck()
{
	if(!m_pIAMTimeCodeReader || !m_pIBFStreamControl)
		return -1;

	m_pIBFStreamControl->InitDeckControl(0);

	unsigned int CaptureThreadId = 0;
	if(m_hCaptureThread)
		return 0;

	m_bThreadStopped = false;
	m_hCaptureThread = (HANDLE)_beginthreadex(0, 0, &CaptureThread, this, 0, &CaptureThreadId);
	if(!m_hCaptureThread)
	{
		m_bThreadStopped = true;
		return -1;
	}

	return 0;
}

INT32 CDSInterface::CreatePreviewGraph()
{
	HRESULT hr = S_OK;

	//BUILD PREVIEW FILTERGRAPH
	//1. Create a BridgeStream object
	m_pIGMFBridgeController->AddStream(true, eAny, true);

	//2. Add our source filter to filtergraph #1 (constant capture for preview)
	/*
	---------------------
	|					|
	| BF Source Filter	| ->	
	|					|
	---------------------
	*/
	FILTER_INFO FInfo;
	m_pVideoSourceFilter->QueryFilterInfo(&FInfo);
	m_pGraphPreview->AddFilter(m_pVideoSourceFilter, FInfo.achName);

	//3. Add a GMFBridge sink filter to filtergraph #1 
	/*	---------------------
	|					|
	| GMFBridge Sink	|
	|					|
	---------------------
	*/
	IUnknownPtr punkSink;
	hr = m_pIGMFBridgeController->InsertSinkFilter(m_pGraphPreview, &punkSink);
	m_pGMFBridgeSink = punkSink;

	//4. Use capture graph builder to render preview (uses smart tee filter, because we want to preview and our source filter does not have a preview pin)
	/*
	---------------------		------------		---------------------
	|					|		|	Capture:| --->	|					|
	| BF Source Filter	| --->	| Smart Tee	|		| GMFBridge Sink	|
	|					|		|	Preview:| -		|					|
	---------------------		------------   \	---------------------
											    |
												|	---------------------		-----------------------
												|	|					|		|					  |
												-->	| AVI Decompressor	| --->	| Dflt Video Renderer |
													|					|		|					  |
													---------------------		-----------------------*/
	ICaptureGraphBuilder2Ptr pBuilder;
	hr = pBuilder.CreateInstance(CLSID_CaptureGraphBuilder2);
	if (SUCCEEDED(hr))
	{
		pBuilder->SetFiltergraph(m_pGraphPreview);
		hr = pBuilder->RenderStream(&PIN_CATEGORY_PREVIEW, 
									&MEDIATYPE_Video,
									m_pVideoSourceFilter,
									NULL,
									NULL);
	}

	//5. Build capture part of the graph
	/*
	---------------------		------------		---------------------
	|					|		|	Capture:| --->	|					|
	| BF Source Filter	| --->	| Smart Tee	|		| GMFBridge Sink	|
	|					|		|	Preview:| -		|					|
	---------------------		------------   \	---------------------
											    |
												|	---------------------		-----------------------
												|	|					|		|					  |
												-->	| AVI Decompressor	| --->	| Dflt Video Renderer |
													|					|		|					  |
													---------------------		-----------------------*/
	if (SUCCEEDED(hr))
	{
		// connect capture output to the pseudo-sink filter,
		// where it will be discarded until required
		hr = pBuilder->RenderStream(&PIN_CATEGORY_CAPTURE,
									&MEDIATYPE_Video,
									m_pVideoSourceFilter,
									NULL,
									m_pGMFBridgeSink);
	}

	if(!SUCCEEDED(hr))
		return -1;
	
	pBuilder->SetFiltergraph(NULL);
	AddToROT(m_pGraphPreview, &m_dwROTRegPreview, 0);

	return 0;
}

bool CDSInterface::StartCapture()
{
	unsigned int CaptureThreadId = 0;

	if(!m_Clip.m_bPointsSet)
		return false;

	if(!m_hCaptureThread)
		return false;

	m_bIsSeeking = true;
	Sleep(5);
	m_bCaptureActive = true;

	m_pIAMExtTransport->SetEditProperty(0, ED_EDIT_SRC_INPOINT, m_Clip.m_PreRollPoint.TimeCodeBCD);
	//m_pIAMExtTransport->SetEditProperty(0, ED_EDIT_SRC_OUTPOINT, m_Clip.m_OutPoint.TimeCodeBCD);
	m_pIAMExtTransport->SetEditProperty(0, ED_EDIT_SEEK_MODE, ED_EDIT_SEEK_EDIT_IN);

	return true;
}

bool CDSInterface::CreateCaptureGraph(const _bstr_t bstrFile, UINT32 InPoint, UINT32 OutPoint)
{
	HRESULT hr = S_OK;
	bool bSuccess = true;

	//BUILD CAPTURE FILTERGRAPH
	if(!m_pGraphCapture || !m_pIGMFBridgeController)
	{
		m_Clip.ClearPoints();
		return false;
	}

	if(m_dwROTRegCapture)
		RemoveFromROT(m_dwROTRegCapture);
	m_dwROTRegCapture = 0;

	RemoveAllFilters(m_pGraphCapture);

	/*-----------------------
	  |						|
	  |	 GMFBridge Source	|
	  |						|
	  -----------------------*/
	//Make the GMFBridge Sink filter the source filter for filtergraph #2 (for capture-to-file or batch capture)
	IUnknownPtr punkSource;
	hr = m_pIGMFBridgeController->InsertSourceFilter(m_pGMFBridgeSink, m_pGraphCapture, &punkSource);
	m_pGMFBridgeSource = punkSource;

	ICaptureGraphBuilder2Ptr pBuilder;
	hr = pBuilder.CreateInstance(CLSID_CaptureGraphBuilder2);
	if(SUCCEEDED(hr))
		pBuilder->SetFiltergraph(m_pGraphCapture);

	/*-----------------------		---------		-------------
	  |						|		|		|		|			|
	  |	 GMFBridge Source	| --->	|  MUX	| --->	| File.avi	|
	  |						|		|		|		|			|
	  -----------------------		---------		-------------*/
	IBaseFilterPtr pfMux;
	hr = pBuilder->SetOutputFileName(&MEDIASUBTYPE_Avi, bstrFile, &pfMux, NULL);
	if(SUCCEEDED(hr))
		hr = pBuilder->RenderStream(NULL, NULL, m_pGMFBridgeSource, NULL, pfMux);

	if(SUCCEEDED(hr))
		AddToROT(m_pGraphCapture, &m_dwROTRegCapture, 1);

	if(SUCCEEDED(hr))
	{
		hr = S_OK;
		m_Clip.SetPointsBCD(InPoint, OutPoint, m_FPS);
	}
	else
		bSuccess = false;

	return bSuccess;

}

bool CDSInterface::IsActive()
{
	return m_bCaptureActive;
}

bool CDSInterface::IsSeeking()
{
	return m_bIsSeeking;
}

bool CDSInterface::IsRolling()
{
	return m_bIsRolling;
}

bool CDSInterface::IsCapturing()
{
	return m_bIsCapturing;
}

INT32 CDSInterface::StartPreview()
{
	if(m_pMediaControlPreview)
	{
		m_pMediaControlPreview->Run();
		m_bPreviewGraphRunning = true;
		return 0;
	}
	return -1;
}

INT32 CDSInterface::GetTimeCode(BYTE* h, BYTE* m, BYTE* s, BYTE* f)
{
	*h = m_PrivateHours;
	*m = m_PrivateMinutes;
	*s = m_PrivateSeconds;
	*f = m_PrivateFrames;

	return 0;
}

INT32 CDSInterface::GetPrivateTimeCode()
{
	TIMECODE_SAMPLE TC;
	HRESULT hr = S_OK;
	UINT32 hours=0, minutes=0, seconds=0, frames=0;
	BYTE FramesPerSecond = 0;
	hr = m_pIAMTimeCodeReader->GetTimecode(&TC);

	switch(TC.timecode.wFrameRate)
	{
	case ED_FORMAT_SMPTE_30:
	case ED_FORMAT_SMPTE_30DROP:	//TODO: fix this up
		FramesPerSecond = 30;
		m_FPS = 30;
		break;
	case ED_FORMAT_SMPTE_24:
		FramesPerSecond = 24;
		m_FPS = 24;
		break;
	default: //case ED_FORMAT_SMPTE_25
		FramesPerSecond = 25;
		m_FPS = 25;
		break;
	}
	if(hr == S_OK && TC.timecode.dwFrames >= 0)
	{
		frames = TC.timecode.dwFrames;
		seconds = frames / FramesPerSecond;
		frames %= FramesPerSecond;
		minutes = seconds / 60;
		seconds %= 60;
		hours = minutes / 60;
		minutes %= 60;
	}
	else
		return -1;

	m_PrivateHours = (BYTE)hours;
	m_PrivateMinutes = (BYTE)minutes;
	m_PrivateSeconds = (BYTE)seconds;
	m_PrivateFrames = (BYTE)frames;

	return 0;
}

bool CDSInterface::GetDeckStatus(long* pStatus)
{
	if(!m_pIAMExtTransport)
		return false;

	m_pIAMExtTransport->get_Mode(pStatus);
	return true;
}

void CDSInterface::DeckPlay()
{
	if(m_pIAMExtTransport)
		m_pIAMExtTransport->put_Mode(ED_MODE_PLAY);
}

void CDSInterface::DeckStop()
{
	if(m_pIAMExtTransport)
		m_pIAMExtTransport->put_Mode(ED_MODE_STOP);
}

void CDSInterface::DeckForward()
{
	if(m_pIAMExtTransport)
		m_pIAMExtTransport->put_Mode(ED_MODE_FF);
}

void CDSInterface::DeckRewind()
{
	if(m_pIAMExtTransport)
		m_pIAMExtTransport->put_Mode(ED_MODE_REW);
}

int CDSInterface::StopCaptureThread()
{
	m_bThreadStopped = true;
	if(m_hCaptureThread)
	{
		DWORD dw = WaitForSingleObject(m_hCaptureThread, -1);
		CloseHandle(m_hCaptureThread);
	}
	m_hCaptureThread = NULL;

	return 0;
}

unsigned int __stdcall CDSInterface::CaptureThread(void * pArg)
{
	long lEventCode;
	LONG_PTR lParam1, lParam2;
	CDSInterface* pThis = (CDSInterface*)pArg;

	while(!pThis->m_bThreadStopped)
	{
		//Get current time code from the deck
		pThis->GetPrivateTimeCode();

		if(pThis->m_bCaptureActive)
		{
			if(pThis->m_bIsSeeking)
			{
				if(pThis->m_PrivateHours == pThis->m_Clip.m_PreRollPoint.HoursDEC)
				{
					if(pThis->m_PrivateMinutes == pThis->m_Clip.m_PreRollPoint.MinutesDEC)
					{
						if(pThis->m_PrivateSeconds == pThis->m_Clip.m_PreRollPoint.SecondsDEC)
						{
							if(pThis->m_PrivateFrames <= pThis->m_Clip.m_PreRollPoint.FramesDEC)
							{
								if(pThis->m_PrivateFrames >= pThis->m_Clip.m_PreRollPoint.FramesDEC)
								{
									//PreRoll is done, let's capture
									pThis->m_bIsSeeking = false;
									pThis->m_bIsRolling = true;

									pThis->m_pIAMExtTransport->put_Mode(ED_MODE_STOP);
									Sleep(50);	//let's wait to make sure the deck has stopped

									//Start Deck Playback
									pThis->m_pIAMExtTransport->put_Mode(ED_MODE_PLAY);
									Sleep(50);	//let's wait to make sure the deck has properly started

									//Activate In- and OutPoint
									pThis->m_pIGMFBridgeController->BridgeGraphs(pThis->m_pGMFBridgeSink, pThis->m_pGMFBridgeSource);
									pThis->m_pMediaControlCapture->Run();
									pThis->m_bCaptureGraphRunning = true;
									pThis->m_pIBFStreamControl->SetInOutPoints(pThis->m_Clip.m_InPoint.TimeCodeBCD, pThis->m_Clip.m_OutPoint.TimeCodeBCD, TRUE, FALSE);
								}
							}
						}
					}
				}
			}
			else if(pThis->m_bIsRolling)
			{
				if(pThis->m_PrivateHours == pThis->m_Clip.m_InPoint.HoursDEC)
				{
					if(pThis->m_PrivateMinutes == pThis->m_Clip.m_InPoint.MinutesDEC)
					{
						if(pThis->m_PrivateSeconds == pThis->m_Clip.m_InPoint.SecondsDEC)
						{
							if(pThis->m_PrivateFrames <= pThis->m_Clip.m_InPoint.FramesDEC)
							{
								if(pThis->m_PrivateFrames >= pThis->m_Clip.m_InPoint.FramesDEC)
								{
									pThis->m_bIsRolling = false;
									pThis->m_bIsCapturing = true;
								}
							}
						}
					}
				}
			}
			else if(pThis->m_bIsCapturing)
			{
				//are we done yet?
				if(pThis->m_pIMediaEventPreview)
				{
					while(pThis->m_pIMediaEventPreview->GetEvent(&lEventCode, &lParam1, &lParam2, 0) >= 0)
					{
						pThis->m_pIMediaEventPreview->FreeEventParams(lEventCode, lParam1, lParam2);
						if(EC_STREAM_CONTROL_STOPPED == lEventCode)
						{
							//open bridge, no more samples delivered
							pThis->m_pIGMFBridgeController->BridgeGraphs(NULL, NULL);
							//stop the catpure graph altogether
							pThis->m_pMediaControlCapture->Stop();
							pThis->m_bCaptureGraphRunning = false;

							pThis->m_pIAMExtTransport->put_Mode(ED_MODE_STOP);
							pThis->m_Clip.ClearPoints();
							pThis->m_bCaptureActive = false;
							pThis->m_bIsCapturing = false;
						}
					}
				}
			}
		}
	}

	_endthreadex(0);
	return 0;
}
