///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Apr 16 2008)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "Frame.h"

///////////////////////////////////////////////////////////////////////////

DCFrame::DCFrame( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxFrame( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	this->SetBackgroundColour( wxColour( 65, 64, 56 ) );
	
	m_menubar1 = new wxMenuBar( 0 );
	this->SetMenuBar( m_menubar1 );
	
	m_statusBar1 = this->CreateStatusBar( 3, 0, wxID_ANY );
	wxBoxSizer* bSizer6;
	bSizer6 = new wxBoxSizer( wxVERTICAL );
	
	wxBoxSizer* bSizer71;
	bSizer71 = new wxBoxSizer( wxHORIZONTAL );
	
	wxBoxSizer* bSizer7;
	bSizer7 = new wxBoxSizer( wxHORIZONTAL );
	
	m_staticText1 = new wxStaticText( this, wxID_ANY, wxT("StartAt:"), wxDefaultPosition, wxSize( 50,-1 ), 0 );
	m_staticText1->Wrap( -1 );
	m_staticText1->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), 70, 90, 92, false, wxEmptyString ) );
	m_staticText1->SetForegroundColour( wxColour( 255, 128, 0 ) );
	
	bSizer7->Add( m_staticText1, 0, wxALIGN_CENTER|wxALL, 5 );
	
	m_txtStartAtHours = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer7->Add( m_txtStartAtHours, 0, wxALIGN_CENTER, 5 );
	
	m_txtStartAtMinutes = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer7->Add( m_txtStartAtMinutes, 0, wxALIGN_CENTER, 5 );
	
	m_txtStartAtSeconds = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer7->Add( m_txtStartAtSeconds, 0, wxALIGN_CENTER, 5 );
	
	m_txtStartAtFrames = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer7->Add( m_txtStartAtFrames, 0, wxALIGN_CENTER, 5 );
	
	bSizer71->Add( bSizer7, 1, wxALIGN_CENTER, 5 );
	
	wxBoxSizer* bSizer4;
	bSizer4 = new wxBoxSizer( wxHORIZONTAL );
	
	m_staticText11 = new wxStaticText( this, wxID_ANY, wxT("StopAt:"), wxDefaultPosition, wxSize( 50,-1 ), 0 );
	m_staticText11->Wrap( -1 );
	m_staticText11->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), 70, 90, 92, false, wxEmptyString ) );
	m_staticText11->SetForegroundColour( wxColour( 255, 128, 0 ) );
	
	bSizer4->Add( m_staticText11, 0, wxALIGN_CENTER|wxALL, 5 );
	
	m_txtStopAtHours = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer4->Add( m_txtStopAtHours, 0, wxALIGN_CENTER, 5 );
	
	m_txtStopAtMinutes = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer4->Add( m_txtStopAtMinutes, 0, wxALIGN_CENTER, 5 );
	
	m_txtStopAtSeconds = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer4->Add( m_txtStopAtSeconds, 0, wxALIGN_CENTER, 5 );
	
	m_txtStopAtFrames = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer4->Add( m_txtStopAtFrames, 0, wxALIGN_CENTER, 5 );
	
	bSizer71->Add( bSizer4, 1, wxALIGN_CENTER, 5 );
	
	bSizer6->Add( bSizer71, 1, wxALIGN_CENTER, 5 );
	
	wxBoxSizer* bSizer711;
	bSizer711 = new wxBoxSizer( wxHORIZONTAL );
	
	wxBoxSizer* bSizer72;
	bSizer72 = new wxBoxSizer( wxHORIZONTAL );
	
	m_staticText12 = new wxStaticText( this, wxID_ANY, wxT("StartAt:"), wxDefaultPosition, wxSize( 50,-1 ), 0 );
	m_staticText12->Wrap( -1 );
	m_staticText12->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), 70, 90, 92, false, wxEmptyString ) );
	m_staticText12->SetForegroundColour( wxColour( 255, 128, 0 ) );
	
	bSizer72->Add( m_staticText12, 0, wxALIGN_CENTER|wxALL, 5 );
	
	m_txtStartAtHours1 = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer72->Add( m_txtStartAtHours1, 0, wxALIGN_CENTER, 5 );
	
	m_txtStartAtMinutes1 = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer72->Add( m_txtStartAtMinutes1, 0, wxALIGN_CENTER, 5 );
	
	m_txtStartAtSeconds1 = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer72->Add( m_txtStartAtSeconds1, 0, wxALIGN_CENTER, 5 );
	
	m_txtStartAtFrames1 = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer72->Add( m_txtStartAtFrames1, 0, wxALIGN_CENTER, 5 );
	
	bSizer711->Add( bSizer72, 1, wxALIGN_CENTER, 5 );
	
	wxBoxSizer* bSizer41;
	bSizer41 = new wxBoxSizer( wxHORIZONTAL );
	
	m_staticText111 = new wxStaticText( this, wxID_ANY, wxT("StopAt:"), wxDefaultPosition, wxSize( 50,-1 ), 0 );
	m_staticText111->Wrap( -1 );
	m_staticText111->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), 70, 90, 92, false, wxEmptyString ) );
	m_staticText111->SetForegroundColour( wxColour( 255, 128, 0 ) );
	
	bSizer41->Add( m_staticText111, 0, wxALIGN_CENTER|wxALL, 5 );
	
	m_txtStopAtHours1 = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer41->Add( m_txtStopAtHours1, 0, wxALIGN_CENTER, 5 );
	
	m_txtStopAtMinutes1 = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer41->Add( m_txtStopAtMinutes1, 0, wxALIGN_CENTER, 5 );
	
	m_txtStopAtSeconds1 = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer41->Add( m_txtStopAtSeconds1, 0, wxALIGN_CENTER, 5 );
	
	m_txtStopAtFrames1 = new wxTextCtrl( this, wxID_ANY, wxT("--"), wxDefaultPosition, wxSize( 30,-1 ), wxTE_CENTRE );
	bSizer41->Add( m_txtStopAtFrames1, 0, wxALIGN_CENTER, 5 );
	
	bSizer711->Add( bSizer41, 1, wxALIGN_CENTER, 5 );
	
	bSizer6->Add( bSizer711, 1, wxALIGN_CENTER, 5 );
	
	wxBoxSizer* bSizer61;
	bSizer61 = new wxBoxSizer( wxHORIZONTAL );
	
	m_btnCapture = new wxButton( this, wxID_ANY, wxT("Batch Capture"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer61->Add( m_btnCapture, 0, wxALIGN_CENTER|wxALL, 5 );
	
	m_txtFilename = new wxTextCtrl( this, wxID_ANY, wxT("BFTestFile"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer61->Add( m_txtFilename, 0, wxALIGN_CENTER|wxALL, 5 );
	
	m_txtCurrentFileName = new wxTextCtrl( this, wxID_ANY, wxT("C:\\BFTestFile0.avi"), wxDefaultPosition, wxDefaultSize, 0 );
	m_txtCurrentFileName->Enable( false );
	
	bSizer61->Add( m_txtCurrentFileName, 0, wxALIGN_CENTER|wxALL, 5 );
	
	bSizer6->Add( bSizer61, 1, wxALIGN_CENTER, 5 );
	
	m_staticText5 = new wxStaticText( this, wxID_ANY, wxT("DECK CONTROL:"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText5->Wrap( -1 );
	m_staticText5->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), 70, 90, 92, false, wxEmptyString ) );
	m_staticText5->SetForegroundColour( wxColour( 255, 128, 0 ) );
	
	bSizer6->Add( m_staticText5, 0, wxALIGN_CENTER|wxALL, 5 );
	
	m_txtTimeCode = new wxTextCtrl( this, wxID_ANY, wxT("-- : -- : -- : --"), wxDefaultPosition, wxDefaultSize, wxTE_CENTRE );
	m_txtTimeCode->Enable( false );
	
	bSizer6->Add( m_txtTimeCode, 0, wxALIGN_CENTER|wxALL, 5 );
	
	wxBoxSizer* bSizer8;
	bSizer8 = new wxBoxSizer( wxHORIZONTAL );
	
	m_bpBtnRewind = new wxBitmapButton( this, wxID_ANY, wxBitmap( wxT("res/Rewind.bmp"), wxBITMAP_TYPE_ANY ), wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW );
	bSizer8->Add( m_bpBtnRewind, 0, wxALL, 5 );
	
	m_bpBtnPlay = new wxBitmapButton( this, wxID_ANY, wxBitmap( wxT("res/Play.bmp"), wxBITMAP_TYPE_ANY ), wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW );
	bSizer8->Add( m_bpBtnPlay, 0, wxALL, 5 );
	
	m_bpBtnStop = new wxBitmapButton( this, wxID_ANY, wxBitmap( wxT("res/Stop.bmp"), wxBITMAP_TYPE_ANY ), wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW );
	bSizer8->Add( m_bpBtnStop, 0, wxALL, 5 );
	
	m_bpBtnForward = new wxBitmapButton( this, wxID_ANY, wxBitmap( wxT("res/Forward.bmp"), wxBITMAP_TYPE_ANY ), wxDefaultPosition, wxDefaultSize, wxBU_AUTODRAW );
	bSizer8->Add( m_bpBtnForward, 0, wxALL, 5 );
	
	bSizer6->Add( bSizer8, 1, wxALIGN_CENTER, 5 );
	
	this->SetSizer( bSizer6 );
	this->Layout();
	bSizer6->Fit( this );
	
	// Connect Events
	m_btnCapture->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( DCFrame::OnCapture ), NULL, this );
	m_txtFilename->Connect( wxEVT_COMMAND_TEXT_UPDATED, wxCommandEventHandler( DCFrame::OnChangeFilename ), NULL, this );
	m_bpBtnRewind->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( DCFrame::OnRewind ), NULL, this );
	m_bpBtnPlay->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( DCFrame::OnPlay ), NULL, this );
	m_bpBtnStop->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( DCFrame::OnStop ), NULL, this );
	m_bpBtnForward->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( DCFrame::OnForward ), NULL, this );
}

DCFrame::~DCFrame()
{
	// Disconnect Events
	m_btnCapture->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( DCFrame::OnCapture ), NULL, this );
	m_txtFilename->Disconnect( wxEVT_COMMAND_TEXT_UPDATED, wxCommandEventHandler( DCFrame::OnChangeFilename ), NULL, this );
	m_bpBtnRewind->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( DCFrame::OnRewind ), NULL, this );
	m_bpBtnPlay->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( DCFrame::OnPlay ), NULL, this );
	m_bpBtnStop->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( DCFrame::OnStop ), NULL, this );
	m_bpBtnForward->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( DCFrame::OnForward ), NULL, this );
}
