#include "CDCFrame.h"

CDCFrame::CDCFrame( wxWindow* parent )
:
DCFrame( parent )
{

}

void CDCFrame::OnCapture( wxCommandEvent& event )
{
	// TODO: Implement OnCapture
}

void CDCFrame::OnChangeFilename( wxCommandEvent& event )
{
	// TODO: Implement OnChangeFilename
}

void CDCFrame::OnRewind( wxCommandEvent& event )
{
	// TODO: Implement OnRewind
}

void CDCFrame::OnPlay( wxCommandEvent& event )
{
	// TODO: Implement OnPlay
}

void CDCFrame::OnStop( wxCommandEvent& event )
{
	// TODO: Implement OnStop
}

void CDCFrame::OnForward( wxCommandEvent& event )
{
	// TODO: Implement OnForward
}
