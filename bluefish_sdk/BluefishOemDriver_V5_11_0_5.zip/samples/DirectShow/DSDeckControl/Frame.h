///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Apr 16 2008)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#ifndef __Frame__
#define __Frame__

#include <wx/string.h>
#include <wx/menu.h>
#include <wx/gdicmn.h>
#include <wx/font.h>
#include <wx/colour.h>
#include <wx/settings.h>
#include <wx/statusbr.h>
#include <wx/stattext.h>
#include <wx/textctrl.h>
#include <wx/sizer.h>
#include <wx/button.h>
#include <wx/bitmap.h>
#include <wx/image.h>
#include <wx/icon.h>
#include <wx/bmpbuttn.h>
#include <wx/frame.h>

///////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
/// Class DCFrame
///////////////////////////////////////////////////////////////////////////////
class DCFrame : public wxFrame 
{
	private:
	
	protected:
		wxMenuBar* m_menubar1;
		wxStatusBar* m_statusBar1;
		wxStaticText* m_staticText1;
		wxTextCtrl* m_txtStartAtHours;
		wxTextCtrl* m_txtStartAtMinutes;
		wxTextCtrl* m_txtStartAtSeconds;
		wxTextCtrl* m_txtStartAtFrames;
		wxStaticText* m_staticText11;
		wxTextCtrl* m_txtStopAtHours;
		wxTextCtrl* m_txtStopAtMinutes;
		wxTextCtrl* m_txtStopAtSeconds;
		wxTextCtrl* m_txtStopAtFrames;
		wxStaticText* m_staticText12;
		wxTextCtrl* m_txtStartAtHours1;
		wxTextCtrl* m_txtStartAtMinutes1;
		wxTextCtrl* m_txtStartAtSeconds1;
		wxTextCtrl* m_txtStartAtFrames1;
		wxStaticText* m_staticText111;
		wxTextCtrl* m_txtStopAtHours1;
		wxTextCtrl* m_txtStopAtMinutes1;
		wxTextCtrl* m_txtStopAtSeconds1;
		wxTextCtrl* m_txtStopAtFrames1;
		wxButton* m_btnCapture;
		wxTextCtrl* m_txtFilename;
		wxTextCtrl* m_txtCurrentFileName;
		wxStaticText* m_staticText5;
		wxTextCtrl* m_txtTimeCode;
		wxBitmapButton* m_bpBtnRewind;
		wxBitmapButton* m_bpBtnPlay;
		wxBitmapButton* m_bpBtnStop;
		wxBitmapButton* m_bpBtnForward;
		
		// Virtual event handlers, overide them in your derived class
		virtual void OnCapture( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnChangeFilename( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnRewind( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnPlay( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnStop( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnForward( wxCommandEvent& event ){ event.Skip(); }
		
	
	public:
		DCFrame( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("DS Deck Control"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( -1,-1 ), long style = wxCAPTION|wxCLOSE_BOX|wxSYSTEM_MENU|wxTAB_TRAVERSAL );
		~DCFrame();
	
};

#endif //__Frame__
