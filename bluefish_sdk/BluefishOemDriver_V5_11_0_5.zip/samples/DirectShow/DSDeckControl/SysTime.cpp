#include <windows.h>
#include "SysTime.h"

__int64 SysTime::m_QPFCallTime = 0;
__int64 SysTime::m_liFrequency = 0;

__int64 SysTime::getSystemTime()
{
	__int64 t0;
    if ( !m_liFrequency)
        initSystemTime();
    QueryPerformanceCounter((LARGE_INTEGER *)&t0);
    double d = (double)(t0 * 1000.0 / m_liFrequency);
    return (__int64)(d);
}

void SysTime::initSystemTime()
{
	__int64 t0,
		    t1;
	QueryPerformanceCounter((LARGE_INTEGER *)&t0);
	for (int i = 0; i < 10000; i++)
	{
		QueryPerformanceCounter((LARGE_INTEGER *)&t1);
	}
	m_QPFCallTime = ((t1 - t0) / 10000L);
	QueryPerformanceFrequency((LARGE_INTEGER *)&m_liFrequency);
}

