#include <windows.h>
#include "SysTime.h"
#include <initguid.h>
#include "dshow.h"
#include "DSUtils.h"

// get Pin of specifed direction 
extern DWORD g_dwROTReg;

bool isZeroRect( const RECT &rect )
{
    return (  rect.top == 0 && rect.left == 0 && rect.right == 0 && rect.bottom == 0 );
}
 
IPin *GetPin(IBaseFilter *pBF, PIN_DIRECTION pinDir )
{
	IEnumPins *pEnumPins = 0;
	IPin *pTmpPin = 0;
    IPin *pRes = NULL;
	PIN_INFO pin_info;
	pBF->EnumPins(&pEnumPins);
	ULONG res;
	while ( (!pRes) && pEnumPins->Next(1,&pTmpPin,&res)==S_OK )
	{
		pTmpPin->QueryPinInfo(&pin_info);
		
        if (pin_info.dir == pinDir) 
		{
			pRes = pTmpPin;
		}
		else 
			pTmpPin->Release();	
        
        if ( pin_info.pFilter )
            pin_info.pFilter->Release();
		
	}
	pEnumPins->Release();
	return pRes;
}

// we don't need  itellegent connect 
HRESULT ConnectFiltersDirect(IFilterGraph *pGraph, IBaseFilter * pOut,IBaseFilter *pIn )
{
	HRESULT hr = S_OK;

    IPin *pOutPin,*pInPin;
	pOutPin = GetPin(pOut,PINDIR_OUTPUT);
	
    if ( pOutPin == NULL )
        return S_FALSE;

	pInPin = GetPin(pIn,PINDIR_INPUT );
    
    if ( pOutPin == NULL )
    {
        pOutPin->Release();
        return S_FALSE;
    }
	
	hr = pGraph->ConnectDirect(pOutPin,pInPin,NULL);
	pInPin->Release();
	pOutPin->Release();
	return hr;
}


// remove all filters from FilterGraph
HRESULT RemoveAllFilters( IFilterGraph *pGraph)
{
    ULONG dbg;
	HRESULT hr = S_OK;
	IEnumFilters *pEF;
	pGraph->EnumFilters(&pEF);
	IBaseFilter *pBF[20];
	ULONG n;
	hr = pEF->Next(20,pBF,&n);
	pEF->Release();
//	FILTER_INFO fi;
	for (unsigned int i=0;i<n;i++)
	{	
		//pBF[i]->QueryFilterInfo(&fi);
		//MessageBox(NULL,fi.achName ,L"Filter Info",MB_OK);
		hr = pGraph->RemoveFilter(pBF[i]);
		dbg = pBF[i]->Release();

	}
	return hr;
}

__int64 calcVideoRefTime( __int64 step , __int64 scale, double frameRate, __int64 tickNo)
{
        double  frame_num = (double) tickNo;
        double  frame_rate = 0;
        __int64 ref_tm = 0; 

        if ( frameRate )
        {
            frame_rate = 1000.0 / frameRate;
            ref_tm = ( frame_rate * frame_num ) * 10000.0;            
        }
        else if ( step == 0 )
        {
            ref_tm = 0;
        }
        else 
        {
            ref_tm = (scale * 10000000 * tickNo ) / step;
        }

        return ref_tm;
};

HRESULT AddToROT(IUnknown *pUnkGraph, DWORD* pROTdwREG, int number) 
{
    HRESULT hr = S_OK;
    IMoniker * pmk = NULL;
    IRunningObjectTable *pROT = NULL;
    WCHAR wsz[256];
    
    if (FAILED(GetRunningObjectTable(0, &pROT))) 
    {
        return E_FAIL;
    }

	wsprintfW(wsz, L"FilterGraph %08x  pid %08x\0", (DWORD_PTR) number, GetCurrentProcessId());
    //wsprintfW(wsz, L"FilterGraph%d %08x  pid %08x\0", number, (DWORD_PTR) 0, GetCurrentProcessId());

    hr = CreateItemMoniker(L"!", wsz, &pmk);
    if (SUCCEEDED(hr)) 
    {
        // Use the ROTFLAGS_REGISTRATIONKEEPSALIVE to ensure a strong reference
        // to the object.  Using this flag will cause the object to remain
        // registered until it is explicitly revoked with the Revoke() method.
        //
        // Not using this flag means that if GraphEdit remotely connects
        // to this graph and then GraphEdit exits, this object registration 
        // will be deleted, causing future attempts by GraphEdit to fail until
        // this application is restarted or until the graph is registered again.
        hr = pROT->Register(ROTFLAGS_REGISTRATIONKEEPSALIVE, pUnkGraph, 
                            pmk, pROTdwREG);
        pmk->Release();
    }

    pROT->Release();
    return hr;
}

void RemoveFromROT(DWORD ROTdwREG)
{
    IRunningObjectTable *pirot=0;

    if (SUCCEEDED(GetRunningObjectTable(0, &pirot))) 
    {
        pirot->Revoke(ROTdwREG);
        pirot->Release();
    }
}


//////////////////////////////////////////////////////
////BFClip////BFClip////BFClip////BFClip////BFClip////
//////////////////////////////////////////////////////
BFClip::BFClip()
{
	ClearPoints();
}

void BFClip::ClearPoints()
{
	memset(&m_PreRollPoint, 0, sizeof(BFTimeCodePoint));
	memset(&m_InPoint, 0, sizeof(BFTimeCodePoint));
	memset(&m_OutPoint, 0, sizeof(BFTimeCodePoint));
	m_bPointsSet = false;
}

void BFClip::SetPointsBCD(UINT32 InBCD, UINT32 OutBCD, UINT32 fps)
{
	m_InPoint.TimeCodeBCD = InBCD;
	m_InPoint.HoursBCD = (BYTE)((InBCD >> 24) & 0xFF);
	m_InPoint.MinutesBCD = (BYTE)((InBCD >> 16) & 0xFF);
	m_InPoint.SecondsBCD = (BYTE)((InBCD >> 8) & 0xFF);
	m_InPoint.FramesBCD = (BYTE)(InBCD & 0xFF);
	m_InPoint.HoursDEC = ConvertToDEC(m_InPoint.HoursBCD);
	m_InPoint.MinutesDEC = ConvertToDEC(m_InPoint.MinutesBCD);
	m_InPoint.SecondsDEC = ConvertToDEC(m_InPoint.SecondsBCD);
	m_InPoint.FramesDEC = ConvertToDEC(m_InPoint.FramesBCD);
	m_InPoint.TimeCodeDEC = (m_InPoint.HoursDEC << 24) | (m_InPoint.MinutesDEC << 16) | (m_InPoint.SecondsDEC << 8) | m_InPoint.FramesDEC;
	m_InPoint.TotalFrames = m_InPoint.FramesDEC;
	m_InPoint.TotalFrames += m_InPoint.SecondsDEC*fps;
	m_InPoint.TotalFrames += m_InPoint.MinutesDEC*fps*60;
	m_InPoint.TotalFrames += m_InPoint.HoursDEC*fps*60*60;

	m_OutPoint.TimeCodeBCD = OutBCD;
	m_OutPoint.HoursBCD = (BYTE)((OutBCD >> 24) & 0xFF);
	m_OutPoint.MinutesBCD = (BYTE)((OutBCD >> 16) & 0xFF);
	m_OutPoint.SecondsBCD = (BYTE)((OutBCD >> 8) & 0xFF);
	m_OutPoint.FramesBCD = (BYTE)(OutBCD & 0xFF);
	m_OutPoint.HoursDEC = ConvertToDEC(m_OutPoint.HoursBCD);
	m_OutPoint.MinutesDEC = ConvertToDEC(m_OutPoint.MinutesBCD);
	m_OutPoint.SecondsDEC = ConvertToDEC(m_OutPoint.SecondsBCD);
	m_OutPoint.FramesDEC = ConvertToDEC(m_OutPoint.FramesBCD);
	m_OutPoint.TimeCodeDEC = (m_OutPoint.HoursDEC << 24) | (m_OutPoint.MinutesDEC << 16) | (m_OutPoint.SecondsDEC << 8) | m_OutPoint.FramesDEC;
	m_OutPoint.TotalFrames = m_OutPoint.FramesDEC;
	m_OutPoint.TotalFrames += m_OutPoint.SecondsDEC*fps;
	m_OutPoint.TotalFrames += m_OutPoint.MinutesDEC*fps*60;
	m_OutPoint.TotalFrames += m_OutPoint.HoursDEC*fps*60*60;

	m_PreRollPoint.HoursDEC = m_InPoint.HoursDEC;
	m_PreRollPoint.MinutesDEC = m_InPoint.MinutesDEC;
	m_PreRollPoint.SecondsDEC = m_InPoint.SecondsDEC;
	m_PreRollPoint.FramesDEC = m_InPoint.FramesDEC;

	//subtract 5 seconds if possible for prerolling
	if(m_PreRollPoint.SecondsDEC >=5)
		m_PreRollPoint.SecondsDEC -= 5;
	else
	{
		int diff = 5 - m_PreRollPoint.SecondsDEC;
		m_PreRollPoint.SecondsDEC = 60 - diff;
		if(m_PreRollPoint.MinutesDEC >= 1)
			m_PreRollPoint.MinutesDEC--;
		else
		{
			if(m_PreRollPoint.HoursDEC >= 1)
				m_PreRollPoint.HoursDEC--;
			else
			{
				m_PreRollPoint.HoursDEC = 0;
				m_PreRollPoint.MinutesDEC = 0;
				m_PreRollPoint.SecondsDEC = 0;
				m_PreRollPoint.FramesDEC = 0;
			}
		}
	}
	m_PreRollPoint.TimeCodeDEC = (m_PreRollPoint.HoursDEC << 24) | (m_PreRollPoint.MinutesDEC << 16) | (m_PreRollPoint.SecondsDEC << 8) | m_PreRollPoint.FramesDEC;

	m_PreRollPoint.HoursBCD = ConvertToBCD(m_PreRollPoint.HoursDEC);
	m_PreRollPoint.MinutesBCD = ConvertToBCD(m_PreRollPoint.MinutesDEC);
	m_PreRollPoint.SecondsBCD = ConvertToBCD(m_PreRollPoint.SecondsDEC);
	m_PreRollPoint.FramesBCD = ConvertToBCD(m_PreRollPoint.FramesDEC);
	m_PreRollPoint.TimeCodeBCD = (m_PreRollPoint.HoursBCD << 24) | (m_PreRollPoint.MinutesBCD << 16) | (m_PreRollPoint.SecondsBCD << 8) | m_PreRollPoint.FramesBCD;

	m_bPointsSet = true;
}

void BFClip::SetPointsDEC(UINT32 InDEC, UINT32 OutDEC, UINT32 fps)
{
}

BYTE BFClip::ConvertToDEC(BYTE In)
{
	BYTE tens = ((In >> 4) & 0xF) * 10;
	BYTE onse = In & 0xF;
	tens += onse;
	return tens;
}

BYTE BFClip::ConvertToBCD(BYTE In)
{
	BYTE high = In/10;
	BYTE low = In%10;
	return (high << 4) | (low);
}
