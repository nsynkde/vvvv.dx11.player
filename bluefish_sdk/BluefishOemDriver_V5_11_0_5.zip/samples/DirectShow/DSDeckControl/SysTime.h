#ifndef _SYSTIME_H_
#define _SYSTIME_H_

class SysTime
{
public:
    static  __int64 getSystemTime();

protected:   
    static void initSystemTime();

public:
    static __int64 m_QPFCallTime;
    static __int64 m_liFrequency;
};

#endif //_SYSTIME_H_