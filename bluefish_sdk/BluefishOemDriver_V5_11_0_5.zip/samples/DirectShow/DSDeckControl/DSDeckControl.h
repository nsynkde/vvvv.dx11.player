#ifndef __DSDeckControl__
#define __DSDeckControl__

#include <wx/wx.h>
#include "CDCFrame.h"
#include "DSInterface.h"


class wxWidgetsApp : public wxApp
{
public:
    wxWidgetsApp();
    virtual ~wxWidgetsApp();
    virtual bool OnInit();
};

DECLARE_APP(wxWidgetsApp)


class StateMachineThread : public wxThread
{
public:
    StateMachineThread(void* hDeckControl);

    // thread execution starts here
    virtual void *Entry();

    // called when the thread exits - whether it terminates normally or is
    // stopped with Delete() (but not when it is Kill()ed!)
    virtual void OnExit();

public:
	void* m_hDeckControl;
};

StateMachineThread::StateMachineThread(void* hDeckControl)
: wxThread()
{
    m_hDeckControl = hDeckControl;
}

void StateMachineThread::OnExit()
{}


class CDeckControl : public CDCFrame
{
public:
	CDSInterface*		m_pDSInterface;
	StateMachineThread	*m_pSMThread;
	bool				m_bRunThread;
	bool				m_bThreadStarted;

	int					m_NumberOfClipsToCapture;
	int					m_Inpoint_01;
	int					m_Inpoint_02;
	int					m_Outpoint_01;
	int					m_Outpoint_02;
	int					m_FileIndex;

public:
	CDeckControl(wxWindow* parent);
	~CDeckControl();

	void OnCapture( wxCommandEvent& event );
	void OnRewind( wxCommandEvent& event );
	void OnPlay( wxCommandEvent& event );
	void OnStop( wxCommandEvent& event );
	void OnForward( wxCommandEvent& event );
	void OnChangeFilename( wxCommandEvent& event );

// local functions
	void SetDeckStatus();
	void SetTimeCodeInfo(int h, int m, int s, int f, bool valid);
	bool SetCaptureGraph(UINT32 InPoint, UINT32 OutPoint);
	void CancelCapture();
	void InitClips();
	void SetCaptureStatus(int State);
};

#endif //__DSDeckControl__
