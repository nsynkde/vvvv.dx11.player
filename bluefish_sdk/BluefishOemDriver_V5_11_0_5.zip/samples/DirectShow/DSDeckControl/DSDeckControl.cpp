#include "DSDeckControl.h"
#include "DSUtils.h"
#include <assert.h>
#include "wx\string.h"


IMPLEMENT_APP(wxWidgetsApp)

wxWidgetsApp::wxWidgetsApp()
{
}

wxWidgetsApp::~wxWidgetsApp()
{
}

bool wxWidgetsApp::OnInit()
{
    CDeckControl* dialog = new CDeckControl( (wxWindow*)NULL );
    dialog->Show();
    SetTopWindow( dialog );
    return true;
}

CDeckControl::CDeckControl(wxWindow* parent)
: CDCFrame(parent)
{
	bool bSuccess = true;
	m_pSMThread = NULL;
	m_bRunThread = false;
	m_bThreadStarted = false;
	m_FileIndex = 0;
	m_NumberOfClipsToCapture = 0;
	m_Inpoint_01 = 0;
	m_Outpoint_01 = 0;
	m_Inpoint_02 = 0;
	m_Outpoint_02 = 0;
	m_FileIndex = 0;

	//wxMessageBox(wxT("Hello."));

	m_pDSInterface = NULL;
	m_pDSInterface = new CDSInterface();
	
	if(!bSuccess || (m_pDSInterface->InitFilters() != 0))
	{
		m_statusBar1->SetStatusText(wxT("Not Initialised."),0);
		wxMessageBox(wxT("Error InitFilters"));
		bSuccess = false;
	}
	else
		m_statusBar1->SetStatusText(wxT("Initialised."),0);

	if(!bSuccess || (m_pDSInterface->ConnectToDeck() != 0))
	{
		m_txtTimeCode->SetLabel(wxT("-- : -- : -- : --"));
		m_statusBar1->SetStatusText(wxT("VTR not connected."),1);
		wxMessageBox(wxT("Error ConnectToDeck (switched off?)"));
		bSuccess = false;
	}
	else
	{
		m_txtStartAtHours->SetLabel(wxT("01"));
		m_txtStartAtMinutes->SetLabel(wxT("01"));
		m_txtStartAtSeconds->SetLabel(wxT("10"));
		m_txtStartAtFrames->SetLabel(wxT("00"));
		m_txtStopAtHours->SetLabel(wxT("01"));
		m_txtStopAtMinutes->SetLabel(wxT("01"));
		m_txtStopAtSeconds->SetLabel(wxT("20"));
		m_txtStopAtFrames->SetLabel(wxT("00"));

		m_txtStartAtHours1->SetLabel(wxT("01"));
		m_txtStartAtMinutes1->SetLabel(wxT("01"));
		m_txtStartAtSeconds1->SetLabel(wxT("30"));
		m_txtStartAtFrames1->SetLabel(wxT("00"));
		m_txtStopAtHours1->SetLabel(wxT("01"));
		m_txtStopAtMinutes1->SetLabel(wxT("01"));
		m_txtStopAtSeconds1->SetLabel(wxT("40"));
		m_txtStopAtFrames1->SetLabel(wxT("00"));

		BYTE hours=0, minutes=0, seconds=0, frames=0;
		wxString strTimecode = wxT("-- : -- : -- : --");
		if(m_pDSInterface->GetTimeCode(&hours, &minutes, &seconds, &frames) == 0)
			strTimecode.Printf(wxT("%02d : %02d : %02d : %02d"), hours, minutes, seconds, frames);

		m_txtTimeCode->SetLabel(strTimecode);
		m_statusBar1->SetStatusText(wxT("VTR connected."),2);
	}

	if(!bSuccess || (m_pDSInterface->CreatePreviewGraph() != 0))
	{
		m_statusBar1->SetStatusText(wxT("Preview not available."),0);
		wxMessageBox(wxT("Error CreatePreviewGraph"));
		bSuccess = false;
	}

	if(bSuccess)
	{
		m_bRunThread = true;
		m_pSMThread = new StateMachineThread(this);
		m_pSMThread->Create();
		m_pSMThread->Run();
		m_bThreadStarted = true;
	}
	
	if(bSuccess)
	{
		m_pDSInterface->StartPreview();
		m_statusBar1->SetStatusText(wxT("Graph running."),0);
	}
}

CDeckControl::~CDeckControl()
{
	if(m_pDSInterface)
		delete m_pDSInterface;

	if(m_bRunThread)
	{
		m_bRunThread = false;
		Sleep(1000);
	}
}

void CDeckControl::SetDeckStatus()
{
	long Mode;

	if(!m_pDSInterface || !m_pDSInterface->GetDeckStatus(&Mode))
	{
		m_statusBar1->SetStatusText(wxT("Deck not initialised."),1);
		return;
	}

	if(Mode == ED_MODE_PLAY)
		m_statusBar1->SetStatusText(wxT("Deck playing."),1);
	else if(Mode == ED_MODE_STOP)
		m_statusBar1->SetStatusText(wxT("Deck stopped."),1);
	else if(Mode == ED_MODE_FREEZE)
		m_statusBar1->SetStatusText(wxT("Deck paused."),1);
	else if(Mode == ED_MODE_FF)
		m_statusBar1->SetStatusText(wxT("Deck FF mode."),1);
	else if(Mode == ED_MODE_REW)
		m_statusBar1->SetStatusText(wxT("Deck REW mode."),1);
	else
		m_statusBar1->SetStatusText(wxT("Deck state unknown."),1);
}

void CDeckControl::OnChangeFilename( wxCommandEvent& event )
{
	m_FileIndex = 0;
	wxString tmpString = wxT("C:\\");
	wxString tmpString2; tmpString2.Printf(wxT("%d.avi"),m_FileIndex);
	tmpString.append(m_txtFilename->GetLabel());
	tmpString.append(tmpString2);
	m_txtCurrentFileName->SetLabel(tmpString);
}

void CDeckControl::OnCapture( wxCommandEvent& event )
{
	m_btnCapture->Enable(false);
	m_FileIndex = 0;

	//Set up In- and Outpoints
	InitClips();

	if(SetCaptureGraph(m_Inpoint_01, m_Outpoint_01))
		m_pDSInterface->StartCapture();
}

void ConvertToDEC(int* pIn)
{
	int tens = (((*pIn) >> 4) & 0xF) * 10;
	int onse = (*pIn) & 0xF;
	tens += onse;

	*pIn = tens;
}

void ConvertToBCD(int* pIn)
{
	int high = (*pIn)/10;
	int low = (*pIn)%10;

	*pIn = 0;
	*pIn = (high << 4) | (low);
}

void CDeckControl::InitClips()
{
	m_NumberOfClipsToCapture = 0;

	//first clip
	int inPointH = wxAtoi(m_txtStartAtHours->GetLabel());
	int inPointM = wxAtoi(m_txtStartAtMinutes->GetLabel());
	int inPointS = wxAtoi(m_txtStartAtSeconds->GetLabel());
	int inPointF = wxAtoi(m_txtStartAtFrames->GetLabel());
	ConvertToBCD(&inPointH); ConvertToBCD(&inPointM); ConvertToBCD(&inPointS); ConvertToBCD(&inPointF);
	m_Inpoint_01 = inPointF | (inPointS << 8) | (inPointM << 16) | (inPointH << 24);

	int outPointH = wxAtoi(m_txtStopAtHours->GetLabel());
	int outPointM = wxAtoi(m_txtStopAtMinutes->GetLabel());
	int outPointS = wxAtoi(m_txtStopAtSeconds->GetLabel());
	int outPointF = wxAtoi(m_txtStopAtFrames->GetLabel());
	ConvertToBCD(&outPointH); ConvertToBCD(&outPointM); ConvertToBCD(&outPointS); ConvertToBCD(&outPointF);
	m_Outpoint_01 = outPointF | (outPointS << 8) | (outPointM << 16) | (outPointH << 24);
	m_NumberOfClipsToCapture++;

	//second clip
	inPointH = wxAtoi(m_txtStartAtHours1->GetLabel());
	inPointM = wxAtoi(m_txtStartAtMinutes1->GetLabel());
	inPointS = wxAtoi(m_txtStartAtSeconds1->GetLabel());
	inPointF = wxAtoi(m_txtStartAtFrames1->GetLabel());
	ConvertToBCD(&inPointH); ConvertToBCD(&inPointM); ConvertToBCD(&inPointS); ConvertToBCD(&inPointF);
	m_Inpoint_02 = inPointF | (inPointS << 8) | (inPointM << 16) | (inPointH << 24);
	
	outPointH = wxAtoi(m_txtStopAtHours1->GetLabel());
	outPointM = wxAtoi(m_txtStopAtMinutes1->GetLabel());
	outPointS = wxAtoi(m_txtStopAtSeconds1->GetLabel());
	outPointF = wxAtoi(m_txtStopAtFrames1->GetLabel());
	ConvertToBCD(&outPointH); ConvertToBCD(&outPointM); ConvertToBCD(&outPointS); ConvertToBCD(&outPointF);
	m_Outpoint_02 = outPointF | (outPointS << 8) | (outPointM << 16) | (outPointH << 24);
	m_NumberOfClipsToCapture++;
}

void CDeckControl::OnPlay( wxCommandEvent& event )
{
	if(m_pDSInterface)
		m_pDSInterface->DeckPlay();
}

void CDeckControl::OnStop( wxCommandEvent& event )
{
	if(m_pDSInterface)
		m_pDSInterface->DeckStop();
}

void CDeckControl::OnForward( wxCommandEvent& event )
{
	if(m_pDSInterface)
		m_pDSInterface->DeckForward();
}

void CDeckControl::OnRewind( wxCommandEvent& event )
{
	if(m_pDSInterface)
		m_pDSInterface->DeckRewind();
}

void CDeckControl::SetTimeCodeInfo(int h, int m, int s, int f, bool valid)
{
	if(valid)
	{
		wxString strTimecode = wxT("");
		strTimecode.Printf(wxT("%02d : %02d : %02d : %02d"), h, m, s, f);
		m_txtTimeCode->SetLabel(strTimecode.c_str());
	}
	else
		m_txtTimeCode->SetLabel(wxT("-- : -- : -- : --"));
}

bool CDeckControl::SetCaptureGraph(UINT32 InPoint, UINT32 OutPoint)
{
	wxString tmpString = wxT("C:\\");
	wxString tmpString2; tmpString2.Printf(wxT("%d.avi"),m_FileIndex);
	tmpString.append(m_txtFilename->GetLabel());
	tmpString.append(tmpString2);
	m_txtCurrentFileName->SetLabel(tmpString);
	_bstr_t bstrFile = (_bstr_t)tmpString.c_str();
	if(!m_pDSInterface->CreateCaptureGraph(bstrFile, InPoint, OutPoint))
	{
		wxMessageBox(wxT("Couldn't create capture Graph."));
		CancelCapture();
		return false;
	}
	m_FileIndex++;

	return true;
}

void CDeckControl::CancelCapture()
{
	if(m_pDSInterface)
		m_pDSInterface->StopCaptureThread();

	m_NumberOfClipsToCapture = 0;
	m_btnCapture->Enable(true);
}

void CDeckControl::SetCaptureStatus(int State)
{
	switch(State)
	{
	case 0:
		m_statusBar1->SetStatusText(wxT("Ready..."),2);
		break;
	case 1:
		m_statusBar1->SetStatusText(wxT("Seeking..."),2);
		break;
	case 2:
		m_statusBar1->SetStatusText(wxT("Rolling..."),2);
		break;
	case 3:
		m_statusBar1->SetStatusText(wxT("Capturing..."),2);
		break;
	}
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
void *StateMachineThread::Entry()
{
    int cou = 0;
	CDeckControl* pDeckControlFrame = (CDeckControl*)m_hDeckControl;
	int DeckStatusIntervall = 0;
	BYTE hours=0, minutes=0, seconds=0, frames=0;
	bool bClipDone = false;

	do
    {
        // check if we were asked to exit
        if ( TestDestroy() )
            break;

		pDeckControlFrame->m_pDSInterface->GetTimeCode(&hours, &minutes, &seconds, &frames); //this is synchronised (blocking call) to the card's video input interrupt
		pDeckControlFrame->SetTimeCodeInfo(hours, minutes, seconds, frames, true);

		if(DeckStatusIntervall >= 10)
		{
			pDeckControlFrame->SetDeckStatus();
			DeckStatusIntervall = 0;
		}
		DeckStatusIntervall++;

		if(pDeckControlFrame->m_NumberOfClipsToCapture > 0)
		{
			if(pDeckControlFrame->m_NumberOfClipsToCapture == 2)	//we are capturing clip 1
			{
				if(pDeckControlFrame->m_pDSInterface->IsActive())
				{
					if(pDeckControlFrame->m_pDSInterface->IsSeeking())
						pDeckControlFrame->SetCaptureStatus(1);
					else if(pDeckControlFrame->m_pDSInterface->IsRolling())
						pDeckControlFrame->SetCaptureStatus(2);
					else if(pDeckControlFrame->m_pDSInterface->IsCapturing())
					{
						bClipDone = true;
						pDeckControlFrame->SetCaptureStatus(3);
					}
				}
				else if(bClipDone)
				{
					bClipDone = false;
					pDeckControlFrame->SetCaptureStatus(0);

					pDeckControlFrame->m_NumberOfClipsToCapture--;
					//set up clip 2
					if(!pDeckControlFrame->SetCaptureGraph(pDeckControlFrame->m_Inpoint_02, pDeckControlFrame->m_Outpoint_02))
					{
						pDeckControlFrame->CancelCapture();
					}
					else
					{
						if(!pDeckControlFrame->m_pDSInterface->StartCapture())
						{
							wxMessageBox(wxT("Couldn't start capture Graph."));
							pDeckControlFrame->CancelCapture();
						}
					}
				}
			}
			else if(pDeckControlFrame->m_NumberOfClipsToCapture == 1)	//we are capturing clip 2
			{
				if(pDeckControlFrame->m_pDSInterface->IsActive())
				{
					if(pDeckControlFrame->m_pDSInterface->IsSeeking())
						pDeckControlFrame->SetCaptureStatus(1);
					else if(pDeckControlFrame->m_pDSInterface->IsRolling())
						pDeckControlFrame->SetCaptureStatus(2);
					else if(pDeckControlFrame->m_pDSInterface->IsCapturing())
					{
						bClipDone = true;
						pDeckControlFrame->SetCaptureStatus(3);
					}
				}
				else if(bClipDone)
				{
					bClipDone = false;
					pDeckControlFrame->SetCaptureStatus(0);
					pDeckControlFrame->m_NumberOfClipsToCapture--;
					pDeckControlFrame->CancelCapture();
				}
			}
		}

		wxThread::Sleep(30);
		cou++;
    }while(pDeckControlFrame->m_bRunThread);

	pDeckControlFrame->m_bRunThread = false;
	pDeckControlFrame->m_bThreadStarted = false;
	return NULL;
}
