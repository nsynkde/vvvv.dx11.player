// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows XP or later.                   
#define _WIN32_WINNT 0x0501	// Change this to the appropriate value to target other versions of Windows.
#endif						

#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <math.h>
#include <shellapi.h>


// TODO: reference additional headers your program requires here
#include <conio.h>
#include <initguid.h>
#include <dshow.h>

#import "..\..\..\..\DirectShow\BlueFishFilters\Debug\BlueFishFilters.tlb" no_namespace
#include"BlueDriver_p.h"

#define SAFE_RELEASE(p) {if(p) {p->Release(); p = NULL;} }
#define SAFE_RELEASE_RES(r,p) {if(p) {r=p->Release(); p = NULL;} }
