// BlueFilterCapRen.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


HRESULT AddToRot(IUnknown *pUnkGraph, DWORD *pdwRegister) 
{
	IMoniker * pMoniker = NULL;
	IRunningObjectTable *pROT = NULL;
	const size_t STRING_LENGTH = 256;

	if(FAILED(GetRunningObjectTable(0, &pROT))) 
		return E_FAIL;

	WCHAR wsz[STRING_LENGTH];
	StringCchPrintfW(wsz, STRING_LENGTH, L"FilterGraph %08x pid %08x", (DWORD_PTR)pUnkGraph, GetCurrentProcessId());
    
    HRESULT hr = CreateItemMoniker(L"!", wsz, &pMoniker);
    if (SUCCEEDED(hr)) 
    {
        hr = pROT->Register(ROTFLAGS_REGISTRATIONKEEPSALIVE, pUnkGraph, pMoniker, pdwRegister);
        pMoniker->Release();
    }
    pROT->Release();
    hr = S_OK;
    return hr;
}

void RemoveFromRot(DWORD pdwRegister)
{
    IRunningObjectTable *pROT;
    if(SUCCEEDED(GetRunningObjectTable(0, &pROT)))
	{
        pROT->Revoke(pdwRegister);
        pROT->Release();
    }
}

volatile BOOL bDoThread1 = TRUE;
volatile BOOL bDoThread2 = TRUE;
volatile BOOL bDoThread3 = TRUE;
volatile BOOL bDoThread4 = TRUE;
DWORD WINAPI loadThread1(LPVOID arg)
{
   double volatile r=0.0;
   while(bDoThread1)
   {	for(int i=0;i<10; i++)
		{
			for (int i=0;i<5000000; i++) r=sin((double)i*2*3.14159/180);
			Sleep(1);
		}
	}return 0;
}
DWORD WINAPI loadThread2(LPVOID arg)
{
   double volatile r=0.0;
   while(bDoThread2)
   {	for(int i=0;i<10; i++)
		{
			for (int i=0;i<5000000; i++) r=sin((double)i*2*3.14159/180);
			Sleep(1);
		}
	}return 0;
}
DWORD WINAPI loadThread3(LPVOID arg)
{
   double volatile r=0.0;
   while(bDoThread3)
   {	for(int i=0;i<10; i++)
		{
			for (int i=0;i<5000000; i++) r=sin((double)i*2*3.14159/180);
			Sleep(1);
		}
	}return 0;
}
DWORD WINAPI loadThread4(LPVOID arg)
{
   double volatile r=0.0;
   while(bDoThread4)
   {	for(int i=0;i<10; i++)
		{
			for (int i=0;i<5000000; i++) r=sin((double)i*2*3.14159/180);
			Sleep(1);
		}
	}return 0;
}


IPin *GetPin(IBaseFilter *pBF, PIN_DIRECTION pinDir, int iPinNumber=0)
{
	IEnumPins *pEnumPins = 0;
	IPin* pTmpPin = 0;
    IPin* pRes = NULL;
	PIN_INFO pin_info;
	pBF->EnumPins(&pEnumPins);
	ULONG res;
	int iPinsFound = 0;
	while((!pRes) && pEnumPins->Next(1, &pTmpPin, &res) == S_OK)
	{
		pTmpPin->QueryPinInfo(&pin_info);
		
        if(pin_info.dir == pinDir)
		{
			if(iPinsFound == iPinNumber)
				pRes = pTmpPin;
			else
				pTmpPin->Release();	
			iPinsFound++;
		}
		else 
			pTmpPin->Release();	
        
        if(pin_info.pFilter)
            pin_info.pFilter->Release();
	}
	pEnumPins->Release();
	return pRes;
}

HRESULT RemoveOtherFilters(IFilterGraph *pGraph)
{
    ULONG dbg,n = 0;
	HRESULT hr = S_OK;
	IBaseFilter *pBF[20];
	IEnumFilters *pEF;

	if(!pGraph)
		return S_FALSE;

	pGraph->EnumFilters(&pEF);
	hr = pEF->Next(20,pBF,&n);
	pEF->Release();

	hr = S_OK;
	for (unsigned int i=0;i<n;i++)
	{
		hr = pGraph->RemoveFilter(pBF[i]);

		if(pBF[i] && (hr == S_OK))
		{
			dbg = pBF[i]->Release();
			pBF[i] = NULL;
		}
	}
	return hr;
}

int _tmain(int argc, _TCHAR* argv[])
{
	IBaseFilter*			pBFVideoSource = NULL; 
    IBFFilterControl*		pBFVideoSourceFilterControl = NULL;
    IBFPropertiesControl*	pBFVideoSourcePropertiesControl = NULL;
    IBFVideoSourceControl*	pBFVideoSourceControl = NULL;

    IBaseFilter*			pBFAudioSource = NULL; 
    IBFFilterControl*		pBFAudioSourceFilterControl = NULL;
	IBFAudioSourceControl*	pBFAudioSourceControl = NULL;
	IBFAudioSourcePropertyControl* pBFAudioSourcePropertyControl = NULL;

	IBaseFilter*			pBFVideoRenderer = NULL; 
    IBFFilterControl*		pBFVideoRendererFilterControl = NULL;
    IBFPropertiesControl*	pBFVideoRendererPropertiesControl = NULL;
    IBFVideoRenderControl*	pBFVideoRendererControl = NULL;

    IBaseFilter*			pBFAudioRenderer = NULL; 
    IBFFilterControl*		pBFAudioRendererFilterCtrl = NULL;

	IGraphBuilder*			pFilterGraph = NULL;
	IMediaControl*			pMediaControl = NULL;
	IMediaSeeking*			pMediaSeeking = NULL;
	IMediaFilter*			pMediaFilter = NULL;
	IReferenceClock*		pRefClock = NULL;

	HRESULT					hr = S_OK;
	DWORD					dw_register = 0;	//to register in ROT (running objects table)

	bool UseVideo			= true;
	bool UseAudio			= true;
	bool IsEmbeddedAudio	= true;
	int CaptureVBI			= 0;	// 0 = no VBI; 1 = VBI
	bool UseChannelA		= true;
	//bool UseChannelA		= false;

	//MessageBox(NULL, L"Test", L"Debug", MB_OK);

//*********************************************************************************
	CoInitialize(NULL);
//*********************************************************************************

	if(UseVideo)
	{
		if(UseChannelA)
			hr = CoCreateInstance ( __uuidof(CBFVideoSourceInstC1ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoSource );
		else
			hr = CoCreateInstance ( __uuidof(CBFVideoSourceInstC1ChB), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoSource );

		if(UseChannelA)
			hr = CoCreateInstance ( __uuidof(CBFVideoRenderer), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoRenderer );
		else
			hr = CoCreateInstance ( __uuidof(CBFVideoRendererInstC1ChB), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoRenderer );
	}

	if(UseAudio)
	{
		if(UseChannelA)
			hr = CoCreateInstance ( __uuidof(CBFAudioSourceInstC1ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFAudioSource );
		else
			hr = CoCreateInstance ( __uuidof(CBFAudioSourceInstC1ChB), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFAudioSource );
	}

	if(UseAudio)
	{
		if(UseChannelA) //CBFAudioRenderer provides AES/Analog audio/Embedded Audio channel A
			hr = CoCreateInstance ( __uuidof(CBFAudioRenderer), NULL, CLSCTX_INPROC_SERVER, IID_IBaseFilter, (void **) &pBFAudioRenderer );
		else	//CBFAudioRendererInstC1ChB provides Embedded Audio channel B
			hr = CoCreateInstance ( __uuidof(CBFAudioRendererInstC1ChB), NULL, CLSCTX_INPROC_SERVER, IID_IBaseFilter, (void **) &pBFAudioRenderer );
	}

	if(pBFVideoSource)
		printf("Video Capture Filter created\n");
	if(pBFAudioSource)
		printf("Audio Capture Filter created\n");
	if(pBFVideoRenderer)
		printf("Video Render Filter created\n");
	if(pBFAudioRenderer)
		printf("Audio Render Filter created\n");
	if(!pBFVideoSource && !pBFAudioSource && !pBFVideoRenderer && !pBFAudioRenderer)
	{
		printf("Error: No BF filter created!\n");
		return 0;
	}

	//init capture side
	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFVideoSourceControl), (void **)&pBFVideoSourceControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFPropertiesControl), (void **)&pBFVideoSourcePropertiesControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFVideoSourceFilterControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IReferenceClock), (void **)&pRefClock);

	if (hr == S_OK && pBFAudioSource)
		hr = pBFAudioSource->QueryInterface(__uuidof(IBFAudioSourceControl), (void **)&pBFAudioSourceControl);

	if (hr == S_OK && pBFAudioSource)
		hr = pBFAudioSource->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFAudioSourceFilterControl);

	if (hr == S_OK && pBFAudioSource)
		hr = pBFAudioSource->QueryInterface(__uuidof(IBFAudioSourcePropertyControl), (void **)&pBFAudioSourcePropertyControl);

	//init render side
	if (hr == S_OK && pBFVideoRenderer)
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFVideoRendererFilterControl);

	if (hr == S_OK && pBFVideoRenderer)
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFPropertiesControl), (void **)&pBFVideoRendererPropertiesControl);

	if (hr == S_OK && pBFVideoRenderer)    
		hr = pBFVideoRenderer->QueryInterface(__uuidof(IBFVideoRenderControl), (void **)&pBFVideoRendererControl);

	if (hr == S_OK && pBFAudioRenderer && UseAudio)
		hr = pBFAudioRenderer->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFAudioRendererFilterCtrl);

	//Initialise filtergraph/filters/bluefish card
	if (hr == S_OK)
		hr = CoCreateInstance ( CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER,IID_IGraphBuilder, (void **)&pFilterGraph );

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface(IID_IMediaControl, (void **)&pMediaControl);

	if (hr == S_OK && pFilterGraph)
		pFilterGraph->QueryInterface(IID_IMediaFilter, (void**)&pMediaFilter);

	if(hr == S_OK && pFilterGraph && pMediaFilter && pRefClock)
		pMediaFilter->SetSyncSource(pRefClock);

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface(IID_IMediaSeeking, (void **)&pMediaSeeking);

	if (hr == S_OK && pFilterGraph)
		hr = AddToRot(pFilterGraph, &dw_register);

	//set up which audio channels to capture
	if(hr == S_OK && UseAudio && pBFAudioSourcePropertyControl)
	{
		if(pBFAudioSourcePropertyControl)
			hr = pBFAudioSourcePropertyControl->setPropertyInt32(0, MONO_CHANNEL_1 | MONO_CHANNEL_2);
	}


	//Add filters to filtergraph
	if (hr == S_OK && pFilterGraph)
	{
		//VIDEO
		if(pBFVideoSource && pBFVideoRenderer)
		{
			if(hr == S_OK)
				hr = pFilterGraph->AddFilter(pBFVideoSource, L"BlueFish Video Source");
			if(hr == S_OK)
				hr = pFilterGraph->AddFilter(pBFVideoRenderer, L"BlueFish Video Renderer");
			if (hr == S_OK)
			{
				IPin *pOutPin = NULL;
				pOutPin = GetPin(pBFVideoSource, PINDIR_OUTPUT);
				if(pOutPin)
				{
					hr = pFilterGraph->Render(pOutPin);
					pOutPin->Release();
				}
				pOutPin = GetPin(pBFVideoSource, PINDIR_OUTPUT, 1);	//VANC pin
				if(pOutPin)
				{
					hr = pFilterGraph->Render(pOutPin);
					pOutPin->Release();
				}
			}
		}

		if(pBFAudioSource && pBFAudioRenderer)
		{
			if(hr == S_OK)
				hr = pFilterGraph->AddFilter(pBFAudioSource, L"BlueFish Audio Source");
			if(hr == S_OK)
				hr = pFilterGraph->AddFilter ( pBFAudioRenderer, L"BlueFish Audio Renderer");

			if (hr == S_OK)
			{
				IPin *pOutPin = NULL;
				pOutPin = GetPin(pBFAudioSource,PINDIR_OUTPUT);
				if(pOutPin)
				{
					hr = pFilterGraph->Render(pOutPin);
					pOutPin->Release();
				}
			}
		}
	}

	DWORD ThreadId1;
	HANDLE ThreadHandle1;
	DWORD ThreadId2;
	HANDLE ThreadHandle2;
	DWORD ThreadId3;
	HANDLE ThreadHandle3;
	DWORD ThreadId4;
	HANDLE ThreadHandle4;

	if(pMediaControl)
	{
		ThreadHandle1 = CreateThread (NULL, 0, loadThread1, NULL, 0, &ThreadId1);
		ThreadHandle2 = CreateThread (NULL, 0, loadThread2, NULL, 0, &ThreadId2);
		ThreadHandle3 = CreateThread (NULL, 0, loadThread3, NULL, 0, &ThreadId3);
		ThreadHandle4 = CreateThread (NULL, 0, loadThread4, NULL, 0, &ThreadId4);

		pMediaControl->Run();
		//Sleep(2000);
		printf("Press any key to stop capture!\n");
		getch();
	}
	else
		printf("An error occured during initialisation.\n");

	if(pMediaControl)
		hr = pMediaControl->Stop();
	//printf("Stopped: hr = %d\n", hr);
	//Sleep(2000);

	bDoThread1 = FALSE;
	bDoThread2 = FALSE;
	bDoThread3 = FALSE;
	bDoThread4 = FALSE;
	WaitForSingleObject(ThreadHandle1, 10000);
	WaitForSingleObject(ThreadHandle2, 10000);
	WaitForSingleObject(ThreadHandle3, 10000);
	WaitForSingleObject(ThreadHandle4, 10000);
	CloseHandle(ThreadHandle1);
	CloseHandle(ThreadHandle2);
	CloseHandle(ThreadHandle3);
	CloseHandle(ThreadHandle4);

	hr = S_OK;
	RemoveFromRot(dw_register);

	if(hr == S_OK && pFilterGraph && pBFAudioSource)
        hr = pFilterGraph->RemoveFilter(pBFAudioSource);

	if(hr == S_OK && pFilterGraph && pBFAudioRenderer)
        hr = pFilterGraph->RemoveFilter(pBFAudioRenderer);

	if(hr == S_OK && pFilterGraph && pBFVideoRenderer)
        hr = pFilterGraph->RemoveFilter(pBFVideoRenderer);

	if(hr == S_OK && pFilterGraph && pBFVideoSource)
        hr = pFilterGraph->RemoveFilter(pBFVideoSource);
	

	if(hr != S_OK)
		printf("An ERROR occured (exit)!\n");

	/*if(pMediaFilter)
		pMediaFilter->SetSyncSource(NULL);*/

	ULONG ret;

	SAFE_RELEASE_RES(ret,pRefClock)
	SAFE_RELEASE_RES(ret,pMediaFilter)
	
	SAFE_RELEASE_RES(ret,pBFVideoSourceControl)
	SAFE_RELEASE_RES(ret,pBFVideoSourcePropertiesControl)
	SAFE_RELEASE_RES(ret,pBFVideoSourceFilterControl)
	SAFE_RELEASE_RES(ret,pBFVideoSource)
	
	SAFE_RELEASE_RES(ret,pBFAudioSourcePropertyControl)
	SAFE_RELEASE_RES(ret,pBFAudioSourceControl)
	SAFE_RELEASE_RES(ret,pBFAudioSourceFilterControl)
	SAFE_RELEASE_RES(ret,pBFAudioSource)

	SAFE_RELEASE_RES(ret,pBFVideoRendererFilterControl)
	SAFE_RELEASE_RES(ret,pBFVideoRendererPropertiesControl)
	SAFE_RELEASE_RES(ret,pBFVideoRendererControl)
	SAFE_RELEASE_RES(ret,pBFVideoRenderer)
	
	SAFE_RELEASE_RES(ret,pBFAudioRendererFilterCtrl)
	SAFE_RELEASE_RES(ret,pBFAudioRenderer)

	RemoveOtherFilters(pFilterGraph);

	SAFE_RELEASE_RES(ret,pMediaControl)
	SAFE_RELEASE_RES(ret,pMediaSeeking)
	SAFE_RELEASE_RES(ret,pFilterGraph)

//*********************************************************************************
	CoUninitialize();
//*********************************************************************************
	printf("Filters destroyed. Press any key to exit...\n");
	//system("pause");

	return 0;
}

