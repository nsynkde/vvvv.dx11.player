// BlueFilterCapture.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


HRESULT AddToRot(IUnknown *pUnkGraph, DWORD *pdwRegister) 
{
	IMoniker * pMoniker = NULL;
	IRunningObjectTable *pROT = NULL;
	const size_t STRING_LENGTH = 256;

	if(FAILED(GetRunningObjectTable(0, &pROT))) 
		return E_FAIL;

	WCHAR wsz[STRING_LENGTH];
	StringCchPrintfW(wsz, STRING_LENGTH, L"FilterGraph %08x pid %08x", (DWORD_PTR)pUnkGraph, GetCurrentProcessId());
    
    HRESULT hr = CreateItemMoniker(L"!", wsz, &pMoniker);
    if (SUCCEEDED(hr)) 
    {
        hr = pROT->Register(ROTFLAGS_REGISTRATIONKEEPSALIVE, pUnkGraph, pMoniker, pdwRegister);
        pMoniker->Release();
    }
    pROT->Release();
    hr = S_OK;
    return hr;
}

void RemoveFromRot(DWORD pdwRegister)
{
    IRunningObjectTable *pROT;
    if(SUCCEEDED(GetRunningObjectTable(0, &pROT)))
	{
        pROT->Revoke(pdwRegister);
        pROT->Release();
    }
}

IPin *GetPin(IBaseFilter *pBF, PIN_DIRECTION pinDir )
{
	IEnumPins *pEnumPins = 0;
	IPin *pTmpPin = 0;
    IPin *pRes = NULL;
	PIN_INFO pin_info;
	pBF->EnumPins(&pEnumPins);
	ULONG res;
	while((!pRes) && pEnumPins->Next(1, &pTmpPin, &res) == S_OK)
	{
		pTmpPin->QueryPinInfo(&pin_info);
		
        if (pin_info.dir == pinDir) 
			pRes = pTmpPin;
		else 
			pTmpPin->Release();	
        
        if(pin_info.pFilter)
            pin_info.pFilter->Release();
	}
	pEnumPins->Release();
	return pRes;
}

HRESULT RemoveOtherFilters(IFilterGraph *pGraph)
{
    ULONG dbg,n = 0;
	HRESULT hr = S_OK;
	IBaseFilter *pBF[20];
	IEnumFilters *pEF;

	if(!pGraph)
		return S_FALSE;

	pGraph->EnumFilters(&pEF);
	hr = pEF->Next(20,pBF,&n);
	pEF->Release();

	hr = S_OK;
	for (unsigned int i=0;i<n;i++)
	{
		hr = pGraph->RemoveFilter(pBF[i]);

		if(pBF[i] && (hr == S_OK))
		{
			dbg = pBF[i]->Release();
			pBF[i] = NULL;
		}
	}
	return hr;
}

int _tmain(int argc, _TCHAR* argv[])
{
	IBaseFilter*			pBFVideoSource = NULL; 
    IBFFilterControl*		pBFVideoSourceFilterControl = NULL;
    IBFPropertiesControl*	pBFVideoSourcePropertiesControl = NULL;
    IBFVideoSourceControl*	pBFVideoSourceControl = NULL;

    IBaseFilter*			pBFAudioSource = NULL; 
    IBFFilterControl*		pBFAudioSourceFilterControl = NULL;
	IBFAudioSourceControl*	pBFAudioSourceControl = NULL;
	IBFAudioSourcePropertyControl* pBFAudioSourcePropertyControl = NULL;

	IGraphBuilder*			pFilterGraph = NULL;
	IMediaControl*			pMediaControl = NULL;
	IMediaSeeking*			pMediaSeeking = NULL;
	IMediaFilter*			pMediaFilter = NULL;
	IReferenceClock*		pRefClock = NULL;

	HRESULT					hr = S_OK;
	DWORD					dw_register = 0;	//to register in ROT (running objects table)

	bool UseVideo			= true;
	bool UseAudio			= true;
	bool IsEmbeddedAudio	= true;
	int CaptureVBI			= 0;	// 0 = no VBI; 1 = VBI
	bool UseChannelA		= true;
	bool bUseEpoch			= true;	//If we use an Epoch card and want embedded audio we have to use CBFAudioSourceInstC1ChA instead of CBFEmbAudioSourceInstC1ChA
									//and configure the audio source type

//*********************************************************************************
	CoInitialize(NULL);
//*********************************************************************************

	//Create Bluefish filter instances
	if(UseVideo)
	{
		if(UseChannelA)
			hr = CoCreateInstance ( __uuidof(CBFVideoSourceInstC1ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoSource );
		else
			hr = CoCreateInstance ( __uuidof(CBFVideoSourceInstC1ChB), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFVideoSource );
	}
	if(UseAudio)
	{
		if(UseChannelA)
		{
			if(IsEmbeddedAudio && !bUseEpoch)
				hr = CoCreateInstance ( __uuidof(CBFEmbAudioSourceInstC1ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFAudioSource );
			else
				hr = CoCreateInstance ( __uuidof(CBFAudioSourceInstC1ChA), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFAudioSource );
		}
		else
		{
			if(IsEmbeddedAudio && !bUseEpoch)
				hr = CoCreateInstance ( __uuidof(CBFEmbAudioSourceInstC1ChB), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFAudioSource );
			else
				hr = CoCreateInstance ( __uuidof(CBFAudioSourceInstC1ChB), NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **) &pBFAudioSource );
		}
	}

	if(pBFVideoSource)
		printf("Video Filter created\n");
	if(pBFAudioSource)
		printf("Audio Filter created\n");
	if(!pBFVideoSource && !pBFAudioSource)
	{
		printf("Error: No BF filter created!\n");
		return 0;
	}

	//Initialise filtergraph/filters/bluefish card
	if (hr == S_OK)
		hr = CoCreateInstance ( CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER,IID_IGraphBuilder, (void **)&pFilterGraph );

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFVideoSourceControl), (void **)&pBFVideoSourceControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFPropertiesControl), (void **)&pBFVideoSourcePropertiesControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFVideoSourceFilterControl);

	if(hr == S_OK && pBFVideoSource)
		hr = pBFVideoSource->QueryInterface(__uuidof(IReferenceClock), (void **)&pRefClock);

	if (hr == S_OK && pBFAudioSource)
		hr = pBFAudioSource->QueryInterface(__uuidof(IBFAudioSourceControl), (void **)&pBFAudioSourceControl);

	if (hr == S_OK && pBFAudioSource)
		hr = pBFAudioSource->QueryInterface(__uuidof(IBFFilterControl), (void **)&pBFAudioSourceFilterControl);

	if (hr == S_OK && pBFAudioSource)
		hr = pBFAudioSource->QueryInterface(__uuidof(IBFAudioSourcePropertyControl), (void **)&pBFAudioSourcePropertyControl);

	if (hr == S_OK)
		hr = CoCreateInstance ( CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER,IID_IGraphBuilder, (void **)&pFilterGraph );

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface(IID_IMediaControl, (void **)&pMediaControl);

	if (hr == S_OK && pFilterGraph)
		pFilterGraph->QueryInterface(IID_IMediaFilter, (void**)&pMediaFilter);

	if(hr == S_OK && pFilterGraph && pMediaFilter && pRefClock)
		pMediaFilter->SetSyncSource(pRefClock);

	if (hr == S_OK && pFilterGraph)
		hr = pFilterGraph->QueryInterface(IID_IMediaSeeking, (void **)&pMediaSeeking);

	if (hr == S_OK && pFilterGraph)
		hr = AddToRot(pFilterGraph, &dw_register);

	//VBI setting
	if (hr == S_OK && pBFVideoSourceControl)
	{
		int VBISupported;
		int VBIState;

		hr = pBFVideoSourceControl->getCaptureVBI(&VBISupported, &VBIState);
		if(VBISupported)
		{
			hr = pBFVideoSourceControl->setCaptureVBI(CaptureVBI);
			hr = pBFVideoSourceControl->getCaptureVBI(&VBISupported, &VBIState);
		}
	}

	//Audio input type
	if(hr == S_OK && UseAudio && IsEmbeddedAudio && bUseEpoch && pBFAudioSourceControl)
	{
		int CardAudioType;
		int NewAudioType;
		hr = pBFAudioSourceControl->get_AudioInputType(&CardAudioType);

		if(UseChannelA)
			NewAudioType = BLUE_AUDIO_SDIA;
		else
			NewAudioType = BLUE_AUDIO_SDIB;

		if(NewAudioType != CardAudioType)
		{
			if(hr == S_OK)
				hr = pBFAudioSourceControl->put_AudioInputType(NewAudioType);

			if(hr == S_OK)
			{
				hr = pBFAudioSourceControl->get_AudioInputType(&CardAudioType);
				if(NewAudioType != CardAudioType)
				{
					hr = S_FALSE;
					printf("Can't set audio type\n");
				}
			}
		}
	}

	//set up which audio channels to capture
	if(hr == S_OK && UseAudio && bUseEpoch && pBFAudioSourcePropertyControl)
	{
		if(pBFAudioSourcePropertyControl)
			hr = pBFAudioSourcePropertyControl->setPropertyInt32(0, MONO_CHANNEL_1 | MONO_CHANNEL_2);
	}

	//Add filters to filtergraph
	if (hr == S_OK && pFilterGraph)
	{
		//VIDEO
		if(hr == S_OK && pBFVideoSource)
		{
			hr = pFilterGraph->AddFilter(pBFVideoSource, L"BlueFish Video Source");

			if (hr == S_OK)
			{
				IPin *pOutPin = NULL;
				pOutPin = GetPin(pBFVideoSource,PINDIR_OUTPUT);
				if(pOutPin)
				{
					hr = pFilterGraph->Render(pOutPin);
					pOutPin->Release();
				}
			}
		}

		//AUDIO
		if(hr == S_OK && pBFAudioSource)
		{
			hr = pFilterGraph->AddFilter(pBFAudioSource, L"BlueFish Audio Source");

			if (hr == S_OK)
			{
				IPin *pOutPin = NULL;
				pOutPin = GetPin(pBFAudioSource,PINDIR_OUTPUT);
				if(pOutPin)
				{
					hr = pFilterGraph->Render(pOutPin);
					pOutPin->Release();
				}
			}
		}
	}

	if(pMediaControl)
	{
		pMediaControl->Run();
		printf("Press any key to stop capture!\n");
		getch();
	}
	else
		printf("An error occured during initialisation.\n");

	if(pMediaControl)
		pMediaControl->Stop();

	hr = S_OK;
	RemoveFromRot(dw_register);

	if(hr == S_OK && pFilterGraph && pBFAudioSource)
        hr = pFilterGraph->RemoveFilter(pBFAudioSource);

	if(hr == S_OK && pFilterGraph && pBFVideoSource)
        hr = pFilterGraph->RemoveFilter(pBFVideoSource);

	if(hr != S_OK)
		printf("An ERROR occured (exit)!\n");

	ULONG ret;

	if(pMediaFilter)
		pMediaFilter->SetSyncSource(NULL);

	SAFE_RELEASE_RES(ret,pRefClock)
	SAFE_RELEASE_RES(ret,pMediaFilter)
	
	SAFE_RELEASE_RES(ret,pBFVideoSourceControl)
	SAFE_RELEASE_RES(ret,pBFVideoSourcePropertiesControl)
	SAFE_RELEASE_RES(ret,pBFVideoSourceFilterControl)
	SAFE_RELEASE_RES(ret,pBFVideoSource)
	
	SAFE_RELEASE_RES(ret,pBFAudioSourcePropertyControl)
	SAFE_RELEASE_RES(ret,pBFAudioSourceControl)
	SAFE_RELEASE_RES(ret,pBFAudioSourceFilterControl)
	SAFE_RELEASE_RES(ret,pBFAudioSource)

	RemoveOtherFilters(pFilterGraph);

	SAFE_RELEASE_RES(ret,pMediaControl)
	SAFE_RELEASE_RES(ret,pMediaSeeking)
	SAFE_RELEASE_RES(ret,pFilterGraph)

//*********************************************************************************
	CoUninitialize();
//*********************************************************************************
	printf("Filters destroyed. Press any key to exit...\n");
	system("pause");

	return 0;
}

