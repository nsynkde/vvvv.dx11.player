// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <iostream>
#include <iomanip>
#include <conio.h>


// TODO: reference additional headers your program requires here
#include "BlueVelvet4.h"
#include "BlueHancUtils.h"


using namespace std;

#pragma pack(push, blue_timecode_struct, 1)
struct BlueTimeCodeStruct
{
	ULONGLONG	unit_frame:4,			//00-03:	frame
				binary1:4,				//04-07:	not used, set to 0
				ten_frame:2,			//08-09:	frame tens
				drop_frame_flag:1,		//10:		only 30/60 framerates: drop frame flag, otherwise 0
				color_frame_flag:1,		//11:		not used, set to 0
				binary2:4,				//12-15:	not used, set to 0
				unit_second:4,			//16-19:	second
				binary3:4,				//20-23:	not used, set to 0
				ten_second:3,			//24-26:	second tens
				field_bit:1,			//27:		24/30/60 framerates: field bit/LTC polarity; 25/50 framerates: Binary Group flag 0
				binary4:4,				//28-31:	not used, set to 0
				unit_minute:4,			//32-35:	minute
				binary5:4,				//36-39:	not used, set to 0
				ten_minute:3,			//40-42:	minute tens
				binarygroupflag43:1,	//43:		not used, set to 0
				binary6:4,				//44-47:	not used, set to 0
				unit_hours:4,			//48-51:	hour
				binary7:4,				//52-55:	not used, set to 0
				ten_hours:2,			//56-57:	hour tens
				binarygroupflag58:1,	//58:		not used, set to 0
				binarygroupflag59:1,	//59:		24/30/60 framerates: Binary Group flag 2; 25/50 framerates: field bit/LTC polarity
				binary8:4;				//60-63:	not used, set to 0
};

struct TimeCode
{
	union 
	{
		struct BlueTimeCodeStruct struct_timecode;
		ULONGLONG timecode_u64;
	};
	
};
#pragma pack(pop, blue_timecode_struct)
