// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	CaptureAncillary_FieldMode_FS_VITC2
// Written by:			Tim Bragulla
// Date:				23 July 2013
//
// Brief description:	This sample application shows how to capture interlaced SDI video, VBI/VANC data and Embedded Audio in field mode using FRAMESTORE mode
//						(progressive formats do not support field mode)
//						(Capturing interlaced SDI video and Embedded Audio in frame mode please refer to the sample application CaptureAV_FS)
//						VBI is only available in SD video modes and takes the same memory format as the video data
//						VANC is only available in HD video modes and is always in V210 memory format
//						The SDK macros tend to be named VBI, but are also used for VANC
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.2.10 and above
//		Firwmare:				SuperNova 2i/2o fw 78 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_2_10\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"


#define HANC_BUFFER_SIZE (256*1024)


void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

void InitInputChannel(CBlueVelvet4* pSDK, ULONG DefaultInputChannel, ULONG UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultInputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_capture_stop();

	RouteChannel(pSDK, EPOCH_SRC_SDI_INPUT_A, EPOCH_DEST_INPUT_MEM_INTERFACE_CHA, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required update type and memory format and make sure that there is a valid input signal
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);
}

void SelectAudioInputSource(CBlueVelvet4* pSDK, ULONG AudioInputSource)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = AudioInputSource;
	pSDK->SetCardProperty(AUDIO_INPUT_PROP, varVal);
}

void print_timecode_value(struct TimeCode tc, ULONG ulFieldCount)
{
	unsigned int frames, second, minutes, hours;
	hours =		(UINT32)(tc.struct_timecode.ten_hours*10) + tc.struct_timecode.unit_hours;
	minutes =	(UINT32)(tc.struct_timecode.ten_minute*10) + tc.struct_timecode.unit_minute;
	second =	(UINT32)(tc.struct_timecode.ten_second*10) + tc.struct_timecode.unit_second;
	frames =	(UINT32)(tc.struct_timecode.ten_frame*10) + tc.struct_timecode.unit_frame;	
	printf("%02d:%02d:%02d:%02d (%d), 24/30/60: %d, 25/50: %d\n", hours, minutes, second, frames, ulFieldCount, (tc.struct_timecode.field_bit)?1:0, (tc.struct_timecode.binarygroupflag59)?1:0);
	//printf("%d, %d\n", (tc.struct_timecode.binarygroupflag58)?1:0, (tc.struct_timecode.binarygroupflag59)?1:0);
	//printf(" 0x%I64X", tc.timecode_u64);
	cout << setfill('0');
	cout << " 0x" << hex << setw(16) << tc.timecode_u64 << dec << endl;
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "CaptureAncillary_FieldMode_FS_VITC2 sample app" << endl;

	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;
	ULONG StartFieldCount = 0;
	ULONG CurrentFieldCount = 0;
	ULONG LastFieldCount = 0;
	int iHancBufferID = -1;

	ULONG VideoMode = VID_FMT_INVALID;
	ULONG UpdateFormat = UPD_FMT_FIELD;
	ULONG MemoryFormat = MEM_FMT_2VUY;
	ULONG VideoEngine = VIDEO_ENGINE_FRAMESTORE;
	ULONG AudioInputSource = BLUE_AUDIO_EMBEDDED;	//Epoch and SuperNova cards only support BLUE_AUDIO_AES and BLUE_AUDIO_EMBEDDED

	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDK = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDK->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card, in this case card 1
	if(BLUE_FAIL(pSDK->device_attach(1, 0)))
	{
		cout << "Error on device attach (channel A)" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Get the card type and firmware type
	int iCardType = pSDK->has_video_cardtype();
	if(	iCardType != CRD_BLUE_EPOCH_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_CORE &&
		iCardType != CRD_BLUE_EPOCH_ULTRA &&
		iCardType != CRD_BLUE_EPOCH_2K_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_2K_CORE &&
		iCardType != CRD_BLUE_EPOCH_2K_ULTRA &&
		iCardType != CRD_BLUE_SUPER_NOVA &&
		iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Card not supported for OEM capture" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	pSDK->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal);
	cout << "Product ID / firmware type: " << varVal.ulVal << endl;

	varVal.ulVal = 0;
	if(BLUE_FAIL(pSDK->QueryCardProperty(CARD_FEATURE_STREAM_INFO, varVal)))
	{
		cout << "Function not supported; need driver 5.10.2.x" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	unsigned int nOutputStreams = CARD_FEATURE_GET_SDI_OUTPUT_STREAM_COUNT(varVal.ulVal);
	unsigned int nInputStreams = CARD_FEATURE_GET_SDI_INPUT_STREAM_COUNT(varVal.ulVal);
	if(!nInputStreams)
	{
		cout << "Card does not support input channels" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	InitInputChannel(pSDK, BLUE_VIDEO_INPUT_CHANNEL_A, UpdateFormat, MemoryFormat, VideoEngine);
	SelectAudioInputSource(pSDK, AudioInputSource);	//Epoch and SuperNova cards only support BLUE_AUDIO_AES and BLUE_AUDIO_EMBEDDED

	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDK->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	//Check if we have a valid input signal
	pSDK->wait_input_video_synch(UPD_FMT_FRAME, LastFieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	varVal.vt = VT_UI4;
	pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	if(varVal.ulVal >= InvalidVideoModeFlag)
	{
		cout << "No valid input signal on channel A" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}
	VideoMode = varVal.ulVal;

	ULONG GoldenSize = BlueVelvetGolden(VideoMode, MemoryFormat, UpdateFormat);
	ULONG GoldenSizeVbiVanc = BlueVelvetVANCGoldenValue(iCardType, VideoMode, MemoryFormat, (UpdateFormat == UPD_FMT_FRAME)?BLUE_DATA_FRAME:BLUE_DATA_FIELD1);	//BLUE_DATA_FIELD1 and BLUE_DATA_FIELD2 are the same on Epoch/SuperNova cards
	unsigned char* pVideoBuffer = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBuffer, GoldenSize);
	unsigned char* pVbiVancBuffer = (unsigned char*)VirtualAlloc(NULL, GoldenSizeVbiVanc, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVbiVancBuffer, GoldenSizeVbiVanc);
	unsigned char* pHancBuffer = (unsigned char*)VirtualAlloc(NULL, HANC_BUFFER_SIZE, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pHancBuffer, HANC_BUFFER_SIZE);
	unsigned char* pAudioSamples = new unsigned char[2002*16*4];	//maximum of 2002 samples per frame, 16 audio channels and 4 byte samples

	//structure for decoding the HANC buffer (extracting audio samples)
	struct hanc_decode_struct HancInfo;
	memset(&HancInfo, 0, sizeof(HancInfo));
	UINT32 nAudioChannels = 2;
	HancInfo.audio_ch_required_mask = MONO_CHANNEL_1 | MONO_CHANNEL_2;
	HancInfo.audio_pcm_data_ptr = pAudioSamples;
	HancInfo.type_of_sample_required = AUDIO_CHANNEL_16BIT;	//AUDIO_CHANNEL_16BIT, AUDIO_CHANNEL_24BIT or 0 for 32bit
	HancInfo.max_expected_audio_sample_count = 2002;		// this is the biggest audio frame the card can generate (this happens in 1080PSF 23 video mode)

	ULONG ScheduleID = 0;
	ULONG CapturingID = 0;
	ULONG DoneID = 0;

	//start the capture sequence
	pSDK->wait_input_video_synch(UpdateFormat, CurrentFieldCount);	//this call just synchronises us to the card
	if((CurrentFieldCount & 0x1) == 0)
		pSDK->wait_input_video_synch(UpdateFormat, CurrentFieldCount);	//we need to schedule the capture of field 0 at field 1 interrupt
	pSDK->render_buffer_capture(BlueBuffer_Image_VBI_HANC(ScheduleID), 0);
	CapturingID = ScheduleID;
	ScheduleID = (++ScheduleID%3);
	LastFieldCount = CurrentFieldCount;

	pSDK->wait_input_video_synch(UpdateFormat, CurrentFieldCount);	//the first buffer starts to be captured now; this is it's field count
	cout << CurrentFieldCount << endl;
	pSDK->render_buffer_capture(BlueBuffer_Image_VBI_HANC(ScheduleID), 0);
	DoneID = CapturingID;
	CapturingID = ScheduleID;
	ScheduleID = (++ScheduleID%3);
	LastFieldCount = CurrentFieldCount;
	StartFieldCount = CurrentFieldCount;
	VARIANT varVal64;
	varVal64.vt = VT_UI8;
	varVal64.ullVal = 0LL;
	TimeCode rp188_vitc;

	while(!_kbhit())
	{
		pSDK->wait_input_video_synch(UpdateFormat, CurrentFieldCount);

		
		pSDK->QueryCardProperty(EPOCH_INPUT_VITC, varVal64);
		rp188_vitc.timecode_u64 = varVal64.ullVal;
		print_timecode_value(rp188_vitc, CurrentFieldCount);
		//cout << dec << "RP188 VITC: " << CurrentFieldCount << ": " << hex << HancInfo.timecodes[0] << endl;	// RP188 VITC time code
		
		//DMA the video field
		pSDK->system_buffer_read_async(pVideoBuffer, GoldenSize, NULL, BlueImage_VBI_HANC_DMABuffer(DoneID, BLUE_DATA_FIELD1)); //Epoch and SuperNova cards don't distinguish between BLUE_DATA_FIELD1 and BLUE_DATA_FIELD2
		pSDK->system_buffer_read_async(pVbiVancBuffer, GoldenSizeVbiVanc, NULL, BlueImage_VBI_HANC_DMABuffer(DoneID, BLUE_DATA_VBI));

		//Audio capture is frame based, so we only handle audio frames every second field
		if((CurrentFieldCount & 0x1) == 0)	//this is field 0 interrupt which means that the previous video field 1 and the whole HANC frame have finished being captured
		{
			if(iHancBufferID != -1)
			{
				//DMA the whole audio frame
				pSDK->system_buffer_read_async(pHancBuffer, HANC_BUFFER_SIZE, NULL, BlueImage_VBI_HANC_DMABuffer(iHancBufferID, BLUE_DATA_HANC));

				//decode HANC buffer to extract the audio samples
				HancInfo.raw_custom_anc_pkt_data_ptr = NULL;
				HancInfo.audio_input_source = (AudioInputSource == BLUE_AUDIO_AES)?AUDIO_INPUT_SOURCE_AES:AUDIO_INPUT_SOURCE_EMB;
				hanc_decoder_ex(iCardType, (UINT32*)pHancBuffer, &HancInfo);
				iHancBufferID = -1;
			}
			else
				cout << "ERROR" << endl;
		}
		else	//this is field 1 interrupt
		{
			iHancBufferID = DoneID;	//this is the buffer we need, but at this point in time only half the audio frame has been capture;
		}

		//tell the card to capture another frame at the next interrupt
		pSDK->render_buffer_capture(BlueBuffer_Image_VBI_HANC(ScheduleID), 0);

		if(LastFieldCount + 1 < CurrentFieldCount)
			cout << "Error: dropped " << (CurrentFieldCount - LastFieldCount + 1) << " frames" << endl;

		DoneID = CapturingID;
		CapturingID = ScheduleID;
		ScheduleID = (++ScheduleID%4);
		LastFieldCount = CurrentFieldCount;
 	}

	delete [] pAudioSamples;
	VirtualUnlock(pVbiVancBuffer, GoldenSizeVbiVanc);
	VirtualUnlock(pHancBuffer, HANC_BUFFER_SIZE);
	VirtualUnlock(pVideoBuffer, GoldenSize);
	VirtualFree(pVbiVancBuffer, 0, MEM_RELEASE);
	VirtualFree(pHancBuffer, 0, MEM_RELEASE);
	VirtualFree(pVideoBuffer, 0, MEM_RELEASE);

	BailOut(pSDK);
	cout << "Done" << endl;
	system("pause");
	return 0;
}
