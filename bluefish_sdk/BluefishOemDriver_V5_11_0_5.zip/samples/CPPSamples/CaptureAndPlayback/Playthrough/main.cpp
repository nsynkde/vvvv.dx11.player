// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	Playthrough
// Written by:			Tim Bragulla
// Date:				28 September 2012
//
// Brief description:	This sample application shows how to capture SDI video using FIFO mode and have the firmware/driver automatically playout video and audio
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"


void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

BOOL InitInputChannelAndPlaythroughChannel(CBlueVelvet4* pSDK, ULONG UpdateFormat, ULONG MemoryFormat)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = BLUE_VIDEO_INPUT_CHANNEL_A;
	pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

	//we also need to mirror the input settings on the output
	//only in the case of using the playthrough feature we should attempt using a single SDK instance to set properties for more than one channel
	varVal.ulVal = BLUE_VIDEO_OUTPUT_CHANNEL_A;
	pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_capture_stop();
	pSDK->video_playback_stop(0, 0);

	RouteChannel(pSDK, EPOCH_SRC_SDI_INPUT_A, EPOCH_DEST_INPUT_MEM_INTERFACE_CHA, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	//Query the input video signal
	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDK->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	//Check if we have a valid input signal
	unsigned long FieldCount = 0;
	pSDK->wait_input_video_synch(UPD_FMT_FRAME, FieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	varVal.vt = VT_UI4;
	pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	if(varVal.ulVal >= InvalidVideoModeFlag)
	{
		cout << "No valid input signal on channel A" << endl;
		return FALSE;
	}
	unsigned long VideoMode = varVal.ulVal;

	varVal.ulVal = VideoMode;
	pSDK->SetCardProperty(VIDEO_MODE, varVal);

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);
	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);
	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required update type and memory format and make sure that there is a valid input signal
	varVal.ulVal = VIDEO_ENGINE_CAPTURE;
	pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);

	varVal.ulVal = 0;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	//if we want audio to playthrough as well we need to make sure that audio output is enabled (embedd audio in this case)
	ULONG EmbAudioProp = 0;
	ULONG NumberAudioChannels = 8;
	ULONG AudioSampleBitDepth = AUDIO_CHANNEL_16BIT;	// 16 bit
	//ULONG AudioSampleBitDepth = AUDIO_CHANNEL_24BIT;	// 24 bit
	//ULONG AudioSampleBitDepth = 0;					// 32 bit
	ULONG EmbAudioFlag = 0;

	if(NumberAudioChannels > 0)
		EmbAudioProp |= (blue_emb_audio_group1_enable);
	if(NumberAudioChannels > 4)
		EmbAudioProp |= (blue_emb_audio_group2_enable);
	if(NumberAudioChannels > 8)
		EmbAudioProp |= (blue_emb_audio_group3_enable);
	if(NumberAudioChannels > 12)
		EmbAudioProp |= (blue_emb_audio_group4_enable);
	if(EmbAudioProp)
		EmbAudioProp |= blue_emb_audio_enable;
	
	EmbAudioFlag = EmbAudioProp;
	EmbAudioProp |= blue_enable_hanc_timestamp_pkt;	//enable timecode
	varVal.ulVal = EmbAudioProp;
	pSDK->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);

	return TRUE;
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Playthrough sample app" << endl;

	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;
	blue_videoframe_info_ex	FrameInfo;
	unsigned int FifoSize = 0;
	ULONG FieldCount = 0;
	ULONG LastFieldCount = 0;

	ULONG VideoMode = VID_FMT_INVALID;
	ULONG UpdateFormat = UPD_FMT_FRAME;
	ULONG MemoryFormat = MEM_FMT_2VUY;
	ULONG VideoEngine = VIDEO_ENGINE_DUPLEX;

	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDK = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDK->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card, in this case card 1
	if(BLUE_FAIL(pSDK->device_attach(1, 0)))
	{
		cout << "Error on device attach (channel A)" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Get the card type and firmware type
	int iCardType = pSDK->has_video_cardtype();
	if(	iCardType != CRD_BLUE_EPOCH_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_CORE &&
		iCardType != CRD_BLUE_EPOCH_ULTRA &&
		iCardType != CRD_BLUE_EPOCH_2K_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_2K_CORE &&
		iCardType != CRD_BLUE_EPOCH_2K_ULTRA &&
		iCardType != CRD_BLUE_SUPER_NOVA &&
		iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Card not supported for OEM capture" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	pSDK->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal);
	cout << "Product ID / firmware type: " << varVal.ulVal << endl;

	varVal.ulVal = 0;
	if(BLUE_FAIL(pSDK->QueryCardProperty(CARD_FEATURE_STREAM_INFO, varVal)))
	{
		cout << "Function not supported; need driver 5.10.2.x" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	unsigned int nOutputStreams = CARD_FEATURE_GET_SDI_OUTPUT_STREAM_COUNT(varVal.ulVal);
	unsigned int nInputStreams = CARD_FEATURE_GET_SDI_INPUT_STREAM_COUNT(varVal.ulVal);
	if(!nInputStreams)
	{
		cout << "Card does not support input channels" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	if(!InitInputChannelAndPlaythroughChannel(pSDK, UpdateFormat, MemoryFormat))
	{
		cout << "Error on Init." << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDK->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	//Check if we have a valid input signal
	pSDK->wait_input_video_synch(UPD_FMT_FRAME, FieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	varVal.vt = VT_UI4;
	pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	if(varVal.ulVal >= InvalidVideoModeFlag)
	{
		cout << "No valid input signal on channel A" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}
	VideoMode = varVal.ulVal;

	OVERLAPPED OverlapChA;
	OverlapChA.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	ULONG GoldenSize = BlueVelvetGolden(VideoMode, MemoryFormat, UpdateFormat);
	unsigned char* pVideoBuffer = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBuffer, GoldenSize);

	//synchronise with the card
	pSDK->wait_input_video_synch(UpdateFormat, LastFieldCount);

	if(BLUE_FAIL(pSDK->video_capture_start(0)))
		cout << "Error video capture start failed on channel A" << endl;
	
	while(!_kbhit())
	{
		pSDK->wait_input_video_synch(UpdateFormat, FieldCount);
		
		if(BLUE_FAIL(GetVideo_CaptureFrameInfoEx(pSDK, &OverlapChA, FrameInfo, 0, &FifoSize)) || (FrameInfo.nVideoSignalType >= InvalidVideoModeFlag) || (FrameInfo.BufferId == -1))
		{
			cout << "continue" << endl;
			continue;
		}

		if(LastFieldCount + 2 < FieldCount)
		{
			cout << "Error: dropped " << ((FieldCount - LastFieldCount + 2)/2) << " frames" << endl;
		}
		else
			cout << ".";

		pSDK->system_buffer_read_async(pVideoBuffer, GoldenSize, NULL, BlueImage_DMABuffer(FrameInfo.BufferId, BLUE_DATA_IMAGE));

		LastFieldCount = FieldCount;
 	}

	pSDK->video_capture_stop();
	CloseHandle(OverlapChA.hEvent);
	VirtualUnlock(pVideoBuffer, GoldenSize);
	VirtualFree(pVideoBuffer, 0, MEM_RELEASE);

	BailOut(pSDK);
	cout << "Done" << endl;
	system("pause");
	return 0;
}
