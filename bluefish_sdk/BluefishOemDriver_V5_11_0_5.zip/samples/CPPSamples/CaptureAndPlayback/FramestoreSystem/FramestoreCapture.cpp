#include "stdafx.h"

extern struct blue_videomode_info gVideoModeInfo[];
extern CFifoBuffer gCaptureFifo;
extern CFifoBuffer gPlaybackFifo;

CFrameStoreCapture::CFrameStoreCapture() :
	m_pSDK(NULL),
	m_iDevices(0),
	m_nIsAttached(0),
	m_nVideoMode(VID_FMT_INVALID),
	m_hThread(0),
	m_nThreadStopping(TRUE)
{
	m_pSDK = BlueVelvetFactory4();
	if(!m_pSDK)
		cout << "No Bluefish SDK" << endl;

	if(m_pSDK)
	{
		m_pSDK->device_enumerate(m_iDevices);
		if(!m_iDevices)
			cout << "No Bluefish card" << endl;
	}
}

CFrameStoreCapture::~CFrameStoreCapture()
{
	if(m_pSDK)
	{
		if(m_nIsAttached)
			m_pSDK->device_detach();
		BlueVelvetDestroy(m_pSDK);
	}
	m_pSDK = NULL;
}

BLUE_INT32 CFrameStoreCapture::Init(BLUE_INT32 CardNumber, BLUE_UINT32 VideoChannel, BLUE_UINT32 UpdateFormat, BLUE_UINT32 MemoryFormat)
{
	ULONG FieldCount = 0;
	VARIANT varVal;
	BLUE_INT32 card_type = CRD_INVALID;

	if(m_nIsAttached)
	{
		m_pSDK->device_detach();
		m_nIsAttached = 0;
	}

	if(CardNumber <= 0 || CardNumber > m_iDevices)
	{
		cout << "Card " << CardNumber << " not available; maximum card number is: " << m_iDevices << endl;
		return -1;
	}

	m_pSDK->device_attach(CardNumber, 0);
	m_nIsAttached = 1;

	card_type = m_pSDK->has_video_cardtype();
	if(card_type != CRD_BLUE_EPOCH_HORIZON &&
		card_type != CRD_BLUE_EPOCH_CORE &&
		card_type != CRD_BLUE_EPOCH_ULTRA &&
		card_type != CRD_BLUE_EPOCH_2K_HORIZON &&
		card_type != CRD_BLUE_EPOCH_2K_CORE &&
		card_type != CRD_BLUE_EPOCH_2K_ULTRA &&
		card_type != CRD_BLUE_SUPER_NOVA &&
		card_type != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Not an Epoch/SuperNova card" << endl;
		m_pSDK->device_detach();
		m_nIsAttached = 0;
		return -1;
	}

	varVal.vt = VT_UI4;
	varVal.ulVal = VideoChannel;
	m_pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

	m_pSDK->wait_input_video_synch(UPD_FMT_FRAME, FieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	varVal.vt = VT_UI4;
	m_pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	if(varVal.ulVal >= VID_FMT_INVALID)
	{
		cout << "No valid input signal" << endl;
		m_pSDK->device_detach();
		m_nIsAttached = 0;
		return -1;
	}
	m_nVideoMode = varVal.ulVal;
	cout << "Video Input mode: " << gVideoModeInfo[m_nVideoMode].strVideoModeFriendlyName.c_str() << endl;

	m_nUpdateFormat = UpdateFormat;
	varVal.ulVal = m_nUpdateFormat;
	m_pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);

	m_nMemoryFormat = MemoryFormat;
	varVal.ulVal = m_nMemoryFormat;
	m_pSDK->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);

	varVal.ulVal = VIDEO_ENGINE_FRAMESTORE;
	m_pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);

	ULONG GoldenSize = BlueVelvetGolden(m_nVideoMode, m_nMemoryFormat, m_nUpdateFormat);
	ULONG BytesPerLine = BlueVelvetLineBytes(m_nVideoMode, m_nMemoryFormat);
	gCaptureFifo.Init(4, GoldenSize, BytesPerLine);

	return 0;
}

BLUE_INT32 CFrameStoreCapture::InitThread()
{
	unsigned int ThreadId = 0;

	if(m_hThread)
	{
		cout << "Capture Thread already started" << endl;
		return 0;
	}

	cout << "Starting Capture Thread..." << endl;
	m_hThread = (HANDLE)_beginthreadex(NULL, 0, &CaptureThread, this, CREATE_SUSPENDED, &ThreadId);
	if(!m_hThread)
	{
		cout << "Error starting Capture Thread" << endl;
		return -1;
	}

	m_nThreadStopping = FALSE;
	SetThreadPriority(m_hThread, THREAD_PRIORITY_TIME_CRITICAL);
	cout << "...done." << endl;
	return 0;
}

void CFrameStoreCapture::StartThread()
{
	ResumeThread(m_hThread);
}

void CFrameStoreCapture::StopThread()
{
	DWORD dw = 0;

	if(m_hThread)
	{
		cout << "Stopping Capture Thread..." << endl;
		m_nThreadStopping = TRUE;
		dw = WaitForSingleObject(m_hThread, -1);
		CloseHandle(m_hThread);
	}
	else
	{
		m_hThread = NULL;
		cout << "...done." << endl;
	}
	return;
}

unsigned int __stdcall CFrameStoreCapture::CaptureThread(void * pArg)
{
	CFrameStoreCapture* pThis = (CFrameStoreCapture*)pArg;
	ULONG ScheduleID = 0;
	ULONG CapturingID = 0;
	ULONG DoneID = 0;
	ULONG StartFieldCount = 0;
	ULONG CurrentFieldCount = 0;
	ULONG LastFieldCount = 0;
	CFrame* pFrame = NULL;
#ifdef SIMULATE_FRAMEDROP_ON_CAPTURE_SIDE
	srand(4321);
	BLUE_INT32 iRandom = (rand()%200+1);
#endif

	pThis->m_pSDK->wait_input_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);	//this call just synchronises us to the card
	pThis->m_pSDK->render_buffer_capture(ScheduleID, 0);
	CapturingID = ScheduleID;
	ScheduleID = (++ScheduleID%4);
	LastFieldCount = CurrentFieldCount;

	pThis->m_pSDK->wait_input_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);	//the first buffer starts to be captured now; this is it's field count
	pThis->m_pSDK->render_buffer_capture(ScheduleID, 0);
	DoneID = CapturingID;
	CapturingID = ScheduleID;
	ScheduleID = (++ScheduleID%4);
	LastFieldCount = CurrentFieldCount;
	StartFieldCount = CurrentFieldCount;

	while(!pThis->m_nThreadStopping)
	{
		pThis->m_pSDK->wait_input_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
#ifdef SIMULATE_FRAMEDROP_ON_CAPTURE_SIDE
		if(!(CurrentFieldCount%iRandom))	//drop a frame every 1 to 200 frames by just waiting for an extra interrupt
		{
			pThis->m_pSDK->wait_input_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
			cout << "simulated frame drop (capture): " << (CurrentFieldCount-2) << endl;
			iRandom = (rand()%200+1);
		}
#endif
		pFrame = gCaptureFifo.GetFreeBuffer();

		if(pFrame)
		{
			pThis->m_pSDK->system_buffer_read_async((unsigned char*)pFrame->m_pBuffer,
																	pFrame->m_nSize,
																	NULL,
																	BlueImage_DMABuffer(DoneID, BLUE_DATA_IMAGE));
			
			//dispatch captured frame with
			//	-DoneID
			//	-LastFieldCount
			pFrame->m_lFieldCount = LastFieldCount;
			pFrame->m_nCardBufferID = DoneID;
			gCaptureFifo.PutLiveBuffer(pFrame);
		}
		else
			cout << "Capture: No free buffer" << endl;

		pThis->m_pSDK->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);

		if(LastFieldCount+2 < CurrentFieldCount)
			cout << "Frame dropped (capture). Should be " << (LastFieldCount+2) << ", is " << CurrentFieldCount << endl;

		DoneID = CapturingID;
		CapturingID = ScheduleID;
		ScheduleID = (++ScheduleID%4);
		LastFieldCount = CurrentFieldCount;
	}

	_endthreadex(0);
	return 0;
}
