#ifndef H_GUARD_FIFOCAPTURE
#define H_GUARD_FIFOCAPTURE


class CFifoCapture
{
public:
	CFifoCapture();
	~CFifoCapture();

	BLUE_INT32						Init(BLUE_INT32 CardNumber, BLUE_UINT32 VideoChannel, BLUE_UINT32 UpdateFormat, BLUE_UINT32 MemoryFormat, CFifoBuffer* pFifoBuffer);
	void							RouteChannel(ULONG Source, ULONG Destination, ULONG LinkType);
	unsigned int static __stdcall	CaptureThread(void * pArg);
	BLUE_INT32						InitThread();
	void							StartThread();
	void							StopThread();

public:
	CBlueVelvet4*	m_pSDK;
	BLUE_INT32		m_iDevices;
	BLUE_INT32		m_nIsAttached;
	BLUE_UINT32		m_nVideoMode;
	BLUE_UINT32		m_nUpdateFormat;
	BLUE_UINT32		m_nMemoryFormat;

	CFifoBuffer*	m_pFifoBuffer;

	HANDLE			m_hThread;
	BLUE_UINT32		m_nThreadStopping;

	OVERLAPPED		m_Overlap;
};

#endif	//H_GUARD_FIFOCAPTURE
