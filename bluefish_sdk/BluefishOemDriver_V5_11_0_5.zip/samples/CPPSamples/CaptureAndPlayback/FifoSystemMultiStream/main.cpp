// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	FifoSystemMultiStream
// Written by:			Tim Bragulla
// Date:				21 June 2012
//
// Brief description:	This sample application shows how to capture and playback (full duplex) two independent video streams using FIFO mode
//						For 3D capture and playback in FIFO mode please refer to the sample application FifoSystem3D
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

// main.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

CFifoBuffer gCaptureFifoChA;
CFifoBuffer gPlaybackFifoChA;
CFifoBuffer gCaptureFifoChB;
CFifoBuffer gPlaybackFifoChB;


struct MainThreadArgs
{
	CFifoBuffer*	pInputFifo;
	CFifoBuffer*	pOutputFifo;
	string			strChannel;
	BOOL			bDoRun;
	BOOL			bModifyCapturedFrame;	//if this flag is set to TRUE we will modify the capture frame before playing back (just for test purposes)
};

unsigned int __stdcall MainThread(void * pArg)
{
	MainThreadArgs* pParams = (MainThreadArgs*)pArg;
	CFrame* pFrameIn = NULL;
	CFrame* pFrameOut = NULL;
	BLUE_UINT32 FrameNumber = 0;
	BLUE_UINT32 Thickness = 100;	//in lines;
	cout << "Thread " << pParams->strChannel.c_str() << " running." << endl;

	while(pParams->bDoRun)
	{
		if(!pFrameIn)
			pFrameIn = pParams->pInputFifo->GetLiveBuffer();

		if(pFrameIn)
		{
			pFrameOut = pParams->pOutputFifo->GetFreeBuffer();
			if(pFrameOut)
			{
				//copy In to Out
				if(pFrameIn->m_nSize == pFrameOut->m_nSize)
				{
					if(pParams->bModifyCapturedFrame)
					{
						//the black line will only shift by 2 lines per update
						BlueMemZero((pFrameIn->m_pBuffer+pFrameIn->m_nSize/2+pFrameIn->m_nBytesPerLine*2*FrameNumber), pFrameIn->m_nBytesPerLine*Thickness);
						FrameNumber = (++FrameNumber%50);	//this is just arbitrary to get our "Animation" to use 50 frames before repeating
					}
					BlueMemCpy(pFrameOut->m_pBuffer, pFrameIn->m_pBuffer, pFrameIn->m_nSize);
					pFrameOut->m_lFieldCount = pFrameIn->m_lFieldCount;

					//cout << pParams->strChannel.c_str();
				}
				else
				{
					cout << "Input/Output buffers don't match!" << endl;
					pParams->bDoRun = FALSE;
					break;
				}
				pParams->pInputFifo->PutFreeBuffer(pFrameIn);
				pFrameIn = NULL;
				pParams->pOutputFifo->PutLiveBuffer(pFrameOut);
				pFrameOut = NULL;
			}
		}
	}

	cout << "Thread " << pParams->strChannel.c_str() << " exiting." << endl;
	_endthreadex(0);
	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	CFifoCapture*	pCaptureChA = new CFifoCapture();
	CFifoPlayback*	pPlaybackChA = new CFifoPlayback();
	CFifoCapture*	pCaptureChB = new CFifoCapture();
	CFifoPlayback*	pPlaybackChB = new CFifoPlayback();

	BLUE_UINT32 CardNumber = 1;

	if(!pCaptureChA || !pPlaybackChA || !pCaptureChB || !pPlaybackChB)
	{
		cout << "Can't create class" << endl;
		system("pause");
		return 0;
	}

	if(pCaptureChA->Init(CardNumber, BLUE_VIDEO_INPUT_CHANNEL_A, UPD_FMT_FRAME, MEM_FMT_BGRA, &gCaptureFifoChA))
	{
		cout << "Error on Init" << endl;
		delete pCaptureChA;
		delete pPlaybackChA;
		delete pCaptureChB;
		delete pPlaybackChB;
		system("pause");
		return 0;
	}
	pCaptureChA->RouteChannel(EPOCH_SRC_SDI_INPUT_A, EPOCH_DEST_INPUT_MEM_INTERFACE_CHA, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	if(pCaptureChB->Init(CardNumber, BLUE_VIDEO_INPUT_CHANNEL_B, UPD_FMT_FRAME, MEM_FMT_BGRA, &gCaptureFifoChB))
	{
		cout << "Error on Init" << endl;
		delete pCaptureChA;
		delete pPlaybackChA;
		delete pCaptureChB;
		delete pPlaybackChB;
		system("pause");
		return 0;
	}
	pCaptureChB->RouteChannel(EPOCH_SRC_SDI_INPUT_B, EPOCH_DEST_INPUT_MEM_INTERFACE_CHB, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	if(pPlaybackChA->Init(CardNumber, BLUE_VIDEO_OUTPUT_CHANNEL_A, UPD_FMT_FRAME, MEM_FMT_BGRA, VID_FMT_1080I_5000, &gPlaybackFifoChA))
	{
		cout << "Error on Init" << endl;
		delete pCaptureChA;
		delete pPlaybackChA;
		delete pCaptureChB;
		delete pPlaybackChB;
		system("pause");
		return 0;
	}
	pPlaybackChA->RouteChannel(EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	if(pPlaybackChB->Init(CardNumber, BLUE_VIDEO_OUTPUT_CHANNEL_B, UPD_FMT_FRAME, MEM_FMT_BGRA, VID_FMT_1080I_5000, &gPlaybackFifoChB))
	{
		cout << "Error on Init" << endl;
		delete pCaptureChA;
		delete pPlaybackChA;
		delete pCaptureChB;
		delete pPlaybackChB;
		system("pause");
		return 0;
	}
	pPlaybackChA->RouteChannel(EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	if(pCaptureChA->InitThread())
	{
		cout << "Error on Capture InitThread A" << endl;
		delete pCaptureChA;
		delete pPlaybackChA;
		delete pCaptureChB;
		delete pPlaybackChB;
		system("pause");
		return 0;
	}

	if(pCaptureChB->InitThread())
	{
		cout << "Error on Capture InitThread B" << endl;
		delete pCaptureChA;
		delete pPlaybackChA;
		delete pCaptureChB;
		delete pPlaybackChB;
		system("pause");
		return 0;
	}

	if(pPlaybackChA->InitThread())
	{
		cout << "Error on Playback InitThread A" << endl;
		delete pCaptureChA;
		delete pPlaybackChA;
		delete pCaptureChB;
		delete pPlaybackChB;
		system("pause");
		return 0;
	}

	if(pPlaybackChB->InitThread())
	{
		cout << "Error on Playback InitThread B" << endl;
		delete pCaptureChA;
		delete pPlaybackChA;
		delete pCaptureChB;
		delete pPlaybackChB;
		system("pause");
		return 0;
	}

	MainThreadArgs* pThreadParamsChA = new MainThreadArgs;
	MainThreadArgs* pThreadParamsChB = new MainThreadArgs;

	pThreadParamsChA->bDoRun = TRUE;
	pThreadParamsChA->bModifyCapturedFrame = TRUE;
	pThreadParamsChA->pInputFifo = &gCaptureFifoChA;
	pThreadParamsChA->pOutputFifo = &gPlaybackFifoChA;
	pThreadParamsChA->strChannel = "A";
	pThreadParamsChB->bDoRun = TRUE;
	pThreadParamsChB->bModifyCapturedFrame = TRUE;
	pThreadParamsChB->pInputFifo = &gCaptureFifoChB;
	pThreadParamsChB->pOutputFifo = &gPlaybackFifoChB;
	pThreadParamsChB->strChannel = "B";

	unsigned int ThreadIdChA = 0;
	HANDLE hMainThreadChA = (HANDLE)_beginthreadex(NULL, 0, &MainThread, pThreadParamsChA, CREATE_SUSPENDED, &ThreadIdChA);
	if(!hMainThreadChA)
	{
		cout << "Error starting Main Thread ChA" << endl;
		delete pCaptureChA;
		delete pPlaybackChA;
		delete pCaptureChB;
		delete pPlaybackChB;
		return 0;
	}

	unsigned int ThreadIdChB = 0;
	HANDLE hMainThreadChB = (HANDLE)_beginthreadex(NULL, 0, &MainThread, pThreadParamsChB, CREATE_SUSPENDED, &ThreadIdChB);
	if(!hMainThreadChB)
	{
		cout << "Error starting Main Thread ChB" << endl;
		delete pCaptureChA;
		delete pPlaybackChA;
		delete pCaptureChB;
		delete pPlaybackChB;
		return 0;
	}

	SetThreadPriority(hMainThreadChA, THREAD_PRIORITY_TIME_CRITICAL);
	SetThreadPriority(hMainThreadChB, THREAD_PRIORITY_TIME_CRITICAL);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "*********************************************" << endl;
	cout << "* Starting Threads Press any key to stop... *" << endl;
	cout << "*********************************************" << endl;

	pCaptureChA->StartThread();	//this actually just resumes the threads; it would take too long to start them from scracth
	pPlaybackChA->StartThread();	//that's why we created them before as suspended
	pCaptureChB->StartThread();
	pPlaybackChB->StartThread();

	ResumeThread(hMainThreadChA);
	ResumeThread(hMainThreadChB);

	while(!_kbhit())
	{
		Sleep(50);
	}

	pThreadParamsChA->bDoRun = FALSE;
	pThreadParamsChB->bDoRun = FALSE;
	DWORD dw = WaitForSingleObject(hMainThreadChA, -1);
	CloseHandle(hMainThreadChA);
	dw = WaitForSingleObject(hMainThreadChB, -1);
	CloseHandle(hMainThreadChB);

	pCaptureChA->StopThread();
	pPlaybackChA->StopThread();
	pCaptureChB->StopThread();
	pPlaybackChB->StopThread();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	delete pCaptureChA;
	pCaptureChA = NULL;
	delete pPlaybackChA;
	pPlaybackChA = NULL;

	delete pCaptureChB;
	pCaptureChB = NULL;
	delete pPlaybackChB;
	pPlaybackChB = NULL;

	delete pThreadParamsChA;
	pThreadParamsChA = NULL;
	delete pThreadParamsChB;
	pThreadParamsChB = NULL;

	system("pause");
	return 0;
}

