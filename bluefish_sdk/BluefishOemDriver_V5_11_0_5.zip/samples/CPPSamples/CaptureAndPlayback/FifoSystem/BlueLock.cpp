#include "stdafx.h"


BlueLock::BlueLock() :
	m_hMutex(NULL)
{
	m_hMutex = CreateMutex(NULL, FALSE, NULL);
}

BlueLock::~BlueLock()
{
	CloseHandle(m_hMutex);
}

void BlueLock::lock()
{
	WaitForSingleObject(m_hMutex, -1);
}

void BlueLock::unlock()
{
	ReleaseMutex(m_hMutex);
}
