#include "stdafx.h"

extern struct blue_videomode_info gVideoModeInfo[];
extern CFifoBuffer gCaptureFifo;
extern CFifoBuffer gPlaybackFifo;

CFifoPlayback::CFifoPlayback() :
	m_pSDK(NULL),
	m_iDevices(0),
	m_nIsAttached(0),
	m_nVideoMode(VID_FMT_INVALID),
	m_hThread(0),
	m_nThreadStopping(TRUE)
{
	m_pSDK = BlueVelvetFactory4();
	if(!m_pSDK)
		cout << "No Bluefish SDK" << endl;

	if(m_pSDK)
	{
		m_pSDK->device_enumerate(m_iDevices);
		if(!m_iDevices)
			cout << "No Bluefish card" << endl;
	}
}

CFifoPlayback::~CFifoPlayback()
{
	if(m_pSDK)
	{
		if(m_nIsAttached)
			m_pSDK->device_detach();
		BlueVelvetDestroy(m_pSDK);
	}
	m_pSDK = NULL;
}

BLUE_INT32 CFifoPlayback::Init(BLUE_INT32 CardNumber, BLUE_UINT32 VideoChannel, BLUE_UINT32 UpdateFormat, BLUE_UINT32 MemoryFormat, BLUE_UINT32 VideoMode)
{
	VARIANT varVal;
	BLUE_INT32 card_type = CRD_INVALID;

	if(m_nIsAttached)
	{
		m_pSDK->device_detach();
		m_nIsAttached = 0;
	}

	if(CardNumber <= 0 || CardNumber > m_iDevices)
	{
		cout << "Card " << CardNumber << " not available; maximum card number is: " << m_iDevices << endl;
		return -1;
	}

	m_pSDK->device_attach(CardNumber, 0);
	m_nIsAttached = 1;

	card_type = m_pSDK->has_video_cardtype();
	if(card_type != CRD_BLUE_EPOCH_HORIZON &&
		card_type != CRD_BLUE_EPOCH_CORE &&
		card_type != CRD_BLUE_EPOCH_ULTRA &&
		card_type != CRD_BLUE_EPOCH_2K_HORIZON &&
		card_type != CRD_BLUE_EPOCH_2K_CORE &&
		card_type != CRD_BLUE_EPOCH_2K_ULTRA &&
		card_type != CRD_BLUE_SUPER_NOVA &&
		card_type != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Not an Epoch/SuperNova card" << endl;
		m_pSDK->device_detach();
		m_nIsAttached = 0;
		return -1;
	}

	varVal.vt = VT_UI4;
	varVal.ulVal = VideoChannel;
	m_pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	
	if(VideoMode >= VID_FMT_INVALID)
	{
		cout << "Not a valid video mode" << endl;
		m_pSDK->device_detach();
		m_nIsAttached = 0;
		return -1;
	}

	varVal.ulVal = VideoMode;
	m_pSDK->SetCardProperty(VIDEO_MODE, varVal);
	m_pSDK->QueryCardProperty(VIDEO_MODE, varVal);
	if(VideoMode != varVal.ulVal)
	{
		cout << "Can't set video mode: " << gVideoModeInfo[m_nVideoMode].strVideoModeFriendlyName.c_str() << endl;
		m_pSDK->device_detach();
		m_nIsAttached = 0;
		return -1;
	}
	m_nVideoMode = varVal.ulVal;

	m_nUpdateFormat = UpdateFormat;
	varVal.ulVal = m_nUpdateFormat;
	m_pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	m_nMemoryFormat = MemoryFormat;
	varVal.ulVal = m_nMemoryFormat;
	m_pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	varVal.ulVal = VIDEO_ENGINE_PLAYBACK;
	m_pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	m_pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	ULONG GoldenSize = BlueVelvetGolden(m_nVideoMode, m_nMemoryFormat, m_nUpdateFormat);
	ULONG BytesPerLine = BlueVelvetLineBytes(m_nVideoMode, m_nMemoryFormat);
	gPlaybackFifo.Init(4, GoldenSize, BytesPerLine);

	return 0;
}

BLUE_INT32 CFifoPlayback::InitThread()
{
	unsigned int ThreadId = 0;

	if(m_hThread)
	{
		cout << "Playback Thread already started" << endl;
		return 0;
	}

	cout << "Starting Playback Thread..." << endl;
	m_hThread = (HANDLE)_beginthreadex(NULL, 0, &PlaybackThread, this, CREATE_SUSPENDED, &ThreadId);
	if(!m_hThread)
	{
		cout << "Error starting Playback Thread" << endl;
		return -1;
	}

	m_nThreadStopping = FALSE;
	SetThreadPriority(m_hThread, THREAD_PRIORITY_TIME_CRITICAL);
	cout << "...done." << endl;
	return 0;
}

void CFifoPlayback::StartThread()
{
	ResumeThread(m_hThread);
}

void CFifoPlayback::StopThread()
{
	DWORD dw = 0;

	if(m_hThread)
	{
		cout << "Stopping Playback Thread..." << endl;
		m_nThreadStopping = TRUE;
		dw = WaitForSingleObject(m_hThread, -1);
		CloseHandle(m_hThread);
	}
	else
	{
		m_hThread = NULL;
		cout << "...done." << endl;
	}
	return;
}

unsigned int __stdcall CFifoPlayback::PlaybackThread(void * pArg)
{
	CFifoPlayback* pThis = (CFifoPlayback*)pArg;
	ULONG BufferId = 0;
	ULONG CurrentFieldCount = 0;
	ULONG LastFieldCount = 0;
	ULONG LastBufferTimeStamp = 0;
	unsigned long* NotUsedAddress = NULL;
	unsigned long Underrun = 0;
	unsigned long LastUnderrun = 0;
	unsigned long UniqueId = 0;
	unsigned int nFramesTobuffer = 1;
	unsigned int nFramesPlayed = 0;
	BOOL bPlaybackStarted = FALSE;
	CFrame* pFrame = NULL;

	//make sure FIFO is not running
	pThis->m_pSDK->video_playback_stop(0, 0);

	pThis->m_pSDK->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
	LastFieldCount = CurrentFieldCount;
	while(!pThis->m_nThreadStopping)
	{
		if(!pFrame)
			pFrame = gPlaybackFifo.GetLiveBuffer();

		if(!pFrame)
		{
			cout << "Couldn't get buffer from Live queue" << endl;
			pThis->m_pSDK->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
			continue;
		}

		if(BLUE_OK(pThis->m_pSDK->video_playback_allocate((void**)&NotUsedAddress, BufferId, Underrun)))
		{
			pThis->m_pSDK->system_buffer_write_async((unsigned char*)pFrame->m_pBuffer,
																	pFrame->m_nSize,
																	NULL, 
																	BlueImage_DMABuffer(BufferId, BLUE_DATA_IMAGE));
			pThis->m_pSDK->video_playback_present(UniqueId, BlueBuffer_Image(BufferId), 1, 0, 0);
			nFramesPlayed++;

			gPlaybackFifo.PutFreeBuffer(pFrame);
			pFrame = NULL;

			if(bPlaybackStarted && Underrun != LastUnderrun)
				cout << "Frame dropped (playback). Current underruns: " << Underrun << endl;
			LastUnderrun = Underrun;

			if(nFramesTobuffer == nFramesPlayed)	//make sure that there is at least one frame buffered on the card before playback
			{
				cout << "Starting playback" << endl;
				pThis->m_pSDK->video_playback_start(0, 0);
				bPlaybackStarted = TRUE;
			}

			if(bPlaybackStarted)
				pThis->m_pSDK->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
		}
		else
			pThis->m_pSDK->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
	}
	pThis->m_pSDK->video_playback_stop(0, 0);

	_endthreadex(0);
	return 0;
}
