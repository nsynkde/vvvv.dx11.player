// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	FifoSystem
// Written by:			Tim Bragulla
// Date:				21 June 2012
//
// Brief description:	This sample application shows how to capture and playback (full duplex) a video stream using FIFO mode
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

// main.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

CFifoBuffer gCaptureFifo;
CFifoBuffer gPlaybackFifo;

int _tmain(int argc, _TCHAR* argv[])
{
	CFifoCapture*	pCapture = new CFifoCapture();
	CFifoPlayback*	pPlayback = new CFifoPlayback();
	BLUE_UINT32 CardNumber = 1;

	if(!pCapture || !pPlayback)
	{
		cout << "Can't create class" << endl;
		system("pause");
		return 0;
	}

	if(pCapture->Init(CardNumber, BLUE_VIDEO_INPUT_CHANNEL_A, UPD_FMT_FRAME, MEM_FMT_BGRA))
	{
		cout << "Error on Init" << endl;
		delete pCapture;
		delete pPlayback;
		system("pause");
		return 0;
	}

	if(pPlayback->Init(CardNumber, BLUE_VIDEO_OUTPUT_CHANNEL_A, UPD_FMT_FRAME, MEM_FMT_BGRA, VID_FMT_1080I_5000))
	{
		cout << "Error on Init" << endl;
		delete pCapture;
		delete pPlayback;
		system("pause");
		return 0;
	}

	if(pCapture->InitThread())
	{
		cout << "Error on Capture InitThread" << endl;
		delete pCapture;
		delete pPlayback;
		system("pause");
		return 0;
	}

	if(pPlayback->InitThread())
	{
		cout << "Error on Playback InitThread" << endl;
		delete pCapture;
		delete pPlayback;
		system("pause");
		return 0;
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	pCapture->StartThread();	//this actually just resumes the threads; it would take too long to start them from scracth
	pPlayback->StartThread();	//that's why we created them before as suspended

	BOOL bModifyCapturedFrame = FALSE;	//if this flag is set to TRUE we will modify the capture frame before playing back (just for test purposes)
	CFrame* pFrameIn = NULL;
	CFrame* pFrameOut = NULL;
	BLUE_UINT32 FrameNumber = 0;
	BLUE_UINT32 Thickness = 100;	//in lines;
	cout << "Threads running." << endl;
	while(!_kbhit())
	{
		if(!pFrameIn)
			pFrameIn = gCaptureFifo.GetLiveBuffer();

		if(pFrameIn)
		{
			pFrameOut = gPlaybackFifo.GetFreeBuffer();
			if(pFrameOut)
			{
				//copy In to Out
				if(pFrameIn->m_nSize == pFrameOut->m_nSize)
				{
					if(bModifyCapturedFrame)
					{
						//the black line will only shift by 2 lines per update
						BlueMemZero((pFrameIn->m_pBuffer+pFrameIn->m_nSize/2+pFrameIn->m_nBytesPerLine*2*FrameNumber), pFrameIn->m_nBytesPerLine*Thickness);
						FrameNumber = (++FrameNumber%50);	//this is just arbitrary to get our "Animation" to use 50 frames before repeating
					}
					BlueMemCpy(pFrameOut->m_pBuffer, pFrameIn->m_pBuffer, pFrameIn->m_nSize);
					pFrameOut->m_lFieldCount = pFrameIn->m_lFieldCount;
					cout << ".";
				}
				else
				{
					cout << "Input/Output buffers don't match!" << endl;
					break;
				}
				gCaptureFifo.PutFreeBuffer(pFrameIn);
				pFrameIn = NULL;
				gPlaybackFifo.PutLiveBuffer(pFrameOut);
				pFrameOut = NULL;
			}
		}
	}

	pCapture->StopThread();
	pPlayback->StopThread();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	delete pCapture;
	pCapture = NULL;
	delete pPlayback;
	pPlayback = NULL;

	system("pause");
	return 0;
}

