#ifndef H_GUARD_FRAMESTOREPLAYBACK
#define H_GUARD_FRAMESTOREPLAYBACK


class CFrameStorePlayback
{
public:
	CFrameStorePlayback();
	~CFrameStorePlayback();

	BLUE_INT32						Init(BLUE_INT32 CardNumber, BLUE_UINT32 UpdateFormat, BLUE_UINT32 MemoryFormat, BLUE_UINT32 VideoMode);
	unsigned int static __stdcall	PlaybackThread(void * pArg);
	BLUE_INT32						InitThread();
	void							StartThread();
	void							StopThread();

public:
	CBlueVelvet4*	m_pSDKLeft;
	CBlueVelvet4*	m_pSDKRight;
	BLUE_INT32		m_iDevices;
	BLUE_INT32		m_nIsAttached;
	BLUE_UINT32		m_nVideoMode;
	BLUE_UINT32		m_nUpdateFormat;
	BLUE_UINT32		m_nMemoryFormat;
	BLUE_UINT32		m_InvalidVideoModeFlag;

	HANDLE			m_hThread;
	BLUE_UINT32		m_nThreadStopping;
};

#endif	//H_GUARD_FRAMESTOREPLAYBACK
