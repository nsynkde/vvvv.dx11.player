#include "stdafx.h"

extern struct blue_videomode_info gVideoModeInfo[];
extern CFifoBuffer gCaptureFifo;
extern CFifoBuffer gPlaybackFifo;

CFifoPlayback::CFifoPlayback() :
	m_pSDKLeft(NULL),
	m_pSDKRight(NULL),
	m_iDevices(0),
	m_nIsAttached(0),
	m_nVideoMode(VID_FMT_INVALID),
	m_InvalidVideoModeFlag(VID_FMT_INVALID),
	m_hThread(0),
	m_nThreadStopping(TRUE)
{
	m_pSDKLeft = BlueVelvetFactory4();
	m_pSDKRight = BlueVelvetFactory4();
	if(!m_pSDKLeft || !m_pSDKRight)
		cout << "No Bluefish SDK" << endl;

	if(m_pSDKLeft && m_pSDKRight)
	{
		m_pSDKLeft->device_enumerate(m_iDevices);
		if(!m_iDevices)
			cout << "No Bluefish card" << endl;
	}
}

CFifoPlayback::~CFifoPlayback()
{
	if(m_pSDKLeft)
	{
		if(m_nIsAttached)
			m_pSDKLeft->device_detach();
		BlueVelvetDestroy(m_pSDKLeft);
	}
	if(m_pSDKRight)
	{
		if(m_nIsAttached)
			m_pSDKRight->device_detach();
		BlueVelvetDestroy(m_pSDKRight);
	}

	m_pSDKLeft = NULL;
	m_pSDKRight = NULL;
}

BLUE_INT32 CFifoPlayback::Init(BLUE_INT32 CardNumber, BLUE_UINT32 UpdateFormat, BLUE_UINT32 MemoryFormat, BLUE_UINT32 VideoMode)
{
	VARIANT varVal;
	BLUE_INT32 card_type = CRD_INVALID;

	if(m_nIsAttached)
	{
		m_pSDKLeft->device_detach();
		m_pSDKRight->device_detach();
		m_nIsAttached = 0;
	}

	if(CardNumber <= 0 || CardNumber > m_iDevices)
	{
		cout << "Card " << CardNumber << " not available; maximum card number is: " << m_iDevices << endl;
		return -1;
	}

	m_pSDKLeft->device_attach(CardNumber, 0);
	m_pSDKRight->device_attach(CardNumber, 0);
	m_nIsAttached = 1;

	card_type = m_pSDKLeft->has_video_cardtype();
	if(	card_type != CRD_BLUE_EPOCH_2K_HORIZON &&
		card_type != CRD_BLUE_EPOCH_2K_CORE &&
		card_type != CRD_BLUE_EPOCH_2K_ULTRA &&
		card_type != CRD_BLUE_SUPER_NOVA &&
		card_type != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Not an Epoch/SuperNova card or does not support two channels" << endl;
		m_pSDKLeft->device_detach();
		m_pSDKRight->device_detach();
		m_nIsAttached = 0;
		return -1;
	}

	varVal.vt = VT_UI4;
	varVal.ulVal = BLUE_VIDEO_OUTPUT_CHANNEL_A;
	m_pSDKLeft->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);
	varVal.ulVal = BLUE_VIDEO_OUTPUT_CHANNEL_B;
	m_pSDKRight->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	m_pSDKLeft->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	m_InvalidVideoModeFlag = varVal.ulVal;

	varVal.ulVal = EPOCH_SET_ROUTING(EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	m_pSDKLeft->SetCardProperty(MR2_ROUTING, varVal);
	varVal.ulVal = EPOCH_SET_ROUTING(EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	m_pSDKRight->SetCardProperty(MR2_ROUTING, varVal);
	
	if(VideoMode >= m_InvalidVideoModeFlag)
	{
		cout << "Not a valid video mode" << endl;
		m_pSDKLeft->device_detach();
		m_pSDKRight->device_detach();
		m_nIsAttached = 0;
		return -1;
	}

	varVal.ulVal = VideoMode;
	m_pSDKLeft->SetCardProperty(VIDEO_MODE, varVal);
	m_pSDKLeft->QueryCardProperty(VIDEO_MODE, varVal);
	if(VideoMode != varVal.ulVal)
	{
		cout << "Can't set video mode A: " << gVideoModeInfo[m_nVideoMode].strVideoModeFriendlyName.c_str() << endl;
		m_pSDKLeft->device_detach();
		m_pSDKRight->device_detach();
		m_nIsAttached = 0;
		return -1;
	}

	varVal.ulVal = VideoMode;
	m_pSDKRight->SetCardProperty(VIDEO_MODE, varVal);
	m_pSDKRight->QueryCardProperty(VIDEO_MODE, varVal);
	if(VideoMode != varVal.ulVal)
	{
		cout << "Can't set video mode B: " << gVideoModeInfo[m_nVideoMode].strVideoModeFriendlyName.c_str() << endl;
		m_pSDKLeft->device_detach();
		m_pSDKRight->device_detach();
		m_nIsAttached = 0;
		return -1;
	}
	m_nVideoMode = varVal.ulVal;

	m_nUpdateFormat = UpdateFormat;
	varVal.ulVal = m_nUpdateFormat;
	m_pSDKLeft->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);
	varVal.ulVal = m_nUpdateFormat;
	m_pSDKRight->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	m_nMemoryFormat = MemoryFormat;
	varVal.ulVal = m_nMemoryFormat;
	m_pSDKLeft->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);
	varVal.ulVal = m_nMemoryFormat;
	m_pSDKRight->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	varVal.ulVal = VIDEO_ENGINE_PLAYBACK;
	m_pSDKLeft->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);
	varVal.ulVal = VIDEO_ENGINE_PLAYBACK;
	m_pSDKRight->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	m_pSDKLeft->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	m_pSDKRight->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	ULONG GoldenSize = BlueVelvetGolden(m_nVideoMode, m_nMemoryFormat, m_nUpdateFormat);
	ULONG BytesPerLine = BlueVelvetLineBytes(m_nVideoMode, m_nMemoryFormat);
	gPlaybackFifo.Init(4, GoldenSize, BytesPerLine);

	return 0;
}

BLUE_INT32 CFifoPlayback::InitThread()
{
	unsigned int ThreadId = 0;

	if(m_hThread)
	{
		cout << "Playback Thread already started" << endl;
		return 0;
	}

	cout << "Starting Playback Thread..." << endl;
	m_hThread = (HANDLE)_beginthreadex(NULL, 0, &PlaybackThread, this, CREATE_SUSPENDED, &ThreadId);
	if(!m_hThread)
	{
		cout << "Error starting Playback Thread" << endl;
		return -1;
	}

	m_nThreadStopping = FALSE;
	SetThreadPriority(m_hThread, THREAD_PRIORITY_TIME_CRITICAL);
	cout << "...done." << endl;
	return 0;
}

void CFifoPlayback::StartThread()
{
	ResumeThread(m_hThread);
}

void CFifoPlayback::StopThread()
{
	DWORD dw = 0;

	if(m_hThread)
	{
		cout << "Stopping Playback Thread..." << endl;
		m_nThreadStopping = TRUE;
		dw = WaitForSingleObject(m_hThread, -1);
		CloseHandle(m_hThread);
	}
	else
	{
		m_hThread = NULL;
		cout << "...done." << endl;
	}
	return;
}

unsigned int __stdcall CFifoPlayback::PlaybackThread(void * pArg)
{
	CFifoPlayback* pThis = (CFifoPlayback*)pArg;
	ULONG BufferIdChA = 0;
	ULONG BufferIdChB = 0;
	ULONG CurrentFieldCount = 0;
	ULONG LastFieldCount = 0;
	ULONG LastBufferTimeStamp = 0;
	unsigned long* NotUsedAddress = NULL;
	unsigned long UnderrunChA = 0;
	unsigned long UnderrunChB = 0;
	unsigned long LastUnderrunChA = 0;
	unsigned long LastUnderrunChB = 0;
	unsigned long UniqueIdChA = 0;
	unsigned long UniqueIdChB = 0;
	unsigned int nFramesTobuffer = 1;
	unsigned int nFramesPlayed = 0;
	BOOL bPlaybackStarted = FALSE;
	CFrame* pFrame = NULL;
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//make sure FIFO is not running
	pThis->m_pSDKLeft->video_playback_stop(0, 0);
	pThis->m_pSDKRight->video_playback_stop(0, 0);

	pThis->m_pSDKLeft->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
	LastFieldCount = CurrentFieldCount;
	while(!pThis->m_nThreadStopping)
	{
		if(!pFrame)
			pFrame = gPlaybackFifo.GetLiveBuffer();

		if(!pFrame)
		{
			cout << "Couldn't get buffer from Live queue (playback)" << endl;
			pThis->m_pSDKLeft->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
			continue;
		}

		if(BLUE_OK(pThis->m_pSDKLeft->video_playback_allocate((void**)&NotUsedAddress, BufferIdChA, UnderrunChA)))
		{
			if(BLUE_OK(pThis->m_pSDKRight->video_playback_allocate((void**)&NotUsedAddress, BufferIdChB, UnderrunChB)))
			{

				pThis->m_pSDKLeft->system_buffer_write_async((unsigned char*)pFrame->m_pBufferLeft,
																		pFrame->m_nSize,
																		NULL, 
																		BlueImage_DMABuffer(BufferIdChA, BLUE_DATA_IMAGE));
				pThis->m_pSDKRight->system_buffer_write_async((unsigned char*)pFrame->m_pBufferRight,
																		pFrame->m_nSize,
																		NULL, 
																		BlueImage_DMABuffer(BufferIdChB, BLUE_DATA_IMAGE));

				pThis->m_pSDKLeft->video_playback_present(UniqueIdChA, BlueBuffer_Image(BufferIdChA), 1, 0);
				pThis->m_pSDKRight->video_playback_present(UniqueIdChB, BlueBuffer_Image(BufferIdChB), 1, 0);
				nFramesPlayed++;

				gPlaybackFifo.PutFreeBuffer(pFrame);
				pFrame = NULL;

				if(bPlaybackStarted && ((UnderrunChA != LastUnderrunChA) || (UnderrunChB != LastUnderrunChB)))
					cout << "Frame dropped (playback). Current underruns: " << UnderrunChA << " (A), " << UnderrunChA << " (B)" << endl;
				LastUnderrunChA = UnderrunChA;
				LastUnderrunChB = UnderrunChB;

				if(nFramesTobuffer == nFramesPlayed)	//make sure that there is at least one frame buffered on the card before playback
				{
					cout << "Starting playback" << endl;
					if(BLUE_FAIL(pThis->m_pSDKLeft->video_playback_start(0, 0)))
						cout << "Error video playback start failed on left channel" << endl;

					if(BLUE_FAIL(pThis->m_pSDKRight->video_playback_start(0, 0)))
						cout << "Error video playback start failed on right channel" << endl;

					bPlaybackStarted = TRUE;
				}

				if(bPlaybackStarted)
					pThis->m_pSDKLeft->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
			}
			else
			{
				pThis->m_pSDKLeft->video_playback_release(BufferIdChA);	 // we can't use this buffer now as we didn't get one for channel B as well (shouldn't happen)
				cout << "Error getting buffer for channel B" << endl;
			}
		}
		else
		{
			cout << "Allocate A failed" << endl;
			pThis->m_pSDKLeft->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
		}
	}
	pThis->m_pSDKLeft->video_playback_stop(0, 0);
	pThis->m_pSDKRight->video_playback_stop(0, 0);

	_endthreadex(0);
	return 0;
}
