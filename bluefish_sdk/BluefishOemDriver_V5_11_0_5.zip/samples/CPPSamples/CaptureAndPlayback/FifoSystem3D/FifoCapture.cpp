#include "stdafx.h"

extern struct blue_videomode_info gVideoModeInfo[];
extern CFifoBuffer gCaptureFifo;
extern CFifoBuffer gPlaybackFifo;

CFifoCapture::CFifoCapture() :
	m_pSDKLeft(NULL),
	m_pSDKRight(NULL),
	m_iDevices(0),
	m_nIsAttached(0),
	m_nVideoMode(VID_FMT_INVALID),
	m_InvalidVideoModeFlag(VID_FMT_INVALID),
	m_hThread(0),
	m_nThreadStopping(TRUE)
{
	m_pSDKLeft = BlueVelvetFactory4();
	m_pSDKRight = BlueVelvetFactory4();
	if(!m_pSDKLeft || !m_pSDKRight)
		cout << "No Bluefish SDK" << endl;

	if(m_pSDKLeft && m_pSDKRight)
	{
		m_pSDKLeft->device_enumerate(m_iDevices);
		if(!m_iDevices)
			cout << "No Bluefish card" << endl;
	}
}

CFifoCapture::~CFifoCapture()
{
	if(m_pSDKLeft)
	{
		if(m_nIsAttached)
			m_pSDKLeft->device_detach();
		BlueVelvetDestroy(m_pSDKLeft);
	}
	if(m_pSDKRight)
	{
		if(m_nIsAttached)
			m_pSDKRight->device_detach();
		BlueVelvetDestroy(m_pSDKRight);
	}

	m_pSDKLeft = NULL;
	m_pSDKRight = NULL;
}

BLUE_INT32 CFifoCapture::Init(BLUE_INT32 CardNumber, BLUE_UINT32 UpdateFormat, BLUE_UINT32 MemoryFormat)
{
	ULONG FieldCount = 0;
	VARIANT varVal;
	BLUE_INT32 card_type = CRD_INVALID;

	if(!m_pSDKLeft || !m_pSDKRight)
		return -1;

	if(m_nIsAttached)
	{
		m_pSDKLeft->device_detach();
		m_pSDKRight->device_detach();
		m_nIsAttached = 0;
	}

	if(CardNumber <= 0 || CardNumber > m_iDevices)
	{
		cout << "Card " << CardNumber << " not available; maximum card number is: " << m_iDevices << endl;
		return -1;
	}

	m_pSDKLeft->device_attach(CardNumber, 0);
	m_pSDKRight->device_attach(CardNumber, 0);
	m_nIsAttached = 1;

	card_type = m_pSDKLeft->has_video_cardtype();
	if(	card_type != CRD_BLUE_EPOCH_2K_HORIZON &&
		card_type != CRD_BLUE_EPOCH_2K_CORE &&
		card_type != CRD_BLUE_EPOCH_2K_ULTRA &&
		card_type != CRD_BLUE_SUPER_NOVA &&
		card_type != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Not an Epoch/SuperNova card or does not support two channels" << endl;
		m_pSDKLeft->device_detach();
		m_pSDKRight->device_detach();
		m_nIsAttached = 0;
		return -1;
	}

	varVal.vt = VT_UI4;
	varVal.ulVal = BLUE_VIDEO_INPUT_CHANNEL_A;
	m_pSDKLeft->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);
	varVal.ulVal = BLUE_VIDEO_INPUT_CHANNEL_B;
	m_pSDKRight->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

	m_pSDKLeft->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	m_InvalidVideoModeFlag = varVal.ulVal;

	varVal.ulVal = EPOCH_SET_ROUTING(EPOCH_SRC_SDI_INPUT_A, EPOCH_DEST_INPUT_MEM_INTERFACE_CHA, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	m_pSDKLeft->SetCardProperty(MR2_ROUTING, varVal);
	varVal.ulVal = EPOCH_SET_ROUTING(EPOCH_SRC_SDI_INPUT_B, EPOCH_DEST_INPUT_MEM_INTERFACE_CHB, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	m_pSDKRight->SetCardProperty(MR2_ROUTING, varVal);

	m_pSDKLeft->wait_input_video_synch(UPD_FMT_FRAME, FieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	varVal.vt = VT_UI4;
	m_pSDKLeft->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	if(varVal.ulVal >= m_InvalidVideoModeFlag)
	{
		cout << "No valid input signal A" << endl;
		m_pSDKLeft->device_detach();
		m_pSDKRight->device_detach();
		m_nIsAttached = 0;
		return -1;
	}
	m_nVideoMode = varVal.ulVal;
	m_pSDKRight->wait_input_video_synch(UPD_FMT_FRAME, FieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	varVal.vt = VT_UI4;
	m_pSDKRight->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	if((varVal.ulVal >= m_InvalidVideoModeFlag) || (varVal.ulVal != m_nVideoMode))
	{
		cout << "No valid input signal B or does not match channel A input" << endl;
		m_pSDKLeft->device_detach();
		m_pSDKRight->device_detach();
		m_nIsAttached = 0;
		return -1;
	}
	m_nVideoMode = varVal.ulVal;
	cout << "Video Input mode: " << gVideoModeInfo[m_nVideoMode].strVideoModeFriendlyName.c_str() << endl;

	m_nUpdateFormat = UpdateFormat;
	varVal.ulVal = m_nUpdateFormat;
	m_pSDKLeft->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);
	varVal.ulVal = m_nUpdateFormat;
	m_pSDKRight->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);

	m_nMemoryFormat = MemoryFormat;
	varVal.ulVal = m_nMemoryFormat;
	m_pSDKLeft->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);
	varVal.ulVal = m_nMemoryFormat;
	m_pSDKRight->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);

	varVal.ulVal = VIDEO_ENGINE_DUPLEX;	//do not set it to VIDEO_ENGINE_CAPTURE as this will automatically do a playthrough and this will conflict with our playback thread
	m_pSDKLeft->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);
	varVal.ulVal = VIDEO_ENGINE_DUPLEX;
	m_pSDKRight->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);

	ULONG GoldenSize = BlueVelvetGolden(m_nVideoMode, m_nMemoryFormat, m_nUpdateFormat);
	ULONG BytesPerLine = BlueVelvetLineBytes(m_nVideoMode, m_nMemoryFormat);
	gCaptureFifo.Init(4, GoldenSize, BytesPerLine);

	::ZeroMemory(&m_OverlapChA, sizeof(m_OverlapChA));
	m_OverlapChB.hEvent = ::CreateEvent( NULL, TRUE, FALSE, NULL );
	::ZeroMemory(&m_OverlapChA, sizeof(m_OverlapChA));
	m_OverlapChA.hEvent = ::CreateEvent( NULL, TRUE, FALSE, NULL );

	return 0;
}

BLUE_INT32 CFifoCapture::InitThread()
{
	unsigned int ThreadId = 0;

	if(m_hThread)
	{
		cout << "Capture Thread already started" << endl;
		return 0;
	}

	cout << "Starting Capture Thread..." << endl;
	m_hThread = (HANDLE)_beginthreadex(NULL, 0, &CaptureThread, this, CREATE_SUSPENDED, &ThreadId);
	if(!m_hThread)
	{
		cout << "Error starting Capture Thread" << endl;
		return -1;
	}

	m_nThreadStopping = FALSE;
	SetThreadPriority(m_hThread, THREAD_PRIORITY_TIME_CRITICAL);
	cout << "...done." << endl;
	return 0;
}

void CFifoCapture::StartThread()
{
	ResumeThread(m_hThread);
}

void CFifoCapture::StopThread()
{
	DWORD dw = 0;

	if(m_hThread)
	{
		cout << "Stopping Capture Thread..." << endl;
		m_nThreadStopping = TRUE;
		dw = WaitForSingleObject(m_hThread, -1);
		CloseHandle(m_hThread);
	}
	else
	{
		m_hThread = NULL;
		cout << "...done." << endl;
	}
	return;
}

unsigned int __stdcall CFifoCapture::CaptureThread(void * pArg)
{
	CFifoCapture* pThis = (CFifoCapture*)pArg;
	ULONG CurrentFieldCount = 0;
	ULONG LastFieldCount = 0;
	CFrame* pFrame = NULL;
	struct blue_videoframe_info_ex FrameInfoChA;
	struct blue_videoframe_info_ex FrameInfoChB;
	int	NotUsedCompostLater = 0;
	unsigned int CaptureFifoSizeChA = 0;
	unsigned int CaptureFifoSizeChB = 0;
	BOOL bFirstFrame = TRUE;
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//reset the field count for all input channels
	varVal.ulVal = 0;
	pThis->m_pSDKLeft->SetCardProperty(EPOCH_RESET_VIDEO_INPUT_FIELDCOUNT, varVal);
	//and wait one interrupt to take effect
	pThis->m_pSDKLeft->wait_input_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount); 

	pThis->m_pSDKLeft->video_capture_start();
	pThis->m_pSDKRight->video_capture_start();
	while(!pThis->m_nThreadStopping)
	{
		if(!pFrame)
			pFrame = gCaptureFifo.GetFreeBuffer();

		if(!pFrame)
			continue;

		pThis->m_pSDKLeft->wait_input_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);

		if(BLUE_FAIL(GetVideo_CaptureFrameInfoEx(pThis->m_pSDKLeft, &pThis->m_OverlapChA, FrameInfoChA, NotUsedCompostLater, &CaptureFifoSizeChA)) ||
			(FrameInfoChA.nVideoSignalType >= pThis->m_InvalidVideoModeFlag) || (FrameInfoChA.BufferId == -1))
		{
			cout << "continue A" << endl;
			continue;
		}

		if(BLUE_FAIL(GetVideo_CaptureFrameInfoEx(pThis->m_pSDKRight, &pThis->m_OverlapChB, FrameInfoChB, NotUsedCompostLater, &CaptureFifoSizeChB)) ||
			(FrameInfoChB.nVideoSignalType >= pThis->m_InvalidVideoModeFlag) || (FrameInfoChB.BufferId == -1))
		{
			cout << "continue B" << endl;
			continue;
		}

		while((FrameInfoChA.nFrameTimeStamp != FrameInfoChB.nFrameTimeStamp) && !_kbhit())
		{
			cout << "Re-synching: " << FrameInfoChA.nFrameTimeStamp << ", " << FrameInfoChB.nFrameTimeStamp << endl;
			if(FrameInfoChA.nFrameTimeStamp < FrameInfoChB.nFrameTimeStamp)
			{
				if(BLUE_FAIL(GetVideo_CaptureFrameInfoEx(pThis->m_pSDKLeft, &pThis->m_OverlapChA, FrameInfoChA, 0 ,&CaptureFifoSizeChA)))
					break;
			}
			else if(FrameInfoChA.nFrameTimeStamp > FrameInfoChB.nFrameTimeStamp)
			{
				if(BLUE_FAIL(GetVideo_CaptureFrameInfoEx(pThis->m_pSDKRight, &pThis->m_OverlapChB, FrameInfoChB, 0 ,&CaptureFifoSizeChB)))
					break;
			}
		}

		if(FrameInfoChA.nFrameTimeStamp != FrameInfoChB.nFrameTimeStamp)
		{
			cout << "Error: not in synch: " << FrameInfoChA.nFrameTimeStamp << ", " << FrameInfoChB.nFrameTimeStamp << endl;
			continue;
		}

		pThis->m_pSDKLeft->system_buffer_read_async((unsigned char*)pFrame->m_pBufferLeft,
																pFrame->m_nSize,
																NULL,
																BlueImage_DMABuffer(FrameInfoChA.BufferId, BLUE_DATA_IMAGE));
		pThis->m_pSDKRight->system_buffer_read_async((unsigned char*)pFrame->m_pBufferRight,
																pFrame->m_nSize,
																NULL,
																BlueImage_DMABuffer(FrameInfoChA.BufferId, BLUE_DATA_IMAGE));

		CurrentFieldCount = FrameInfoChA.nFrameTimeStamp;
		if(!bFirstFrame && LastFieldCount + 2 < CurrentFieldCount)
			cout << "Dropped a frame, FC expected: " << (LastFieldCount + 2) << ", current FC: " << CurrentFieldCount << endl;
		LastFieldCount = CurrentFieldCount;

		pFrame->m_lFieldCountChA = FrameInfoChA.nFrameTimeStamp;
		pFrame->m_lFieldCountChB = FrameInfoChB.nFrameTimeStamp;
		pFrame->m_nCardBufferIDChA = FrameInfoChA.BufferId;
		pFrame->m_nCardBufferIDChB = FrameInfoChB.BufferId;
		gCaptureFifo.PutLiveBuffer(pFrame);
		pFrame = NULL;
		bFirstFrame = FALSE;
	}
	pThis->m_pSDKLeft->video_capture_stop();
	pThis->m_pSDKRight->video_capture_stop();

	_endthreadex(0);
	return 0;
}
