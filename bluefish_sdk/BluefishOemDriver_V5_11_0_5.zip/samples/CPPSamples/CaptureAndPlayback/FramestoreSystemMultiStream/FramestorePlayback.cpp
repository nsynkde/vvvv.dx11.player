#include "stdafx.h"

extern struct blue_videomode_info gVideoModeInfo[];


CFrameStorePlayback::CFrameStorePlayback() :
	m_pSDK(NULL),
	m_iDevices(0),
	m_nIsAttached(0),
	m_nVideoMode(VID_FMT_INVALID),
	m_pFifoBuffer(NULL),
	m_hThread(0),
	m_nThreadStopping(TRUE)
{
	m_pSDK = BlueVelvetFactory4();
	if(!m_pSDK)
		cout << "No Bluefish SDK" << endl;

	if(m_pSDK)
	{
		m_pSDK->device_enumerate(m_iDevices);
		if(!m_iDevices)
			cout << "No Bluefish card" << endl;
	}
}

CFrameStorePlayback::~CFrameStorePlayback()
{
	if(m_pSDK)
	{
		if(m_nIsAttached)
			m_pSDK->device_detach();
		BlueVelvetDestroy(m_pSDK);
	}
	m_pSDK = NULL;
}

BLUE_INT32 CFrameStorePlayback::Init(BLUE_INT32 CardNumber, BLUE_UINT32 VideoChannel, BLUE_UINT32 UpdateFormat, BLUE_UINT32 MemoryFormat, BLUE_UINT32 VideoMode, CFifoBuffer* pFifoBuffer)
{
	VARIANT varVal;
	BLUE_INT32 card_type = CRD_INVALID;

	if(m_nIsAttached)
	{
		m_pSDK->device_detach();
		m_nIsAttached = 0;
	}

	if(CardNumber <= 0 || CardNumber > m_iDevices)
	{
		cout << "Card " << CardNumber << " not available; maximum card number is: " << m_iDevices << endl;
		return -1;
	}

	m_pSDK->device_attach(CardNumber, 0);
	m_nIsAttached = 1;

	card_type = m_pSDK->has_video_cardtype();
	if(card_type != CRD_BLUE_EPOCH_HORIZON &&
		card_type != CRD_BLUE_EPOCH_CORE &&
		card_type != CRD_BLUE_EPOCH_ULTRA &&
		card_type != CRD_BLUE_EPOCH_2K_HORIZON &&
		card_type != CRD_BLUE_EPOCH_2K_CORE &&
		card_type != CRD_BLUE_EPOCH_2K_ULTRA &&
		card_type != CRD_BLUE_SUPER_NOVA &&
		card_type != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Not an Epoch/SuperNova card" << endl;
		m_pSDK->device_detach();
		m_nIsAttached = 0;
		return -1;
	}

	varVal.vt = VT_UI4;
	varVal.ulVal = VideoChannel;
	m_pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	
	if(VideoMode >= VID_FMT_INVALID)
	{
		cout << "Not a valid video mode" << endl;
		m_pSDK->device_detach();
		m_nIsAttached = 0;
		return -1;
	}

	varVal.ulVal = VideoMode;
	m_pSDK->SetCardProperty(VIDEO_MODE, varVal);
	m_pSDK->QueryCardProperty(VIDEO_MODE, varVal);
	if(VideoMode != varVal.ulVal)
	{
		cout << "Can't set video mode: " << gVideoModeInfo[m_nVideoMode].strVideoModeFriendlyName.c_str() << endl;
		m_pSDK->device_detach();
		m_nIsAttached = 0;
		return -1;
	}
	m_nVideoMode = varVal.ulVal;

	m_nUpdateFormat = UpdateFormat;
	varVal.ulVal = m_nUpdateFormat;
	m_pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	m_nMemoryFormat = MemoryFormat;
	varVal.ulVal = m_nMemoryFormat;
	m_pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	varVal.ulVal = VIDEO_ENGINE_FRAMESTORE;
	m_pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	m_pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	ULONG GoldenSize = BlueVelvetGolden(m_nVideoMode, m_nMemoryFormat, m_nUpdateFormat);
	ULONG BytesPerLine = BlueVelvetLineBytes(m_nVideoMode, m_nMemoryFormat);
	m_pFifoBuffer = pFifoBuffer;
	m_pFifoBuffer->Init(4, GoldenSize, BytesPerLine);

	return 0;
}

void CFrameStorePlayback::RouteChannel(ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	m_pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

BLUE_INT32 CFrameStorePlayback::InitThread()
{
	unsigned int ThreadId = 0;

	if(m_hThread)
	{
		cout << "Playback Thread already started" << endl;
		return 0;
	}

	cout << "Starting Playback Thread..." << endl;
	m_hThread = (HANDLE)_beginthreadex(NULL, 0, &PlaybackThread, this, CREATE_SUSPENDED, &ThreadId);
	if(!m_hThread)
	{
		cout << "Error starting Playback Thread" << endl;
		return -1;
	}

	m_nThreadStopping = FALSE;
	SetThreadPriority(m_hThread, THREAD_PRIORITY_TIME_CRITICAL);
	cout << "...done." << endl;
	return 0;
}

void CFrameStorePlayback::StartThread()
{
	ResumeThread(m_hThread);
}

void CFrameStorePlayback::StopThread()
{
	DWORD dw = 0;

	if(m_hThread)
	{
		cout << "Stopping Playback Thread..." << endl;
		m_nThreadStopping = TRUE;
		dw = WaitForSingleObject(m_hThread, -1);
		CloseHandle(m_hThread);
	}
	else
	{
		m_hThread = NULL;
		cout << "...done." << endl;
	}
	return;
}

unsigned int __stdcall CFrameStorePlayback::PlaybackThread(void * pArg)
{
	CFrameStorePlayback* pThis = (CFrameStorePlayback*)pArg;
	ULONG BufferId = 0;
	ULONG CurrentFieldCount = 0;
	ULONG LastFieldCount = 0;
	ULONG LastBufferTimeStamp = 0;
	CFrame* pFrame = NULL;
#ifdef SIMULATE_FRAMEDROP_ON_PLAYBACK_SIDE
	srand(1234);
	BLUE_INT32 iRandom = (rand()%200+1);
#endif

	pThis->m_pSDK->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
	LastFieldCount = CurrentFieldCount;
	while(!pThis->m_nThreadStopping)
	{
		pThis->m_pSDK->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
#ifdef SIMULATE_FRAMEDROP_ON_PLAYBACK_SIDE
		if(!(CurrentFieldCount%iRandom))	//drop a frame every 1 to 200 frames by just waiting for an extra interrupt
		{
			pThis->m_pSDK->wait_output_video_synch(pThis->m_nUpdateFormat, CurrentFieldCount);
			cout << "simulated frame drop (playback): " << (CurrentFieldCount-2) << endl;
			iRandom = (rand()%200+1);
		}
#endif
		if(LastFieldCount+2 < CurrentFieldCount)
			cout << "Frame dropped (playback). Should be " << (LastFieldCount+2) << ", is " << CurrentFieldCount << endl;

		pFrame = pThis->m_pFifoBuffer->GetLiveBuffer();
		if(pFrame)
		{
			if(LastBufferTimeStamp)
			{
				if(LastBufferTimeStamp+2 < pFrame->m_lFieldCount)
					cout << "Missing frame in playback Fifo: should be " << (LastBufferTimeStamp+2) << ", is " << pFrame->m_lFieldCount << endl;
			}
			LastBufferTimeStamp = pFrame->m_lFieldCount;
			pThis->m_pSDK->system_buffer_write_async((unsigned char*)pFrame->m_pBuffer,
																	pFrame->m_nSize,
																	NULL,
																	BlueImage_DMABuffer(BufferId, BLUE_DATA_IMAGE));
			pThis->m_pFifoBuffer->PutFreeBuffer(pFrame);
			pThis->m_pSDK->render_buffer_update(BlueBuffer_Image(BufferId));

			BufferId = (++BufferId%2); //only update the buffer ID if we actually manage to update the buffer with a new frame
		}
		LastFieldCount = CurrentFieldCount;
	}

	_endthreadex(0);
	return 0;
}
