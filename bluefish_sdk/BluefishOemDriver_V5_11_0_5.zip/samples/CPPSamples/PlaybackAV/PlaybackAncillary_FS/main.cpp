// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	PlaybackAncillary_FS
// Written by:			Tim Bragulla
// Date:				20 June 2012
//
// Brief description:	This sample application shows how to playback a video stream, VBI/VANC data and Embedded Audio using FRAMESTORE mode
//						VBI is only available in SD video modes and takes the same memory format as the video data
//						VANC is only available in HD video modes and is always in V210 memory format
//						The SDK macros tend to be named VBI, but are also used for VANC
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"


#define HANC_BUFFER_SIZE (256*1024)


void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

void InitOutputChannel(CBlueVelvet4* pSDK, ULONG DefaultOutputChannel, ULONG VideoMode, ULONG UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultOutputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_playback_stop(0, 0);

	RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	//route the same audio to AES as well (AES only supports 8 channels, though)
	RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_AES_ANALOG_AUDIO_OUTPUT, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	//Set the required video mode
	varVal.ulVal = VideoMode;
	pSDK->SetCardProperty(VIDEO_MODE, varVal);
	pSDK->QueryCardProperty(VIDEO_MODE, varVal);
	if(varVal.ulVal != VideoMode)
	{
		cout << "Can't set video mode; FIFO running already?" << endl;
		system("pause");
		BailOut(pSDK);
		exit(0);
	}

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required video mode, update type and memory format
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
}

void InitBuffer(BLUE_UINT8* pVideoBuffer, ULONG PixelsPerLine, ULONG VideoLines)
{
	//For the test purpose of this sample we simply fill the buffer with a solid color
	BLUE_UINT8* pTmp = (BLUE_UINT8*)pVideoBuffer;

	for(ULONG i=0; i<PixelsPerLine*VideoLines/3; i++)
	{
		//BLUE
		*pTmp = 0xFF; pTmp++;
		*pTmp = 0x00; pTmp++;
		*pTmp = 0x00; pTmp++;
	}

	for(ULONG i=0; i<PixelsPerLine*VideoLines/3; i++)
	{
		//GREEN
		*pTmp = 0x00; pTmp++;
		*pTmp = 0xFF; pTmp++;
		*pTmp = 0x00; pTmp++;
	}

	for(ULONG i=0; i<PixelsPerLine*VideoLines/3; i++)
	{
		//RED
		*pTmp = 0x00; pTmp++;
		*pTmp = 0x00; pTmp++;
		*pTmp = 0xFF; pTmp++;
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "PlaybackAncillary_FS sample app" << endl;

	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;
	ULONG VideoMode = VID_FMT_1080I_5000;
	ULONG UpdateFormat = UPD_FMT_FRAME;
	ULONG MemoryFormat = MEM_FMT_BGR;
	ULONG VideoEngine = VIDEO_ENGINE_FRAMESTORE;
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDK = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDK->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card, in this case card 1
	if(BLUE_FAIL(pSDK->device_attach(1, 0)))
	{
		cout << "Error on device attach (channel A)" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Get the card type and firmware type
	int iCardType = pSDK->has_video_cardtype();
	if(	iCardType != CRD_BLUE_EPOCH_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_CORE &&
		iCardType != CRD_BLUE_EPOCH_ULTRA &&
		iCardType != CRD_BLUE_EPOCH_2K_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_2K_CORE &&
		iCardType != CRD_BLUE_EPOCH_2K_ULTRA &&
		iCardType != CRD_BLUE_SUPER_NOVA &&
		iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Card not supported for OEM playback" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	pSDK->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal);
	cout << "Product ID / firmware type: " << varVal.ulVal << endl;

	varVal.ulVal = 0;
	if(BLUE_FAIL(pSDK->QueryCardProperty(CARD_FEATURE_STREAM_INFO, varVal)))
	{
		cout << "Function not supported; need driver 5.10.2.x" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	unsigned int nOutputStreams = CARD_FEATURE_GET_SDI_OUTPUT_STREAM_COUNT(varVal.ulVal);
	unsigned int nInputStreams = CARD_FEATURE_GET_SDI_INPUT_STREAM_COUNT(varVal.ulVal);
	if(!nOutputStreams)
	{
		cout << "Card does not support output channels" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDK->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	InitOutputChannel(pSDK, BLUE_VIDEO_OUTPUT_CHANNEL_A, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);

	//enable audio output groups
	ULONG EmbAudioProp = 0;
	ULONG NumberAudioChannels = 2;
	ULONG AudioSampleBitDepth = AUDIO_CHANNEL_16BIT;	// 16 bit
	//ULONG AudioSampleBitDepth = AUDIO_CHANNEL_24BIT;	// 24 bit
	//ULONG AudioSampleBitDepth = 0;					// 32 bit
	ULONG EmbAudioFlag = 0;

	if(NumberAudioChannels > 0)
		EmbAudioProp |= (blue_emb_audio_group1_enable);
	if(NumberAudioChannels > 4)
		EmbAudioProp |= (blue_emb_audio_group2_enable);
	if(NumberAudioChannels > 8)
		EmbAudioProp |= (blue_emb_audio_group3_enable);
	if(NumberAudioChannels > 12)
		EmbAudioProp |= (blue_emb_audio_group4_enable);
	if(EmbAudioProp)
		EmbAudioProp |= blue_emb_audio_enable;
	
	EmbAudioFlag = EmbAudioProp;
	EmbAudioProp |= blue_enable_hanc_timestamp_pkt;	//enable timecode
	varVal.ulVal = EmbAudioProp;
	pSDK->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);

	//keep RP188 timecode when stopping playback:
	pSDK->QueryCardProperty(EPOCH_AUDIOOUTPUT_METADATA_SETTINGS, varVal);
	if(EmbAudioProp & blue_enable_hanc_timestamp_pkt)
		varVal.ulVal |= AUDIO_METADATA_KEEP_ALIVE; //set flag
	else
		varVal.ulVal &= ~(AUDIO_METADATA_KEEP_ALIVE); //clear flag
	pSDK->SetCardProperty(EPOCH_AUDIOOUTPUT_METADATA_SETTINGS, varVal);

	OVERLAPPED OverlapChA;
	OverlapChA.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	ULONG GoldenSize = BlueVelvetGolden(VideoMode, MemoryFormat, UpdateFormat);
	ULONG GoldenSizeVbiVanc = BlueVelvetVANCGoldenValue(iCardType, VideoMode, MemoryFormat, (UpdateFormat == UPD_FMT_FRAME)?BLUE_DATA_FRAME:BLUE_DATA_FIELD1);	//BLUE_DATA_FIELD1 and BLUE_DATA_FIELD2 are the same on Epoch/SuperNova cards
	ULONG PixelsPerLine = BlueVelvetLinePixels(VideoMode);
	ULONG VbiVancLineCount = BlueVelvetVANCLineCount(iCardType, VideoMode, (UpdateFormat == UPD_FMT_FRAME)?BLUE_DATA_FRAME:BLUE_DATA_FIELD1);	//BLUE_DATA_FIELD1 and BLUE_DATA_FIELD2 are the same on Epoch/SuperNova cards
	ULONG VideoLines =  BlueVelvetFrameLines(VideoMode, UpdateFormat);
	ULONG BytesPerFrame = BlueVelvetFrameBytes(VideoMode, MemoryFormat, UpdateFormat);
	ULONG BytesPerLine = BlueVelvetLineBytes(VideoMode, MemoryFormat);

	cout << "Video Golden:             " << GoldenSize << endl;
	cout << "VBI/VANC Golden           " << GoldenSizeVbiVanc << endl;
	cout << "Video Pixels per line:    " << PixelsPerLine << endl;
	cout << "VBI/VANC line count:      " << VbiVancLineCount << endl;
	cout << "Video lines:              " << VideoLines << endl;
	cout << "Video Bytes per frame:    " << BytesPerFrame << endl;
	cout << "Video Bytes per line:     " << BytesPerLine << endl;

	unsigned char* pVideoBufferA_0 = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBufferA_0, GoldenSize);
	unsigned char* pVideoBufferA_1 = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBufferA_1, GoldenSize);
	unsigned char* pBufferArrayA[2] = {pVideoBufferA_0, pVideoBufferA_1};
	ULONG VideoFrameIndex = 0;
	ULONG CurrentBufferIndex = 0;

	//For the test purpose of this sample we simply fill the buffers with a solid color
	InitBuffer(pVideoBufferA_0, PixelsPerLine, VideoLines);
	InitBuffer(pVideoBufferA_1, PixelsPerLine, VideoLines);

	//Initialise VBI/VANC buffer
	unsigned char* pVbiVancBuffer = (unsigned char*)VirtualAlloc(NULL, GoldenSizeVbiVanc, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVbiVancBuffer, GoldenSizeVbiVanc);
	if((VideoMode == VID_FMT_PAL) || (VideoMode == VID_FMT_NTSC))
		memset(pVbiVancBuffer, 0, GoldenSizeVbiVanc);
	else //it's VANC and therfore V210 data
		blue_init_vanc_buffer(iCardType, VideoMode, PixelsPerLine, VbiVancLineCount, (UINT32*)pVbiVancBuffer);

	unsigned char* pHancBuffer = (unsigned char*)VirtualAlloc(NULL, HANC_BUFFER_SIZE, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pHancBuffer, HANC_BUFFER_SIZE);
	unsigned char* pAudioSamples = new unsigned char[2002*16*4];	//maximum of 2002 samples per frame, 16 audio channels and 4 byte samples
	//This only works for video modes with a frame rate of 25 fps
	Fill48((USHORT*)pAudioSamples, GetNumberOfAudioSamplesPerFrame(VideoMode, 0), NumberAudioChannels);

	hanc_stream_info_struct HancInfo;
	::ZeroMemory(&HancInfo, sizeof(HancInfo));

	HancInfo.AudioDBNArray[0] = -1;
	HancInfo.AudioDBNArray[1] = -1;
	HancInfo.AudioDBNArray[2] = -1;
	HancInfo.AudioDBNArray[3] = -1;
	HancInfo.hanc_data_ptr = (UINT32*)pHancBuffer;
	HancInfo.video_mode = VideoMode;

	//synchronise with the card
	ULONG FieldCount = 0;
	ULONG LastFieldCount = 0;
	pSDK->wait_output_video_synch(UpdateFormat, LastFieldCount);

	DWORD BytesReturnedChA = 0;
	int FramesToBuffer = 2;

	//Make the first buffer the current one to be updated and DMAd
	CurrentBufferIndex = 0;
	//You would read the first frame from a file here into pBufferArrayA[VideoFrameIndex]
	//read frame...start
	// pBufferArrayA[VideoFrameIndex] = next frame for channel A
	//read frame...done

	// also get the first audio frame; in this sample app we have a single buffer with a tone that works for a frame rate of 25 fps
	// pAudioSamples = next audio frame

	UINT32 FrameNumber = 0;
	while(!_kbhit())
	{
		cout << ".";
		pSDK->wait_output_video_synch(UpdateFormat, FieldCount);

		//start to DMA the frame to the card
		pSDK->system_buffer_write_async(pBufferArrayA[VideoFrameIndex], GoldenSize, &OverlapChA, BlueImage_VBI_HANC_DMABuffer(CurrentBufferIndex, BLUE_DATA_IMAGE), 0);

		//while DMA is happening read the next frame into our buffer
		// read frame...start
		// pBufferArrayA[((++VideoFrameIndex)%2)] = next frame for channel A
		// read frame...done

		// also get new audio frame; in this sample app we have a single buffer with a tone that works for a frame rate of 25 fps
		// pAudioSamples = next audio frame

		HancInfo.time_code = 0LL;			//RP188 VITC time code
		HancInfo.rp188_ltc_time_code = 0LL;	//RP188 LTC time code
		HancInfo.ltc_time_code = 0LL;		//external LTC time code
		HancInfo.sd_vitc_time_code = 0LL;	//this field is only valid for SD video signal

		//encode raw audio samples into the HANC buffer while the video DMA is going
		encode_hanc_frame_ex(iCardType, &HancInfo, pAudioSamples, NumberAudioChannels, GetNumberOfAudioSamplesPerFrame(VideoMode, FrameNumber), AudioSampleBitDepth, EmbAudioFlag);

		//wait for both DMA transfers to be finished
		GetOverlappedResult(pSDK->m_hDevice, &OverlapChA, &BytesReturnedChA, TRUE);
		ResetEvent(OverlapChA.hEvent);

		//now we can DMA the HANC frame
		pSDK->system_buffer_write_async(pHancBuffer, HANC_BUFFER_SIZE, NULL, BlueImage_VBI_HANC_DMABuffer(CurrentBufferIndex, BLUE_DATA_HANC), 0);
		//DMA VBI/VANC data
		pSDK->system_buffer_write_async(pVbiVancBuffer, GoldenSizeVbiVanc, NULL, BlueImage_VBI_HANC_DMABuffer(CurrentBufferIndex, BLUE_DATA_VBI), 0);

		//tell the card to playback the frames on the next interrupt
		pSDK->render_buffer_update(BlueBuffer_Image_VBI_HANC(CurrentBufferIndex));
		FrameNumber++;

		//set the buffer id to the next frame
		CurrentBufferIndex = ((++CurrentBufferIndex)%4);

		//track FieldCount to see if frames were dropped
		if(LastFieldCount + 2 < FieldCount)
		{
			cout << "Error: dropped " << ((FieldCount - LastFieldCount + 2)/2) << " frames" << endl;
		}

		LastFieldCount = FieldCount;
 	}

	//turn off audio by selecting the BlueBuffer_Image_VBI() rather than BlueBuffer_Image_HANC() macro
	pSDK->render_buffer_update(BlueBuffer_Image_VBI(((++CurrentBufferIndex)%4))); // we are only using buffers 0 and 1, but we need to render the previous buffer again as CurrentBufferIndex has been modified above

	//turn on black generator (unless we want to keep displaying the last rendered frame)
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	CloseHandle(OverlapChA.hEvent);

	delete [] pAudioSamples;
	VirtualUnlock(pVbiVancBuffer, GoldenSizeVbiVanc);
	VirtualUnlock(pHancBuffer, HANC_BUFFER_SIZE);
	VirtualUnlock(pVideoBufferA_0, GoldenSize);
	VirtualUnlock(pVideoBufferA_1, GoldenSize);
	VirtualFree(pVbiVancBuffer, 0, MEM_RELEASE);
	VirtualFree(pHancBuffer, 0, MEM_RELEASE);
	VirtualFree(pVideoBufferA_0, 0, MEM_RELEASE);
	VirtualFree(pVideoBufferA_1, 0, MEM_RELEASE);

	BailOut(pSDK);
	cout << "Done" << endl;
	system("pause");
	return 0;
}
