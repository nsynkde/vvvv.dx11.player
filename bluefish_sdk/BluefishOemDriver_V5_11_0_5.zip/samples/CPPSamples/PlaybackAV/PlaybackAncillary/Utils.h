UINT32 GetNumberOfAudioSamplesPerFrame(UINT32 VideoMode, UINT32 FrameNumber);
void Fill48(USHORT* pAudio16, UINT32 Samples, UINT32 Channels);

