#include "stdafx.h"


unsigned short sine_wave_const_48[]={	0x0000, 0x01A8, 0x0349, 0x04DB, 0x0658, 0x07BA,
										0x08FA, 0x0A12, 0x0AFE, 0x0BBA, 0x0C43, 0x0C96,
										0x0CB1, 0x0C96, 0x0C43, 0x0BBA, 0x0AFE, 0x0A12,
										0x08FA, 0x07BA, 0x0658, 0x04DB, 0x0349, 0x01A8,
										0x0000, 0xFE58, 0xFCB7, 0xFB25, 0xF9A8, 0xF846,
										0xF706, 0xF5EE, 0xF502, 0xF446, 0xF3BD, 0xF36A,
										0xF34F, 0xF36A, 0xF3BD, 0xF446, 0xF502, 0xF5EE,
										0xF706, 0xF846, 0xF9A8, 0xFB25, 0xFCB7, 0xFE58};

UINT32 GetNumberOfAudioSamplesPerFrame(UINT32 VideoMode, UINT32 FrameNumber)
{
	UINT32 NTSC_frame_seq[]={	1602,1601,1602,1601,1602};
	UINT32 NTSC_frame_offset[]={0,
								1602,
								1602+1601,
								1602+1601+1602,
								1602+1601+1602+1601};

	UINT32 p59_frame_seq[]={	801,800,801,801,801,801,800,801,801,801};
	UINT32 p59_frame_offset[]={	0,
								801,
								801+800,
								801+800+801,
								801+800+801+801,
								801+800+801+801+801,
								801+800+801+801+801+801,
								801+800+801+801+801+801+800,
								801+800+801+801+801+801+800+801,
								801+800+801+801+801+801+800+801+801};

	UINT32 p23_frame_seq[]={	2002,2002,2002,2002};
	UINT32 p23_frame_offset[]={	0,
								2002,
								2002+2002,
								2002+2002+2002};

	switch(VideoMode)
	{
	case VID_FMT_720P_2398:
	case VID_FMT_1080P_2397:
	case VID_FMT_1080PSF_2397:
	case VID_FMT_2048_1080PSF_2397:
	case VID_FMT_2048_1080P_2397:
		return 2002;
	case VID_FMT_NTSC:
	case VID_FMT_720P_2997:
	case VID_FMT_1080P_2997:
	case VID_FMT_1080PSF_2997:
	case VID_FMT_1080I_5994:
	case VID_FMT_2048_1080PSF_2997:
	case VID_FMT_2048_1080P_2997:
		return NTSC_frame_seq[FrameNumber%5];
		break;
	case VID_FMT_720P_5994:
	case VID_FMT_1080P_5994:
		return p59_frame_seq[FrameNumber%10];
		break;
	case VID_FMT_720P_2400:
	case VID_FMT_1080PSF_2400:
	case VID_FMT_1080P_2400:
	case VID_FMT_2048_1080PSF_2400:
	case VID_FMT_2048_1080P_2400:
		return 2000;
		break;
	case VID_FMT_720P_3000:
	case VID_FMT_1080I_6000:
	case VID_FMT_1080P_3000:
	case VID_FMT_1080PSF_3000:
	case VID_FMT_2048_1080PSF_3000:
	case VID_FMT_2048_1080P_3000:
		return 1600;
		break;
	case VID_FMT_720P_6000:
	case VID_FMT_1080P_6000:
		return 800;
		break;
	case VID_FMT_720P_5000:
	case VID_FMT_1080P_5000:
		return 960;
		break;
	case VID_FMT_PAL:
	case VID_FMT_1080I_5000:
	case VID_FMT_1080PSF_2500:
	case VID_FMT_2048_1080PSF_2500:
		return 1920;
		break;
	case VID_FMT_720P_2500:
	case VID_FMT_1080P_2500:
	case VID_FMT_2048_1080P_2500:
	default:
		return 1920;
		break;
	}
}

void Fill48(USHORT* pAudio16, UINT32 Samples, UINT32 Channels)
{
	USHORT data = 0;
	USHORT end = Samples/48;
	USHORT Bytes = 0;
	USHORT SampleCount = 0;

	for(USHORT i=0; i<end; i++)
	{
		for(USHORT k=0; k<48; k++)
		{
				data = sine_wave_const_48[k];
				// 16 channels
				if(Channels > 0)  { *pAudio16 = data; pAudio16++; }
				if(Channels > 1)  { *pAudio16 = data; pAudio16++; }
				if(Channels > 2)  { *pAudio16 = data; pAudio16++; }
				if(Channels > 3)  { *pAudio16 = data; pAudio16++; }
				if(Channels > 4)  { *pAudio16 = data; pAudio16++; }
				if(Channels > 5)  { *pAudio16 = data; pAudio16++; }
				if(Channels > 6)  { *pAudio16 = data; pAudio16++; }
				if(Channels > 7)  { *pAudio16 = data; pAudio16++; }
				if(Channels > 8)  { *pAudio16 = data; pAudio16++; }
				if(Channels > 9)  { *pAudio16 = data; pAudio16++; }
				if(Channels > 10) { *pAudio16 = data; pAudio16++; }
				if(Channels > 11) { *pAudio16 = data; pAudio16++; }
				if(Channels > 12) { *pAudio16 = data; pAudio16++; }
				if(Channels > 13) { *pAudio16 = data; pAudio16++; }
				if(Channels > 14) { *pAudio16 = data; pAudio16++; }
				if(Channels > 15) { *pAudio16 = data; pAudio16++; }
				Bytes++;
		}
	}
}
