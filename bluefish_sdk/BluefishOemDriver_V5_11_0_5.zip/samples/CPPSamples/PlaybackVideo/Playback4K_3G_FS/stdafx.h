// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <iostream>
#include <conio.h>


// TODO: reference additional headers your program requires here
#include "BlueVelvet4.h"


using namespace std;


class BlueBenchMark
{
private:
	LARGE_INTEGER m_liStartTime;
	LARGE_INTEGER m_liEndTime;
	LARGE_INTEGER m_liFrequency;

public:
	BlueBenchMark() { QueryPerformanceFrequency(&m_liFrequency); };
	void StartClock(){QueryPerformanceCounter(&m_liStartTime);}
	void StopClock(){QueryPerformanceCounter(&m_liEndTime);}
	double GetTimeElapsed()
	{
		if(m_liFrequency.QuadPart == 0)
		{
			return 0.0;
		}	
		return (double)( (m_liEndTime.QuadPart - m_liStartTime.QuadPart)* (double)1000.0/(double)m_liFrequency.QuadPart );	
	}
};


#pragma pack(push, dpxheader, 1)

struct DPXFileHeader
{
    UINT32	magic_num;        /* magic number 0x53445058 (SDPX) or 0x58504453 (XPDS) */
    UINT32	offset;           /* offset to image data in bytes */
    CHAR	vers[8];          /* which header format version is being used (v1.0)*/
    UINT32	file_size;        /* file size in bytes */
    UINT32	ditto_key;        /* read time short cut - 0 = same, 1 = new */
    UINT32	gen_hdr_size;     /* generic header length in bytes */
    UINT32	ind_hdr_size;     /* industry header length in bytes */
    UINT32	user_data_size;   /* user-defined data length in bytes */
    CHAR	file_name[100];   /* iamge file name */
    CHAR	create_time[24];  /* file creation date "yyyy:mm:dd:hh:mm:ss:LTZ" */
    CHAR	creator[100];     /* file creator's name */
    CHAR	project[200];     /* project name */
    CHAR	copyright[200];   /* right to use or copyright info */
    UINT32	key;              /* encryption ( FFFFFFFF = unencrypted ) */
    CHAR	Reserved[104];    /* reserved field TBD (need to pad) */
};	

#pragma pack(pop, dpxheader)
