// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	Playback4K_50P_4224_TwoCards_FS
// Written by:			Tim Bragulla
// Date:				27 March 2013
//
// Brief description:	This sample application shows how to playback a 4:2:2:4 video stream in 1080P25 video mode using two SuperNova QuadOut cards using FIFO mode
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.2.2 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_2_2\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//		Files:					Sample4K.dpx
//								Sample4K.yuv
//

#include "stdafx.h"


int LoadBfImageDpx(BLUE_UINT8* pVideo)
{
	FILE* fp = NULL;
	DPXFileHeader FileHeader;
	int nVideoSize = 0;
	BLUE_UINT32* pTmp = NULL;
	BLUE_UINT8* pTmp8 = NULL;

	fp = fopen("Sample4K.dpx", "rb");
	if(fp)
	{
		//1. read file header
		fread(&FileHeader, sizeof(DPXFileHeader), 1, fp);
		nVideoSize = FileHeader.file_size - FileHeader.offset;
		float fVideoSize = (float)nVideoSize;
	
		//2. rewind file pointer to start of the file
		fseek(fp, 0, SEEK_SET);

		//3. adjust file pointer to point to start of video area; we don't need this info
		fread(pVideo, 1, FileHeader.offset, fp);

		//4. read video data into our page aligned video buffer
		fread(pVideo, 1, nVideoSize, fp);
		fclose(fp);
	}
	else
	{
		MessageBox(NULL, L"Could not load file Sample4K.dpx", L"Error", MB_OK);
		return -1;
	}
	return 0;
}

void LoadAlpha8Bit(BLUE_UINT8* pKey)
{
	BLUE_UINT8* pTmp = pKey;
	BLUE_UINT8 alpha = 0;

	for(int i=0; i<2160; i++) //lines of video
	{
		for(int a=0; a<4096; a++)
		{
			if(a == 0)
				alpha = 0x10;

			if(a == 2048)
				alpha = 0xF0;

			*pTmp = alpha;
			pTmp++;

			if(a < 2048)
			{
				alpha++;
				if(alpha > 0xF0)
					alpha = 0x10;
			}
			else
			{
				alpha--;
				if(alpha < 0x10)
					alpha = 0xF0;
			}
		}
	}
}

int LoadBfImageYUV8Bit(BLUE_UINT8* pVideo)
{
	FILE* fp = NULL;
	int nVideoSize = 0;
	BLUE_UINT32* pTmp = NULL;
	BLUE_UINT8* pTmp8 = NULL;

	fp = fopen("Sample4K.yuv", "rb");
	if(fp)
	{
		fseek(fp, 0, SEEK_END);
		nVideoSize = ftell (fp);
		fseek(fp, 0, SEEK_SET);
		float fVideoSize = (float)nVideoSize;
		fread(pVideo, 1, nVideoSize, fp);

		fclose(fp);
	}
	else
	{
		MessageBox(NULL, L"Could not load file Sample4K.yuv", L"Error", MB_OK);
		return -1;
	}
	return 0;
}

void ClearYUVBuffer(BLUE_UINT8* pVideoBuffer, UINT32 nSize)
{
	BLUE_UINT8* pTmp = pVideoBuffer;
	for(UINT32 i=0; i<nSize/2; i++)
	{
		*pTmp = 0x80; pTmp++;
		*pTmp = 0x10; pTmp++;
	}
}

void AdjustProcessWorkingSet(int iSizePerFrame)
{
	// Increase the process working set size to allow pinning of more memory.
    static SIZE_T  dwMin = 0, dwMax = 0;
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA, FALSE, GetCurrentProcessId());

    if(!hProcess)
    {
        printf( "OpenProcess failed (%d)\n", GetLastError() );
    }

    // Retrieve the working set size of the process.
    if (!dwMin && !GetProcessWorkingSetSize(hProcess, &dwMin, &dwMax))
    {
        printf("GetProcessWorkingSetSize failed (%d)\n",
            GetLastError());
    }

	int size = iSizePerFrame;
	BOOL res = SetProcessWorkingSetSize(hProcess, size + dwMin, size + (dwMax-dwMin));
	if(!res)
		printf("SetProcessWorkingSetSize failed (%d)\n", GetLastError());

    CloseHandle(hProcess);
}

void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

void InitOutputChannel(CBlueVelvet4* pSDK, ULONG DefaultOutputChannel, ULONG VideoMode, ULONG UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultOutputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_playback_stop(0, 0);

	//Set the required video mode
	varVal.ulVal = VideoMode;
	pSDK->SetCardProperty(VIDEO_MODE, varVal);
	pSDK->QueryCardProperty(VIDEO_MODE, varVal);
	if(varVal.ulVal != VideoMode)
	{
		cout << "Can't set video mode; FIFO running already?" << endl;
		system("pause");
		BailOut(pSDK);
		exit(0);
	}

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required video mode, update type and memory format
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
}

int Playback4K_50P_4224_TwoCards_FS()
{
	CBlueVelvet4* pSDKC1FillA = NULL;
	CBlueVelvet4* pSDKC1FillB = NULL;
	CBlueVelvet4* pSDKC1KeyA = NULL;
	CBlueVelvet4* pSDKC1KeyB = NULL;
	CBlueVelvet4* pSDKC2FillA = NULL;
	CBlueVelvet4* pSDKC2FillB = NULL;
	CBlueVelvet4* pSDKC2KeyA = NULL;
	CBlueVelvet4* pSDKC2KeyB = NULL;

	int iDevices = 0;
	ULONG VideoMode = VID_FMT_2048_1080P_5000;
	ULONG UpdateFormat = UPD_FMT_FRAME;
	ULONG VideoEngine = VIDEO_ENGINE_FRAMESTORE;

	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDKC1FillA = BlueVelvetFactory4();
	pSDKC2FillA = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDKC1FillA->device_enumerate(iDevices);
	if(iDevices < 2)
	{
		cout << "Need two SuperNova QuadOut cards for this sample app" << endl;
		BlueVelvetDestroy(pSDKC1FillA);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card
	pSDKC1FillA->device_attach(1, 0);
	pSDKC2FillA->device_attach(2, 0);

	//Get the card type and firmware type
	int iCardType1 = pSDKC1FillA->has_video_cardtype();
	int iCardType2 = pSDKC2FillA->has_video_cardtype();
	if(	(iCardType1 != CRD_BLUE_SUPER_NOVA && iCardType1 != CRD_BLUE_SUPER_NOVA_S_PLUS) ||
		(iCardType2 != CRD_BLUE_SUPER_NOVA && iCardType2 != CRD_BLUE_SUPER_NOVA_S_PLUS))
	{
		cout << "Need two SuperNova QuadOut cards for this sample app" << endl;
		system("pause");
		BailOut(pSDKC1FillA);
		BailOut(pSDKC2FillA);
		return 0;
	}

	pSDKC1FillA->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal);
	if(varVal.ulVal != ORAC_4SDIOUTPUT_FIRMWARE_PRODUCTID)
	{
		cout << "Need two SuperNova QuadOut cards for this sample app" << endl;
		system("pause");
		BailOut(pSDKC1FillA);
		BailOut(pSDKC2FillA);
		return 0;
	}

	pSDKC2FillA->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal);
	if(varVal.ulVal != ORAC_4SDIOUTPUT_FIRMWARE_PRODUCTID)
	{
		cout << "Need two SuperNova QuadOut cards for this sample app" << endl;
		system("pause");
		BailOut(pSDKC1FillA);
		BailOut(pSDKC2FillA);
		return 0;
	}

	//MessageBox(NULL, L"", L"", MB_OK);

	pSDKC1FillB = BlueVelvetFactory4();
	pSDKC1KeyA = BlueVelvetFactory4();
	pSDKC1KeyB = BlueVelvetFactory4();
	pSDKC2FillB = BlueVelvetFactory4();
	pSDKC2KeyA = BlueVelvetFactory4();
	pSDKC2KeyB = BlueVelvetFactory4();

	pSDKC1FillB->device_attach(1, 0);
	pSDKC1KeyA->device_attach(1, 0);
	pSDKC1KeyB->device_attach(1, 0);
	pSDKC2FillB->device_attach(2, 0);
	pSDKC2KeyA->device_attach(2, 0);
	pSDKC2KeyB->device_attach(2, 0);

	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDKC1FillA->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	//turn off audio, we won't need it and it cause an issue in earlier version of the QuadOut firmware
	varVal.ulVal = 0;
	pSDKC1FillA->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);
	pSDKC1FillB->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);
	pSDKC2FillA->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);
	pSDKC2FillB->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);

	InitOutputChannel(pSDKC1FillA, BLUE_VIDEO_OUTPUT_CHANNEL_A, VideoMode, UpdateFormat, MEM_FMT_2VUY, VideoEngine);
	RouteChannel(pSDKC1FillA, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	
	InitOutputChannel(pSDKC1FillB, BLUE_VIDEO_OUTPUT_CHANNEL_B, VideoMode, UpdateFormat, MEM_FMT_2VUY, VideoEngine);
	RouteChannel(pSDKC1FillB, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	InitOutputChannel(pSDKC1KeyA, BLUE_VIDEO_OUTPUT_CHANNEL_C, VideoMode, UpdateFormat, MEM_FMT_YUV_ALPHA, VideoEngine);
	RouteChannel(pSDKC1KeyA, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHC, EPOCH_DEST_SDI_OUTPUT_C, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	
	InitOutputChannel(pSDKC1KeyB, BLUE_VIDEO_OUTPUT_CHANNEL_D, VideoMode, UpdateFormat, MEM_FMT_YUV_ALPHA, VideoEngine);
	RouteChannel(pSDKC1KeyB, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHD, EPOCH_DEST_SDI_OUTPUT_D, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	InitOutputChannel(pSDKC2FillA, BLUE_VIDEO_OUTPUT_CHANNEL_A, VideoMode, UpdateFormat, MEM_FMT_2VUY, VideoEngine);
	RouteChannel(pSDKC2FillA, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	InitOutputChannel(pSDKC2FillB, BLUE_VIDEO_OUTPUT_CHANNEL_B, VideoMode, UpdateFormat, MEM_FMT_2VUY, VideoEngine);
	RouteChannel(pSDKC2FillB, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	InitOutputChannel(pSDKC2KeyA, BLUE_VIDEO_OUTPUT_CHANNEL_C, VideoMode, UpdateFormat, MEM_FMT_YUV_ALPHA, VideoEngine);
	RouteChannel(pSDKC2KeyA, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHC, EPOCH_DEST_SDI_OUTPUT_C, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	InitOutputChannel(pSDKC2KeyB, BLUE_VIDEO_OUTPUT_CHANNEL_D, VideoMode, UpdateFormat, MEM_FMT_YUV_ALPHA, VideoEngine);
	RouteChannel(pSDKC2KeyB, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHD, EPOCH_DEST_SDI_OUTPUT_D, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	OVERLAPPED OverlapC1ChAFill;
	OverlapC1ChAFill.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OVERLAPPED OverlapC1ChBFill;
	OverlapC1ChBFill.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OVERLAPPED OverlapC1ChAKey;
	OverlapC1ChAKey.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OVERLAPPED OverlapC1ChBKey;
	OverlapC1ChBKey.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	
	OVERLAPPED OverlapC2ChAFill;
	OverlapC2ChAFill.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OVERLAPPED OverlapC2ChBFill;
	OverlapC2ChBFill.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OVERLAPPED OverlapC2ChAKey;
	OverlapC2ChAKey.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OVERLAPPED OverlapC2ChBKey;
	OverlapC2ChBKey.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	ULONG GoldenSizeFill = BlueVelvetGolden(VideoMode, MEM_FMT_2VUY, UpdateFormat);
	ULONG GoldenSizeKey = BlueVelvetGolden(VideoMode, MEM_FMT_YUV_ALPHA, UpdateFormat);
	ULONG PixelsPerLine = BlueVelvetLinePixels(VideoMode);
	ULONG VideoLines =  BlueVelvetFrameLines(VideoMode, UpdateFormat);
	ULONG BytesPerFrameFill = BlueVelvetFrameBytes(VideoMode, MEM_FMT_2VUY, UpdateFormat);
	ULONG BytesPerFrameKey = BlueVelvetFrameBytes(VideoMode, MEM_FMT_YUV_ALPHA, UpdateFormat);
	ULONG BytesPerLineFill = BlueVelvetLineBytes(VideoMode, MEM_FMT_2VUY);
	ULONG BytesPerLineKey = BlueVelvetLineBytes(VideoMode, MEM_FMT_YUV_ALPHA);

	cout << "Video Golden Fill:          " << GoldenSizeFill << endl;
	cout << "Video Golden Key:           " << GoldenSizeKey << endl;
	cout << "Video Pixels per line:      " << PixelsPerLine << endl;
	cout << "Video lines:                " << VideoLines << endl;
	cout << "Video Bytes per frame Fill: " << BytesPerFrameFill << endl;
	cout << "Video Bytes per frame Key:  " << BytesPerFrameKey << endl;
	cout << "Video Bytes per line Fill:  " << BytesPerLineFill << endl;
	cout << "Video Bytes per line Key:  " << BytesPerLineKey << endl;

	//Increase working set before allocating that much memory using VirtualAlloc()
	AdjustProcessWorkingSet(GoldenSizeFill + GoldenSizeKey);

	BLUE_UINT8* pBlackVideoBuffer = NULL;
	pBlackVideoBuffer = (BLUE_UINT8*)VirtualAlloc(NULL, 2048*1080*2, MEM_COMMIT, PAGE_READWRITE);
	ClearYUVBuffer(pBlackVideoBuffer, 2048*1080*2);
	ULONG BufferCount = 2;
	for(ULONG i=0; i<BufferCount; i++)
	{
		pSDKC1FillA->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*2, NULL, i);
		pSDKC1FillB->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*2, NULL, i);
		pSDKC2FillA->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*2, NULL, i);
		pSDKC2FillB->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*2, NULL, i);
	}
	//memset(pBlackVideoBuffer, 0x10, 2048*1080*1);
	memset(pBlackVideoBuffer, 0xF0, 2048*1080*1);
	for(ULONG i=0; i<BufferCount; i++)
	{
		pSDKC1KeyA->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*1, NULL, i);
		pSDKC1KeyB->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*1, NULL, i);
		pSDKC2KeyA->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*1, NULL, i);
		pSDKC2KeyB->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*1, NULL, i);
	}
	VirtualFree(pBlackVideoBuffer, 0, MEM_RELEASE);
	pBlackVideoBuffer = NULL;


	BLUE_UINT8* pVideoBuffer4KImage8Bit = NULL;
	pVideoBuffer4KImage8Bit = (BLUE_UINT8*)VirtualAlloc(NULL, GoldenSizeFill*4 + 2048*2, MEM_COMMIT, PAGE_READWRITE);
	if(LoadBfImageYUV8Bit(pVideoBuffer4KImage8Bit) == -1)
		return 0;

	BLUE_UINT8* pVideoBuffer4KKey8Bit = NULL;
	pVideoBuffer4KKey8Bit = (BLUE_UINT8*)VirtualAlloc(NULL, GoldenSizeKey*4 + 2048*1, MEM_COMMIT, PAGE_READWRITE);
	LoadAlpha8Bit(pVideoBuffer4KKey8Bit);

	BlueBenchMark bm;
	double dTime = 0.0;

	//synchronise with the card
	ULONG FieldCount = 0;
	ULONG LastFieldCount = 0;
	DWORD BytesReturned = 0;
	ULONG CurrentBufferIndex = 0;
	ULONG DroppedFrames = 0;
	pSDKC1FillA->wait_output_video_synch(UpdateFormat, LastFieldCount);

	while(!_kbhit())
	{
		//cards must be genlocked; only then all for output channels are completely in synch
		pSDKC1FillA->wait_output_video_synch(UPD_FMT_FRAME, FieldCount);
		bm.StartClock();

		//DMA the buffers to the card
		//Source Quadrant is only 2048*1024, but target frame is 2048*1080, so we have to add an offset to the DMA call
		//									pointer to source, size of source image, event handle, buffer id, offset on card
		//FILL
		varVal.ulVal = 2048*2;	//fill image width for each 2K stream is 2048 pixels * 2 bytes per pixel
		pSDKC1FillA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
		pSDKC1FillB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
		pSDKC2FillA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
		pSDKC2FillB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);

		varVal.ulVal = 1024;	//image height of 4K source image is 1024 lines
		pSDKC1FillA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
		pSDKC1FillB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
		pSDKC2FillA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
		pSDKC2FillB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);

		varVal.ulVal = 4096*2;	//fill image width of 4K source image is 4096 pixels * 2 bytes per pixel
		pSDKC1FillA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
		pSDKC1FillB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
		pSDKC2FillA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
		pSDKC2FillB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
		
		pSDKC1FillA->system_buffer_write_async(pVideoBuffer4KImage8Bit, 4096*1024*2, &OverlapC1ChAFill, CurrentBufferIndex, 2048*(1080-1024)*2);
		pSDKC1FillB->system_buffer_write_async(pVideoBuffer4KImage8Bit + 2048*2, 4096*1024*2, &OverlapC1ChBFill, CurrentBufferIndex, 2048*(1080-1024)*2);
		pSDKC2FillA->system_buffer_write_async(pVideoBuffer4KImage8Bit + 4096*1024*2, 4096*1024*2, &OverlapC2ChAFill, CurrentBufferIndex);
		pSDKC2FillB->system_buffer_write_async(pVideoBuffer4KImage8Bit + 4096*1024*2 + 2048*2, 4096*1024*2, &OverlapC2ChBFill, CurrentBufferIndex);

		/////////////////////////////////////////////////
		//KEY
		varVal.ulVal = 2048*1;	//alpha image width for each 2K stream is 2048 pixels * 1 bytes per pixel
		pSDKC1KeyA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
		pSDKC1KeyB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
		pSDKC2KeyA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
		pSDKC2KeyB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);

		varVal.ulVal = 1080;	//image height of 4K source image is 1080 lines
		pSDKC1KeyA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
		pSDKC1KeyB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
		pSDKC2KeyA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
		pSDKC2KeyB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);

		varVal.ulVal = 4096*1;	//key image width of 4K source image is 4096 pixels * 1 bytes per pixel
		pSDKC1KeyA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
		pSDKC1KeyB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
		pSDKC2KeyA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
		pSDKC2KeyB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);

		pSDKC1KeyA->system_buffer_write_async(pVideoBuffer4KKey8Bit, 4096*1080*1, &OverlapC1ChAKey, CurrentBufferIndex, 0);
		pSDKC1KeyB->system_buffer_write_async(pVideoBuffer4KKey8Bit + 2048*1, 4096*1080*1, &OverlapC1ChBKey, CurrentBufferIndex, 0);
		pSDKC2KeyA->system_buffer_write_async(pVideoBuffer4KKey8Bit + 4096*1080*1, 4096*1080*1, &OverlapC2ChAKey, CurrentBufferIndex);
		pSDKC2KeyB->system_buffer_write_async(pVideoBuffer4KKey8Bit + 4096*1080*1 + 2048*1, 4096*1080*1, &OverlapC2ChBKey, CurrentBufferIndex);

		//while DMA is happening read the next frame into our buffer
		// read frame...start
		// read frame...done

		//track FieldCount to see if frames were dropped
		if(LastFieldCount + 2 < FieldCount)
		{
			cout << "Error: dropped " << ((FieldCount - LastFieldCount + 2)/2) << " frames" << "Time taken: " << (float)dTime << ", FC: " << FieldCount << endl;
			DroppedFrames++;
		}
		else
		{
			cout << "Time taken: " << (float)dTime << ", dropped: " << DroppedFrames << endl;
		}
		LastFieldCount = FieldCount;

		//wait for all 8 DMA transfers to be finished
		GetOverlappedResult(pSDKC1FillA->m_hDevice, &OverlapC1ChAFill, &BytesReturned, TRUE);
		ResetEvent(OverlapC1ChAFill.hEvent);
		GetOverlappedResult(pSDKC1FillB->m_hDevice, &OverlapC1ChBFill, &BytesReturned, TRUE);
		ResetEvent(OverlapC1ChBFill.hEvent);
		GetOverlappedResult(pSDKC2FillA->m_hDevice, &OverlapC2ChAFill, &BytesReturned, TRUE);
		ResetEvent(OverlapC2ChAFill.hEvent);
		GetOverlappedResult(pSDKC2FillB->m_hDevice, &OverlapC2ChBFill, &BytesReturned, TRUE);
		ResetEvent(OverlapC2ChBFill.hEvent);
		GetOverlappedResult(pSDKC1KeyA->m_hDevice, &OverlapC1ChAKey, &BytesReturned, TRUE);
		ResetEvent(OverlapC1ChAKey.hEvent);
		GetOverlappedResult(pSDKC1KeyB->m_hDevice, &OverlapC1ChBKey, &BytesReturned, TRUE);
		ResetEvent(OverlapC1ChBKey.hEvent);
		GetOverlappedResult(pSDKC2KeyA->m_hDevice, &OverlapC2ChBKey, &BytesReturned, TRUE);
		ResetEvent(OverlapC2ChBKey.hEvent);
		GetOverlappedResult(pSDKC2KeyB->m_hDevice, &OverlapC2ChBKey, &BytesReturned, TRUE);
		ResetEvent(OverlapC2ChBKey.hEvent);

		//schedule the frames to be rendered at the next interrupt
		pSDKC1FillA->render_buffer_update(CurrentBufferIndex);
		pSDKC1KeyA->render_buffer_update(CurrentBufferIndex);
		pSDKC1FillB->render_buffer_update(CurrentBufferIndex);
		pSDKC1KeyB->render_buffer_update(CurrentBufferIndex);
		pSDKC2FillA->render_buffer_update(CurrentBufferIndex);
		pSDKC2KeyA->render_buffer_update(CurrentBufferIndex);
		pSDKC2FillB->render_buffer_update(CurrentBufferIndex);
		pSDKC2KeyB->render_buffer_update(CurrentBufferIndex);

		bm.StopClock();
		dTime = bm.GetTimeElapsed();

		CurrentBufferIndex = (++CurrentBufferIndex)%2;
 	}

	//turn on black generator (unless we want to keep displaying the last rendered frame)
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDKC1FillA->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDKC1FillB->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDKC2FillA->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDKC2FillB->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDKC1KeyA->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDKC1KeyB->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDKC2KeyA->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDKC2KeyB->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = 0;

	varVal.ulVal = 0;
	pSDKC1FillA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDKC1FillB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDKC2FillA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDKC2FillB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDKC1KeyA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDKC1KeyB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDKC2KeyA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDKC2KeyB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
		
	varVal.ulVal = 0;
	pSDKC1FillA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDKC1FillB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDKC2FillA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDKC2FillB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDKC1KeyA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDKC1KeyB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDKC2KeyA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDKC2KeyB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);

	varVal.ulVal = 0;
	pSDKC1FillA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDKC1FillB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDKC2FillA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDKC2FillB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDKC1KeyA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDKC1KeyB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDKC2KeyA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDKC2KeyB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);

	CloseHandle(OverlapC1ChAFill.hEvent);
	CloseHandle(OverlapC1ChBFill.hEvent);
	CloseHandle(OverlapC2ChAFill.hEvent);
	CloseHandle(OverlapC2ChBFill.hEvent);

	CloseHandle(OverlapC1ChAKey.hEvent);
	CloseHandle(OverlapC1ChBKey.hEvent);
	CloseHandle(OverlapC2ChAKey.hEvent);
	CloseHandle(OverlapC2ChBKey.hEvent);

	VirtualFree(pVideoBuffer4KImage8Bit, 0, MEM_RELEASE);
	VirtualFree(pVideoBuffer4KKey8Bit, 0, MEM_RELEASE);

	BailOut(pSDKC1FillA);
	BailOut(pSDKC1FillB);
	BailOut(pSDKC2FillA);
	BailOut(pSDKC2FillB);

	BailOut(pSDKC1KeyA);
	BailOut(pSDKC1KeyB);
	BailOut(pSDKC2KeyA);
	BailOut(pSDKC2KeyB);

	cout << "Dropped Frames: " << DroppedFrames << endl;

	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Playback4K_50P_4224_TwoCards_FS sample app" << endl;

	int RetVal = 0;
	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;
	VARIANT varVal;
	varVal.vt = VT_UI4;

	pSDK = BlueVelvetFactory4();

	//Check if there are any cards available
	pSDK->device_enumerate(iDevices);

	if(iDevices < 2)	//we need two SuperNova QuadOut cards for 4 dual link signals (8 cables)
	{
		cout << "This sample app needs two SuperNova QuadOut cards!" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}
	else
	{
		int iCardType = pSDK->has_video_cardtype(1);
		if((iCardType != CRD_BLUE_SUPER_NOVA) && (iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS))
		{
			cout << "Card 1 is not a SuperNova card!" << endl;
			BlueVelvetDestroy(pSDK);
			system("pause");
			return 0;
		}

		iCardType = pSDK->has_video_cardtype(2);
		if((iCardType != CRD_BLUE_SUPER_NOVA) && (iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS))
		{
			cout << "Card 2 is not a SuperNova card!" << endl;
			BlueVelvetDestroy(pSDK);
			system("pause");
			return 0;
		}

		//we have two cards and will use two output channels on each card
		BailOut(pSDK);	//detach this object from the card; we'll reinitialise everything in the next function
		Playback4K_50P_4224_TwoCards_FS();
	}

	system("pause");
	return RetVal;
}
