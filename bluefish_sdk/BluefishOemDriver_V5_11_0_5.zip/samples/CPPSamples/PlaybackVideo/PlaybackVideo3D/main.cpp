// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	PlaybackVideo3D
// Written by:			Tim Bragulla
// Date:				20 June 2012
//
// Brief description:	This sample application shows how to playback two individual video streams in a synchronised and DMA optimised matter using FIFO mode;
//						can be used for 3D playback
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"


void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

void InitOutputChannel(CBlueVelvet4* pSDK, ULONG DefaultOutputChannel, ULONG VideoMode, ULONG UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultOutputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_playback_stop(0, 0);

	if(DefaultOutputChannel == BLUE_VIDEO_OUTPUT_CHANNEL_A)
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	else
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	//Set the required video mode
	varVal.ulVal = VideoMode;
	pSDK->SetCardProperty(VIDEO_MODE, varVal);
	pSDK->QueryCardProperty(VIDEO_MODE, varVal);
	if(varVal.ulVal != VideoMode)
	{
		cout << "Can't set video mode; FIFO running already?" << endl;
		system("pause");
		BailOut(pSDK);
		exit(0);
	}

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required video mode, update type and memory format
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
}

void InitBuffers(BLUE_UINT8* pVideoBufferLeft, BLUE_UINT8* pVideoBufferRight, ULONG PixelsPerLine, ULONG VideoLines)
{
	//For the test purpose of this sample we simply fill the buffers with a solid color
	BLUE_UINT8* pTmp1 = (BLUE_UINT8*)pVideoBufferLeft;
	BLUE_UINT8* pTmp2 = (BLUE_UINT8*)pVideoBufferRight;

	for(ULONG i=0; i<PixelsPerLine*VideoLines; i++)
	{
		//GREEN (left eye video source stream)
		*pTmp1 = 0x00; pTmp1++;
		*pTmp1 = 0xFF; pTmp1++;
		*pTmp1 = 0x00; pTmp1++;

		//RED (right eye video source stream)
		*pTmp2 = 0x00; pTmp2++;
		*pTmp2 = 0x00; pTmp2++;
		*pTmp2 = 0xFF; pTmp2++;
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "PlaybackVideo3D sample app" << endl;

	CBlueVelvet4* pSDK_ChA = NULL;
	CBlueVelvet4* pSDK_ChB = NULL;
	int iDevices = 0;

	unsigned int FifoSizeChA = 0;
	unsigned int FifoSizeChB = 0;

	ULONG VideoMode = VID_FMT_1080I_5000;
	ULONG UpdateFormat = UPD_FMT_FRAME;
	ULONG MemoryFormat = MEM_FMT_BGR;
	ULONG VideoEngine = VIDEO_ENGINE_DUPLEX;

	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDK_ChA = BlueVelvetFactory4();
	pSDK_ChB = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDK_ChA->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK_ChA);
		BlueVelvetDestroy(pSDK_ChB);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card, in this case card 1
	if(BLUE_FAIL(pSDK_ChA->device_attach(1, 0)))
	{
		cout << "Error on device attach (channel A)" << endl;
		BlueVelvetDestroy(pSDK_ChA);
		BlueVelvetDestroy(pSDK_ChB);
		system("pause");
		return 0;
	}

	if( BLUE_FAIL( pSDK_ChB->device_attach(1, 0) ) )
	{
		cout << "Error on device attach (channel B)" << endl;
		BlueVelvetDestroy(pSDK_ChA);
		BlueVelvetDestroy(pSDK_ChB);
		system("pause");
		return 0;
	}

	//Get the card type and firmware type
	int iCardType = pSDK_ChA->has_video_cardtype();
	if(	iCardType != CRD_BLUE_EPOCH_2K_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_2K_CORE &&
		iCardType != CRD_BLUE_EPOCH_2K_ULTRA &&
		iCardType != CRD_BLUE_SUPER_NOVA &&
		iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Card not supported for OEM 3D playback" << endl;
		system("pause");
		BailOut(pSDK_ChA);
		BailOut(pSDK_ChB);
		return 0;
	}

	pSDK_ChA->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal);
	cout << "Product ID / firmware type: " << varVal.ulVal << endl;

	varVal.ulVal = 0;
	if(BLUE_FAIL(pSDK_ChA->QueryCardProperty(CARD_FEATURE_STREAM_INFO, varVal)))
	{
		cout << "Function not supported; need driver 5.10.2.x" << endl;
		system("pause");
		BailOut(pSDK_ChA);
		BailOut(pSDK_ChB);
		return 0;
	}

	unsigned int nOutputStreams = CARD_FEATURE_GET_SDI_OUTPUT_STREAM_COUNT(varVal.ulVal);
	unsigned int nInputStreams = CARD_FEATURE_GET_SDI_INPUT_STREAM_COUNT(varVal.ulVal);
	if(!nOutputStreams)
	{
		cout << "Card does not support two output channels" << endl;
		system("pause");
		BailOut(pSDK_ChA);
		BailOut(pSDK_ChB);
		return 0;
	}

	InitOutputChannel(pSDK_ChA, BLUE_VIDEO_OUTPUT_CHANNEL_A, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);
	InitOutputChannel(pSDK_ChB, BLUE_VIDEO_OUTPUT_CHANNEL_B, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);

	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDK_ChA->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	OVERLAPPED OverlapChA;
	OVERLAPPED OverlapChB;
	OverlapChA.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OverlapChB.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	ULONG GoldenSize = BlueVelvetGolden(VideoMode, MemoryFormat, UpdateFormat);
	ULONG PixelsPerLine = BlueVelvetLinePixels(VideoMode);
	ULONG VideoLines =  BlueVelvetFrameLines(VideoMode, UpdateFormat);
	ULONG BytesPerFrame = BlueVelvetFrameBytes(VideoMode, MemoryFormat, UpdateFormat);
	ULONG BytesPerLine = BlueVelvetLineBytes(VideoMode, MemoryFormat);

	cout << "Video Golden:          " << GoldenSize << endl;
	cout << "Video Pixels per line: " << PixelsPerLine << endl;
	cout << "Video lines:           " << VideoLines << endl;
	cout << "Video Bytes per frame: " << BytesPerFrame << endl;
	cout << "Video Bytes per line:  " << BytesPerLine << endl;

	unsigned char* pVideoBufferA_0 = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBufferA_0, GoldenSize);
	unsigned char* pVideoBufferA_1 = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBufferA_1, GoldenSize);
	unsigned char* pVideoBufferB_0 = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBufferB_0, GoldenSize);
	unsigned char* pVideoBufferB_1 = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBufferB_1, GoldenSize);

	unsigned char* pBufferArrayA[2] = {pVideoBufferA_0, pVideoBufferA_1};
	unsigned char* pBufferArrayB[2] = {pVideoBufferB_0, pVideoBufferB_1};
	ULONG VideoFrameIndex = 0;

	//For the test purpose of this sample we simply fill the buffers with a solid color
	InitBuffers(pVideoBufferA_0, pVideoBufferB_0, PixelsPerLine, VideoLines);
	InitBuffers(pVideoBufferA_1, pVideoBufferB_1, PixelsPerLine, VideoLines);

	//synchronise with the card
	ULONG FieldCount = 0;
	ULONG LastFieldCount = 0;
	pSDK_ChA->wait_output_video_synch(UpdateFormat, FieldCount);

	ULONG BufferIdChA = 0;
	ULONG BufferIdChB = 0;
	ULONG UnderrunChA = 0;
	ULONG UnderrunChB = 0;
	ULONG LastUnderrunChA = 0;
	ULONG LastUnderrunChB = 0;
	ULONG UniqueIdChA = 0;
	ULONG UniqueIdChB = 0;
	void* pAddressNotUsedChA = NULL;
	void* pAddressNotUsedChB = NULL;
	DWORD BytesReturnedChA = 0;
	DWORD BytesReturnedChB = 0;
	int FramesToBuffer = 2;

	//Make the first buffer the current one to be updated and DMAd
	VideoFrameIndex = 0;
	//You would read the first frame from a file here into pBufferArrayA[VideoFrameIndex]
	//read frame...start
	// pBufferArrayA[VideoFrameIndex] = next frame for channel A
	// pBufferArrayB[VideoFrameIndex] = next frame for channel B
	//read frame...done

	while(!_kbhit())
	{
		if(BLUE_OK(pSDK_ChA->video_playback_allocate(&pAddressNotUsedChA, BufferIdChA, UnderrunChA)))
		{
			if(BLUE_OK(pSDK_ChB->video_playback_allocate(&pAddressNotUsedChB, BufferIdChB, UnderrunChB)))
			{
				cout << ".";

				//start to DMA the frames to the card
				pSDK_ChA->system_buffer_write_async(pBufferArrayA[VideoFrameIndex], GoldenSize, &OverlapChA, BlueImage_DMABuffer(BufferIdChA, BLUE_DATA_IMAGE), 0);
				pSDK_ChB->system_buffer_write_async(pBufferArrayB[VideoFrameIndex], GoldenSize, &OverlapChB, BlueImage_DMABuffer(BufferIdChB, BLUE_DATA_IMAGE), 0);

				//while DMA is happening read the next frame into our buffer
				VideoFrameIndex = ((++VideoFrameIndex)%2);
				// read frame...start
				// pBufferArrayA[VideoFrameIndex] = next frame for channel A
				// pBufferArrayB[VideoFrameIndex] = next frame for channel B
				// read frame...done

				//wait for both DMA transfers to be finished
				GetOverlappedResult(pSDK_ChA->m_hDevice, &OverlapChA, &BytesReturnedChA, TRUE);
				ResetEvent(OverlapChA.hEvent);
				GetOverlappedResult(pSDK_ChB->m_hDevice, &OverlapChB, &BytesReturnedChB, TRUE);
				ResetEvent(OverlapChB.hEvent);

				//tell the card to playback the frames on the next interrupt
				pSDK_ChA->video_playback_present(UniqueIdChA, BlueBuffer_Image(BufferIdChA), 1, 0);
				pSDK_ChB->video_playback_present(UniqueIdChB, BlueBuffer_Image(BufferIdChB), 1, 0);

				//track UnderrunChA and UnderrunChB to see if frames were dropped
				if((UnderrunChA != LastUnderrunChA) || (UnderrunChB != LastUnderrunChB))
				{
					cout << "Dropped a frame: ChA underruns: " << UnderrunChA << ", ChB underruns: " << UnderrunChB << endl;
					LastUnderrunChA = UnderrunChA;
					LastUnderrunChB = UnderrunChB;
				}
			}
			else
			{
				pSDK_ChA->video_playback_release(BufferIdChA);	 // we can't use this buffer now as we didn't get one for channel B as well (shouldn't happen)
				cout << "Error getting buffer for channel B" << endl;
				continue;
			}
		}
		else
			pSDK_ChA->wait_output_video_synch(UpdateFormat, FieldCount);

		if(FramesToBuffer > 0)
		{
			FramesToBuffer--;
			if(FramesToBuffer == 0)
			{
				if(BLUE_FAIL(pSDK_ChA->video_playback_start(0, 0)))
					cout << "Error video playback start failed on channel A" << endl;
	
				if(BLUE_FAIL(pSDK_ChB->video_playback_start(0, 0)))
					cout << "Error video playback start failed on channel B" << endl;
			}
		}
 	}

	//turn on black generator (unless we want to keep displaying the last rendered frame)
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK_ChA->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	pSDK_ChA->video_playback_stop(0, 0);
	pSDK_ChB->video_playback_stop(0, 0);

	CloseHandle(OverlapChA.hEvent);
	CloseHandle(OverlapChB.hEvent);

	VirtualUnlock(pVideoBufferA_0, GoldenSize);
	VirtualUnlock(pVideoBufferA_1, GoldenSize);
	VirtualUnlock(pVideoBufferB_0, GoldenSize);
	VirtualUnlock(pVideoBufferB_1, GoldenSize);
	
	VirtualFree(pVideoBufferA_0, 0, MEM_RELEASE);
	VirtualFree(pVideoBufferA_1, 0, MEM_RELEASE);
	VirtualFree(pVideoBufferB_0, 0, MEM_RELEASE);
	VirtualFree(pVideoBufferB_1, 0, MEM_RELEASE);

	BailOut(pSDK_ChA);
	BailOut(pSDK_ChB);
	cout << "Done" << endl;
	system("pause");
	return 0;
}
