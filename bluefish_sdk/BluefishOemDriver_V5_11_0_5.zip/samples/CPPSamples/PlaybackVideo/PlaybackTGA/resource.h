//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PlaybackTGA.rc
//
#define IDD_TGA_DISPLAY_DLG             101
#define IDS_APP_TITLE                   103
#define IDC_TGA_FILENAME                1000
#define IDC_FILE_BROWSE_BTN             1001
#define IDC_PLAYBACK_RADIO              1004
#define IDC_FRAMESTORE_RADIO            1005
#define IDC_IMAGE_NORMAL                1015
#define IDC_RADIO2                      1016
#define IDC_IMAGE_FLIPPED               1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
