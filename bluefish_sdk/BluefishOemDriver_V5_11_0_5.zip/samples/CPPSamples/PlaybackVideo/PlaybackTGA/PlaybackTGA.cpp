// PlaybackTGA.cpp : Defines the entry point for the console application.
//


#include "stdafx.h"

// The one and only application object
CWinApp theApp;
using namespace std;

CBlueVelvet4* gpSdk;
ULONG gCardType;
int gImageOrient;

ULONG GetTargaVideoMode(TargaHeader& tga, ULONG& frameSize, ULONG& hasVBI, ULONG& MemFmt, int& ImageOrient)
{
	ULONG VidMode = VID_FMT_INVALID;
	ULONG bits_per_pixel = 0;
	hasVBI = 0;

	printf("TGA File pixel depth is %d bit, using ", tga.bits);

	switch(tga.bits)
	{
	case 32:
		MemFmt = MEM_FMT_BGRA;
		bits_per_pixel = 4;
		break;
	case 24:
		MemFmt = MEM_FMT_BGR;
		bits_per_pixel = 3;
		break;
	default:
		return VidMode;
	}

	frameSize = 0;
	if (tga.width == 720)
	{
		if ((tga.height >= 486) && (tga.height <= 512) )
		{
			hasVBI = tga.height - 486;
			VidMode = VID_FMT_NTSC;
			printf("NTSC video mode\n");
		}
		else
		if ( (tga.height >= 576) && (tga.height <= 608))
		{
			hasVBI = tga.height - 576;
			VidMode = VID_FMT_PAL;
			printf("PAL video mode\n");
		}
	}
	else
	{
		if (tga.width == 1280)
		{
			VidMode = VID_FMT_720P_6000;
			printf("720P 60 video mode\n");
		}
		else
		if(tga.width >= 1920)
		{
			VidMode = VID_FMT_1080PSF_2400;
			printf("1080PSF 24 video mode\n");
		}
		else
		if(tga.width >= 2048)
		{
			VidMode = VID_FMT_2048_1080PSF_2400;
			printf("2K PSF 24 video mode\n");
		}
	}

	frameSize = tga.width*tga.height*bits_per_pixel;

	if (tga.descriptor & 0x10)
		ImageOrient -= 1;

	return VidMode;
}

int OpenCard()
{
	int iDeviceCount = 0;
	int iTempCounter = 1;

	if (gpSdk == NULL)
	{
		gpSdk = BlueVelvetFactory4();
		gpSdk->device_enumerate(iDeviceCount);
		
		if (iDeviceCount == 0)
			return 0;

		if (iDeviceCount > 1)
		{
			printf("Select the Card\n");
			for (int i = 1; i <= iDeviceCount; i++)
			{
				int cardType = gpSdk->has_video_cardtype(i);
				switch(cardType)
				{
				case CRD_BLUEDEEP_LT:
					printf("Press [%d] For DeepBlue LT \n",i);
					break;
				case CRD_BLUEDEEP_SD:
					printf("Press [%d] For Iridium SD\n",i);
					break;
				case CRD_BLUEDEEP_AV:
					printf("Press [%d] For Iridium AV\n",i);
					break;
				case CRD_BLUEDEEP_IO:
					printf("Press [%d] For DeepBlue IO\n",i);
					break;
				case CRD_BLUEWILD_AV:
					printf("Press [%d] For BlueWild AV\n",i);
					break;
				case CRD_BLUEWILD_RT:
					printf("Press [%d] For Wild Blue AV\n",i);
					break;
				case CRD_BLUE_PRIDE:
					printf("Press [%d] For Pride\n",i);
					break;
				case CRD_BLUE_GREED:
					printf("Press [%d] For Greed\n",i);
					break;
				case CRD_BLUE_INGEST:
					printf("Press [%d] For Ingest\n",i);
					break;
				case CRD_BLUE_SD_INGEST_PRO:
					printf("Press [%d] For Ingest Pro\n",i);
					break;
				case CRD_BLUE_SD_DUALLINK:
					printf("Press [%d] For SD DualLink\n",i);
					break;
				case CRD_BLUE_SD_SINGLELINK_PRO:
					printf("Press [%d] For SD SingleLink Pro\n",i);
					break;
				case CRD_BLUE_SD_DUALLINK_PRO:
					printf("Press [%d] For DualLink Pro\n",i);
					break;
				case CRD_BLUE_SD_DEEPBLUE_LITE_PRO:
					printf("Press [%d] For DeepBlue Lite Pro\n",i);
					break;
				case CRD_BLUE_SD_IRIDIUM_AV_PRO:
					printf("Press [%d] For Iridium AV Pro\n",i);
					break;
				case CRD_BLUE_SD_PRIME:
					printf("Press [%d] For SD Prime\n",i);
					break;
				case CRD_BLUE_ENVY:
					printf("Press [%d] For Envy\n",i);
					break;
				case CRD_BLUEWILD_HD:
					{
						int hdCardType = gpSdk->GetHDCardType(i);

						switch(hdCardType)
						{
						case CRD_HD_FURY:
							printf("Press [%d] For HD Fury\n",i);					
							break;
						case CRD_HD_VENGENCE:
							printf("Press [%d] For HD VENGENCE\n",i);					
							break;
						case CRD_HD_IRIDIUM_XP:
							printf("Press [%d] For HD Iridium XP\n",i);					
							break;
						case CRD_HD_IRIDIUM:
							printf("Press [%d] For HD Iridium\n",i);					
							break;
						case CRD_HD_LUST:
							printf("Press [%d] For HD Lust\n",i);										
							break;
						default:
							printf("Press [%d] For unknown HD Card\n",i);										
							break;
						}
						break;
					}
				case CRD_BLUE_EPOCH_HORIZON:
					printf("Press [%d] For Epoch Horizon\n",i);
					break;
				case CRD_BLUE_EPOCH_CORE:
					printf("Press [%d] For Epoch Core\n",i);
					break;
				case CRD_BLUE_EPOCH_ULTRA:
					printf("Press [%d] For Epoch Ultra\n",i);
					break;
				case CRD_BLUE_EPOCH_2K_HORIZON:
					printf("Press [%d] For Epoch 2K Horizon\n",i);
					break;
				case CRD_BLUE_EPOCH_2K_CORE:
					printf("Press [%d] For Epoch 2K Core\n",i);
					break;
				case CRD_BLUE_EPOCH_2K_ULTRA:
					printf("Press [%d] For Epoch 2K Ultra\n",i);
					break;
				case CRD_BLUE_SUPER_NOVA:
					printf("Press [%d] For SuperNova\n",i);
					break;
				case CRD_BLUE_SUPER_NOVA_S_PLUS:
					printf("Press [%d] For SuperNova S+\n",i);
					break;
				default:
				printf("Press [%d] For Unknown card\n",i);
				}				
			}
			scanf("%d",&iTempCounter);
		}

		gpSdk->device_attach(iTempCounter, FALSE);
		gCardType = gpSdk->has_video_cardtype(iTempCounter);
	}
	return iTempCounter;
}

int InitializeCard(ULONG& VideoEngine, ULONG VideoMode = VID_FMT_INVALID, ULONG MemoryFormat = MEM_FMT_INVALID, ULONG UpdateType = UPD_FMT_FRAME, ULONG flip=0)
{
	int device_id = 0;

	if(VideoMode == VID_FMT_INVALID)
		return -1;

	if(gpSdk == NULL)
	{
		device_id = OpenCard();
		if (device_id == 0)
			return -1;
	}
	unsigned int mem_fmt_count = 0;
	unsigned int i = 1;
	mem_fmt_count = gpSdk->count_memory_format(device_id);

	while(i <= mem_fmt_count)
	{
		if (gpSdk->enum_memory_format(i, device_id) == MemoryFormat)
			break;
		i++;
	}

	// the card does not support this memory format
	if(i > mem_fmt_count)
	{
		printf("Card does not support %d Memory format\n", MemoryFormat);
		return -1;
	}

	EBlueVideoChannel VideoChannel = BLUE_VIDEO_OUTPUT_CHANNEL_A;
	VARIANT varVal;
	varVal.vt = VT_UI4;
	
	varVal.ulVal = VideoChannel;
	gpSdk->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	varVal.ulVal = VideoMode;
	gpSdk->SetCardProperty(VIDEO_MODE, varVal);

	varVal.ulVal = MemoryFormat;
	gpSdk->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	varVal.ulVal = UpdateType;
	gpSdk->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = VideoEngine;
	gpSdk->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	gpSdk->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	
	gpSdk->set_vertical_flip(gImageOrient);

	return 0;
}

void DisplayFrame_Framestore(UCHAR* pMemFrame, ULONG FrameSize, ULONG hasVBI, int offset, unsigned int verticalflip, ULONG VideoMode, ULONG MemFmt, ULONG UpdateType)
{
	ULONG BufferId = 0;
	ULONG Golden = 0;
	ULONG BytesPerLine = 0;
	ULONG LinesPerFrame = 0;

	Golden = BlueVelvetGolden(VideoMode, MemFmt, UpdateType);
	BytesPerLine = BlueVelvetFrameBytes(VideoMode, MemFmt, UPD_FMT_FRAME)/BlueVelvetFrameLines(VideoMode, UPD_FMT_FRAME);
	LinesPerFrame = BlueVelvetFrameLines(VideoMode, UPD_FMT_FRAME);

	printf("\nGolden Value of the frame:         %d \n", Golden);
	printf("Bytes Per Line of Video frame:     %d \n", BytesPerLine);
	printf("Lines in Active Picture region:    %d \n", LinesPerFrame);
	printf("Number of Vertical Blanking Lines: %d \n", hasVBI);

	printf("Using output channel A in FRAMESTOREmode\n");

	if (verticalflip == 0)
	{
		gpSdk->system_buffer_write_async(pMemFrame + (hasVBI)*BytesPerLine, Golden, NULL, (hasVBI)?BlueImage_VBI_DMABuffer(BufferId, BLUE_DATA_IMAGE):BufferId);
		if (hasVBI)
			gpSdk->system_buffer_write_async(pMemFrame, (hasVBI)*BytesPerLine, NULL, BlueImage_VBI_DMABuffer(BufferId, BLUE_DATA_VBI));
	}
	else
	{
		gpSdk->system_buffer_write_async(pMemFrame, Golden, NULL, (hasVBI)?BlueImage_VBI_DMABuffer(BufferId, BLUE_DATA_IMAGE):BufferId);
		if (hasVBI)
			gpSdk->system_buffer_write_async(pMemFrame + (LinesPerFrame)*BytesPerLine, (hasVBI)*BytesPerLine, NULL, BlueImage_VBI_DMABuffer(BufferId, BLUE_DATA_VBI));
	}
	gpSdk->render_buffer_update((hasVBI)?BlueBuffer_Image_VBI(BufferId):BufferId);

	printf("\nPress any key to exit...");
	_getch();
}

void DisplayFrame_Playback(UCHAR* pMemFrame, ULONG FrameSize, ULONG hasVBI, int offset, unsigned int verticalflip, ULONG VideoMode, ULONG MemFmt, ULONG UpdateType)
{
	ULONG FieldCount;
	ULONG BufferId = 0;
	ULONG Golden = 0;
	ULONG BytesPerLine = 0;
	ULONG LinesPerFrame = 0;
	int  iDummy;
	ULONG Underrun, UniqueId;
	ULONG* Address;

	if (verticalflip)
		iDummy = ImageOrientation_VerticalFlip;
	else
		iDummy = ImageOrientation_Normal;

	Golden = BlueVelvetGolden(VideoMode, MemFmt, UpdateType);
	BytesPerLine = BlueVelvetFrameBytes(VideoMode,MemFmt,UPD_FMT_FRAME)/BlueVelvetFrameLines(VideoMode,UPD_FMT_FRAME);
	LinesPerFrame = BlueVelvetFrameLines(VideoMode,UPD_FMT_FRAME);

	printf("\nGolden Value of the frame:         %d \n", Golden);
	printf("Bytes Per Line of Video frame:     %d \n", BytesPerLine);
	printf("Lines in Active Picture region:    %d \n", LinesPerFrame);
	printf("Number of Vertical Blanking Lines: %d \n", hasVBI);
	printf("Using output channel A in FIFO mode\n");

	gpSdk->video_playback_start(0, 0);
	gpSdk->wait_input_video_synch(UPD_FMT_FRAME, FieldCount);

	if (BLUE_PASS(gpSdk->video_playback_allocate((void **)&Address, BufferId, Underrun)))
	{
		if (verticalflip == 0)
		{
			gpSdk->system_buffer_write_async(pMemFrame + (hasVBI)*BytesPerLine, Golden, NULL, (hasVBI)?BlueImage_VBI_DMABuffer(BufferId, BLUE_DATA_IMAGE):BufferId);
			if (hasVBI)
				gpSdk->system_buffer_write_async(pMemFrame, (hasVBI)*BytesPerLine, NULL, BlueImage_VBI_DMABuffer(BufferId, BLUE_DATA_VBI));
		}
		else
		{
			gpSdk->system_buffer_write_async(pMemFrame, Golden, NULL, (hasVBI)?BlueImage_VBI_DMABuffer(BufferId, BLUE_DATA_IMAGE):BufferId);
			if (hasVBI)
				gpSdk->system_buffer_write_async(pMemFrame + (LinesPerFrame)*BytesPerLine, (hasVBI)*BytesPerLine, NULL, BlueImage_VBI_DMABuffer(BufferId, BLUE_DATA_VBI));
		}
		gpSdk->video_playback_present(UniqueId, (hasVBI)?BlueBuffer_Image_VBI(BufferId):BufferId, 1, 0);
	}

	printf("\nPress any key to exit...");
	_getch();
	gpSdk->video_playback_stop(0, 1);
}

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
		unsigned int flip = 0;
		FILE* file = NULL;
		char ttemp[20];
		int funcRet = 0;

		TargaHeader tga;
		memset(&tga, 0, sizeof(tga));

		ULONG frameSize = 0;
		ULONG VideoMode = VID_FMT_PAL;
		ULONG MemFmt = MEM_FMT_BGR;
		ULONG VideoEngine = VIDEO_ENGINE_FRAMESTORE;
		ULONG hasVBI = 0;
		UCHAR* pMemFrame = NULL;

		printf("**********************************\n");
		printf("* PlaybackTGA sample application *\n");
		printf("**********************************\n\n");

		PlaybackTGADlg dlg;
		dlg.DoModal();

		file = fopen((const char*)dlg.m_strFileName, "rb");
		if (file == NULL)
		{
			printf("Error could not open the file \n");
			system("pause");
			return 0;
		}

		VideoEngine = dlg.m_nVideoEngine; 
		gImageOrient = dlg.m_nImageOrient;
		fread(ttemp, sizeof(TargaHeader), 1, file);
		memcpy(&tga, ttemp, sizeof(TargaHeader));
		VideoMode = GetTargaVideoMode(tga, frameSize, hasVBI, MemFmt, gImageOrient);

		funcRet = InitializeCard(VideoEngine, VideoMode, MemFmt, UPD_FMT_FRAME, flip);
		if(funcRet != 0)
		{
			printf("Error initialising card!\n");
			system("pause");
			return 0;
		}

		pMemFrame= (UCHAR*)VirtualAlloc(NULL, frameSize, MEM_COMMIT, PAGE_READWRITE);
		VirtualLock(pMemFrame, frameSize);

		fread(pMemFrame, 1, frameSize, file);

		if (VideoEngine == VIDEO_ENGINE_FRAMESTORE)
			DisplayFrame_Framestore(pMemFrame, frameSize, hasVBI, sizeof(tga), flip, VideoMode, MemFmt, UPD_FMT_FRAME);
		else
			DisplayFrame_Playback(pMemFrame, frameSize, hasVBI, sizeof(tga), flip, VideoMode, MemFmt, UPD_FMT_FRAME);

		if(gpSdk)
		{
			gpSdk->device_detach();
			::BlueVelvetDestroy(gpSdk);
		}
		fclose(file);
		return 0;
	}

	return nRetCode;
}
