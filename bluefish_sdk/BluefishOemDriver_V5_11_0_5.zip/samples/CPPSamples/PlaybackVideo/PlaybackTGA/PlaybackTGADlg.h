#pragma once
#include "afxwin.h"


// PlaybackTGADlg dialog

class PlaybackTGADlg : public CDialog
{
	DECLARE_DYNAMIC(PlaybackTGADlg)

public:
	PlaybackTGADlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~PlaybackTGADlg();

// Dialog Data
	enum { IDD = IDD_TGA_DISPLAY_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
public:
	CEdit m_editFileName;
	CString m_strFileName;
	unsigned int m_nBufferId;
	unsigned int m_nVideoEngine;
	unsigned int m_nImageOrient;

	afx_msg void OnBnClickedFileBrowseBtn();
	afx_msg void OnClickVideoEngine();
	afx_msg void OnBnClickedImageOrient();
};
