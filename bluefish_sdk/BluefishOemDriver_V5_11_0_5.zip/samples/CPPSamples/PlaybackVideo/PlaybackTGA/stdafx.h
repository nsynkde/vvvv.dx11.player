// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


#include <iostream>
#include <tchar.h>
#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// some CString constructors will be explicit

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#endif

#ifndef STRICT
#define STRICT
#endif

#define WINVER        0x0500
#define _WIN32_WINNT  0x0500  // Require Windows 2000 or later
#define _WIN32_IE     0x0501  // Require IE 5.01 or later (comes with Windows 2000 or later)

#include <afx.h>
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// some CString constructors will be explicit

#include <atlbase.h>
#include <afxdlgs.h>
// TODO: reference additional headers your program requires here

#include <conio.h>
#include "BlueVelvet4.h"
#include "TargaHeader.h"
#include "PlaybackTGA.h"
#include "PlaybackTGADlg.h"

