// PlaybackTGADlg.cpp : implementation file
//

#include "stdafx.h"
#include "PlaybackTGA.h"
#include "PlaybackTGADlg.h"
#include "BlueVelvet4.h"

// PlaybackTGADlg dialog

IMPLEMENT_DYNAMIC(PlaybackTGADlg, CDialog)
PlaybackTGADlg::PlaybackTGADlg(CWnd* pParent /*=NULL*/) :
	CDialog(PlaybackTGADlg::IDD, pParent),
	m_nBufferId(0),
	m_nVideoEngine(VIDEO_ENGINE_FRAMESTORE),
	m_nImageOrient(ImageOrientation_VerticalFlip),
	m_strFileName("")
{
}

PlaybackTGADlg::~PlaybackTGADlg()
{
}

void PlaybackTGADlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TGA_FILENAME, m_editFileName);
}

BEGIN_MESSAGE_MAP(PlaybackTGADlg, CDialog)
	ON_BN_CLICKED(IDC_FILE_BROWSE_BTN, OnBnClickedFileBrowseBtn)
	ON_BN_CLICKED(IDC_FRAMESTORE_RADIO, OnClickVideoEngine)
	ON_BN_CLICKED(IDC_PLAYBACK_RADIO, OnClickVideoEngine)
	ON_BN_CLICKED(IDC_IMAGE_NORMAL, OnBnClickedImageOrient)
	ON_BN_CLICKED(IDC_IMAGE_FLIPPED, OnBnClickedImageOrient)
END_MESSAGE_MAP()


// PlaybackTGADlg message handlers

void PlaybackTGADlg::OnBnClickedFileBrowseBtn()
{
	CFileDialog fileDlg(TRUE, 0, "*.tga", 0, 0, this);
    if(fileDlg.DoModal() == IDOK)
    {
        m_strFileName = fileDlg.GetPathName();
		m_editFileName.SetWindowText(m_strFileName);
		UpdateData(0);
    }
}

BOOL PlaybackTGADlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CheckRadioButton(IDC_PLAYBACK_RADIO,IDC_FRAMESTORE_RADIO,IDC_FRAMESTORE_RADIO);
	CheckRadioButton(IDC_IMAGE_NORMAL,IDC_IMAGE_FLIPPED,IDC_IMAGE_FLIPPED);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void PlaybackTGADlg::OnClickVideoEngine()
{
	if (IsDlgButtonChecked(IDC_PLAYBACK_RADIO))
		m_nVideoEngine = VIDEO_ENGINE_PLAYBACK;
	else
	if (IsDlgButtonChecked(IDC_FRAMESTORE_RADIO))
		m_nVideoEngine = VIDEO_ENGINE_FRAMESTORE;
}

void PlaybackTGADlg::OnBnClickedImageOrient()
{
	if (IsDlgButtonChecked(IDC_IMAGE_NORMAL))
		m_nImageOrient = ImageOrientation_Normal;
	else
	if (IsDlgButtonChecked(IDC_IMAGE_FLIPPED))
		m_nImageOrient = ImageOrientation_VerticalFlip;
}
