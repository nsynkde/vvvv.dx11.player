// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	Playback4K_444_FS
// Written by:			Tim Bragulla
// Date:				30 July 2013
//
// Brief description:	This sample application shows how to playback a 12bit 4:4:4 4K video frame as 4 individual Dual Link 2K SDI video streams via 3G Level B
//						(2 SuperNova cards, 4 cables) using FRAMESTORE mode
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.2.10 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_2_10\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"


//#define	USE_2K

#ifdef USE_2K
#define PIXEL_WIDTH_4K_FRAME	4096
#define PIXEL_WIDTH_4K_QUADRANT 2048
#else
#define PIXEL_WIDTH_4K_FRAME 3840
#define PIXEL_WIDTH_4K_QUADRANT 1920
#endif


unsigned short* Create16bitBgrFrame()
{
	//BGR_16
	unsigned short* pFrame = (unsigned short*)VirtualAlloc(NULL, PIXEL_WIDTH_4K_FRAME*2160*6, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pFrame, PIXEL_WIDTH_4K_FRAME*2160*6);

	unsigned short* pTmp = pFrame;

	for(int line=0; line<(2160/4); line++)
	{
		//BLUE
		for(int pixel=0; pixel<PIXEL_WIDTH_4K_FRAME*3; pixel+=3)
		{
			pTmp[pixel] = pixel/3 << 4;	//12 bit data packed in 16 bit word
			pTmp[pixel+1] = 0;
			pTmp[pixel+2] = 0;
		}
		pTmp += PIXEL_WIDTH_4K_FRAME*3;
	}

	for(int line=0; line<(2160/4); line++)
	{
		//GREEN
		for(int pixel=0; pixel<PIXEL_WIDTH_4K_FRAME*3; pixel+=3)
		{
			pTmp[pixel] = 0;
			pTmp[pixel+1] = pixel/3 << 4;	//12 bit data packed in 16 bit word
			pTmp[pixel+2] = 0;
		}
		pTmp += PIXEL_WIDTH_4K_FRAME*3;
	}

	for(int line=0; line<(2160/4); line++)
	{
		//RED
		for(int pixel=0; pixel<PIXEL_WIDTH_4K_FRAME*3; pixel+=3)
		{
			pTmp[pixel] = 0;
			pTmp[pixel+1] = 0;
			pTmp[pixel+2] = pixel/3 << 4;	//12 bit data packed in 16 bit word
		}
		pTmp += PIXEL_WIDTH_4K_FRAME*3;
	}

	for(int line=0; line<(2160/4); line++)
	{
		//BLACK TO WHITE
		for(int pixel=0; pixel<PIXEL_WIDTH_4K_FRAME*3; pixel+=3)
		{
			pTmp[pixel] = pixel/3 << 4;		//12 bit data packed in 16 bit word
			pTmp[pixel+1] = pixel/3 << 4;	//12 bit data packed in 16 bit word
			pTmp[pixel+2] = pixel/3 << 4;	//12 bit data packed in 16 bit word
		}
		pTmp += PIXEL_WIDTH_4K_FRAME*3;
	}

	return pFrame;
}

void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

void InitOutputChannel(CBlueVelvet4* pSDK, ULONG DefaultOutputChannel, ULONG VideoMode, ULONG UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultOutputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_playback_stop(0, 0);

	//set up basic routing for each channel to SDI connector (this prevents the EPOCH_HD_SDI_TRANSPORT from messing up the 3G Links and outpu VPIDs)
	if(DefaultOutputChannel == BLUE_VIDEO_OUTPUT_CHANNEL_A)
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	else if(DefaultOutputChannel == BLUE_VIDEO_OUTPUT_CHANNEL_B)
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	else if(DefaultOutputChannel == BLUE_VIDEO_OUTPUT_CHANNEL_C)
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHC, EPOCH_DEST_SDI_OUTPUT_C, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	else if(DefaultOutputChannel == BLUE_VIDEO_OUTPUT_CHANNEL_D)
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHD, EPOCH_DEST_SDI_OUTPUT_D, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	//Set the required video mode
	varVal.ulVal = VideoMode;
	pSDK->SetCardProperty(VIDEO_MODE, varVal);
	pSDK->QueryCardProperty(VIDEO_MODE, varVal);
	if(varVal.ulVal != VideoMode)
	{
		cout << "Can't set video mode; FIFO running already?" << endl;
		system("pause");
		BailOut(pSDK);
		exit(0);
	}

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required video mode, update type and memory format
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	//enable dual link
	varVal.ulVal = 1;
	pSDK->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT,varVal);	//this automatically sets up the routing

	//set format type to be 4:4:4
	varVal.ulVal = Signal_FormatType_444_12BitSDI;
	pSDK->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT_SIGNAL_FORMAT_TYPE,varVal);

	varVal.vt = VT_UI4;
	varVal.ulVal = RGB_ON_CONNECTOR;
	pSDK->SetCardProperty(VIDEO_OUTPUT_SIGNAL_COLOR_SPACE, varVal);

	//this needs to be set AFTER setting the video mode
	varVal.ulVal = HD_SDI_TRANSPORT_3G_LEVEL_B;
	if(DefaultOutputChannel == BLUE_VIDEO_OUTPUT_CHANNEL_A)
	{
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A_3GB_LINK_A, BLUE_CONNECTOR_PROP_DUALLINK_LINK_1);
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A_3GB_LINK_B, BLUE_CONNECTOR_PROP_DUALLINK_LINK_2);
		varVal.ulVal |= (BLUE_CONNECTOR_SDI_OUTPUT_A << 16);
		pSDK->SetCardProperty(EPOCH_HD_SDI_TRANSPORT, varVal);
	}
	else if(DefaultOutputChannel == BLUE_VIDEO_OUTPUT_CHANNEL_B)
	{
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B_3GB_LINK_A, BLUE_CONNECTOR_PROP_DUALLINK_LINK_1);
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B_3GB_LINK_B, BLUE_CONNECTOR_PROP_DUALLINK_LINK_2);
		varVal.ulVal |= (BLUE_CONNECTOR_SDI_OUTPUT_B << 16);
		pSDK->SetCardProperty(EPOCH_HD_SDI_TRANSPORT, varVal);
	}
	else if(DefaultOutputChannel == BLUE_VIDEO_OUTPUT_CHANNEL_C)
	{
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHC, EPOCH_DEST_SDI_OUTPUT_C_3GB_LINK_A, BLUE_CONNECTOR_PROP_DUALLINK_LINK_1);
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHC, EPOCH_DEST_SDI_OUTPUT_C_3GB_LINK_B, BLUE_CONNECTOR_PROP_DUALLINK_LINK_2);
		varVal.ulVal |= (BLUE_CONNECTOR_SDI_OUTPUT_C << 16);
		pSDK->SetCardProperty(EPOCH_HD_SDI_TRANSPORT, varVal);
	}
	else if(DefaultOutputChannel == BLUE_VIDEO_OUTPUT_CHANNEL_D)
	{
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHD, EPOCH_DEST_SDI_OUTPUT_D_3GB_LINK_A, BLUE_CONNECTOR_PROP_DUALLINK_LINK_1);
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHD, EPOCH_DEST_SDI_OUTPUT_D_3GB_LINK_B, BLUE_CONNECTOR_PROP_DUALLINK_LINK_2);
		varVal.ulVal |= (BLUE_CONNECTOR_SDI_OUTPUT_D << 16);
		pSDK->SetCardProperty(EPOCH_HD_SDI_TRANSPORT, varVal);
	}

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
}

int Playback4K_444_TwoCards()
{
	CBlueVelvet4* pSDK_ChA = NULL;
	CBlueVelvet4* pSDK_ChB = NULL;
	CBlueVelvet4* pSDK_ChC = NULL;
	CBlueVelvet4* pSDK_ChD = NULL;

	int iDevices = 0;
#ifdef USE_2K
	ULONG VideoMode = VID_FMT_2048_1080PSF_2400;
#else
	ULONG VideoMode = VID_FMT_1080PSF_2400;
#endif
	ULONG UpdateFormat = UPD_FMT_FRAME;
	ULONG MemoryFormat = MEM_FMT_BGR_16_16_16;
	ULONG VideoEngine = VIDEO_ENGINE_FRAMESTORE;

	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDK_ChA = BlueVelvetFactory4();
	pSDK_ChB = BlueVelvetFactory4();
	pSDK_ChC = BlueVelvetFactory4();
	pSDK_ChD = BlueVelvetFactory4();
	
	//Due to the checks beforehand we can assume that we have a SuperNova QuadOut available as card 1
	//Attach the SDK objects to the card
	pSDK_ChA->device_attach(1, 0);
	pSDK_ChB->device_attach(1, 0);
	pSDK_ChC->device_attach(2, 0);
	pSDK_ChD->device_attach(2, 0);

	InitOutputChannel(pSDK_ChA, BLUE_VIDEO_OUTPUT_CHANNEL_A, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);
	InitOutputChannel(pSDK_ChB, BLUE_VIDEO_OUTPUT_CHANNEL_B, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);
	InitOutputChannel(pSDK_ChC, BLUE_VIDEO_OUTPUT_CHANNEL_A, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);
	InitOutputChannel(pSDK_ChD, BLUE_VIDEO_OUTPUT_CHANNEL_B, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);

	//Routing is set up automatically by setting up dual link in the above InitOutputChannel() function

	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDK_ChA->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	//turn off audio, we won't need it and it cause an issue in earlier version of the QuadOut firmware
	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);
	pSDK_ChB->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);
	pSDK_ChC->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);
	pSDK_ChD->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);

	OVERLAPPED OverlapChA;
	OVERLAPPED OverlapChB;
	OVERLAPPED OverlapChC;
	OVERLAPPED OverlapChD;
	OverlapChA.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OverlapChB.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OverlapChC.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OverlapChD.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	ULONG GoldenSize = BlueVelvetGolden(VideoMode, MemoryFormat, UpdateFormat);
	ULONG PixelsPerLine = BlueVelvetLinePixels(VideoMode);
	ULONG VideoLines =  BlueVelvetFrameLines(VideoMode, UpdateFormat);
	ULONG BytesPerFrame = BlueVelvetFrameBytes(VideoMode, MemoryFormat, UpdateFormat);
	ULONG BytesPerLine = BlueVelvetLineBytes(VideoMode, MemoryFormat);

	cout << "Video Golden:          " << GoldenSize << endl;
	cout << "Video Pixels per line: " << PixelsPerLine << endl;
	cout << "Video lines:           " << VideoLines << endl;
	cout << "Video Bytes per frame: " << BytesPerFrame << endl;
	cout << "Video Bytes per line:  " << BytesPerLine << endl;


	BLUE_UINT16* pVideoBuffer4KImage16Bit = Create16bitBgrFrame();

	varVal.ulVal = PIXEL_WIDTH_4K_QUADRANT*6;	//image width for each 2K stream is PIXEL_WIDTH_4K_QUADRANT pixels * 2 bytes per pixel
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	
	varVal.ulVal = 1080;	//image height of 4K source image is 1080 lines
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);

	varVal.ulVal = PIXEL_WIDTH_4K_FRAME*6;	//image width of 4K source image is PIXEL_WIDTH_4K_FRAME pixels * 6 bytes per pixel
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);

	HANDLE DmaHandles[4] = { OverlapChA.hEvent, OverlapChB.hEvent, OverlapChC.hEvent, OverlapChD.hEvent };
	BlueBenchMark bm;
	double dTime = 0.0;

	//synchronise with the card
	ULONG FieldCount = 0;
	ULONG LastFieldCount = 0;
	DWORD BytesReturned = 0;
	ULONG CurrentBufferIndex = 0;
	ULONG BufferCount = 4;
	pSDK_ChA->wait_output_video_synch(UpdateFormat, LastFieldCount);

	while(!_kbhit())
	{
		//cards must be genlocked; only then all for output channels are completely in synch
		pSDK_ChA->wait_output_video_synch(UPD_FMT_FRAME, FieldCount);
		bm.StartClock();

		//DMA the buffers to the card
		pSDK_ChA->system_buffer_write_async((unsigned char*)pVideoBuffer4KImage16Bit,															PIXEL_WIDTH_4K_FRAME*1080*6,								&OverlapChA, CurrentBufferIndex);
		pSDK_ChB->system_buffer_write_async((unsigned char*)pVideoBuffer4KImage16Bit + PIXEL_WIDTH_4K_QUADRANT*6,								PIXEL_WIDTH_4K_FRAME*1080*6 - PIXEL_WIDTH_4K_QUADRANT*6,	&OverlapChB, CurrentBufferIndex);
		pSDK_ChC->system_buffer_write_async((unsigned char*)pVideoBuffer4KImage16Bit + PIXEL_WIDTH_4K_FRAME*1080*6,								PIXEL_WIDTH_4K_FRAME*1080*6,								&OverlapChC, CurrentBufferIndex);
		pSDK_ChD->system_buffer_write_async((unsigned char*)pVideoBuffer4KImage16Bit + PIXEL_WIDTH_4K_FRAME*1080*6 + PIXEL_WIDTH_4K_QUADRANT*6,	PIXEL_WIDTH_4K_FRAME*1080*6 - PIXEL_WIDTH_4K_QUADRANT*6,	&OverlapChD, CurrentBufferIndex);

		//while DMA is happening read the next frame into our buffer
		// read frame...start
		// read frame...done

		//wait for all 4 DMA transfers to be finished
		GetOverlappedResult(pSDK_ChA->m_hDevice, &OverlapChA, &BytesReturned, TRUE);
		ResetEvent(OverlapChA.hEvent);
		GetOverlappedResult(pSDK_ChB->m_hDevice, &OverlapChB, &BytesReturned, TRUE);
		ResetEvent(OverlapChB.hEvent);
		GetOverlappedResult(pSDK_ChC->m_hDevice, &OverlapChC, &BytesReturned, TRUE);
		ResetEvent(OverlapChC.hEvent);
		GetOverlappedResult(pSDK_ChD->m_hDevice, &OverlapChD, &BytesReturned, TRUE);
		ResetEvent(OverlapChD.hEvent);

		//schedule the frames to be rendered at the next interrupt
		pSDK_ChA->render_buffer_update(CurrentBufferIndex);
		pSDK_ChB->render_buffer_update(CurrentBufferIndex);
		pSDK_ChC->render_buffer_update(CurrentBufferIndex);
		pSDK_ChD->render_buffer_update(CurrentBufferIndex);

		bm.StopClock();
		dTime = bm.GetTimeElapsed();

		CurrentBufferIndex = (++CurrentBufferIndex)%BufferCount;

		//track FieldCount to see if frames were dropped
		if(LastFieldCount + 2 < FieldCount)
		{
			cout << "Error: dropped " << ((FieldCount - LastFieldCount + 2)/2) << " frames" << "Time taken: " << (float)dTime <<endl;
		}
		else
			cout << "Time taken: " << (float)dTime << endl;

		LastFieldCount = FieldCount;
 	}

	//turn on black generator (unless we want to keep displaying the last rendered frame)
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK_ChA->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK_ChB->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK_ChC->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK_ChD->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	//turn off dual link
	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT,varVal);
	varVal.ulVal = Signal_FormatType_Independent_422;
	pSDK_ChA->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT_SIGNAL_FORMAT_TYPE, varVal);

	varVal.ulVal = 0;
	pSDK_ChB->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT,varVal);
	varVal.ulVal = Signal_FormatType_Independent_422;
	pSDK_ChB->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT_SIGNAL_FORMAT_TYPE, varVal);

	varVal.ulVal = 0;
	pSDK_ChC->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT,varVal);
	varVal.ulVal = Signal_FormatType_Independent_422;
	pSDK_ChC->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT_SIGNAL_FORMAT_TYPE, varVal);

	varVal.ulVal = 0;
	pSDK_ChD->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT,varVal);
	varVal.ulVal = Signal_FormatType_Independent_422;
	pSDK_ChD->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT_SIGNAL_FORMAT_TYPE, varVal);

	//fix routing
	RouteChannel(pSDK_ChA, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChA, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_C, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChB, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChB, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_D, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	RouteChannel(pSDK_ChC, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChC, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_C, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChD, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);	
	RouteChannel(pSDK_ChD, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_D, BLUE_CONNECTOR_PROP_SINGLE_LINK);	

	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	
	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);

	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);

	CloseHandle(OverlapChA.hEvent);
	CloseHandle(OverlapChB.hEvent);
	CloseHandle(OverlapChC.hEvent);
	CloseHandle(OverlapChD.hEvent);

	VirtualUnlock(pVideoBuffer4KImage16Bit, PIXEL_WIDTH_4K_FRAME*2160*6);
	VirtualFree(pVideoBuffer4KImage16Bit, 0, MEM_RELEASE);

	BailOut(pSDK_ChA);
	BailOut(pSDK_ChB);
	BailOut(pSDK_ChC);
	BailOut(pSDK_ChD);

	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Playback4K_444_3G_FS sample app" << endl;

	int RetVal = 0;
	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;
	VARIANT varVal;
	varVal.vt = VT_UI4;

	pSDK = BlueVelvetFactory4();

	//Check if there are any cards available
	pSDK->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	if(iDevices < 2)	//we need two SuperNova QuadOut cards for 4 dual link signals (8 cables)
	{
		cout << "This sample app needs two SuperNova QuadOut cards!" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}
	else	//if there are more than 1 device we will use two cards for two SDI streams each
	{
		int iCardType = pSDK->has_video_cardtype(1);
		if((iCardType != CRD_BLUE_SUPER_NOVA) && (iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS))
		{
			cout << "Card 1 is not a SuperNova card!" << endl;
			BlueVelvetDestroy(pSDK);
			system("pause");
			return 0;
		}

		iCardType = pSDK->has_video_cardtype(2);
		if((iCardType != CRD_BLUE_SUPER_NOVA) && (iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS))
		{
			cout << "Card 2 is not a SuperNova card!" << endl;
			BlueVelvetDestroy(pSDK);
			system("pause");
			return 0;
		}

		//we have two cards and will use two output channels on each card
		BailOut(pSDK);	//detach this object from the card; we'll reinitialise everything in the next function
		cout << "Using two cards to render 4K image as 4 x dual link 2K SDI streams (10bit 4:4:4)" << endl << endl;
		Playback4K_444_TwoCards();
	}

	system("pause");
	return RetVal;
}
