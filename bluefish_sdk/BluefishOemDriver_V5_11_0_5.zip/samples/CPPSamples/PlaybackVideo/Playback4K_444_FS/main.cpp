// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	Playback4K_444_FS
// Written by:			Tim Bragulla
// Date:				20 June 2012
//
// Brief description:	This sample application shows how to playback a 10bit 4:4:4 4K video frame as 4 individual Dual Link 2K SDI video streams
//						(2 SuperNova cards, 8 cables) using FRAMESTORE mode
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//		Files:					Sample4K.dpx
//								Sample4K.yuv
//

#include "stdafx.h"


int LoadBfImageDpx(BLUE_UINT8* pVideo)
{
	FILE* fp = NULL;
	DPXFileHeader FileHeader;
	int nVideoSize = 0;
	BLUE_UINT32* pTmp = NULL;
	BLUE_UINT8* pTmp8 = NULL;

	fp = fopen("Sample4K.dpx", "rb");
	if(fp)
	{
		//1. read file header
		fread(&FileHeader, sizeof(DPXFileHeader), 1, fp);
		nVideoSize = FileHeader.file_size - FileHeader.offset;
		float fVideoSize = (float)nVideoSize;
	
		//2. rewind file pointer to start of the file
		fseek(fp, 0, SEEK_SET);

		//3. adjust file pointer to point to start of video area; we don't need this info
		fread(pVideo, 1, FileHeader.offset, fp);

		//4. read video data into our page aligned video buffer
		fread(pVideo, 1, nVideoSize, fp);
		fclose(fp);
	}
	else
	{
		MessageBox(NULL, L"Could not load file Sample4K.dpx", L"Error", MB_OK);
		return -1;
	}
	return 0;
}

int LoadBfImageYUV8Bit(BLUE_UINT8* pVideo)
{
	FILE* fp = NULL;
	int nVideoSize = 0;
	BLUE_UINT32* pTmp = NULL;
	BLUE_UINT8* pTmp8 = NULL;

	fp = fopen("Sample4K.yuv", "rb");
	if(fp)
	{
		fseek(fp, 0, SEEK_END);
		nVideoSize = ftell (fp);
		fseek(fp, 0, SEEK_SET);
		float fVideoSize = (float)nVideoSize;
		fread(pVideo, 1, nVideoSize, fp);

		fclose(fp);
	}
	else
	{
		MessageBox(NULL, L"Could not load file Sample4K.yuv", L"Error", MB_OK);
		return -1;
	}
	return 0;
}

void ClearYUVBuffer(BLUE_UINT8* pVideoBuffer, UINT32 nSize)
{
	BLUE_UINT8* pTmp = pVideoBuffer;
	for(UINT32 i=0; i<nSize/2; i++)
	{
		*pTmp = 0x80; pTmp++;
		*pTmp = 0x10; pTmp++;
	}
}

void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

void InitOutputChannel(CBlueVelvet4* pSDK, ULONG DefaultOutputChannel, ULONG VideoMode, ULONG UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultOutputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_playback_stop(0, 0);

	//Set the required video mode
	varVal.ulVal = VideoMode;
	pSDK->SetCardProperty(VIDEO_MODE, varVal);
	pSDK->QueryCardProperty(VIDEO_MODE, varVal);
	if(varVal.ulVal != VideoMode)
	{
		cout << "Can't set video mode; FIFO running already?" << endl;
		system("pause");
		BailOut(pSDK);
		exit(0);
	}

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required video mode, update type and memory format
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	//enable dual link
	varVal.ulVal = 1;
	pSDK->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT,varVal);	//this automatically sets up the routing

	//set format type to be 4:4:4
	varVal.ulVal = Signal_FormatType_444_10BitSDI;
	pSDK->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT_SIGNAL_FORMAT_TYPE,varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
}

int Playback4K_444_TwoCards()
{
	CBlueVelvet4* pSDK_ChA = NULL;
	CBlueVelvet4* pSDK_ChB = NULL;
	CBlueVelvet4* pSDK_ChC = NULL;
	CBlueVelvet4* pSDK_ChD = NULL;

	int iDevices = 0;
	ULONG VideoMode = VID_FMT_2048_1080PSF_2400;
	ULONG UpdateFormat = UPD_FMT_FRAME;
	ULONG MemoryFormat = MEM_FMT_BGR;
	ULONG VideoEngine = VIDEO_ENGINE_FRAMESTORE;

	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDK_ChA = BlueVelvetFactory4();
	pSDK_ChB = BlueVelvetFactory4();
	pSDK_ChC = BlueVelvetFactory4();
	pSDK_ChD = BlueVelvetFactory4();
	
	//Due to the checks beforehand we can assume that we have a SuperNova QuadOut available as card 1
	//Attach the SDK objects to the card
	pSDK_ChA->device_attach(1, 0);
	pSDK_ChB->device_attach(1, 0);
	pSDK_ChC->device_attach(2, 0);
	pSDK_ChD->device_attach(2, 0);

	InitOutputChannel(pSDK_ChA, BLUE_VIDEO_OUTPUT_CHANNEL_A, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);
	InitOutputChannel(pSDK_ChB, BLUE_VIDEO_OUTPUT_CHANNEL_B, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);
	InitOutputChannel(pSDK_ChC, BLUE_VIDEO_OUTPUT_CHANNEL_A, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);
	InitOutputChannel(pSDK_ChD, BLUE_VIDEO_OUTPUT_CHANNEL_B, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);

	//Routing is set up automatically by setting up dual link in the above InitOutputChannel() function

	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDK_ChA->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	//turn off audio, we won't need it and it cause an issue in earlier version of the QuadOut firmware
	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);
	pSDK_ChB->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);
	pSDK_ChC->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);
	pSDK_ChD->SetCardProperty(EMBEDDED_AUDIO_OUTPUT, varVal);

	//Set the required video mode
	varVal.ulVal = VideoMode;
	pSDK_ChA->SetCardProperty(VIDEO_MODE, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_MODE, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_MODE, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_MODE, varVal);

	OVERLAPPED OverlapChA;
	OVERLAPPED OverlapChB;
	OVERLAPPED OverlapChC;
	OVERLAPPED OverlapChD;
	OverlapChA.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OverlapChB.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OverlapChC.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OverlapChD.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	ULONG GoldenSize = BlueVelvetGolden(VideoMode, MemoryFormat, UpdateFormat);
	ULONG PixelsPerLine = BlueVelvetLinePixels(VideoMode);
	ULONG VideoLines =  BlueVelvetFrameLines(VideoMode, UpdateFormat);
	ULONG BytesPerFrame = BlueVelvetFrameBytes(VideoMode, MemoryFormat, UpdateFormat);
	ULONG BytesPerLine = BlueVelvetLineBytes(VideoMode, MemoryFormat);

	cout << "Video Golden:          " << GoldenSize << endl;
	cout << "Video Pixels per line: " << PixelsPerLine << endl;
	cout << "Video lines:           " << VideoLines << endl;
	cout << "Video Bytes per frame: " << BytesPerFrame << endl;
	cout << "Video Bytes per line:  " << BytesPerLine << endl;

	//clear all video buffers on the cards to black; the 2VUY file has a height of 2048, but our video buffers have a height of 2160 (=2*1080)
	//so we want the areas that are not updated to be black
	BLUE_UINT8* pBlackVideoBuffer = NULL;
	pBlackVideoBuffer = (BLUE_UINT8*)VirtualAlloc(NULL, 2048*1080*2, MEM_COMMIT, PAGE_READWRITE);
	ClearYUVBuffer(pBlackVideoBuffer, 2048*1080*2);
	ULONG BufferCount = 4;
	for(ULONG i=0; i<BufferCount; i++)
	{
		pSDK_ChA->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*2, NULL, i);
		pSDK_ChB->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*2, NULL, i);
		pSDK_ChC->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*2, NULL, i);
		pSDK_ChD->system_buffer_write_async(pBlackVideoBuffer, 2048*1080*2, NULL, i);
	}
	VirtualFree(pBlackVideoBuffer, 0, MEM_RELEASE);
	pBlackVideoBuffer = NULL;

	BLUE_UINT8* pVideoBuffer4KImage8Bit = NULL;
	pVideoBuffer4KImage8Bit = (BLUE_UINT8*)VirtualAlloc(NULL, 4096*2160*2, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBuffer4KImage8Bit, 4096*2160*2);
	if(LoadBfImageYUV8Bit(pVideoBuffer4KImage8Bit) == -1)
		return 0;

	varVal.ulVal = 2048*2;	//image width for each 2K stream is 2048 pixels * 2 bytes per pixel
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	
	varVal.ulVal = 1024;	//image height of 4K source image is 1024 lines
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);

	varVal.ulVal = 4096*2;	//image width of 4K source image is 4096 pixels * 2 bytes per pixel
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);

	HANDLE DmaHandles[4] = { OverlapChA.hEvent, OverlapChB.hEvent, OverlapChC.hEvent, OverlapChD.hEvent };
	BlueBenchMark bm;
	double dTime = 0.0;

	//synchronise with the card
	ULONG FieldCount = 0;
	ULONG LastFieldCount = 0;
	DWORD BytesReturned = 0;
	ULONG CurrentBufferIndex = 0;
	pSDK_ChA->wait_output_video_synch(UpdateFormat, LastFieldCount);

	while(!_kbhit())
	{
		//cards must be genlocked; only then all for output channels are completely in synch
		pSDK_ChA->wait_output_video_synch(UPD_FMT_FRAME, FieldCount);
		bm.StartClock();

		//DMA the buffers to the card
		//Source Quadrant is only 2048*1024, but target frame is 2048*1080, so we have to add an offset to the DMA call
		//									pointer to source, size of source image, event handle, buffer id, offset on card
		pSDK_ChA->system_buffer_write_async(pVideoBuffer4KImage8Bit, 4096*1024*2, &OverlapChA, CurrentBufferIndex, 2048*(1080-1024)*2);
		pSDK_ChB->system_buffer_write_async(pVideoBuffer4KImage8Bit + 2048*2, 4096*1024*2, &OverlapChB, CurrentBufferIndex, 2048*(1080-1024)*2);
		pSDK_ChC->system_buffer_write_async(pVideoBuffer4KImage8Bit + 4096*1024*2, 4096*1024*2, &OverlapChC, CurrentBufferIndex);
		pSDK_ChD->system_buffer_write_async(pVideoBuffer4KImage8Bit + 4096*1024*2 + 2048*2, 4096*1024*2, &OverlapChD, CurrentBufferIndex);

		//while DMA is happening read the next frame into our buffer
		// read frame...start
		// read frame...done

		//wait for all 4 DMA transfers to be finished
		GetOverlappedResult(pSDK_ChA->m_hDevice, &OverlapChA, &BytesReturned, TRUE);
		ResetEvent(OverlapChA.hEvent);
		GetOverlappedResult(pSDK_ChB->m_hDevice, &OverlapChB, &BytesReturned, TRUE);
		ResetEvent(OverlapChB.hEvent);
		GetOverlappedResult(pSDK_ChC->m_hDevice, &OverlapChC, &BytesReturned, TRUE);
		ResetEvent(OverlapChC.hEvent);
		GetOverlappedResult(pSDK_ChD->m_hDevice, &OverlapChD, &BytesReturned, TRUE);
		ResetEvent(OverlapChD.hEvent);

		//schedule the frames to be rendered at the next interrupt
		pSDK_ChA->render_buffer_update(CurrentBufferIndex);
		pSDK_ChB->render_buffer_update(CurrentBufferIndex);
		pSDK_ChC->render_buffer_update(CurrentBufferIndex);
		pSDK_ChD->render_buffer_update(CurrentBufferIndex);

		bm.StopClock();
		dTime = bm.GetTimeElapsed();

		CurrentBufferIndex = (++CurrentBufferIndex)%BufferCount;

		//track FieldCount to see if frames were dropped
		if(LastFieldCount + 2 < FieldCount)
		{
			cout << "Error: dropped " << ((FieldCount - LastFieldCount + 2)/2) << " frames" << "Time taken: " << (float)dTime <<endl;
		}
		else
			cout << "Time taken: " << (float)dTime << endl;

		LastFieldCount = FieldCount;
 	}

	//turn on black generator (unless we want to keep displaying the last rendered frame)
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK_ChA->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK_ChB->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK_ChC->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK_ChD->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	//turn off dual link
	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT,varVal);
	varVal.ulVal = Signal_FormatType_Independent_422;
	pSDK_ChA->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT_SIGNAL_FORMAT_TYPE, varVal);

	varVal.ulVal = 0;
	pSDK_ChB->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT,varVal);
	varVal.ulVal = Signal_FormatType_Independent_422;
	pSDK_ChB->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT_SIGNAL_FORMAT_TYPE, varVal);

	varVal.ulVal = 0;
	pSDK_ChC->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT,varVal);
	varVal.ulVal = Signal_FormatType_Independent_422;
	pSDK_ChC->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT_SIGNAL_FORMAT_TYPE, varVal);

	varVal.ulVal = 0;
	pSDK_ChD->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT,varVal);
	varVal.ulVal = Signal_FormatType_Independent_422;
	pSDK_ChD->SetCardProperty(VIDEO_DUAL_LINK_OUTPUT_SIGNAL_FORMAT_TYPE, varVal);

	//fix routing
	RouteChannel(pSDK_ChA, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChA, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_C, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChB, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChB, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_D, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	RouteChannel(pSDK_ChC, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChC, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_C, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChD, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);	
	RouteChannel(pSDK_ChD, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_D, BLUE_CONNECTOR_PROP_SINGLE_LINK);	

	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_WIDTH, varVal);
	
	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_HEIGHT, varVal);

	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChB->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChC->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);
	pSDK_ChD->SetCardProperty(VIDEO_IMAGE_PITCH, varVal);

	CloseHandle(OverlapChA.hEvent);
	CloseHandle(OverlapChB.hEvent);
	CloseHandle(OverlapChC.hEvent);
	CloseHandle(OverlapChD.hEvent);

	VirtualUnlock(pVideoBuffer4KImage8Bit, 4096*2160*2);
	VirtualFree(pVideoBuffer4KImage8Bit, 0, MEM_RELEASE);

	BailOut(pSDK_ChA);
	BailOut(pSDK_ChB);
	BailOut(pSDK_ChC);
	BailOut(pSDK_ChD);

	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Playback4K_444_FS sample app" << endl;

	int RetVal = 0;
	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;
	VARIANT varVal;
	varVal.vt = VT_UI4;

	pSDK = BlueVelvetFactory4();

	//Check if there are any cards available
	pSDK->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	if(iDevices < 2)	//we need two SuperNova QuadOut cards for 4 dual link signals (8 cables)
	{
		cout << "This sample app needs two SuperNova QuadOut cards!" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}
	else	//if there are more than 1 device we will use two cards for two SDI streams each
	{
		int iCardType = pSDK->has_video_cardtype(1);
		if((iCardType != CRD_BLUE_SUPER_NOVA) && (iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS))
		{
			cout << "Card 1 is not a SuperNova card!" << endl;
			BlueVelvetDestroy(pSDK);
			system("pause");
			return 0;
		}

		iCardType = pSDK->has_video_cardtype(2);
		if((iCardType != CRD_BLUE_SUPER_NOVA) && (iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS))
		{
			cout << "Card 2 is not a SuperNova card!" << endl;
			BlueVelvetDestroy(pSDK);
			system("pause");
			return 0;
		}

		//we have two cards and will use two output channels on each card
		BailOut(pSDK);	//detach this object from the card; we'll reinitialise everything in the next function
		cout << "Using two cards to render 4K image as 4 x dual link 2K SDI streams (10bit 4:4:4)" << endl << endl;
		Playback4K_444_TwoCards();
	}

	system("pause");
	return RetVal;
}
