// EmbAudioDecoder.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include <windows.h>
#include <comdef.h>
#include <conio.h>
#include <iostream>
#include "BlueVelvet4.h"
#include "BlueHancUtils.h"
#include "WaveFile.h"
#include "Commdlg.h"
#include "resource.h"
#include "VideoChannelSelector.h"

using namespace std;

#pragma pack(push, blue_timecode_struct, 1)
struct BlueTimeCodeStruct
{
	ULONGLONG	unit_frame:4,			//00-03:	frame
				binary1:4,				//04-07:	not used, set to 0
				ten_frame:2,			//08-09:	frame tens
				drop_frame_flag:1,		//10:		only 30/60 framerates: drop frame flag, otherwise 0
				color_frame_flag:1,		//11:		not used, set to 0
				binary2:4,				//12-15:	not used, set to 0
				unit_second:4,			//16-19:	second
				binary3:4,				//20-23:	not used, set to 0
				ten_second:3,			//24-26:	second tens
				field_bit:1,			//27:		24/30/60 framerates: odd parity; 25/50 framerates: not used, set to 0
				binary4:4,				//28-31:	not used, set to 0
				unit_minute:4,			//32-35:	minute
				binary5:4,				//36-39:	not used, set to 0
				ten_minute:3,			//40-42:	minute tens
				binarygroupflag43:1,	//43:		not used, set to 0
				binary6:4,				//44-47:	not used, set to 0
				unit_hours:4,			//48-51:	hour
				binary7:4,				//52-55:	not used, set to 0
				ten_hours:2,			//56-57:	hour tens
				binarygroupflag58:1,	//58:		not used, set to 0
				binarygroupflag59:1,	//59:		24/30/60 framerates: not used, set to 0; 25/50 framerates: odd parity
				binary8:4;				//60-63:	not used, set to 0
};

struct TimeCode
{
	union 
	{
		struct BlueTimeCodeStruct struct_timecode;
		ULONGLONG timecode_u64;
	};
	
};
#pragma pack(pop, blue_timecode_struct)

bool get_output_file(wchar_t* pszFileName)
{
    OPENFILENAME ofn;

    ZeroMemory(&ofn, sizeof(ofn));
	*pszFileName = L'\0';

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = 0;
    ofn.lpstrFilter = L"Audio Wave Files (*.wav)\0*.wav\0";
    ofn.lpstrFile = pszFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
    ofn.lpstrDefExt = L"wav";

    if(GetSaveFileName(&ofn))
    {
		return true;
    }

	return false;
}

void print_timecode_value(struct TimeCode tc)
{
	unsigned int framePerSec=25,frames ,second,minutes ,hours;
	hours =		(UINT32)(tc.struct_timecode.ten_hours*10)+tc.struct_timecode.unit_hours;
	minutes =	(UINT32)(tc.struct_timecode.ten_minute*10)+tc.struct_timecode.unit_minute;
	second =	(UINT32)(tc.struct_timecode.ten_second*10)+tc.struct_timecode.unit_second;
	frames =	(UINT32)(tc.struct_timecode.ten_frame*10)+tc.struct_timecode.unit_frame;	
	printf("(%02d:%02d:%02d:%02d)", hours, minutes, second, frames);
}

#define MAX_HANC_BUFFER_SIZE (256*1024)


/**
This function captures audio from an epoch card.
To stop capture press any key.
pFileName: wave file name to capture to.If file name is NULL, we would playback the captured audio sample 
			using WriteAudioSample function.
channel: Specifies whether to capture from video input channel A or B
sample_type: whether to audio channel data bitdepth should be 16,24 or 32 bits 
channel_mask: specifies which channels should be captured.
audio_ch_count: specified how many channels should be captured.
audio_input_source:specifies whether audio should be captured from AES or embedded source.(this is only valid on epoch range of cards).
video_update_type: specifies whether the video input framestore should be set to frame or field
*/
void CaptureAudio_FifoMode(		wchar_t* pFileName,
								EBlueVideoChannel channel, 
								BLUE_UINT32 sample_type,
								BLUE_UINT32 channel_mask,
								BLUE_UINT32 audio_ch_count,
								BLUE_UINT32 audio_input_source,
								BLUE_UINT32 video_update_type)
{
	unsigned long video_engine = VIDEO_ENGINE_DUPLEX;
	unsigned long fieldcount = 0;
	int nHancField1BufferId = -1;
	unsigned int nHancField1TS=0;
	unsigned int card_index=1;
	int device_count;
	int nHancBufferId=-1;
	int nCardType = 0;
	BLUE_UINT32* pBuffer,*read_video_buffer,nBytesWritten, nSamplesWritten,last_field_count=0,last_timecode=0;
	BLUE_UINT32* dest_data_ptr;
	BLUE_UINT32 nBytesPerAudioChannel = 2;
	CWaveFile	wav_adapter;
	WAVEFORMATEX wav_file_info;
	CBlueVelvet4* pSDK = NULL;
	struct blue_videoframe_info_ex video_capture_frame;
	TimeCode rp188_vitc,rp188_ltc,ext_ltc,sd_vitc;
	int	CompostLater = 0;
	unsigned int capture_fifo_size = 0,VidFmt,MemFmt,video_frame_size,index=0;
	BLUE_UINT32 written = 0;
	int card_type;
	BLUE_UINT32 sample_count_NotUsed = 1920, audio_samplesize = AUDIO_CHANNEL_16BIT;
	int LastFrameWasInvalid = 0;
	FILE * fp=NULL;
	pSDK = BlueVelvetFactory4();
	pSDK->device_enumerate(device_count);
	card_index=1;
	// If there are multiple cards in the machine 
	// give user the option to select which card they want to work with
	if (device_count > 1)
	{
		for (int i=1;i<=device_count;i++)
		{
			nCardType  = pSDK->has_video_cardtype(i);
			switch (nCardType)
			{
			case CRD_BLUE_EPOCH_2K_HORIZON:
				printf("Epoch 2K Horizon : %d\n",i);
				break;
			case CRD_BLUE_EPOCH_2K_ULTRA:
				printf("Epoch 2K ULTRA : %d\n",i);
				break;
			case CRD_BLUE_EPOCH_2K_CORE:
				printf("Epoch 2K Core : %d\n",i);
				break;
			case CRD_BLUE_EPOCH_HORIZON:
				printf("Epoch Horizon : %d\n",i);
				break;
			case CRD_BLUE_EPOCH_ULTRA:
				printf("Epoch  ULTRA : %d\n",i);
				break;
			case CRD_BLUE_EPOCH_CORE:
				printf("Epoch Core : %d\n",i);
				break;
			case CRD_BLUE_SUPER_NOVA:
				printf("Super Nova : %d\n",i);
				break;
			}
		}
		printf("Select Card:");
		scanf("%d",&card_index);
	}
		
	pSDK->device_attach(card_index,0);

	OVERLAPPED overlap;
	::ZeroMemory(&overlap, sizeof(overlap));
	overlap.hEvent = ::CreateEvent( NULL, TRUE, FALSE, NULL );

	VARIANT variantValue;
	variantValue.vt  = VT_UI4;
	variantValue.ulVal = channel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL,variantValue);
	
	variantValue.vt = VT_UI4;
	variantValue.ulVal = video_update_type;	
	pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE,variantValue);

	pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE,variantValue);
	VidFmt = variantValue.ulVal;

	pSDK->QueryCardProperty(VIDEO_INPUT_MEMORY_FORMAT,variantValue);
	MemFmt = variantValue.ulVal;
	video_frame_size = BlueVelvetGolden(VidFmt,MemFmt,video_update_type);

	variantValue.vt = VT_UI4;
	variantValue.ulVal = (audio_input_source == AUDIO_INPUT_SOURCE_AES)?BLUE_AUDIO_AES:BLUE_AUDIO_EMBEDDED;
	pSDK->SetCardProperty(AUDIO_INPUT_PROP,variantValue);
	card_type = pSDK->has_video_cardtype();
	if(card_type != CRD_BLUE_EPOCH_HORIZON &&
		card_type != CRD_BLUE_EPOCH_CORE &&
		card_type != CRD_BLUE_EPOCH_ULTRA &&
		card_type != CRD_BLUE_EPOCH_2K_HORIZON &&
		card_type != CRD_BLUE_EPOCH_2K_CORE &&
		card_type != CRD_BLUE_EPOCH_2K_ULTRA &&
		card_type != CRD_BLUE_CREATE_HD &&
		card_type != CRD_BLUE_CREATE_2K &&
		card_type != CRD_BLUE_CREATE_2K_ULTRA &&
		card_type != CRD_BLUE_SUPER_NOVA)
	{
		void* pBlueDevice = blue_attach_to_device(1);
		EBlueConnectorPropertySetting video_routing[1];
		video_routing[0].channel = channel;	
		video_routing[0].propType = BLUE_CONNECTOR_PROP_SINGLE_LINK;
		video_routing[0].connector = channel == BLUE_VIDEO_INPUT_CHANNEL_A ? 
				BLUE_CONNECTOR_SDI_INPUT_A : BLUE_CONNECTOR_SDI_INPUT_B;
		blue_set_connector_property(pBlueDevice, 1, video_routing);
		blue_detach_from_device(&pBlueDevice);
	}

	if (sample_type & AUDIO_CHANNEL_16BIT)
	{
		nBytesPerAudioChannel = 2;
		wav_file_info.wBitsPerSample = 16;
	}
	else
	if (sample_type & AUDIO_CHANNEL_24BIT)
	{
		nBytesPerAudioChannel =3;
		wav_file_info.wBitsPerSample = 24;
	}
	else
	{
		nBytesPerAudioChannel =4;
		wav_file_info.wBitsPerSample = 32;
	}

	
	wav_file_info.nSamplesPerSec = 48000;
	wav_file_info.wFormatTag = WAVE_FORMAT_PCM;
	wav_file_info.cbSize  = sizeof(wav_file_info);
	wav_file_info.nBlockAlign = (WORD)(audio_ch_count * wav_file_info.wBitsPerSample / 8);
	wav_file_info.nAvgBytesPerSec = wav_file_info.nBlockAlign*wav_file_info.nSamplesPerSec;
	wav_file_info.nChannels = audio_ch_count;
	
	pBuffer = (BLUE_UINT32 *)VirtualAlloc(NULL,MAX_HANC_BUFFER_SIZE,MEM_COMMIT, PAGE_READWRITE);
	read_video_buffer =(BLUE_UINT32 *)VirtualAlloc(NULL,video_frame_size,MEM_COMMIT, PAGE_READWRITE);

	dest_data_ptr = new BLUE_UINT32[2002*16*4]; //can accept upto 16 channels
	variantValue.ulVal = video_engine;
	pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, variantValue);

	pSDK->video_capture_stop();
	pSDK->wait_input_video_synch(video_update_type, fieldcount);

	ULONG ulVideoStandard;
	struct hanc_decode_struct  decode;
	bool bIgnoreTimeCodeContinuity=false;
	memset(&decode,0,sizeof(decode));
	decode.audio_ch_required_mask = channel_mask;
	decode.audio_pcm_data_ptr = dest_data_ptr;
	decode.audio_split_buffer_mask = 0;
	decode.type_of_sample_required = sample_type;
	decode.max_expected_audio_sample_count = 2002;  // this is the biggest audio frame that epoch can generate .
													// this happens in 1080PSF 23 video mode.
	pSDK->get_video_input_format(ulVideoStandard);
	unsigned int count=0;
	if ( ulVideoStandard != VID_FMT_INVALID )
	{	
		pSDK->video_capture_start();
		if (pFileName)
		{
			wav_adapter.Open(pFileName,&wav_file_info,WAVEFILE_WRITE);
		}
		//else
		//{
		//	pSDK->InitAudioPlaybackMode();
		//}

		while (!_kbhit())
		{
			GetVideo_CaptureFrameInfoEx(pSDK, &overlap, video_capture_frame, CompostLater, &capture_fifo_size);
			if(video_capture_frame.nVideoSignalType < VID_FMT_INVALID && video_capture_frame.BufferId != -1)
			{
				pSDK->system_buffer_read_async((unsigned char *)read_video_buffer,video_frame_size,NULL,
												BlueImage_VBI_HANC_DMABuffer(video_capture_frame.BufferId,BLUE_DATA_FRAME));
				nHancBufferId = -1;				
				if (video_update_type == UPD_FMT_FRAME)
				{
					nHancBufferId = video_capture_frame.BufferId;
				}
				else
				{
					if ((video_capture_frame.nFrameTimeStamp & 0x1)==0)	
					{
						nHancField1BufferId = video_capture_frame.BufferId;
						nHancField1TS = video_capture_frame.nFrameTimeStamp;
					}
					else
					{
						if (video_capture_frame.nFrameTimeStamp == (nHancField1TS +1))
							nHancBufferId = nHancField1BufferId;
					}
				}

				if (nHancBufferId != -1)
				{
					//capture_frame_count--;
					// do hanc decoder only when you get field 1 + and Field 1 video data when in field mode.
					// this is the reason why we store the field 1 buffer id and when we get field 2 buffer id 
					// we schedule a hanc buffer DMA
					// if you dma the buffer before you get field 2 , you will only get half of the hanc frame.
					pSDK->system_buffer_read_async((unsigned char *)pBuffer,MAX_HANC_BUFFER_SIZE,NULL,
												BlueImage_VBI_HANC_DMABuffer(nHancBufferId,BLUE_DATA_HANC));
					{
							decode.raw_custom_anc_pkt_data_ptr = 0;
							decode.audio_input_source = audio_input_source;
							hanc_decoder_ex(card_type,pBuffer,&decode);
							nSamplesWritten = decode.no_audio_samples;
					}
					// use the nFrameTimeStamp to determine dropped frame.  
					/*ATLTRACE("Dropped frame %d Video Frame Field count %d Video Input signal %d sample count %d\n",
															video_capture_frame.DroppedFrameCount,
															video_capture_frame.nFrameTimeStamp,
															video_capture_frame.nVideoSignalType,decode.no_audio_samples);*/
					rp188_vitc.timecode_u64 = decode.timecodes[0];// RP188 VITC time code
					rp188_ltc.timecode_u64 = decode.timecodes[1]; // RP188 LTC time code
					sd_vitc.timecode_u64 = decode.timecodes[2]; // this field is only valid for SD video signal 
					ext_ltc.timecode_u64 = decode.timecodes[3]; // To capture external LTC you need to connect a cable to the onboard LTC connector

					print_timecode_value(rp188_vitc);
					//print_timecode_value(rp188_ltc);
					//print_timecode_value(sd_vitc);
					printf(" Sample Count %d mask %x \n",(decode.no_audio_samples/audio_ch_count),decode.audio_split_buffer_mask);

					if (count %100 == 0)
						printf("[%8d] TS=%8d BFId=%2d Got %4d samples TC %I64X video signal %d raw count %d \n",count,
											video_capture_frame.nFrameTimeStamp,video_capture_frame.BufferId,
											decode.no_audio_samples/audio_ch_count,
											decode.timecodes[0],video_capture_frame.nVideoSignalType,decode.no_audio_samples);
					if ( (decode.no_audio_samples/audio_ch_count) > decode.max_expected_audio_sample_count)
					{
						printf("[%8d] Error TS=%8d BFId=%2d Got %4d samples TC %I64X video signal %d raw count %d \n",count,
											video_capture_frame.nFrameTimeStamp,video_capture_frame.BufferId,
											decode.no_audio_samples/audio_ch_count,
											decode.timecodes[0],video_capture_frame.nVideoSignalType,decode.no_audio_samples);
						//FILE * fp;
						//fp= fopen("RawHancFrame.bin","wb");
						//fwrite(pBuffer,1,256*1024,fp);
						//fclose(fp);
						break;
					}
					count++;
					last_field_count = video_capture_frame.nFrameTimeStamp;
					// If file name was provided then 
					if (nSamplesWritten && (pFileName))
						wav_adapter.Write(nBytesPerAudioChannel*nSamplesWritten,(BLUE_UINT8 *)dest_data_ptr,&nBytesWritten);
					//else
					//{
					//	if (count == 1)
					//		pSDK->StartAudioPlayback(0);
					//	pSDK->WriteAudioSample(channel_mask,dest_data_ptr,decode.no_audio_samples/audio_ch_count,sample_type,0);
					//}
				}
			}
			else
			{
				//if (video_capture_frame.nVideoSignalType == VID_FMT_INVALID)
				//	printf("No video input signal found\n");
				LastFrameWasInvalid = 1;
				pSDK->wait_input_video_synch(video_update_type,fieldcount);
			}
		}
		if (pFileName)
			wav_adapter.Close();
	//	else
	//	{
	//		pSDK->StopAudioPlayback();
	//		pSDK->EndAudioPlaybackMode();
	//	}
	}
	else
	{
		MessageBox(0, L"No input signal on SDI B", L"Embedded Audio Decoder", MB_OK);
	}
	::CloseHandle(overlap.hEvent);
	if (dest_data_ptr)
		delete [] dest_data_ptr;
	pSDK->video_capture_stop();
	pSDK->device_detach();
	::BlueVelvetDestroy(pSDK);
	VirtualFree(pBuffer,MAX_HANC_BUFFER_SIZE,MEM_DECOMMIT);
	VirtualFree(read_video_buffer,video_frame_size,MEM_DECOMMIT);
	printf("\n Press any key\n");
	_getch();
}


/**
This function captures audio from an epoch card.
To stop capture press any key.
pFileName: wave file name to capture to.If file name is NULL, we would playback the captured audio sample 
			using WriteAudioSample function.
channel: Specifies whether to capture from video input channel A or B
sample_type: whether to audio channel data bitdepth should be 16,24 or 32 bits 
channel_mask: specifies which channels should be captured.
audio_ch_count: specified how many channels should be captured.
audio_input_source:specifies whether audio should be captured from AES or embedded source.(this is only valid on epoch range of cards).
video_update_type: specifies whether the video input framestore should be set to frame or field


*/
void CaptureAudio_FramestoreMode(wchar_t* pFileName,
								EBlueVideoChannel channel, 
								BLUE_UINT32 sample_type,
								BLUE_UINT32 channel_mask,
								BLUE_UINT32 audio_ch_count,
								BLUE_UINT32 audio_input_source,
								BLUE_UINT32 video_update_type)
{
	unsigned long video_engine=VIDEO_ENGINE_FRAMESTORE, fieldcount = 0,max_buffer_count;
	int nHancField1BufferId=-1;
	unsigned int nHancField1TS=0,card_index=1;
	int device_count;
	int nHancBufferId=-1,nCardType;
	BLUE_UINT32* pBuffer,*read_video_buffer,nBytesWritten, nSamplesWritten,last_field_count=0,last_timecode=0;
	BLUE_UINT32* dest_data_ptr;
	BLUE_UINT32		nBytesPerAudioChannel =2;
	CWaveFile	wav_adapter;
	WAVEFORMATEX wav_file_info;
	CBlueVelvet4 * pSDK = NULL;
	TimeCode rp188_vitc,rp188_ltc,ext_ltc,sd_vitc;
	int	CompostLater = 0;
	unsigned int capture_fifo_size = 0,VidFmt,MemFmt,video_frame_size,index=0;
	BLUE_UINT32 written = 0;
	int card_type;
	BLUE_UINT32 sample_count_NotUsed = 1920, audio_samplesize = AUDIO_CHANNEL_16BIT;
	int LastFrameWasInvalid = 0;
	ULONG ulVideoStandard;
	struct hanc_decode_struct  decode;
	bool bIgnoreTimeCodeContinuity=false;

	FILE * fp=NULL;
	pSDK = BlueVelvetFactory4();
	pSDK->device_enumerate(device_count);
	card_index=1;
	// If there are multiple cards in the machine 
	// give user the option to select which card they want to work with
	if (device_count > 1)
	{
		for (int i=1;i<=device_count;i++)
		{
			nCardType  = pSDK->has_video_cardtype(i);
			switch (nCardType)
			{
			case CRD_BLUE_EPOCH_2K_HORIZON:
				printf("Epoch 2K Horizon : %d\n",i);
				break;
			case CRD_BLUE_EPOCH_2K_ULTRA:
				printf("Epoch 2K ULTRA : %d\n",i);
				break;
			case CRD_BLUE_EPOCH_2K_CORE:
				printf("Epoch 2K Core : %d\n",i);
				break;
			case CRD_BLUE_EPOCH_HORIZON:
				printf("Epoch Horizon : %d\n",i);
				break;
			case CRD_BLUE_EPOCH_ULTRA:
				printf("Epoch  ULTRA : %d\n",i);
				break;
			case CRD_BLUE_EPOCH_CORE:
				printf("Epoch Core : %d\n",i);
				break;
			case CRD_BLUE_SUPER_NOVA:
				printf("Super Nova : %d\n",i);
				break;
			}
		}
		printf("Select Card:");
		scanf("%d",&card_index);
	}
		
	pSDK->device_attach(card_index,0);

	OVERLAPPED overlap;
	::ZeroMemory(&overlap, sizeof(overlap));
	overlap.hEvent = ::CreateEvent( NULL, TRUE, FALSE, NULL );

	VARIANT variantValue;
	variantValue.vt  = VT_UI4;
	variantValue.ulVal = channel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL,variantValue);

	BOOL bSupportsPlayback = pSDK->has_output_sdi();
	
	variantValue.vt = VT_UI4;
	variantValue.ulVal = video_update_type;	
	pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE,variantValue);

	pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE,variantValue);
	VidFmt = variantValue.ulVal;

	pSDK->QueryCardProperty(VIDEO_INPUT_MEMORY_FORMAT,variantValue);
	MemFmt = variantValue.ulVal;
	video_frame_size = BlueVelvetGolden(VidFmt,MemFmt,video_update_type);

	card_type = pSDK->has_video_cardtype();
	if(card_type != CRD_BLUE_EPOCH_HORIZON &&
		card_type != CRD_BLUE_EPOCH_CORE &&
		card_type != CRD_BLUE_EPOCH_ULTRA &&
		card_type != CRD_BLUE_EPOCH_2K_HORIZON &&
		card_type != CRD_BLUE_EPOCH_2K_CORE &&
		card_type != CRD_BLUE_EPOCH_2K_ULTRA &&
		card_type != CRD_BLUE_CREATE_HD &&
		card_type != CRD_BLUE_CREATE_2K &&
		card_type != CRD_BLUE_CREATE_2K_ULTRA &&
		card_type != CRD_BLUE_SUPER_NOVA)
	{
		void* pBlueDevice = blue_attach_to_device(1);
		EBlueConnectorPropertySetting video_routing[1];
		video_routing[0].channel = channel;	
		video_routing[0].propType = BLUE_CONNECTOR_PROP_SINGLE_LINK;
		video_routing[0].connector = channel == BLUE_VIDEO_INPUT_CHANNEL_A ? 
				BLUE_CONNECTOR_SDI_INPUT_A : BLUE_CONNECTOR_SDI_INPUT_B;
		blue_set_connector_property(pBlueDevice, 1, video_routing);
		blue_detach_from_device(&pBlueDevice);
	}

	if (sample_type & AUDIO_CHANNEL_16BIT)
	{
		nBytesPerAudioChannel = 2;
		wav_file_info.wBitsPerSample = 16;
	}
	else
	if (sample_type & AUDIO_CHANNEL_24BIT)
	{
		nBytesPerAudioChannel =3;
		wav_file_info.wBitsPerSample = 24;
	}
	else
	{
		nBytesPerAudioChannel =4;
		wav_file_info.wBitsPerSample = 32;
	}

	
	wav_file_info.nSamplesPerSec = 48000;
	wav_file_info.wFormatTag = WAVE_FORMAT_PCM;
	wav_file_info.cbSize  = sizeof(wav_file_info);
	wav_file_info.nBlockAlign = (WORD)(audio_ch_count * wav_file_info.wBitsPerSample / 8);
	wav_file_info.nAvgBytesPerSec = wav_file_info.nBlockAlign*wav_file_info.nSamplesPerSec;
	wav_file_info.nChannels = audio_ch_count;
	
	pBuffer = (BLUE_UINT32 *)VirtualAlloc(NULL,MAX_HANC_BUFFER_SIZE,MEM_COMMIT, PAGE_READWRITE);
	read_video_buffer =(BLUE_UINT32 *)VirtualAlloc(NULL,video_frame_size,MEM_COMMIT, PAGE_READWRITE);

	dest_data_ptr = new BLUE_UINT32[2002*16*4]; //can accept upto 16 channels

	variantValue.vt  = VT_UI4;
	variantValue.ulVal = video_engine;
	pSDK->SetCardProperty(VIDEO_INPUT_ENGINE,variantValue);

	variantValue.vt  = VT_UI4;	
	pSDK->QueryCardProperty(VIDEO_CAPTURE_AVAIL_BUFFER_COUNT,variantValue);
	max_buffer_count = variantValue.ulVal;

	memset(&decode,sizeof(decode),0);
	decode.audio_ch_required_mask = channel_mask;
	decode.audio_pcm_data_ptr = dest_data_ptr;
	decode.audio_split_buffer_mask = 0;
	decode.type_of_sample_required = sample_type;
	decode.max_expected_audio_sample_count = 2002;  // this is the biggest audio frame that epoch can generate .
													// this happens in 1080PSF 23 video mode.
	pSDK->get_video_input_format(ulVideoStandard);
	unsigned int count=0;
	int capture_scheduled_buffer_id=-1,capture_in_progress_buffer_id=-1,captured_frame_bufffer_id=-1;
	if(ulVideoStandard != VID_FMT_INVALID)
	{	
		if (pFileName)
		{
			wav_adapter.Open(pFileName,&wav_file_info,WAVEFILE_WRITE);
		}
		else
		{
			if(bSupportsPlayback)
				pSDK->InitAudioPlaybackMode();
		}

		capture_scheduled_buffer_id = 0;

		//schedule first frame
		pSDK->wait_input_video_synch(video_update_type,fieldcount);
		pSDK->render_buffer_capture(BlueBuffer_Image_HANC(capture_scheduled_buffer_id),0);
		capture_in_progress_buffer_id = capture_scheduled_buffer_id;
		capture_scheduled_buffer_id++;

		//schedule second frame, mark frist frame in progress
		pSDK->wait_input_video_synch(video_update_type,fieldcount);
		pSDK->render_buffer_capture(BlueBuffer_Image_HANC(capture_scheduled_buffer_id),0);
		captured_frame_bufffer_id = capture_in_progress_buffer_id;
		capture_in_progress_buffer_id = capture_scheduled_buffer_id;
		capture_scheduled_buffer_id = (capture_scheduled_buffer_id+1)%max_buffer_count;

		//schedule third frame, mark second frame in progress, retrieve first frame (fully captured)
		while (!_kbhit())
		{
			pSDK->wait_input_video_synch(video_update_type,fieldcount);
			pSDK->render_buffer_capture(BlueBuffer_Image_HANC(capture_scheduled_buffer_id),0);
	
			pSDK->system_buffer_read_async((unsigned char *)read_video_buffer,video_frame_size,NULL,
											BlueImage_VBI_HANC_DMABuffer(captured_frame_bufffer_id,BLUE_DATA_FRAME));
			nHancBufferId = -1;				
			if (video_update_type == UPD_FMT_FRAME)
			{
				nHancBufferId = captured_frame_bufffer_id;
			}
			else
			{
				if (fieldcount & 0x1)
					nHancField1BufferId =captured_frame_bufffer_id;
				else
					nHancBufferId = nHancField1BufferId;
			}
			if (nHancBufferId != -1)
			{
				//capture_frame_count--;
				// do hanc decoder only when you get field 1 + and Field 1 video data when in field mode.
				// this is the reason why we store the field 1 buffer id and when we get field 2 buffer id 
				// we schedule a hanc buffer DMA
				// if you dma the buffer before you get field 2 , you will only get half of the hanc frame.
				pSDK->system_buffer_read_async((unsigned char *)pBuffer,MAX_HANC_BUFFER_SIZE,NULL,
											BlueImage_VBI_HANC_DMABuffer(nHancBufferId,BLUE_DATA_HANC));
				{
					decode.raw_custom_anc_pkt_data_ptr = 0;
						decode.audio_input_source = audio_input_source;
						hanc_decoder_ex(card_type,pBuffer,&decode);
						nSamplesWritten = decode.no_audio_samples;
				}
				// use the nFrameTimeStamp to determine dropped frame.  
				/*ATLTRACE("Dropped frame %d Video Frame Field count %d Video Input signal %d sample count %d\n",
														video_capture_frame.DroppedFrameCount,
														video_capture_frame.nFrameTimeStamp,
														video_capture_frame.nVideoSignalType,decode.no_audio_samples);*/
				rp188_vitc.timecode_u64 = decode.timecodes[0];// RP188 VITC time code
				rp188_ltc.timecode_u64 = decode.timecodes[1]; // RP188 LTC time code
				sd_vitc.timecode_u64 = decode.timecodes[2]; // this field is only valid for SD video signal 
				ext_ltc.timecode_u64 = decode.timecodes[3]; // To capture external LTC you need to connect a cable to the onboard LTC connector

				print_timecode_value(rp188_vitc);
				print_timecode_value(rp188_ltc);
				printf(" Buf ID %d Sample Count %d mask %x \n",nHancBufferId,(decode.no_audio_samples/audio_ch_count),decode.audio_split_buffer_mask);

				if (count %100 == 0)
					printf("[%8d] TS=%8d BFId=%2d Got %4d samples TC %I64X  raw count %d \n",count,
										fieldcount,nHancBufferId,
										decode.no_audio_samples/audio_ch_count,
										decode.timecodes[0],decode.no_audio_samples);
				if ( (decode.no_audio_samples/audio_ch_count) > decode.max_expected_audio_sample_count)
				{
					printf("%8d] Error TS=%8d BFId=%2d Got %4d samples TC %I64X  raw count %d \n",count,
										fieldcount,nHancBufferId,
										decode.no_audio_samples/audio_ch_count,
										decode.timecodes[0],decode.no_audio_samples);
					//FILE * fp;
					//fp= fopen("RawHancFrame.bin","wb");
					//fwrite(pBuffer,1,256*1024,fp);
					//fclose(fp);
					break;
				}
				count++;					
				// If file name was provided then 
				if (nSamplesWritten && (pFileName))
					wav_adapter.Write(nBytesPerAudioChannel*nSamplesWritten,(BLUE_UINT8 *)dest_data_ptr,&nBytesWritten);
				else
				{
					if(bSupportsPlayback)
					{
						if(count == 1)
							pSDK->StartAudioPlayback(0);
					
						pSDK->WriteAudioSample(channel_mask,dest_data_ptr,decode.no_audio_samples/audio_ch_count,sample_type,0);
					}
				}
			}

			captured_frame_bufffer_id = capture_in_progress_buffer_id;
			capture_in_progress_buffer_id = capture_scheduled_buffer_id;
			capture_scheduled_buffer_id = (capture_scheduled_buffer_id+1)%max_buffer_count;
		}
		if (pFileName)
			wav_adapter.Close();
		else
		{
			if(bSupportsPlayback)
			{
				pSDK->StopAudioPlayback();
				pSDK->EndAudioPlaybackMode();
			}
		}
	}
	else
	{
		MessageBox(0, L"No input signal on SDI B", L"Embedded Audio Decoder", MB_OK);
	}
	::CloseHandle(overlap.hEvent);
	if (dest_data_ptr)
		delete [] dest_data_ptr;

	pSDK->device_detach();
	::BlueVelvetDestroy(pSDK);
	VirtualFree(pBuffer,MAX_HANC_BUFFER_SIZE,MEM_DECOMMIT);
	VirtualFree(read_video_buffer,video_frame_size,MEM_DECOMMIT);
	printf("\n Press any key\n");
	_getch();
}

int _tmain(int argc, wchar_t* argv[])
{
	CVideoChannelSelector dlg;

	if (dlg.DoModal() == IDOK)
	{
		wchar_t file[MAX_PATH];
		if (dlg.m_bCaptureToFile)
			get_output_file(file);
		if (dlg.m_nVideoEngine == VIDEO_ENGINE_FRAMESTORE)
			CaptureAudio_FramestoreMode((dlg.m_bCaptureToFile)?file:NULL,
										dlg.m_nChannelSelection,
										dlg.m_nAudioChType,
										dlg.m_nAudioChannelMask,
										dlg.m_nAudioChannelCount,
										dlg.m_nAudioSource,
										dlg.m_nUpdFmt);
		else
			CaptureAudio_FifoMode(	(dlg.m_bCaptureToFile)?file:NULL,
									dlg.m_nChannelSelection,
									dlg.m_nAudioChType,
									dlg.m_nAudioChannelMask,
									dlg.m_nAudioChannelCount,
									dlg.m_nAudioSource,
									dlg.m_nUpdFmt);
	}

	system("pause");
	return 0;
}
