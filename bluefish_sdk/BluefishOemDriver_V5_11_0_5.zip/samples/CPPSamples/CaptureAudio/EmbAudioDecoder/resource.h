//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by EmbAudioDecoder.rc
//
#define IDCANCEL2                       4
#define IDD_SELECT_CHANNEL              101
#define IDC_CHANNEL_A                   1001
#define IDC_CHANNEL_B                   1002
#define IDC_LOOP_COUNT                  1003
#define IDC_RADIO_AUDIO_SOURCE_AES      1004
#define IDC_RADIO_AUDIO_SOURCE_EMB      1005
#define IDC_CHECK_CH1                   1006
#define IDC_CHECK_CH2                   1007
#define IDC_CHECK_CH3                   1008
#define IDC_CHECK_CH4                   1009
#define IDC_CHECK_CH5                   1010
#define IDC_CHECK_CH6                   1011
#define IDC_CHECK_CH7                   1012
#define IDC_CHECK_CH8                   1013
#define IDC_RADIO_FIELD_MODE            1014
#define IDC_RADIO_FRAME_MODE            1015
#define IDC_RADIO_24BIT_DEPTH           1016
#define IDC_RADIO_16BIT_DEPTH           1017
#define IDC_RADIO_32BIT_DEPTH           1018
#define IDC_CHECK_CAPTURE_TO_FILE       1019
#define IDC_RADIO_FRAMESTORE_VIDEOENGINE 1020
#define IDC_RADIO_FIFO_VIDEOENGINE      1021
#define IDC_CHANNEL_C                   1022
#define IDC_CHANNEL_D                   1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
