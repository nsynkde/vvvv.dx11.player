#pragma once

class CVideoChannelSelector : public CDialogImpl<CVideoChannelSelector>
{
public:
	CVideoChannelSelector() {};
	~CVideoChannelSelector() {};

	enum { IDD = IDD_SELECT_CHANNEL };

	EBlueVideoChannel m_nChannelSelection;
	bool m_bCaptureToFile;
	unsigned int m_nAudioSource;
	unsigned int m_nAudioChannelMask;
	unsigned int m_nAudioChannelCount;
	unsigned int m_nUpdFmt;
	unsigned int m_nAudioChType;
	unsigned int m_nVideoEngine;

private:
	BEGIN_MSG_MAP(CVideoChannelSelector)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_HANDLER(IDOK, BN_CLICKED, OnClickedOK)
		COMMAND_HANDLER(IDCANCEL, BN_CLICKED, OnClickedCancel)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{		
		m_nChannelSelection = BLUE_VIDEO_INPUT_CHANNEL_A;
		CheckDlgButton(IDC_CHANNEL_A, TRUE);
		CheckDlgButton(IDC_RADIO_AUDIO_SOURCE_EMB,TRUE);
		CheckDlgButton(IDC_RADIO_FRAME_MODE,TRUE);
		CheckDlgButton(IDC_RADIO_16BIT_DEPTH,TRUE);
		CheckDlgButton(IDC_RADIO_FIFO_VIDEOENGINE,TRUE);

		CheckDlgButton(IDC_CHECK_CH1, TRUE);
		CheckDlgButton(IDC_CHECK_CH2, TRUE);
		CheckDlgButton(IDC_CHECK_CH3, TRUE);
		CheckDlgButton(IDC_CHECK_CH4, TRUE);

		CheckDlgButton(IDC_CHECK_CAPTURE_TO_FILE, TRUE);

		CenterWindow();
		return 0;
	}
		
	LRESULT OnClickedOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		if(IsDlgButtonChecked(IDC_CHANNEL_D))
			m_nChannelSelection = BLUE_VIDEO_INPUT_CHANNEL_D;
		else if(IsDlgButtonChecked(IDC_CHANNEL_C))
			m_nChannelSelection = BLUE_VIDEO_INPUT_CHANNEL_C;
		else if(IsDlgButtonChecked(IDC_CHANNEL_B))
			m_nChannelSelection = BLUE_VIDEO_INPUT_CHANNEL_B;
		else
			m_nChannelSelection = BLUE_VIDEO_INPUT_CHANNEL_A;

		if (IsDlgButtonChecked(IDC_RADIO_AUDIO_SOURCE_AES))
			m_nAudioSource = AUDIO_INPUT_SOURCE_AES;
		else
			m_nAudioSource = AUDIO_INPUT_SOURCE_EMB;

		if (IsDlgButtonChecked(IDC_RADIO_FRAME_MODE))
			m_nUpdFmt = UPD_FMT_FRAME;
		else
			m_nUpdFmt = UPD_FMT_FIELD;

		if (IsDlgButtonChecked(IDC_RADIO_16BIT_DEPTH))
			m_nAudioChType = AUDIO_CHANNEL_16BIT;
		else
		if (IsDlgButtonChecked(IDC_RADIO_24BIT_DEPTH))
			m_nAudioChType = AUDIO_CHANNEL_24BIT;
		else
			m_nAudioChType = 0;

		if (IsDlgButtonChecked(IDC_RADIO_FRAMESTORE_VIDEOENGINE))
			m_nVideoEngine = VIDEO_ENGINE_FRAMESTORE;
		else
		if (IsDlgButtonChecked(IDC_RADIO_FIFO_VIDEOENGINE))
			m_nVideoEngine = VIDEO_ENGINE_DUPLEX;

		m_nAudioChannelMask = 0;
		m_nAudioChannelCount = 0;
		if (IsDlgButtonChecked(IDC_CHECK_CH1))
		{
			m_nAudioChannelMask |= (MONO_CHANNEL_1);
			m_nAudioChannelCount++;
		}

		if (IsDlgButtonChecked(IDC_CHECK_CH2))
		{
			m_nAudioChannelMask |= (MONO_CHANNEL_2);
			m_nAudioChannelCount++;
		}
		if (IsDlgButtonChecked(IDC_CHECK_CH3))
		{
			m_nAudioChannelMask |= (MONO_CHANNEL_3);
			m_nAudioChannelCount++;
		}
		if (IsDlgButtonChecked(IDC_CHECK_CH4))
		{
			m_nAudioChannelMask |= (MONO_CHANNEL_4);
			m_nAudioChannelCount++;
		}
		if (IsDlgButtonChecked(IDC_CHECK_CH5))
		{
			m_nAudioChannelMask |= (MONO_CHANNEL_5);
			m_nAudioChannelCount++;
		}

		if (IsDlgButtonChecked(IDC_CHECK_CH6))
		{
			m_nAudioChannelMask |= (MONO_CHANNEL_6);
			m_nAudioChannelCount++;
		}
		if (IsDlgButtonChecked(IDC_CHECK_CH7))
		{
			m_nAudioChannelMask |= (MONO_CHANNEL_7);
			m_nAudioChannelCount++;
		}
		if (IsDlgButtonChecked(IDC_CHECK_CH8))
		{
			m_nAudioChannelMask |= (MONO_CHANNEL_8);
			m_nAudioChannelCount++;
		}

		m_bCaptureToFile = false;
		if (IsDlgButtonChecked(IDC_CHECK_CAPTURE_TO_FILE))
			m_bCaptureToFile = true;
		
		EndDialog(IDOK);
		return 0;
	}

	LRESULT OnClickedCancel(WORD wNotifyCode, 
		WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(IDCANCEL);
		return 0;
	}
};
