// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	CaptureVideoSubFieldInterrupts_FS
// Written by:			Tim Bragulla
// Date:				25 June 2012
//
// Brief description:	This sample application shows how to capture SDI video using sub field interrupts in FRAMESTORE mode
//						This sample application also uses the video output channel A to playback the captured video frames/fields; this feature can be turned off
//						by commenting out the #define USE_OUTPUT_CHANNEL_AS_MONITOR
//						The sub field interrupts are not available in FIFO mode.
//						For interlaced video modes FIELD mode (UPD_FMT_FIELD) must be used and a maximum of 2 interrupts per field are advised
//						For progressive modes only FRAME mode (UPD_FMT_FRAME) can be used with a maximum of 4 interrupts per frame
//						Overall the minimum time between sub field interrupts should not be less than 10ms and the sub field lines must be even
//						All sub field chunks must be the same size.
//						Using sub field interrupts the normal wait_input_video_synch() function should not be used;
//						use blue_wait_video_sync_async() instead to retrieve the fieldcount and information on the current sub field interrupt
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"
#define USE_OUTPUT_CHANNEL_AS_MONITOR

extern struct blue_videomode_info gVideoModeInfo[];


int CompleteBlueAsyncReq(HANDLE hDevice, LPOVERLAPPED pOverlap)
{
	DWORD bytesReturned;
	ResetEvent(pOverlap->hEvent);
	GetOverlappedResult(hDevice, pOverlap, &bytesReturned, TRUE);
	//cout << "Bytes ret: " << bytesReturned << endl;
	return bytesReturned;
}

void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

BLUE_UINT32 InitInputChannelForSubFieldInterrupts(CBlueVelvet4* pSDK, ULONG DefaultInputChannel, ULONG& VideoMode, ULONG& UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	ULONG FieldCount = 0;
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultInputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_capture_stop();

	RouteChannel(pSDK, EPOCH_SRC_SDI_INPUT_A, EPOCH_DEST_INPUT_MEM_INTERFACE_CHA, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDK->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	//Check if we have a valid input signal
	pSDK->wait_input_video_synch(UPD_FMT_FRAME, FieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	if(varVal.ulVal >= InvalidVideoModeFlag)
	{
		cout << "No valid input signal on channel A" << endl;
		system("pause");
		BailOut(pSDK);
		exit(0);
	}
	VideoMode = varVal.ulVal;
	pSDK->SetCardProperty(VIDEO_MODE, varVal);

	BLUE_UINT32 nChunks = 2;
	if(gVideoModeInfo[VideoMode].bIsProgressive)
	{
		UpdateFormat = UPD_FMT_FRAME;
		if(gVideoModeInfo[VideoMode].nFrameRate > 25)
			nChunks = 2;	//this would mean an interrupt period of less than 10ms (= limit)
		else
			nChunks = 4;
	}
	else
	{
		UpdateFormat = UPD_FMT_FIELD;
		nChunks = 2;
	}

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required update type and memory format and make sure that there is a valid input signal
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);

	varVal.ulVal = nChunks;
	pSDK->SetCardProperty(EPOCH_SUBFIELD_INPUT_INTERRUPTS, varVal);

	cout << "Using " << nChunks << " chunks with video mode " << gVideoModeInfo[VideoMode].strVideoModeFriendlyName.c_str() << endl;

#ifdef USE_OUTPUT_CHANNEL_AS_MONITOR
	varVal.ulVal = BLUE_VIDEO_OUTPUT_CHANNEL_A;
	pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);
#endif

	return nChunks;
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "CaptureVideoSubFieldInterrupts_FS sample app" << endl;

	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;

	ULONG VideoMode = VID_FMT_INVALID;
	ULONG UpdateFormat = UPD_FMT_FIELD;
	ULONG MemoryFormat = MEM_FMT_2VUY;
	ULONG VideoEngine = VIDEO_ENGINE_FRAMESTORE;

	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDK = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDK->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card, in this case card 1
	if(BLUE_FAIL(pSDK->device_attach(1, 0)))
	{
		cout << "Error on device attach (channel A)" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Get the card type and firmware type
	int iCardType = pSDK->has_video_cardtype();
	if(	iCardType != CRD_BLUE_EPOCH_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_CORE &&
		iCardType != CRD_BLUE_EPOCH_ULTRA &&
		iCardType != CRD_BLUE_EPOCH_2K_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_2K_CORE &&
		iCardType != CRD_BLUE_EPOCH_2K_ULTRA &&
		iCardType != CRD_BLUE_SUPER_NOVA &&
		iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Card not supported for OEM capture" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	pSDK->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal);
	cout << "Product ID / firmware type: " << varVal.ulVal << endl;

	varVal.ulVal = 0;
	if(BLUE_FAIL(pSDK->QueryCardProperty(CARD_FEATURE_STREAM_INFO, varVal)))
	{
		cout << "Function not supported; need driver 5.10.2.x" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	unsigned int nOutputStreams = CARD_FEATURE_GET_SDI_OUTPUT_STREAM_COUNT(varVal.ulVal);
	unsigned int nInputStreams = CARD_FEATURE_GET_SDI_INPUT_STREAM_COUNT(varVal.ulVal);
	if(!nInputStreams)
	{
		cout << "Card does not support input channels" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

#ifdef USE_OUTPUT_CHANNEL_AS_MONITOR
	if(!nOutputStreams)
	{
		cout << "Card does not support output channels!" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}
#endif

	BLUE_UINT32 nChunks = InitInputChannelForSubFieldInterrupts(pSDK, BLUE_VIDEO_INPUT_CHANNEL_A, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);
	if(nChunks == 0)
	{
		cout << "Error determining nChunks" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	DWORD IrqReturn = 0;
	blue_video_sync_struct* pIrqInfo = new blue_video_sync_struct;
	memset(pIrqInfo, 0, sizeof(blue_video_sync_struct));

	pIrqInfo->video_channel = BLUE_VIDEO_INPUT_CHANNEL_A;
	pIrqInfo->sync_wait_type = UPD_FMT_FIELD;
	pIrqInfo->timeout_video_msc = IGNORE_SYNC_WAIT_TIMEOUT_VALUE;

	OVERLAPPED Overlap;
	Overlap.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	
	ULONG GoldenSize = BlueVelvetGolden(VideoMode, MemoryFormat, UpdateFormat);
	ULONG BytesPerFrame = BlueVelvetFrameBytes(VideoMode, MemoryFormat, UpdateFormat);
	ULONG ChunkSize = BytesPerFrame/nChunks;

	cout << "Golden       : " << GoldenSize << endl;
	cout << "BytesPerFrame: " << BytesPerFrame << endl;
	cout << "ChunkSize    : " << ChunkSize << endl;

	unsigned char* pVideoBuffer = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBuffer, GoldenSize);

	ULONG StartFieldCount = 0;
	ULONG CurrentFieldCount = 0;
	ULONG LastFieldCount = 0;
	ULONG ScheduleID = 0;
	ULONG CapturingID = 0;
	ULONG DoneID = 0;
	BOOL bWaitForField = TRUE;

	//We need to wait for a major interrupt (sub field interrupt == 0) before we schedule a frame to be captured
	USHORT SubFieldIrqs = 0;
	do
	{
		pIrqInfo->video_channel = BLUE_VIDEO_INPUT_CHANNEL_A;
		pIrqInfo->sync_wait_type = UpdateFormat;
		pIrqInfo->timeout_video_msc = IGNORE_SYNC_WAIT_TIMEOUT_VALUE;
		blue_wait_video_sync_async(pSDK, &Overlap, pIrqInfo);
		IrqReturn = WaitForSingleObject(Overlap.hEvent, 1000);
		CompleteBlueAsyncReq(pSDK->m_hDevice, &Overlap);

		SubFieldIrqs = pIrqInfo->subfield_interrupt;
		if(gVideoModeInfo[VideoMode].bIsProgressive || (pIrqInfo->video_msc & 0x1))
			bWaitForField = FALSE;

	}while(!((SubFieldIrqs == 0) && !bWaitForField));	//we need to schedule the field capture when SubFieldIrqs is 0

	//schedule the first field/frame to be captured
	pSDK->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
	CapturingID = ScheduleID;
	ScheduleID = (++ScheduleID%3);
	LastFieldCount = pIrqInfo->video_msc;

	//We need to wait for a major interrupt (sub field interrupt == 0) before we schedule a frame to be captured
	do
	{
		pIrqInfo->video_channel = BLUE_VIDEO_INPUT_CHANNEL_A;
		pIrqInfo->sync_wait_type = UpdateFormat;
		pIrqInfo->timeout_video_msc = IGNORE_SYNC_WAIT_TIMEOUT_VALUE;
		blue_wait_video_sync_async(pSDK, &Overlap, pIrqInfo);
		IrqReturn = WaitForSingleObject(Overlap.hEvent, 1000);
		CompleteBlueAsyncReq(pSDK->m_hDevice, &Overlap);

		SubFieldIrqs = pIrqInfo->subfield_interrupt;
	}while(SubFieldIrqs != 0);

	//schedule the next field/frame to be captured
	pSDK->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
	DoneID = CapturingID;
	CapturingID = ScheduleID;
	ScheduleID = (++ScheduleID%3);
	LastFieldCount = pIrqInfo->video_msc;
	StartFieldCount = pIrqInfo->video_msc;

	BLUE_UINT32 nOffset = 0;
	BLUE_UINT32 nFieldCountIncrement = 1;
	if(gVideoModeInfo[VideoMode].bIsProgressive)
		nFieldCountIncrement = 2;

	while(!_kbhit())
	{
		pIrqInfo->video_channel = BLUE_VIDEO_INPUT_CHANNEL_A;
		pIrqInfo->sync_wait_type = UpdateFormat;
		pIrqInfo->timeout_video_msc = IGNORE_SYNC_WAIT_TIMEOUT_VALUE;
		blue_wait_video_sync_async(pSDK, &Overlap, pIrqInfo);
		IrqReturn = WaitForSingleObject(Overlap.hEvent, 1000);
		CompleteBlueAsyncReq(pSDK->m_hDevice, &Overlap);
		SubFieldIrqs = pIrqInfo->subfield_interrupt;

		//DMA the frame from the card to our buffer
		if(SubFieldIrqs == 0)
			nOffset = (nChunks - 1) * ChunkSize;
		else
			nOffset = (SubFieldIrqs - 1) * ChunkSize;
		pSDK->system_buffer_read_async(pVideoBuffer + nOffset, ChunkSize, NULL, BlueImage_DMABuffer(DoneID, BLUE_DATA_IMAGE), nOffset);
		pSDK->system_buffer_write_async(pVideoBuffer + nOffset, ChunkSize, NULL, BlueImage_DMABuffer(DoneID, BLUE_DATA_IMAGE), nOffset);

#ifdef USE_OUTPUT_CHANNEL_AS_MONITOR
		//playback the fully captured frame
		if(SubFieldIrqs == 0)
			pSDK->render_buffer_update(DoneID);
#endif

		//tell the card to capture another frame at the next interrupt
		if(SubFieldIrqs == 0)
			pSDK->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);

		if(SubFieldIrqs == 0)
		{
			CurrentFieldCount = pIrqInfo->video_msc;
			if(LastFieldCount + nFieldCountIncrement < CurrentFieldCount)
				cout << endl << "Error: dropped " << ((CurrentFieldCount - LastFieldCount + nFieldCountIncrement)/nFieldCountIncrement) << " frames" << endl;
			else
			{
				//cout << ".";
				cout << endl;
			}
		}

		cout << SubFieldIrqs << " " << pIrqInfo->video_msc << " . ";
		if(SubFieldIrqs == 0)
		{
			DoneID = CapturingID;
			CapturingID = ScheduleID;
			ScheduleID = (++ScheduleID%4);
			LastFieldCount = CurrentFieldCount;
		}
 	}

	//turn off sub field interrupts
	varVal.ulVal = 0;
	pSDK->SetCardProperty(EPOCH_SUBFIELD_INPUT_INTERRUPTS, varVal);

#ifdef USE_OUTPUT_CHANNEL_AS_MONITOR
	//turn on black generator (unless we want to keep displaying the last rendered frame)
	varVal.ulVal = ENUM_BLACKGENERATOR_ON;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);
#endif 

	VirtualUnlock(pVideoBuffer, GoldenSize);
	VirtualFree(pVideoBuffer, 0, MEM_RELEASE);
	delete pIrqInfo;
	CloseHandle(Overlap.hEvent);

	BailOut(pSDK);
	cout << "Done" << endl;
	system("pause");
	return 0;
}
