// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	CaptureVideo_FS
// Written by:			Tim Bragulla
// Date:				31 October 2013
//
// Brief description:	This sample application shows how to capture 4 streams of SDI video as 4K using FRAMESTORE mode
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Hardware:				1 SuperNova card with QuadIn firmware loaded
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//
//	ATTENTION / NOTE:	This sample app sets all four channels to MEM_FMT_RGB, but capturing 4 HD streams with RGB pixel format will result in dropped frames
//	ATTENTION / NOTE:	due to DMA bandwidth restrictions
//	ATTENTION / NOTE:	This sample app primarily shows how to use the selective input DMA feature which needs to be used to transfer each individual HD stream
//	ATTENTION / NOTE:	into a single 4K buffer as the four quadrants making up this 4K video frame
//

#include "stdafx.h"


void WriteToTGA_RGB(unsigned char* pVideoBuffer, unsigned int nWidth, unsigned int nHeight)
{
	TargaHeader tga;
	tga.identsize = 0;
	tga.colourmaptype = 0;
	tga.imagetype = 2;
	tga.colourmapstart = 0;
	tga.colourmaplength = 0;
	tga.colourmapbits = 0;
	tga.xstart = 0;
	tga.ystart = 0;
	tga.width = nWidth*2;
	tga.height = nHeight*2;
	tga.bits = 24;
	tga.descriptor = 0x20;

	cout << "W: " << nWidth*2 << ", H: " << nHeight*2 << ", S: " << nWidth*nHeight*4*tga.bits/8 << endl;

	FILE* pFile = fopen("4KTest.tga", "wb");
	if(pFile)
	{
		fwrite(&tga, sizeof(tga), 1, pFile);
		fwrite(pVideoBuffer, nWidth*nHeight*4*tga.bits/8, 1, pFile);
		fclose(pFile);
	}
}

void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

void InitInputChannel(CBlueVelvet4* pSDK, ULONG DefaultInputChannel, ULONG UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultInputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_capture_stop();

	if(BLUE_VIDEO_INPUT_CHANNEL_A == DefaultInputChannel)
		RouteChannel(pSDK, EPOCH_SRC_SDI_INPUT_A, EPOCH_DEST_INPUT_MEM_INTERFACE_CHA, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	else if(BLUE_VIDEO_INPUT_CHANNEL_B == DefaultInputChannel)
		RouteChannel(pSDK, EPOCH_SRC_SDI_INPUT_B, EPOCH_DEST_INPUT_MEM_INTERFACE_CHB, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	else if(BLUE_VIDEO_INPUT_CHANNEL_C == DefaultInputChannel)
		RouteChannel(pSDK, EPOCH_SRC_SDI_INPUT_C, EPOCH_DEST_INPUT_MEM_INTERFACE_CHC, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	else if(BLUE_VIDEO_INPUT_CHANNEL_D == DefaultInputChannel)
		RouteChannel(pSDK, EPOCH_SRC_SDI_INPUT_D, EPOCH_DEST_INPUT_MEM_INTERFACE_CHD, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required update type and memory format and make sure that there is a valid input signal
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "CaptureVideo4K_FS sample app" << endl;

	CBlueVelvet4* pSDKA = NULL;
	CBlueVelvet4* pSDKB = NULL;
	CBlueVelvet4* pSDKC = NULL;
	CBlueVelvet4* pSDKD = NULL;
	int iDevices = 0;
	ULONG StartFieldCount = 0;
	ULONG CurrentFieldCount = 0;
	ULONG LastFieldCount = 0;

	ULONG VideoMode = VID_FMT_INVALID;
	ULONG UpdateFormat = UPD_FMT_FRAME;
	//ULONG MemoryFormat = MEM_FMT_2VUY;
	ULONG MemoryFormat = MEM_FMT_RGB;
	ULONG VideoEngine = VIDEO_ENGINE_FRAMESTORE;

	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDKA = BlueVelvetFactory4();
	pSDKB = BlueVelvetFactory4();
	pSDKC = BlueVelvetFactory4();
	pSDKD = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDKA->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDKA);
		BlueVelvetDestroy(pSDKB);
		BlueVelvetDestroy(pSDKC);
		BlueVelvetDestroy(pSDKD);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card, in this case card 1
	if(BLUE_FAIL(pSDKA->device_attach(1, 0)))
	{
		cout << "Error on device attach (channel A)" << endl;
		BlueVelvetDestroy(pSDKA);
		BlueVelvetDestroy(pSDKB);
		BlueVelvetDestroy(pSDKC);
		BlueVelvetDestroy(pSDKD);
		system("pause");
		return 0;
	}
	pSDKB->device_attach(1, 0);
	pSDKC->device_attach(1, 0);
	pSDKD->device_attach(1, 0);

	//Get the card type and firmware type
	int iCardType = pSDKA->has_video_cardtype();
	if(	iCardType != CRD_BLUE_EPOCH_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_CORE &&
		iCardType != CRD_BLUE_EPOCH_ULTRA &&
		iCardType != CRD_BLUE_EPOCH_2K_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_2K_CORE &&
		iCardType != CRD_BLUE_EPOCH_2K_ULTRA &&
		iCardType != CRD_BLUE_SUPER_NOVA &&
		iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Card not supported for OEM capture" << endl;
		system("pause");
		BailOut(pSDKA);
		BailOut(pSDKB);
		BailOut(pSDKC);
		BailOut(pSDKD);
		return 0;
	}

	pSDKA->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal);
	cout << "Product ID / firmware type: " << varVal.ulVal << endl;

	varVal.ulVal = 0;
	if(BLUE_FAIL(pSDKA->QueryCardProperty(CARD_FEATURE_STREAM_INFO, varVal)))
	{
		cout << "Function not supported; need driver 5.10.2.x" << endl;
		system("pause");
		BailOut(pSDKA);
		BailOut(pSDKB);
		BailOut(pSDKC);
		BailOut(pSDKD);
		return 0;
	}

	unsigned int nOutputStreams = CARD_FEATURE_GET_SDI_OUTPUT_STREAM_COUNT(varVal.ulVal);
	unsigned int nInputStreams = CARD_FEATURE_GET_SDI_INPUT_STREAM_COUNT(varVal.ulVal);
	if(nInputStreams < 4)
	{
		cout << "Card does not support 4 input channels" << endl;
		system("pause");
		BailOut(pSDKA);
		BailOut(pSDKB);
		BailOut(pSDKC);
		BailOut(pSDKD);
		return 0;
	}

	InitInputChannel(pSDKA, BLUE_VIDEO_INPUT_CHANNEL_A, UpdateFormat, MemoryFormat, VideoEngine);
	InitInputChannel(pSDKB, BLUE_VIDEO_INPUT_CHANNEL_B, UpdateFormat, MemoryFormat, VideoEngine);
	InitInputChannel(pSDKC, BLUE_VIDEO_INPUT_CHANNEL_C, UpdateFormat, MemoryFormat, VideoEngine);
	InitInputChannel(pSDKD, BLUE_VIDEO_INPUT_CHANNEL_D, UpdateFormat, MemoryFormat, VideoEngine);

	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDKA->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	//Check if we have a valid input signal
	pSDKA->wait_input_video_synch(UPD_FMT_FRAME, LastFieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	varVal.vt = VT_UI4;

	ULONG ulVideoModeA = InvalidVideoModeFlag;
	ULONG ulVideoModeB = InvalidVideoModeFlag;
	ULONG ulVideoModeC = InvalidVideoModeFlag;
	ULONG ulVideoModeD = InvalidVideoModeFlag;
	pSDKA->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	ulVideoModeA = varVal.ulVal;
	pSDKB->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	ulVideoModeB = varVal.ulVal;
	pSDKC->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	ulVideoModeC = varVal.ulVal;
	pSDKD->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	ulVideoModeD = varVal.ulVal;
	if(	(ulVideoModeA != ulVideoModeB) ||
		(ulVideoModeA != ulVideoModeC) ||
		(ulVideoModeA != ulVideoModeC) ||
		(ulVideoModeA >= InvalidVideoModeFlag))
	{
		cout << "No valid input signal or inputs not identical" << endl;
		system("pause");
		BailOut(pSDKA);
		BailOut(pSDKB);
		BailOut(pSDKC);
		BailOut(pSDKD);
		return 0;
	}
	VideoMode = varVal.ulVal;

	unsigned int nVideoWidth = BlueVelvetLinePixels(VideoMode);
	unsigned int nVideoHeight = BlueVelvetFrameLines(VideoMode, UpdateFormat);
	ULONG GoldenSize = BlueVelvetGolden(VideoMode, MemoryFormat, UpdateFormat);
	ULONG ul4KSize = nVideoWidth*nVideoHeight*3*4;

	unsigned char* pVideoBuffer = (unsigned char*)VirtualAlloc(NULL, ul4KSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBuffer, ul4KSize);

	//set up selective input DMA
	varVal.ulVal = nVideoWidth * 3;	//width * 3 bytes per pixel as we are using RGB pixel format
	pSDKA->SetCardProperty(VIDEO_INPUT_IMAGE_WIDTH, varVal);
	varVal.ulVal = nVideoHeight;
	pSDKA->SetCardProperty(VIDEO_INPUT_IMAGE_HEIGHT, varVal);
	varVal.ulVal = nVideoWidth * 3 * 2; // width * 3 bytes per pixel * 2 (width of 4K is twice of a single SDI input stream)
	pSDKA->SetCardProperty(VIDEO_INPUT_IMAGE_PITCH, varVal);

	varVal.ulVal = nVideoWidth * 3;	//width * 3 bytes per pixel as we are using RGB pixel format
	pSDKB->SetCardProperty(VIDEO_INPUT_IMAGE_WIDTH, varVal);
	varVal.ulVal = nVideoHeight;
	pSDKB->SetCardProperty(VIDEO_INPUT_IMAGE_HEIGHT, varVal);
	varVal.ulVal = nVideoWidth * 3 * 2; // width * 3 bytes per pixel * 2 (width of 4K is twice of a single SDI input stream)
	pSDKB->SetCardProperty(VIDEO_INPUT_IMAGE_PITCH, varVal);

	varVal.ulVal = nVideoWidth * 3;	//width * 3 bytes per pixel as we are using RGB pixel format
	pSDKC->SetCardProperty(VIDEO_INPUT_IMAGE_WIDTH, varVal);
	varVal.ulVal = nVideoHeight;
	pSDKC->SetCardProperty(VIDEO_INPUT_IMAGE_HEIGHT, varVal);
	varVal.ulVal = nVideoWidth * 3 * 2; // width * 3 bytes per pixel * 2 (width of 4K is twice of a single SDI input stream)
	pSDKC->SetCardProperty(VIDEO_INPUT_IMAGE_PITCH, varVal);

	varVal.ulVal = nVideoWidth * 3;	//width * 3 bytes per pixel as we are using RGB pixel format
	pSDKD->SetCardProperty(VIDEO_INPUT_IMAGE_WIDTH, varVal);
	varVal.ulVal = nVideoHeight;
	pSDKD->SetCardProperty(VIDEO_INPUT_IMAGE_HEIGHT, varVal);
	varVal.ulVal = nVideoWidth * 3 * 2; // width * 3 bytes per pixel * 2 (width of 4K is twice of a single SDI input stream)
	pSDKD->SetCardProperty(VIDEO_INPUT_IMAGE_PITCH, varVal);

	ULONG ScheduleID = 0;
	ULONG CapturingID = 0;
	ULONG DoneID = 0;

	//start the capture sequence
	pSDKA->wait_input_video_synch(UpdateFormat, CurrentFieldCount);	//this call just synchronises us to the card
	pSDKA->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
	pSDKB->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
	pSDKC->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
	pSDKD->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
	CapturingID = ScheduleID;
	ScheduleID = (++ScheduleID%3);
	LastFieldCount = CurrentFieldCount;

	pSDKA->wait_input_video_synch(UpdateFormat, CurrentFieldCount);	//the first buffer starts to be captured now; this is it's field count
	pSDKA->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
	pSDKB->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
	pSDKC->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
	pSDKD->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);

	DoneID = CapturingID;
	CapturingID = ScheduleID;
	ScheduleID = (++ScheduleID%3);
	LastFieldCount = CurrentFieldCount;
	StartFieldCount = CurrentFieldCount;

	while(!_kbhit())
	{
		pSDKA->wait_input_video_synch(UpdateFormat, CurrentFieldCount);
		
		if(LastFieldCount + 2 < CurrentFieldCount)
			cout << "Error: dropped " << ((CurrentFieldCount - LastFieldCount + 2)/2) << " frames" << endl;
		else
			cout << ".";
		LastFieldCount = CurrentFieldCount;
		
		//tell the card to capture another frame at the next interrupt
		pSDKA->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
		pSDKB->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
		pSDKC->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
		pSDKD->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);

		pSDKA->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);	//check if the video signal was valid for the last frame (until wait_input_video_synch() returned)
		if(varVal.ulVal < InvalidVideoModeFlag)
		{
			//DoneID is now what ScheduleID was at the last iteration when we called render_buffer_capture(ScheduleID)
			//we just checked if the video signal for the buffer �DoneID� was valid while it was capturing so we can DMA the buffer
			//DMA the frame from the card to our buffer
			pSDKA->system_buffer_read_async(pVideoBuffer,													nVideoWidth*nVideoHeight*3*2,					NULL, BlueImage_DMABuffer(DoneID, BLUE_DATA_IMAGE));
			pSDKB->system_buffer_read_async(pVideoBuffer + nVideoWidth*3,									nVideoWidth*nVideoHeight*3*2 - nVideoWidth*3,	NULL, BlueImage_DMABuffer(DoneID, BLUE_DATA_IMAGE));
			pSDKC->system_buffer_read_async(pVideoBuffer + nVideoWidth*nVideoHeight*3*2,					nVideoWidth*nVideoHeight*3*2,					NULL, BlueImage_DMABuffer(DoneID, BLUE_DATA_IMAGE));
			pSDKD->system_buffer_read_async(pVideoBuffer + nVideoWidth*nVideoHeight*3*2 + nVideoWidth*3,	nVideoWidth*nVideoHeight*3*2 - nVideoWidth*3,	NULL, BlueImage_DMABuffer(DoneID, BLUE_DATA_IMAGE));

			//for debugging:
			//WriteToTGA_RGB(pVideoBuffer, nVideoWidth, nVideoHeight);
			//break;

			DoneID = CapturingID;
			CapturingID = ScheduleID;
			ScheduleID = (++ScheduleID%4);
		}
 	}

	VirtualUnlock(pVideoBuffer, ul4KSize);
	VirtualFree(pVideoBuffer, 0, MEM_RELEASE);

	BailOut(pSDKA);
	BailOut(pSDKB);
	BailOut(pSDKC);
	BailOut(pSDKD);
	cout << "Done" << endl;
	system("pause");
	return 0;
}
