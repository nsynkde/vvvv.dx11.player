// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	CaptureVideoArriRaw
// Written by:			Tim Bragulla
// Date:				01 May 2013
//
// Brief description:	This sample application shows how to capture a ARRI RAW duallink stream via a 3G Level B connection
//						The ARRI RAW stream is expected to be encoded in a 1920x1080 video stream (active raw data will be 1440x1080)
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.37 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_37\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"


void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

void InitInputChannel(CBlueVelvet4* pSDK, ULONG DefaultInputChannel, ULONG UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	BErr err = 0;
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultInputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_capture_stop();

	if(DefaultInputChannel == BLUE_VIDEO_INPUT_CHANNEL_A)
		RouteChannel(pSDK, EPOCH_SRC_SDI_INPUT_A_3GB_LINK_A, EPOCH_DEST_INPUT_MEM_INTERFACE_CHA, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	else
		RouteChannel(pSDK, EPOCH_SRC_SDI_INPUT_A_3GB_LINK_B, EPOCH_DEST_INPUT_MEM_INTERFACE_CHB, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);

	//set up the card to expect arri raw 12 bit data
	varVal.ulVal = (RAW_VIDEO_INPUT_TYPE_IS_ARRI | RAW_VIDEO_INPUT_TYPE_IS_12BIT);
	err = pSDK->SetCardProperty(EPOCH_RAW_VIDEO_INPUT_TYPE, varVal);
	err = pSDK->QueryCardProperty(EPOCH_RAW_VIDEO_INPUT_TYPE, varVal);
	cout << "EPOCH_RAW_VIDEO_INPUT_TYPE: 0x" << hex << varVal.ulVal << dec << endl;

	//Only set the Video Engine after setting up the required update type and memory format and make sure that there is a valid input signal
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);
}

int _tmain(int argc, _TCHAR* argv[])
{
	BErr err = 0;
	cout << "CaptureVideoArriRaw sample app" << endl;

	CBlueVelvet4* pSDK_ChA = NULL;
	CBlueVelvet4* pSDK_ChB = NULL;
	int iDevices = 0;
	ULONG FieldCount = 0;
	ULONG LastFieldCount = 0;
	blue_videoframe_info_ex	FrameInfoChA;
	blue_videoframe_info_ex	FrameInfoChB;
	unsigned int FifoSizeChA = 0;
	unsigned int FifoSizeChB = 0;
	
	ULONG VideoMode = VID_FMT_INVALID;
	ULONG UpdateFormat = UPD_FMT_FRAME;
	ULONG MemoryFormat = MEM_FMT_Y216;	// we want 12 bit data which needs to be encoded in a 16 bit format
	ULONG VideoEngine = VIDEO_ENGINE_DUPLEX;

	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDK_ChA = BlueVelvetFactory4();
	pSDK_ChB = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDK_ChA->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK_ChA);
		BlueVelvetDestroy(pSDK_ChB);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card, in this case card 1
	if(BLUE_FAIL(pSDK_ChA->device_attach(1, 0)))
	{
		cout << "Error on device attach (channel A)" << endl;
		BlueVelvetDestroy(pSDK_ChA);
		BlueVelvetDestroy(pSDK_ChB);
		system("pause");
		return 0;
	}

	if( BLUE_FAIL( pSDK_ChB->device_attach(1, 0) ) )
	{
		cout << "Error on device attach (channel B)" << endl;
		BlueVelvetDestroy(pSDK_ChA);
		BlueVelvetDestroy(pSDK_ChB);
		system("pause");
		return 0;
	}

	//Get the card type and firmware type
	int iCardType = pSDK_ChA->has_video_cardtype();
	if(	iCardType != CRD_BLUE_EPOCH_2K_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_2K_CORE &&
		iCardType != CRD_BLUE_EPOCH_2K_ULTRA &&
		iCardType != CRD_BLUE_SUPER_NOVA)
	{
		cout << "Card not supported for OEM 3D capture" << endl;
		system("pause");
		BailOut(pSDK_ChA);
		BailOut(pSDK_ChB);
		return 0;
	}

	pSDK_ChA->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal);
	cout << "Product ID / firmware type: " << varVal.ulVal << endl;

	varVal.ulVal = 0;
	if(BLUE_FAIL(pSDK_ChA->QueryCardProperty(CARD_FEATURE_STREAM_INFO, varVal)))
	{
		cout << "Function not supported; need driver 5.10.2.x" << endl;
		system("pause");
		BailOut(pSDK_ChA);
		BailOut(pSDK_ChB);
		return 0;
	}

	unsigned int nOutputStreams = CARD_FEATURE_GET_SDI_OUTPUT_STREAM_COUNT(varVal.ulVal);
	unsigned int nInputStreams = CARD_FEATURE_GET_SDI_INPUT_STREAM_COUNT(varVal.ulVal);
	if(!nInputStreams)
	{
		cout << "Card does not support two input channels" << endl;
		system("pause");
		BailOut(pSDK_ChA);
		BailOut(pSDK_ChB);
		return 0;
	}

	InitInputChannel(pSDK_ChA, BLUE_VIDEO_INPUT_CHANNEL_A, UpdateFormat, MemoryFormat, VideoEngine);
	InitInputChannel(pSDK_ChB, BLUE_VIDEO_INPUT_CHANNEL_B, UpdateFormat, MemoryFormat, VideoEngine);

	//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
	pSDK_ChA->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
	ULONG InvalidVideoModeFlag = varVal.ulVal;

	//Check if we have a valid input signal
	pSDK_ChA->wait_input_video_synch(UPD_FMT_FRAME, FieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	varVal.vt = VT_UI4;
	pSDK_ChA->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	if(varVal.ulVal >= InvalidVideoModeFlag)
	{
		cout << "No valid input signal on channel A" << endl;
		system("pause");
		BailOut(pSDK_ChA);
		BailOut(pSDK_ChB);
		return 0;
	}
	VideoMode = varVal.ulVal;

	pSDK_ChB->wait_input_video_synch(UPD_FMT_FRAME, FieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	varVal.vt = VT_UI4;
	pSDK_ChB->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	if(varVal.ulVal >= InvalidVideoModeFlag)
	{
		cout << "No valid input signal on channel B" << endl;
		system("pause");
		BailOut(pSDK_ChA);
		BailOut(pSDK_ChB);
		return 0;
	}
	else if(VideoMode != varVal.ulVal)
	{
		cout << "Channel B video input does not match Channel A video input" << endl;
		system("pause");
		BailOut(pSDK_ChA);
		BailOut(pSDK_ChB);
		return 0;
	}

	OVERLAPPED OverlapChA;
	OVERLAPPED OverlapChB;
	OverlapChA.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OverlapChB.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	//usually we would calculate the golden value for SDI video modes...
	//ULONG GoldenSize = BlueVelvetGolden(VideoMode, MemoryFormat, UpdateFormat);
	//...but for raw bayer data we don't need to DMA a whole SDI video frame
	ULONG GoldenSize = 1440*1080*4;	//1440 12 bit pixels wide  x  1080 lines  x  4 bytes per pixel (Y216)
	cout << "GoldenSize: " << GoldenSize << endl;

	unsigned char* pVideoBufferA = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBufferA, GoldenSize);
	unsigned char* pVideoBufferB = (unsigned char*)VirtualAlloc(NULL, GoldenSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pVideoBufferB, GoldenSize);

	//synchronise with the card
	pSDK_ChA->wait_input_video_synch(UpdateFormat, FieldCount);

	//reset the field count for all input channels
	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(EPOCH_RESET_VIDEO_INPUT_FIELDCOUNT, varVal);

	//wait for one interrupt so that the field count reset take effect
	pSDK_ChA->wait_input_video_synch(UpdateFormat, FieldCount);

	if(BLUE_FAIL(pSDK_ChA->video_capture_start(0)))
		cout << "Error video capture start failed on channel A" << endl;
	
	if(BLUE_FAIL(pSDK_ChB->video_capture_start(0)))
		cout << "Error video capture start failed on channel B" << endl;

	while(!_kbhit())
	{
		pSDK_ChA->wait_input_video_synch(UpdateFormat, FieldCount);
		
		if(BLUE_FAIL(GetVideo_CaptureFrameInfoEx(pSDK_ChA, &OverlapChA, FrameInfoChA, 0, &FifoSizeChA)) || (FrameInfoChA.nVideoSignalType >= InvalidVideoModeFlag) || (FrameInfoChA.BufferId == -1))
		{
			cout << "continue A" << endl;
			continue;
		}

		if(BLUE_FAIL(GetVideo_CaptureFrameInfoEx(pSDK_ChB, &OverlapChB, FrameInfoChB, 0, &FifoSizeChB)) || (FrameInfoChB.nVideoSignalType >= InvalidVideoModeFlag) || (FrameInfoChB.BufferId == -1))
		{
			cout << "continue B" << endl;
			continue;
		}

		while((FrameInfoChA.nFrameTimeStamp != FrameInfoChB.nFrameTimeStamp) && !_kbhit())
		{
			cout << "Re-synching: " << FrameInfoChA.nFrameTimeStamp << ", " << FrameInfoChB.nFrameTimeStamp << endl;
			if(FrameInfoChA.nFrameTimeStamp < FrameInfoChB.nFrameTimeStamp)
			{
				if(BLUE_FAIL(GetVideo_CaptureFrameInfoEx(pSDK_ChA, &OverlapChA, FrameInfoChA, 0 ,&FifoSizeChA)))
					break;
			}
			else if(FrameInfoChA.nFrameTimeStamp > FrameInfoChB.nFrameTimeStamp)
			{
				if(BLUE_FAIL(GetVideo_CaptureFrameInfoEx(pSDK_ChB, &OverlapChB, FrameInfoChB, 0 ,&FifoSizeChB)))
					break;
			}
		}

		if(FrameInfoChA.nFrameTimeStamp != FrameInfoChB.nFrameTimeStamp)
		{
			cout << "Error: not in synch: " << FrameInfoChA.nFrameTimeStamp << ", " << FrameInfoChB.nFrameTimeStamp << endl;
			continue;
		}

		if(LastFieldCount + 2 < FieldCount)
			cout << "Error: dropped " << ((FieldCount - LastFieldCount + 2)/2) << " frames" << endl;

		//check if the ARRI RECORD flag is set
		err = pSDK_ChA->QueryCardProperty(EPOCH_HANC_INPUT_FLAGS, varVal);
		if((err == 0) && (HANC_FLAGS_IS_ARRI_RECORD_FLAG_SET(varVal.ulVal)))
			cout << "Check: " << err << ", Record flag is set: " << varVal.ulVal << endl;

		//ARRI RAW dual link: ChA contains left stream of image
		pSDK_ChA->system_buffer_read_async(pVideoBufferA, GoldenSize, NULL, BlueImage_DMABuffer(FrameInfoChA.BufferId, BLUE_DATA_IMAGE));
		//ARRI RAW dual link: ChB contains right stream of image
		pSDK_ChB->system_buffer_read_async(pVideoBufferB, GoldenSize, NULL, BlueImage_DMABuffer(FrameInfoChA.BufferId, BLUE_DATA_IMAGE));

		LastFieldCount = FieldCount;
 	}

	pSDK_ChA->video_capture_stop();
	pSDK_ChB->video_capture_stop();

	CloseHandle(OverlapChA.hEvent);
	CloseHandle(OverlapChB.hEvent);

	VirtualUnlock(pVideoBufferA, GoldenSize);
	VirtualUnlock(pVideoBufferB, GoldenSize);
	VirtualFree(pVideoBufferA, 0, MEM_RELEASE);
	VirtualFree(pVideoBufferB, 0, MEM_RELEASE);

	varVal.ulVal = 0;
	pSDK_ChA->SetCardProperty(EPOCH_RAW_VIDEO_INPUT_TYPE, varVal);	//return to normal SDI mode
	varVal.ulVal = 0;
	pSDK_ChB->SetCardProperty(EPOCH_RAW_VIDEO_INPUT_TYPE, varVal);	//return to normal SDI mode

	//fix routing for normal usage
	RouteChannel(pSDK_ChA, EPOCH_SRC_SDI_INPUT_A, EPOCH_DEST_INPUT_MEM_INTERFACE_CHA, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	RouteChannel(pSDK_ChB, EPOCH_SRC_SDI_INPUT_B, EPOCH_DEST_INPUT_MEM_INTERFACE_CHB, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	BailOut(pSDK_ChA);
	BailOut(pSDK_ChB);
	cout << "Done" << endl;
	system("pause");
	return 0;
}
