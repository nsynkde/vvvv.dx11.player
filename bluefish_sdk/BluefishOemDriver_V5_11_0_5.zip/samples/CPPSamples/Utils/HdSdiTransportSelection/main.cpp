// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	PlaybackVideo
// Written by:			Tim Bragulla
// Date:				13 August 2012
//
// Brief description:	This sample application shows how to change the transport type for HD SDI video modes (HD-SDI 1.5G, 3G Level A and 3G Level B)
//
// Supported hardware:	Bluefish Epoch fw 494 and above; SuperNova firmwares will follow
//
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.22 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"


void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "PlaybackVideo sample app" << endl;

	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;
	ULONG VideoMode = VID_FMT_1080P_6000;
	ULONG UpdateFormat = UPD_FMT_FRAME;
	ULONG MemoryFormat = MEM_FMT_BGR;
	ULONG VideoEngine = VIDEO_ENGINE_DUPLEX;

	VARIANT varVal;
	varVal.vt = VT_UI4;

	//Create an SDK instance, one for each channel
	pSDK = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDK->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card, in this case card 1
	if(BLUE_FAIL(pSDK->device_attach(1, 0)))
	{
		cout << "Error on device attach" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Get the card type and firmware type
	int iCardType = pSDK->has_video_cardtype();
	if(	iCardType != CRD_BLUE_EPOCH_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_CORE &&
		iCardType != CRD_BLUE_EPOCH_ULTRA &&
		iCardType != CRD_BLUE_EPOCH_2K_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_2K_CORE &&
		iCardType != CRD_BLUE_EPOCH_2K_ULTRA &&
		iCardType != CRD_BLUE_SUPER_NOVA &&
		iCardType != CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		cout << "Card not supported for OEM playback" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	pSDK->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal);
	cout << "Product ID / firmware type: " << varVal.ulVal << endl;

	varVal.ulVal = 0;
	if(BLUE_FAIL(pSDK->QueryCardProperty(CARD_FEATURE_STREAM_INFO, varVal)))
	{
		cout << "Function not supported; need driver 5.10.2.x" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	unsigned int nOutputStreams = CARD_FEATURE_GET_SDI_OUTPUT_STREAM_COUNT(varVal.ulVal);
	unsigned int nInputStreams = CARD_FEATURE_GET_SDI_INPUT_STREAM_COUNT(varVal.ulVal);
	if(!nOutputStreams)
	{
		cout << "Card does not support output channels" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = BLUE_VIDEO_OUTPUT_CHANNEL_A;
	pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_playback_stop(0, 0);

	RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	//Setting the video mode to a high frame rate one (1080P 50, 59 or 60) will default in 3G Level A as the transport type
	varVal.ulVal = VideoMode;
	pSDK->SetCardProperty(VIDEO_MODE, varVal);
	pSDK->QueryCardProperty(VIDEO_MODE, varVal);
	if(varVal.ulVal != VideoMode)
	{
		cout << "Can't set video mode; FIFO running already?" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}
	cout << "Default transport type for 1080P 60 is 3G Level A" << endl;
	cout << "Press any key to continue..." << endl << endl;
	_getch();

	//change the transport type for SDI A OUTPUT (which output memory channel A is routed to) to 3G Level B
	cout << "Setting transport to 3G Level B" << endl;
	varVal.ulVal = HD_SDI_TRANSPORT_3G_LEVEL_B;				//lower 16 bits for the transport type
	varVal.ulVal |= (BLUE_CONNECTOR_SDI_OUTPUT_A << 16);	//upper 16 bits for the connector ID
	pSDK->SetCardProperty(EPOCH_HD_SDI_TRANSPORT, varVal);
	varVal.ulVal = BLUE_CONNECTOR_SDI_OUTPUT_A;				//lower 16 bits for the connector ID
	pSDK->QueryCardProperty(EPOCH_HD_SDI_TRANSPORT, varVal);
	if(varVal.ulVal == HD_SDI_TRANSPORT_3G_LEVEL_B)
		cout << "Transport for SDI A OUTPUT set to 3G Level B" << endl;
	else
		cout << "ERROR setting transport for SDI A OUTPUT to 3G Level B" << endl;

	cout << "Press any key to continue..." << endl << endl;
	_getch();

	//change the transport type for SDI A OUTPUT (which output memory channel A is routed to) to 1.5G Dual Link (SDI B OUTPUT is selected automatically!)
	cout << "Setting transport to 1.5G Dual Link" << endl;
	varVal.ulVal = HD_SDI_TRANSPORT_1_5G;				//lower 16 bits for the transport type
	varVal.ulVal |= (BLUE_CONNECTOR_SDI_OUTPUT_A << 16);	//upper 16 bits for the connector ID
	pSDK->SetCardProperty(EPOCH_HD_SDI_TRANSPORT, varVal);
	varVal.ulVal = BLUE_CONNECTOR_SDI_OUTPUT_A;				//lower 16 bits for the connector ID
	pSDK->QueryCardProperty(EPOCH_HD_SDI_TRANSPORT, varVal);
	if(varVal.ulVal == HD_SDI_TRANSPORT_1_5G)
		cout << "Transport for SDI A OUTPUT set to 1.5G Dual Link" << endl;
	else
		cout << "ERROR setting transport for SDI A OUTPUT to 1.5G Dual Link" << endl;

	cout << "Press any key to continue..." << endl << endl;
	_getch();

	//change the transport type for SDI A OUTPUT (which output memory channel A is routed to) to 3G Level A
	cout << "Setting transport to 3G Level A" << endl;
	varVal.ulVal = HD_SDI_TRANSPORT_3G_LEVEL_A;				//lower 16 bits for the transport type
	varVal.ulVal |= (BLUE_CONNECTOR_SDI_OUTPUT_A << 16);	//upper 16 bits for the connector ID
	pSDK->SetCardProperty(EPOCH_HD_SDI_TRANSPORT, varVal);
	varVal.ulVal = BLUE_CONNECTOR_SDI_OUTPUT_A;				//lower 16 bits for the connector ID
	pSDK->QueryCardProperty(EPOCH_HD_SDI_TRANSPORT, varVal);
	if(varVal.ulVal == HD_SDI_TRANSPORT_3G_LEVEL_A)
		cout << "Transport for SDI A OUTPUT set to 3G Level A" << endl;
	else
		cout << "ERROR setting transport for SDI A OUTPUT to 3G Level A" << endl;

	cout << "Press any key to continue..." << endl << endl;
	_getch();


	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required video mode, update type and memory format
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	BailOut(pSDK);
	cout << "Done" << endl;
	system("pause");
	return 0;
}
