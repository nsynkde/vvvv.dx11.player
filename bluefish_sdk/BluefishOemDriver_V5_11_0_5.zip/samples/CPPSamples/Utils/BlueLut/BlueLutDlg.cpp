// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	PlaybackVideo3D
// Written by:			Tim Bragulla
// Date:				18 June 2012
//
// Brief description:	This sample application shows how to change the 3x 1D video output LUTs on Epoch/SuperNova cards
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ATTENTION:			The values used for the LUTs, e.g. AntiLog LUT, are not qualified for production use; this sample app is merely there for showing SDK usage!  ///
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"
#include "BlueLut.h"
#include "BlueLutDlg.h"
#include "BlueVelvet4.h"
#include <math.h>
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// BlueLutDlg dialog



BlueLutDlg::BlueLutDlg(CWnd* pParent /*=NULL*/)
	: CDialog(BlueLutDlg::IDD, pParent)
	, m_nRefWhite(685)
	, m_nRefBlack(95)
	, m_nSoftClip(0)
	, m_fDisplayGamma(2.5)
	, m_fFilmGamma(0.6)
	, m_nDeviceId(1)
	, m_nOutputChannel(BLUE_VIDEO_OUTPUT_CHANNEL_A)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void BlueLutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_REF_WHITE, m_nRefWhite);
	DDX_Text(pDX, IDC_REF_BLACK, m_nRefBlack);
	DDX_Text(pDX, IDC_SOFT_CLIP, m_nSoftClip);
	DDX_Text(pDX, IDC_DISP_GAMMA, m_fDisplayGamma);
	DDX_Text(pDX, IDC_FILM_GAMMA, m_fFilmGamma);
	DDX_Control(pDX, IDC_CARD_SELECT_COMBO, m_cmbDeviceSelect);
	DDX_Control(pDX, IDC_CHANNEL_SELECT_COMBO, m_cmbChannelSelect);
	DDX_Control(pDX, IDC_LUT_SELECT_COMBO, m_cmbLUTSelect);
}

BEGIN_MESSAGE_MAP(BlueLutDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_REFRESH_BUTTON, OnRefreshButton)
	ON_BN_CLICKED(IDC_APPLY_LUT_BUTTON, OnBnClickedApplyLut)
	ON_CBN_SELCHANGE(IDC_CARD_SELECT_COMBO, &BlueLutDlg::OnChangeCardSelect)
	ON_CBN_SELCHANGE(IDC_CHANNEL_SELECT_COMBO, &BlueLutDlg::OnCbnSelchangeChannelSelectCombo)
END_MESSAGE_MAP()


BOOL BlueLutDlg::GetCardProperty()
{
	UINT32 iIndex;

	UpdateData(0);

	return TRUE;
}

void BlueLutDlg::InitBlueCard(BOOL bDetachFirst)
{
	if(!m_pSdk)
		return;

	int CardType = m_pSdk->has_video_cardtype(m_nDeviceId);

	if(	CardType == CRD_BLUE_EPOCH_HORIZON ||
		CardType == CRD_BLUE_EPOCH_CORE ||
		CardType == CRD_BLUE_EPOCH_ULTRA ||
		CardType == CRD_BLUE_EPOCH_2K ||
		CardType == CRD_BLUE_EPOCH_2K_CORE ||
		CardType == CRD_BLUE_EPOCH_2K_ULTRA ||
		CardType == CRD_BLUE_SUPER_NOVA &&
		CardType == CRD_BLUE_SUPER_NOVA_S_PLUS)
	{
		if(bDetachFirst)
		{
			m_pSdk->device_detach();
		}
		
		m_pSdk->device_attach(m_nDeviceId, 0);

		VARIANT varVal;
		varVal.vt = VT_UI4;
		varVal.ulVal = m_nOutputChannel;
		m_pSdk->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);
	}
	else
		MessageBox("Card not supported", "Error", MB_OK);

}

// BlueLutDlg message handlers
BOOL BlueLutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	int device_count;
	m_pSdk = BlueVelvetFactory4();
	m_pSdk->device_enumerate(device_count);

	int i=1, hdCardType;
	CString strCardType;
	int cardType = CRD_INVALID;

	while(i <= device_count)
	{
		cardType = m_pSdk->has_video_cardtype(i);
		switch(cardType)
		{
		case CRD_BLUEDEEP_LT:
			strCardType =	"DeepBlue LT";
			break;
		case CRD_BLUEDEEP_SD:
			strCardType =	"Iridium SD";
			break;
		case CRD_BLUEDEEP_AV:
			strCardType =	"Iridium AV";
			break;
		case CRD_BLUEDEEP_IO:
			strCardType =	"DeepBlue IO";
			break;
		case CRD_BLUEWILD_AV:
			strCardType =	"BlueWild AV";
			break;
		case CRD_BLUEWILD_RT:
			strCardType =	"Wild Blue AV";
			break;
		case CRD_BLUE_ENVY:
			strCardType = "Envy";
			break;
		case CRD_BLUE_PRIDE:
			strCardType = "Pride";
			break;
		case CRD_BLUE_GREED:
			strCardType = "Greed";
			break;

		case CRD_BLUE_INGEST:
			strCardType = "Ingest";
			break;
		case CRD_BLUE_SD_DUALLINK:
			strCardType = "SD DualLink";
			break;
		case CRD_BLUE_SD_DUALLINK_PRO:
			strCardType = "SD DualLink Pro";
			break;
		case CRD_BLUE_SD_INGEST_PRO:
			strCardType = "SD Ingest Pro";
			break;
		case CRD_BLUE_SD_DEEPBLUE_LITE_PRO:
			strCardType = "SD DeepBlue Lite Pro";
			break;
		case CRD_BLUE_SD_SINGLELINK_PRO:
			strCardType = "SD SingleLink Pro";
			break;
		case CRD_BLUE_SD_IRIDIUM_AV_PRO:
			strCardType = "SD Iridium AV Pro";
			break;
		case CRD_BLUE_SD_FOCUS:
			strCardType ="SD Focus";
			break;
		case CRD_BLUE_SD_FIDELITY:
			strCardType ="SD Fidelity";
			break;
		case CRD_BLUEWILD_HD:
			{
				hdCardType = m_pSdk->GetHDCardType(i);
				switch(hdCardType)
				{
				case CRD_HD_FURY:
					strCardType =	"HD Fury";					
					break;
				case CRD_HD_VENGENCE:
					strCardType =	"HD VENGENCE";					
					break;
				case CRD_HD_IRIDIUM_XP:
					strCardType =	"HD Iridium XP";					
					break;
				case CRD_HD_IRIDIUM:
					strCardType =	"HD Iridium";					
					break;
				case CRD_HD_LUST:
					strCardType =	"HD Lust";										
					break;
				default:
					strCardType =	"Unknown";
					break;
				}
				break;
			}
		case CRD_BLUE_EPOCH_HORIZON:
			strCardType = "Epoch Horizon";
			break;
		case CRD_BLUE_EPOCH_CORE:
			strCardType = "Epoch Core";
			break;
		case CRD_BLUE_EPOCH_ULTRA:
			strCardType = "Epoch Ultra";
			break;
		case CRD_BLUE_EPOCH_2K:
			strCardType = "Epoch 2K Horizon";
			break;
		case CRD_BLUE_EPOCH_2K_CORE:
			strCardType = "Epoch 2K Core";
			break;
		case CRD_BLUE_EPOCH_2K_ULTRA:
			strCardType = "Epoch 2K Ultra";
			break;
		case CRD_BLUE_SUPER_NOVA:
			strCardType = "Super Nova";
			break;
		case CRD_BLUE_SUPER_NOVA_S_PLUS:
			strCardType = "Super Nova S+";
			break;
		default:
		strCardType = "Unknown";
		}
		m_cmbDeviceSelect.AddString(strCardType);
		i++;
	}

	VARIANT varVal;
	varVal.vt = VT_UI4;

	cardType = m_pSdk->has_video_cardtype(i);
	if((cardType == CRD_BLUE_SUPER_NOVA) || (cardType == CRD_BLUE_SUPER_NOVA_S_PLUS))
	{
		if(BLUE_OK(m_pSdk->QueryCardProperty(EPOCH_GET_PRODUCT_ID, varVal)))
		{
			if(varVal.ulVal == ORAC_4SDIINPUT_FIRMWARE_PRODUCTID)
			{
				MessageBox("QuadIn not supported!", "Error", MB_OK);
				exit(0);
			}
			else if(varVal.ulVal == ORAC_4SDIOUTPUT_FIRMWARE_PRODUCTID)
			{
				m_cmbChannelSelect.AddString("OUTPUT CHANNEL A");
				m_cmbChannelSelect.AddString("OUTPUT CHANNEL B");
				m_cmbChannelSelect.AddString("OUTPUT CHANNEL C");
				m_cmbChannelSelect.AddString("OUTPUT CHANNEL D");
			}
			else
			{
				m_cmbChannelSelect.AddString("OUTPUT CHANNEL A");
				m_cmbChannelSelect.AddString("OUTPUT CHANNEL B");
			}
		}
	}
	else
	{
		m_cmbChannelSelect.AddString("OUTPUT CHANNEL A");
		m_cmbChannelSelect.AddString("OUTPUT CHANNEL B");
	}
	m_cmbChannelSelect.SetCurSel(0);
	m_nOutputChannel = BLUE_VIDEO_OUTPUT_CHANNEL_A;

	m_nDeviceId = 1;
	m_cmbDeviceSelect.SetCurSel(m_nDeviceId - 1);
	InitBlueCard(FALSE);

	GetCardProperty();
	CheckRadioButton(IDC_ANTI_LOG_RADIO, IDC_INVERSE_CGR_RADIO, IDC_INVERSE_CGR_RADIO);
	m_cmbLUTSelect.AddString("LUT B/Pb output");
	m_cmbLUTSelect.AddString("LUT G/Y output");
	m_cmbLUTSelect.AddString("LUT R/Pr output");
	/*m_cmbLUTSelect.AddString("LUT B/Pb for VOX");
	m_cmbLUTSelect.AddString("LUT G/Y for VOX");
	m_cmbLUTSelect.AddString("LUT R/Pr for VOX");*/

	m_cmbLUTSelect.SetCurSel(0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void BlueLutDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void BlueLutDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR BlueLutDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void BlueLutDlg::OnRefreshButton()
{
	GetCardProperty();
}


void BlueLutDlg::update_look_up_table(UINT16 index,UINT32 RedValue, UINT32 GreenValue,UINT32 BlueValue)
{
	m_pLUT[index] = (UINT16)(BlueValue); 
}

void BlueLutDlg::OClickedAntiLog()
{
	FILE* fp = NULL;
	int lut_cmb_index;

	UpdateData(1);
	lut_cmb_index = m_cmbLUTSelect.GetCurSel();
	if (lut_cmb_index == CB_ERR)
		return;

	//fp = fopen("LUT.txt","wt");

	float fGain,fOutputValue,fOffset;
	const float fConConst = (0.002) / 0.6;
	INT32 nLutValue;
	float fPeakValue=1023.0;
	UINT BreakPoint;
	float fGamma;
	float fSMPTEScaleFactor;
	float fKneeOffset,fKneeGain;
	
	int lut_radio_button;
/*	lut_radio_button  = GetCheckedRadioButton(IDC_8BIT_LUT,IDC_10BIT_LUT);
	if (lut_radio_button  == IDC_8BIT_LUT)
		fPeakValue = 255.0;
	else
	if (lut_radio_button  == IDC_10BIT_LUT)
		fPeakValue = 1023.0;
*/
	fSMPTEScaleFactor = (219.0 * 4.0)/(255.0* 4.0);
	
	BreakPoint = m_nRefWhite - m_nSoftClip;
	fGamma = (1.0)/(m_fDisplayGamma * m_fFilmGamma);
	

	fGain = (fPeakValue)/(1.0 - pow(10.0,( (((float)m_nRefBlack - (float)m_nRefWhite)*0.002)/0.6)*(fGamma/1.7)));
	fOffset =  fGain - (fPeakValue);
	fKneeOffset = pow(10.0,( ( (float)BreakPoint - (float)m_nRefWhite) * fConConst * (fGamma/1.7)))*fGain - fOffset;
	fKneeGain = (fPeakValue - fKneeOffset)/(pow((5.0 * m_nSoftClip),(m_nSoftClip/100.0)));
	
	for (unsigned short i=0;i<=1023;i++)
	{
		float temp;

		temp = ((float)(i) - (float)m_nRefWhite);
		if ( i < BreakPoint)
			fOutputValue  = fGain * (pow ( 10.0, (double)((temp * fConConst)*(fGamma/1.7))))  -fOffset;
		else
			fOutputValue  = pow(double(float(i)  - (float)BreakPoint),(double)((float)m_nSoftClip/100.0))*fKneeGain + fKneeOffset;

		if (fOutputValue > 	fPeakValue)
			fOutputValue = fPeakValue;
		fOutputValue = 	(fOutputValue * fSMPTEScaleFactor);
		
		fOutputValue += (64.0);
		
		nLutValue = (int)(fOutputValue+0.5);

		if (nLutValue < 0)
			nLutValue = 0;
		update_look_up_table(i,nLutValue,nLutValue,nLutValue);
		if (fp)
			fprintf(fp,"%6d		%d	%f\n",i,nLutValue,fOutputValue);
	}
	struct blue_1d_lookup_table_struct lut_struct;
	lut_struct.nVideoChannel = m_nOutputChannel;
	lut_struct.nLUTId = lut_cmb_index;
	lut_struct.pLUTData = m_pLUT;
	lut_struct.nLUTElementCount = 1024;
	blue_load_1D_lookup_table(m_pSdk, &lut_struct);
	
	if (fp)
		fclose(fp);
}

void BlueLutDlg::OnClickedTransparentLut(UINT32 DataRange)
{
	UINT32 upconvert,value;
	
	float fSMPTEScaleFactor;
	FILE* fp = NULL;
	//fp = fopen("LUT.txt","wt");
	int lut_cmb_index;
	lut_cmb_index = m_cmbLUTSelect.GetCurSel();
	if (lut_cmb_index == CB_ERR)
		return;

	fSMPTEScaleFactor = (219.0 * 4.0)/(1023);
	for (unsigned short i=0; i<=1023; i++)
	{
		//if (DataRange == SMPTE_RANGE)
		//	value = (i*fSMPTEScaleFactor) + 64.0;
		//else
		//if (DataRange == CGR_RANGE)
			value = i;
		//value = (0);
		update_look_up_table(i,value,value,value);
		if (fp)
			fprintf(fp,"%6d		%d\n",i,value);
	}
	struct blue_1d_lookup_table_struct lut_struct;
	lut_struct.nVideoChannel = m_nOutputChannel;
	lut_struct.nLUTId = lut_cmb_index;
	lut_struct.pLUTData = m_pLUT;
	lut_struct.nLUTElementCount = 1024;
	blue_load_1D_lookup_table(m_pSdk,&lut_struct);

	if (fp)
		fclose(fp);
}

void BlueLutDlg::OnClickedInverseCgrLut(UINT32 DataRange)
{
	UINT32 value = 0;
	int lut_cmb_index = 0;

	lut_cmb_index = m_cmbLUTSelect.GetCurSel();
	if (lut_cmb_index == CB_ERR)
		return;

	for (unsigned short i=0; i<=1023; i++)
	{
		value = (1023-i);
		update_look_up_table(i,value,value,value);
	}

	struct blue_1d_lookup_table_struct lut_struct;
	lut_struct.nVideoChannel = m_nOutputChannel;
	lut_struct.nLUTId = lut_cmb_index;
	lut_struct.pLUTData = m_pLUT;
	lut_struct.nLUTElementCount = 1024;
	blue_load_1D_lookup_table(m_pSdk, &lut_struct);
}

void BlueLutDlg::OnBnClickedApplyLut()
{
	if (IsDlgButtonChecked(IDC_ANTI_LOG_RADIO))
	{
		OClickedAntiLog();
		return;
	}
	else
	if (IsDlgButtonChecked(IDC_TRANSPARENT_RADIO))
	{
		OnClickedTransparentLut(SMPTE_RANGE);
	}
	else
	if(IsDlgButtonChecked(IDC_INVERSE_CGR_RADIO))
	{
		OnClickedInverseCgrLut(CGR_RANGE);
	}
	else
	{
		AfxMessageBox("Select a LUT to upload");
		return;
	}
}


void BlueLutDlg::OnChangeCardSelect()
{
	// TODO: Add your control notification handler code here
	int iDevIndex = 0;
	int iChannelIndex = 0;

	iDevIndex = m_cmbDeviceSelect.GetCurSel();
	m_nDeviceId = iDevIndex+1;

	iChannelIndex = m_cmbChannelSelect.GetCurSel();
	switch(iChannelIndex)
	{
	case 1:
		m_nOutputChannel = BLUE_VIDEO_OUTPUT_CHANNEL_B;
		break;
	case 2:
		m_nOutputChannel = BLUE_VIDEO_OUTPUT_CHANNEL_C;
		break;
	case 3:
		m_nOutputChannel = BLUE_VIDEO_OUTPUT_CHANNEL_D;
		break;
	default:
		m_nOutputChannel = BLUE_VIDEO_OUTPUT_CHANNEL_A;
		break;
	}

	InitBlueCard(TRUE);
	GetCardProperty();
}


void BlueLutDlg::OnCbnSelchangeChannelSelectCombo()
{
	OnChangeCardSelect();
}
