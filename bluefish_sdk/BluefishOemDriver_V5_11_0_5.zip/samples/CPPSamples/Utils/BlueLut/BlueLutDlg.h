// BlueLutDlg.h : header file
//

#pragma once
#include "afxcmn.h"
#include "afxwin.h"

#include "BlueVelvet4.h"
// BlueLutDlg dialog
class BlueLutDlg : public CDialog
{
// Construction
public:
	BlueLutDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_BLUELUT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	void InitBlueCard(BOOL bDetachFirst);
	BOOL GetCardProperty();
	void OnClickedTransparentLut(UINT32 DataRange);
	void OnClickedInverseCgrLut(UINT32 DataRange);
	void update_look_up_table(UINT16 index,UINT32 RedValue, UINT32 GreenValue,UINT32 BlueValue);

	afx_msg void OnRefreshButton();
	afx_msg void OClickedAntiLog();
	afx_msg void OnBnClickedApplyLut();
	afx_msg void OnChangeCardSelect();

public:
	UINT m_nDeviceId;
	UINT m_nOutputChannel;
	UINT m_nRefWhite;
	UINT m_nRefBlack;
	UINT m_nSoftClip;
	float m_fDisplayGamma;
	float m_fFilmGamma;
	CBlueVelvet4 * m_pSdk;
	UINT16 m_pLUT[8192*4];
	
	CComboBox m_cmbDeviceSelect;
	CComboBox m_cmbChannelSelect;
	CComboBox m_cmbLUTSelect;
	afx_msg void OnCbnSelchangeChannelSelectCombo();
};
