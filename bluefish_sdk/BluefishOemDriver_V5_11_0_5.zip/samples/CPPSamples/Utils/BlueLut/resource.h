//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BlueLut.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_BLUELUT_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_IMAGE_HEIGHT                1000
#define IDC_IMAGE_WIDTH                 1001
#define IDC_PANSCAN_H_OFFSET            1002
#define IDC_H_OFFSET_SPIN               1003
#define IDC_PANSCAN_V_OFFSET            1004
#define IDC_V_OFFSET_SPIN               1005
#define IDC_BUTTON_TOP_LEFT             1006
#define IDC_BUTTON_TOP_CENTER           1007
#define IDC_BUTTON_TOP_RIGHT            1008
#define IDC_BUTTON_MIDDLE_LEFT          1009
#define IDC_BUTTON_MIDDLE_RIGHT         1010
#define IDC_BUTTON_BOTTOM_LEFT          1011
#define IDC_BUTTON_BOTTOM_CENTER        1012
#define IDC_BUTTON_BOTTOM_RIGHT         1013
#define IDC_PAN_SCAN_STATUS_CHECK       1014
#define IDC_VGA_COMBO                   1015
#define IDC_SDI_VIDEO_HEIGHT            1017
#define IDC_SDI_VIDEO_WIDTH             1018
#define IDC_VGA_HEIGHT                  1019
#define IDC_VGA_WIDTH                   1020
#define IDC_REFRESH_BUTTON              1021
#define IDC_REF_WHITE                   1022
#define IDC_REF_BLACK                   1023
#define IDC_SOFT_CLIP                   1024
#define IDC_DISP_GAMMA                  1025
#define IDC_FILM_GAMMA                  1026
#define IDC_ANTI_LOG_RADIO              1031
#define IDC_LINEAR_CGR_RADIO            1032
#define IDC_LINEAR_CGR_RADIO_1          1032
#define IDC_TRANSPARENT_RADIO           1033
#define IDC_APPLY_LUT_BUTTON            1034
#define IDC_REQ_PXL_CLK                 1035
#define IDC_LINEAR_SMPTE_RADIO2         1035
#define IDC_INVERSE_CGR_RADIO           1035
#define IDC_REQ_PIXL_CLK_SPIN           1036
#define IDC_H_BLANK_SIZE                1037
#define IDC_CARD_SELECT_COMBO           1037
#define IDC_H_BLANK_SIZE_SPIN           1038
#define IDC_LUT_SELECT_COMBO            1038
#define IDC_H_SYNC_START                1039
#define IDC_CARD_SELECT_COMBO2          1039
#define IDC_CHANNEL_SELECT_COMBO        1039
#define IDC_H_SYNC_START_SPIN           1040
#define IDC_H_SYNC_WIDTH                1041
#define IDC_H_SYNC_WIDTH_SPIN           1042
#define IDC_V_BLANK_SIZE                1043
#define IDC_V_BLANK_SIZE_SPIN           1044
#define IDC_V_SYNC_START                1045
#define IDC_V_SYNC_START_SPIN           1046
#define IDC_V_SYNC_WIDTH                1047
#define IDC_H_SYNC_WIDTH_SPIN2          1048
#define IDC_V_SYNC_WIDTH_SPIN           1048

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
