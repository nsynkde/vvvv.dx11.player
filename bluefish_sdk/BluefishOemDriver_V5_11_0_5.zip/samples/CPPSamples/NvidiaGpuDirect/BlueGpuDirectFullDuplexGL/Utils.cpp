#include "Utils.h"


BlueLock::BlueLock() :
	m_hMutex(NULL)
{
	m_hMutex = CreateMutex(NULL, FALSE, NULL);
}

BlueLock::~BlueLock()
{
	CloseHandle(m_hMutex);
}

void BlueLock::lock()
{
	WaitForSingleObject(m_hMutex, -1);
}

void BlueLock::unlock()
{
	ReleaseMutex(m_hMutex);
}
/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
CBlueTexInfo::CBlueTexInfo(BLUE_UINT32 ID) :
	m_nID(ID)
{
}

CBlueTexInfo::~CBlueTexInfo()
{
}
/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
CBlueFifo::CBlueFifo() :
	m_hFreeMutexEmpty(NULL),
	m_hFreeMutexLive(NULL),
	m_hLiveMutexEmpty(NULL),
	m_hLiveMutexLive(NULL),
	m_pGpuDirect(NULL)
{
}

CBlueFifo::~CBlueFifo()
{
	while(!m_qFreeBuffers.empty())
	{
		m_FreeLock.lock();
		m_qFreeBuffers.front();
		m_qFreeBuffers.pop();
		m_FreeLock.unlock();
	}

	while(!m_qLiveBuffers.empty())
	{
		m_LiveLock.lock();
		m_qLiveBuffers.front();
		m_qLiveBuffers.pop();
		m_LiveLock.unlock();
	}

	CBlueTexInfo* pTextInfo = NULL;
	while(!m_qBuffers.empty())
	{
		pTextInfo = m_qBuffers.front();
		m_qBuffers.pop();
		delete pTextInfo;
		pTextInfo = NULL;
	}

	if(m_hFreeMutexEmpty)	CloseHandle(m_hFreeMutexEmpty);	m_hFreeMutexEmpty = NULL;
	if(m_hFreeMutexLive)	CloseHandle(m_hFreeMutexLive);	m_hFreeMutexLive = NULL;
	if(m_hLiveMutexEmpty)	CloseHandle(m_hLiveMutexEmpty);	m_hLiveMutexEmpty = NULL;
	if(m_hLiveMutexLive)	CloseHandle(m_hLiveMutexLive);	m_hLiveMutexLive = NULL;
}

void CBlueFifo::AddTexture(BLUE_UINT32 ID)
{
	CBlueTexInfo* pBlueTexInfo = NULL;
	pBlueTexInfo = new CBlueTexInfo(ID);
	m_qBuffers.push(pBlueTexInfo);
	m_qFreeBuffers.push(pBlueTexInfo);
}

void CBlueFifo::Init()
{
	if(m_hFreeMutexEmpty)	CloseHandle(m_hFreeMutexEmpty);	m_hFreeMutexEmpty = NULL;
	if(m_hFreeMutexLive)	CloseHandle(m_hFreeMutexLive);	m_hFreeMutexLive = NULL;
	if(m_hLiveMutexEmpty)	CloseHandle(m_hLiveMutexEmpty);	m_hLiveMutexEmpty = NULL;
	if(m_hLiveMutexLive)	CloseHandle(m_hLiveMutexLive);	m_hLiveMutexLive = NULL;

	size_t Count = m_qBuffers.size();
	m_hFreeMutexEmpty = CreateSemaphore(NULL, 0, (LONG)Count, NULL);	//signal that we can't add any buffers to the free queue
    m_hFreeMutexLive = CreateSemaphore(NULL, (LONG)Count, (LONG)Count, NULL);	//signal that we can add a buffer to the live queue as
																				//there are no buffers in the live queue
	m_hLiveMutexEmpty = CreateSemaphore(NULL, (LONG)Count, (LONG)Count, NULL);
    m_hLiveMutexLive = CreateSemaphore(NULL, 0, (LONG)Count, NULL);
}

void CBlueFifo::PutFree(CBlueTexInfo* pTexInfo)
{
	if(!pTexInfo)
		return;

	DWORD dwWaitResult = WaitForSingleObject(m_hFreeMutexEmpty, 100);	//decreases the semaphore
	if(dwWaitResult == WAIT_OBJECT_0)
	{
		m_FreeLock.lock();
		m_qFreeBuffers.push(pTexInfo);
		m_FreeLock.unlock();
		ReleaseSemaphore(m_hFreeMutexLive, 1, NULL);
	}
}

void CBlueFifo::PutLive(CBlueTexInfo* pTexInfo)
{
	if(!pTexInfo)
		return;

	DWORD dwWaitResult = WaitForSingleObject(m_hLiveMutexEmpty, 100);
	if(dwWaitResult == WAIT_OBJECT_0)
	{
		m_LiveLock.lock();
		m_qLiveBuffers.push(pTexInfo);
		m_LiveLock.unlock();
		ReleaseSemaphore(m_hLiveMutexLive, 1, NULL);
	}
}

CBlueTexInfo* CBlueFifo::GetFree(DWORD dwTimeOut)
{
	CBlueTexInfo* pTexInfo = NULL;
	//cout << "GetFree" << endl;
	DWORD dwWaitResult = WaitForSingleObject(m_hFreeMutexLive, dwTimeOut);	//decreases the semaphore
	if(dwWaitResult == WAIT_OBJECT_0)
	{
		m_FreeLock.lock();
		if(!m_qFreeBuffers.empty())
		{
			pTexInfo = m_qFreeBuffers.front();
			m_qFreeBuffers.pop();
		}
		m_FreeLock.unlock();
		ReleaseSemaphore(m_hFreeMutexEmpty, 1, NULL);
	}

	return pTexInfo;
}

CBlueTexInfo* CBlueFifo::GetLive(DWORD dwTimeOut)
{
	CBlueTexInfo* pTexInfo = NULL;
	//cout << "GetLive" << endl;
	DWORD dwWaitResult = WaitForSingleObject(m_hLiveMutexLive, dwTimeOut);	//decreases the semaphore
	if(dwWaitResult == WAIT_OBJECT_0)
	{
		m_LiveLock.lock();
		if(!m_qLiveBuffers.empty())
		{
			pTexInfo = m_qLiveBuffers.front();
			m_qLiveBuffers.pop();
		}
		m_LiveLock.unlock();
		ReleaseSemaphore(m_hLiveMutexEmpty, 1, NULL);
	}

	return pTexInfo;
}
