#include <Windows.h>
#include <queue>
#include "BlueVelvet4.h"
#include "BlueGpuDirect.h"

using namespace std;

class BlueLock
{
public:
	BlueLock();
	~BlueLock();

	void lock();
	void unlock();

private:
	HANDLE	m_hMutex;
};
/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
class CBlueTexInfo
{
public:
	CBlueTexInfo(BLUE_UINT32 ID);
	~CBlueTexInfo();

public:
	BLUE_UINT32	m_nID;
};
/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
class CBlueFifo
{
public:
	CBlueFifo();
	~CBlueFifo();

	void	AddTexture(BLUE_UINT32 ID);
	void	Init();

	void	PutFree(CBlueTexInfo* pTexInfo);
	void	PutLive(CBlueTexInfo* pTexInfo);
	CBlueTexInfo* GetFree(DWORD dwTimeOut=0);
	CBlueTexInfo* GetLive(DWORD dwTimeOut=0);
	void	SetBGDHandle(BLUE_GPUDIRECT_HANDLE pGpuDirect) { m_pGpuDirect = pGpuDirect; };
	BLUE_GPUDIRECT_HANDLE	GetBGDHandle() { return m_pGpuDirect; };

private:
	queue<CBlueTexInfo*>	m_qFreeBuffers;
	queue<CBlueTexInfo*>	m_qLiveBuffers;
	queue<CBlueTexInfo*>	m_qBuffers;
	HANDLE			m_hFreeMutexEmpty;
	HANDLE			m_hFreeMutexLive;
	HANDLE			m_hLiveMutexEmpty;
	HANDLE			m_hLiveMutexLive;
	BlueLock		m_FreeLock;
	BlueLock		m_LiveLock;

	BLUE_GPUDIRECT_HANDLE m_pGpuDirect;
};
