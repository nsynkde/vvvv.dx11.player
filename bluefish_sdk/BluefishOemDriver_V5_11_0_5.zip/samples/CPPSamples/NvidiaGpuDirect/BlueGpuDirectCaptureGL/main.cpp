// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	BlueGpuDirectCaptureGL
// Written by:			Tim Bragulla
// Date:				4 November 2013
//
// Brief description:	This sample application shows how to use the NVIDIA GpuDirect feature to cut down the latency caused by
//						memory transfers between the graphics card, system memory and the Bluefish card
//						This application captures SDI video and processes the frame on the graphics card before rendering in a desktop window
//
// Supported hardware:	NVIDIA Quadro 4000, NVIDIA Quadro 5000 and NVIDIA Quadro 6000
//						Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.2.18 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):				must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_2_18\)
//								$(BLUE_GPUDIRECT_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//
//		32 bit libraries:		BlueGpuDirect.dll		ships with Bluefish's BlueGpuDirect package; available upon request
//								dvp.dll					ships with Bluefish's BlueGpuDirect package; available upon request
//								glew32.dll				ships with Bluefish's BlueGpuDirect package; available upon request
//
//		64 bit libraries:		BlueGpuDirect64.dll		ships with Bluefish's BlueGpuDirect package; available upon request
//								dvp.dll					ships with Bluefish's BlueGpuDirect package; available upon request
//								glew64.dll				ships with Bluefish's BlueGpuDirect package; available upon request
//

#include <windows.h>
#include <conio.h>

#include <GL/glew.h>
#include <GL/wglew.h>
#include <GL/glu.h>
#include <math.h>
#include <assert.h>

#include <iostream>
#include <fstream>
#include <process.h>

#include "teapot.h"
#include "fbo.h"

#include "BlueVelvet4.h"
#include "BlueHancUtils.h"
#include "BlueGpuDirect.h"


using namespace std;


int g_WindowWidth	= 1280;
int g_WindowHeight	= 720;
int g_VideoWidth	= 1920;
int g_VideoHeight	= 1080;

#define NUMBER_OGL_TEXTURES 2	//any number of textures; however, the more textures the more RAM will be used as well!
#define NUMBER_BF_CARD_BUFFERS 3	//3 minimum, but for especially for HD modes not more than 4
#define NUMBER_COMBINED_OGL_BF_BUFFERS 3	//this is for the self contained mode only
#define NUMBER_CHUNKS 2	//split the video frames into chunks for interleaved DMA

unsigned int* g_pAudioScratch;
BLUE_UINT8* g_pHancFrame;
BLUE_UINT8* g_pVancData;

static HWND hWnd;
HDC hDC;
HGLRC hGLRC;
//const GLenum glType = GL_RGBA;
static CFBO dummy_video_fbo;

HANDLE			g_hThread = NULL;
volatile BOOL   g_bStopThread = TRUE;

struct ThreadArgs
{
	CBlueVelvet4* pSDK;
	EBlueVideoChannel nVideoInputChannel;
	EVideoMode VideoMode;
	EUpdateMethod UpdateFormat;
	EMemoryFormat MemoryFormat;
};

void AdjustProcessWorkingSet()
{
	// Increase the process working set size to allow pinning of more memory.
    static SIZE_T  dwMin = 0, dwMax = 0;
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA, FALSE, GetCurrentProcessId());

    if(!hProcess)
    {
        printf( "OpenProcess failed (%d)\n", GetLastError() );
    }

    // Retrieve the working set size of the process.
    if (!dwMin && !GetProcessWorkingSetSize(hProcess, &dwMin, &dwMax))
    {
        printf("GetProcessWorkingSetSize failed (%d)\n",
            GetLastError());
    }

	int size = g_VideoWidth*g_VideoHeight*4;
	BOOL res = SetProcessWorkingSetSize(hProcess, size*NUMBER_COMBINED_OGL_BF_BUFFERS*4 + dwMin, size*NUMBER_COMBINED_OGL_BF_BUFFERS*4 + (dwMax-dwMin));
	if(!res)
		printf("SetProcessWorkingSetSize failed (%d)\n", GetLastError());

    CloseHandle(hProcess);
}

void setupPixelformat(HDC hDC)
{
    PIXELFORMATDESCRIPTOR pfd = {	sizeof(PIXELFORMATDESCRIPTOR),	/* size of this pfd */
									1,				/* version num */
									PFD_DRAW_TO_WINDOW |		/* support window */
									PFD_DOUBLEBUFFER |              /* double buffered */
									PFD_SUPPORT_OPENGL,		/* support OpenGL */
									PFD_TYPE_RGBA,			/* color type */
									8,				/* 8-bit color depth */
									0, 0, 0, 0, 0, 0,		/* color bits (ignored) */
									0,				/* no alpha buffer */
									0,				/* alpha bits (ignored) */
									0,				/* no accumulation buffer */
									0, 0, 0, 0,			/* accum bits (ignored) */
									0,				/* depth buffer (filled below)*/
									0,				/* no stencil buffer */
									0,				/* no auxiliary buffers */
									PFD_MAIN_PLANE,			/* main layer */
									0,				/* reserved */
									0, 0, 0,			/* no layer, visible, damage masks */
									};
    int SelectedPixelFormat;
    BOOL retVal;

    SelectedPixelFormat = ChoosePixelFormat(hDC, &pfd);
    if (SelectedPixelFormat == 0)
        fprintf(stderr, "ChoosePixelFormat failed\n");

    retVal = SetPixelFormat(hDC, SelectedPixelFormat, &pfd);
    if(retVal != TRUE)
        fprintf(stderr, "SetPixelFormat failed\n");
}

void InitGL(void)
{
    const char *renderer = (const char *) glGetString(GL_RENDERER);
    const char *version = (const char *) glGetString(GL_VERSION);

    // Init glew
    glewInit();
    if (!glewIsSupported("GL_VERSION_2_0 "
                         "GL_ARB_pixel_buffer_object "
                         "GL_EXT_framebuffer_object "))
	{
		fprintf(stderr, "Support for necessary OpenGL extensions missing.\n");
    }
    assert (GL_NO_ERROR == glGetError());

    // Hack to detect the presence of G7x. While GL_EXT_geometry_shader4 is not required
    // for this test, it's an easy way to check if the HW is GL 3.0 capable or not.
    if (!strstr((const char *)glGetString(GL_EXTENSIONS), "GL_EXT_geometry_shader4"))
	{
        printf("Found unsupported config for interop.\n");
    }
    assert (GL_NO_ERROR == glGetError());
    if (!strstr(renderer, "Quadro") || strstr(renderer, "Quadro NVS") || !wglewIsSupported("WGL_NV_gpu_affinity "))
	{
    }
    assert (GL_NO_ERROR == glGetError());
}

void ExitGL(void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
}

LRESULT APIENTRY WndProc(HWND hWnd,
						UINT message,
						WPARAM wParam,
						LPARAM lParam)
{
    GLuint res = 0;
    switch (message)
	{
    case WM_CREATE:
        hDC = GetDC(hWnd);
        setupPixelformat(hDC);
        hGLRC = wglCreateContext(hDC);
        wglMakeCurrent(hDC, hGLRC);
        res = glGetError();
        InitGL();
        assert(GL_NO_ERROR == glGetError());
        return 0;
    case WM_DESTROY:
        return 0;
    case WM_CHAR:
        switch ((int)wParam)
		{
        case VK_ESCAPE:
			g_bStopThread = TRUE;
            PostQuitMessage(0);
            return 0;
        default:
            break;
        }
        break;
    default:
        break;
    }

    /* Deal with any unprocessed messages */
    return DefWindowProc(hWnd, message, wParam, lParam);
}

void InitWindow(void)
{
    WNDCLASS wndClass;
    static wchar_t *className = L"GLinterop";
    HINSTANCE hInstance = GetModuleHandle(NULL);
    RECT rect;
	DWORD dwStyle = WS_OVERLAPPED | WS_CAPTION | WS_CLIPCHILDREN | WS_CLIPSIBLINGS;
	DWORD dwExStyle = 0;

    /* Define and register the window class */
    wndClass.style = CS_OWNDC;
    wndClass.lpfnWndProc = WndProc;
    wndClass.cbClsExtra = 0;
    wndClass.cbWndExtra = 0;
    wndClass.hInstance = hInstance,
    wndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
    wndClass.hbrBackground = NULL;
    wndClass.lpszMenuName = NULL;
    wndClass.lpszClassName = className;
    RegisterClass(&wndClass);

    /* Figure out a default size for the window */
    SetRect(&rect, 0, 0, g_WindowWidth, g_WindowHeight);
    //AdjustWindowRect(&rect, dwStyle, FALSE);
	AdjustWindowRectEx(&rect, dwStyle, FALSE, dwExStyle);
	SIZE size;
	size.cx = rect.right - rect.left;
	size.cy = rect.bottom - rect.top;
    /* Create a window of the previously defined class */
    hWnd = CreateWindow(className,
						L"GPUDirect for Video with OpenGL Hello World",
						dwStyle,
						0,
						0,
						size.cx,
						size.cy,
						NULL,
						NULL,
						hInstance,
						NULL);
	ShowWindow(hWnd,SW_SHOW);
}

BOOL InitGlBuffers(GLsizei Count, GLuint* pBuffers, GLenum InternalFormat, BOOL bIsYUV)
{
	glGenTextures(Count, pBuffers);
	GLuint tmp = glGetError();
	if(GL_NO_ERROR != tmp)
	{
		cout << "GL Gen Tex Error: " << tmp << endl;
		return FALSE;
	}

	GLenum pixeltype = GL_UNSIGNED_INT_10_10_10_2;
	GLenum ExternalFormat = GL_RGBA;

	switch(InternalFormat)
	{
		case GL_RGB8:
		case GL_RGBA8:
			pixeltype = GL_UNSIGNED_BYTE;
			break;
		case GL_RGB10:
			pixeltype = GL_UNSIGNED_INT_10_10_10_2;
			break;
		case GL_RGB16:
		case GL_RGBA16:
			pixeltype = GL_UNSIGNED_SHORT;
			break;
		default:
			cout << "Wrong GL type: " << InternalFormat << endl;
			return FALSE;
	}

	for(int i=0; i<Count; i++)
	{
		glBindTexture(GL_TEXTURE_2D, pBuffers[i]);
		tmp = glGetError();
		if(GL_NO_ERROR != tmp)
		{
			cout << "GL Bind Tex Error: " << tmp << endl;
			return FALSE;
		}
		//type = GL_RGB10;
		glTexImage2D(GL_TEXTURE_2D, 0, InternalFormat, bIsYUV?g_VideoWidth/2:g_VideoWidth, g_VideoHeight, 0, ExternalFormat, pixeltype, NULL);
		tmp = glGetError();
		if(GL_NO_ERROR != tmp)
		{
			cout << "GL TexImage2D Error: " << tmp << endl;
			return FALSE;
		}

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		tmp = glGetError();
		if(GL_NO_ERROR != tmp)
		{
			cout << "GL tex filter Error: " << tmp << endl;
			return FALSE;
		}
	}

	cout << "GL textures created: " << Count << endl;
	return TRUE;
}

void CleanupGlBuffers(GLsizei Count, GLuint* pBuffers) 
{
	glDeleteTextures(Count, pBuffers);
}

GLuint ShaderProgram;
GLuint ShaderID;

const char* shaderCharYUVS = {"vec4 YCbCrA709ToPremultipliedRGBA(in vec4 inYCbCrA709Pixel)\n\
{\n\
inYCbCrA709Pixel.r -= 16.0/235.0;\n\
inYCbCrA709Pixel.g -= 0.5;\n\
inYCbCrA709Pixel.b -= 0.5;\n\
vec4 kYCbCr709ToRTable = vec4(1.164383562, 0.0,1.792741071, 0.0);\n\
vec4 kYCbCr709ToGTable = vec4(1.164383562, -0.213248614, -0.532909329, 0.0);\n\
vec4 kYCbCr709ToBTable = vec4(1.164383562, 2.112401786, 0.0, 	0.0);\n\
vec4 RGBA = vec4(dot(inYCbCrA709Pixel, kYCbCr709ToRTable),\n\
dot(inYCbCrA709Pixel, kYCbCr709ToGTable),\n\
dot(inYCbCrA709Pixel, kYCbCr709ToBTable),\n\
inYCbCrA709Pixel.a);\n\
return RGBA;\n\
}\n\
vec4 convert_yuv422_bgra(sampler2D sourceTexUnit, vec2 destTexCoord)\n\
{\n\
vec4 srcTexColorCur;\n\
vec4 destTexColor;\n\
vec4 srcTexCoord;\n\
srcTexCoord.x = destTexCoord.x;\n\
srcTexCoord.y = destTexCoord.y;\n\
float fTexCoordX = destTexCoord.x * 1920.0;\n\
float isEven;\n\
isEven = mod(fTexCoordX, 2.0);\n\
if(isEven < 0.5)\n\
{\n\
srcTexColorCur = texture2D(sourceTexUnit, srcTexCoord);\n\
destTexColor.r =  srcTexColorCur.r;	//Y0\n\
destTexColor.g =  srcTexColorCur.g; //Cb\n\
destTexColor.b =  srcTexColorCur.a; //Cr\n\
}\n\
else\n\
{\n\
srcTexColorCur = texture2D(sourceTexUnit, srcTexCoord);\n\
destTexColor.r =  srcTexColorCur.b;	//Y1\n\
destTexColor.g =  srcTexColorCur.g;	//Cb\n\
destTexColor.b =  srcTexColorCur.a; //Cr\n\
}\n\
destTexColor.a =  1.0;\n\
\n\
return YCbCrA709ToPremultipliedRGBA(destTexColor);\n\
}\n\
uniform sampler2D tex;\n\
void main()\n\
{\n\
gl_FragColor = convert_yuv422_bgra(tex, gl_TexCoord[0].xy);\n\
};\n"
};

const char* shaderChar2VUY = {"vec4 YCbCrA709ToPremultipliedRGBA(in vec4 inYCbCrA709Pixel)\n\
{\n\
inYCbCrA709Pixel.r -= 16.0/235.0;\n\
inYCbCrA709Pixel.g -= 0.5;\n\
inYCbCrA709Pixel.b -= 0.5;\n\
vec4 kYCbCr709ToRTable = vec4(1.164383562, 0.0,1.792741071, 0.0);\n\
vec4 kYCbCr709ToGTable = vec4(1.164383562, -0.213248614, -0.532909329, 0.0);\n\
vec4 kYCbCr709ToBTable = vec4(1.164383562, 2.112401786, 0.0, 	0.0);\n\
vec4 RGBA = vec4(dot(inYCbCrA709Pixel, kYCbCr709ToRTable),\n\
dot(inYCbCrA709Pixel, kYCbCr709ToGTable),\n\
dot(inYCbCrA709Pixel, kYCbCr709ToBTable),\n\
inYCbCrA709Pixel.a);\n\
return RGBA;\n\
}\n\
vec4 convert_yuv422_bgra(sampler2D sourceTexUnit, vec2 destTexCoord)\n\
{\n\
vec4 srcTexColorCur;\n\
vec4 destTexColor;\n\
vec4 srcTexCoord;\n\
srcTexCoord.x = destTexCoord.x;\n\
srcTexCoord.y = destTexCoord.y;\n\
float fTexCoordX = destTexCoord.x * 1920.0;\n\
float isEven;\n\
isEven = mod(fTexCoordX, 2.0);\n\
if(isEven < 0.5)\n\
{\n\
srcTexColorCur = texture2D(sourceTexUnit, srcTexCoord);\n\
destTexColor.r =  srcTexColorCur.g;	//Y0\n\
destTexColor.g =  srcTexColorCur.b; //Cb\n\
destTexColor.b =  srcTexColorCur.r; //Cr\n\
}\n\
else\n\
{\n\
srcTexColorCur = texture2D(sourceTexUnit, srcTexCoord);\n\
destTexColor.r =  srcTexColorCur.a;	//Y1\n\
destTexColor.g =  srcTexColorCur.b; //Cb\n\
destTexColor.b =  srcTexColorCur.r; //Cr\n\
}\n\
destTexColor.a =  1.0;\n\
\n\
return YCbCrA709ToPremultipliedRGBA(destTexColor);\n\
}\n\
uniform sampler2D tex;\n\
void main()\n\
{\n\
gl_FragColor = convert_yuv422_bgra(tex, gl_TexCoord[0].xy);\n\
};\n"
};

void init_dummy_video_setup(int bits, ULONG MemoryFormat)
{
    dummy_video_fbo.create(g_VideoWidth, g_VideoHeight, bits, 1,GL_TRUE, GL_TRUE);

	glEnable(GL_DEPTH_TEST); 
	
	// Initialize lighting for render to texture
	GLfloat spot_ambient[] = {1.0, 1.0, 1.0, 1.0};
	GLfloat spot_position[] = {0.0, 3.0, 3.0, 0.0};
	GLfloat local_view[] = {0.0};
	GLfloat ambient[] = {0.01175f, 0.01175f, 0.1745f};
	GLfloat diffuse[] = {0.04136f, 0.04136f, 0.61424f};
	GLfloat specular[] = {0.626959f, 0.626959f, 0.727811f};

	glLightfv(GL_LIGHT0, GL_POSITION, spot_position);
	glLightfv(GL_LIGHT0, GL_AMBIENT, spot_ambient);
	glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, local_view);

	glFrontFace(GL_CCW);
	//glEnable(GL_CULL_FACE);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_AUTO_NORMAL);
	glEnable(GL_NORMALIZE);
	glDisable(GL_TEXTURE_1D);
	glDisable(GL_TEXTURE_2D);

	glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
	glMaterialf(GL_FRONT, GL_SHININESS, 0.6f*128.0f);

	glDisable(GL_LIGHTING);

	glColor3f(1.0, 1.0, 1.0);
	
	glClearColor(.2f, .2f, .2f, 1.0f);
	glClearDepth( 1.0 ); 
	// Create teapot
	createTeapot(10);

	//turn off VSYNC as this costs us valuable processing time by blocking until the next VSYNC
	//this app is primarily for video processing and pushing it out the Bluefish SDI card rather than rendering to the desktop
	wglSwapIntervalEXT(0);

	if((MemoryFormat == MEM_FMT_YUVS) || (MemoryFormat == MEM_FMT_2VUY))
	{
		ShaderProgram = glCreateProgram();
		ShaderID = glCreateShader(GL_FRAGMENT_SHADER);
		if(MemoryFormat == MEM_FMT_YUVS)
			glShaderSource(ShaderID, 1, &shaderCharYUVS, NULL);
		else
			glShaderSource(ShaderID, 1, &shaderChar2VUY, NULL);
		glCompileShader(ShaderID);

		GLint success;
		glGetShaderiv(ShaderID, GL_COMPILE_STATUS, &success);
	
		GLchar* infoLog = NULL;
		int infoLogLen = 0, charsWritten = 0;
		if(GL_FALSE == success)
		{
			glGetShaderiv(ShaderID, GL_INFO_LOG_LENGTH, &infoLogLen);
			infoLog = new GLchar[infoLogLen];
			glGetShaderInfoLog(ShaderID, infoLogLen, &charsWritten, infoLog);
		}

		assert(success != GL_FALSE);
		if(infoLog)
			delete [] infoLog;

		glAttachShader(ShaderProgram, ShaderID);
		glLinkProgram(ShaderProgram);
		glGetProgramiv(ShaderProgram, GL_LINK_STATUS, &success);
	}
}

void destroy_dummy_video_setup()
{
	dummy_video_fbo.destroy();	
}

void draw_dummy_video(int target, int source)
{
    int width  = g_VideoWidth;
    int height = g_VideoHeight;

	static 	float angle = 0.0;
	static int frame_count_per_rotation = 360;
	static int frame_count = 0;
	
	// Increment rotation angle
	frame_count += 1;
	angle = (GLfloat) (frame_count % frame_count_per_rotation);
	angle /= (GLfloat) frame_count_per_rotation;
	angle = 359 - angle*360;
	// bind fbo to the texture
	dummy_video_fbo.bind(g_VideoWidth, g_VideoHeight, target);

	double halfWinWidth = width / 2.0;
	double halfWinHeight = height / 2.0;

	glClear(GL_COLOR_BUFFER_BIT);	
	glViewport(0, 0, width, height);
	// draw the source texture as the background and render a teapot on top
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(1.0, -1.0, -1.0, 1.0);	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glEnable(GL_TEXTURE_2D);  	
	glBindTexture(GL_TEXTURE_2D, source);  

	if(ShaderProgram)
		glUseProgram(ShaderProgram);

	// Draw the background as the source
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f); glVertex2f(1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex2f(1.0f, 1.0f); 
		glTexCoord2f(1.0f, 1.0f); glVertex2f(-1.0f, 1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex2f(-1.0f, -1.0f);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, 0);
	glDisable(GL_TEXTURE_2D);

	if(ShaderProgram)
		glUseProgram(GL_NONE);

	glClear(GL_DEPTH_BUFFER_BIT);

	// draw the teapot	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-halfWinWidth, halfWinWidth, halfWinHeight, -halfWinHeight, -1000.0, 1000.0), 
	gluLookAt(0, 0.5, 1, 0, 0, 0, 0, 1, 0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glScaled(75.0, 75.0, 75.0);
	glTranslated(0.0, -1.0, 0.0);
	glRotated(angle, 0.0, 1.0, 0.0);

 	// Draw texture
	glEnable(GL_LIGHTING);	
	drawTeapot();
	glDisable(GL_LIGHTING);	
	dummy_video_fbo.unbind(target);
}

void renderToWindow(int target)
{
	//
	// Draw texture contents to graphics window.
	//	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Reset view parameters
	glViewport(0, 0, g_WindowWidth, g_WindowHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(1.0, -1.0, -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Draw contents of each video texture
	glEnable(GL_TEXTURE_2D);  	
	// Bind texture object 	
	glBindTexture(GL_TEXTURE_2D, target);

	// Draw textured quad in lower left quadrant of graphics window.
	glBegin(GL_QUADS);	
		glTexCoord2f(0.0f, 0.0f); glVertex2f(1.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex2f(1.0f, -1.0f); 
		glTexCoord2f(1.0f, 1.0f); glVertex2f(-1.0f, -1.0f); 
		glTexCoord2f(1.0f, 0.0f); glVertex2f(-1.0f, 1.0f);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, 0);  
	glDisable(GL_TEXTURE_2D);
	SwapBuffers(hDC);
}

void processAudioInput(unsigned int nCardType, void* pAudioIn)
{
	if(!pAudioIn)
	{
		cout << "AUDIO ERROR: In: " << (unsigned int)pAudioIn << endl; 
		return;
	}

	hanc_decode_struct HancDecodeStruct;
	memset(&HancDecodeStruct, 0, sizeof(HancDecodeStruct));

	//decode audio
	HancDecodeStruct.audio_ch_required_mask = MONO_CHANNEL_1 | MONO_CHANNEL_2;
	HancDecodeStruct.audio_pcm_data_ptr = (void*)g_pAudioScratch;
	HancDecodeStruct.audio_split_buffer_mask = 0;
	HancDecodeStruct.audio_input_source = AUDIO_INPUT_SOURCE_EMB;
	HancDecodeStruct.type_of_sample_required = AUDIO_CHANNEL_16BIT;
	HancDecodeStruct.max_expected_audio_sample_count = 2002;
	hanc_decoder_ex(nCardType, (unsigned int*)pAudioIn, &HancDecodeStruct);

	//cout << "Audio decoded: " << HancDecodeStruct.no_audio_samples << endl;
}

BOOL IsInputChannel(EBlueVideoChannel VideoChannel)
{
	if(VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_A ||
		VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_B ||
		VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_C ||
		VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_D)
		return TRUE;

	return FALSE;
}

BOOL IsOutputChannel(EBlueVideoChannel VideoChannel)
{
	if(VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_A ||
		VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_B ||
		VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_C ||
		VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_D)
		return TRUE;

	return FALSE;
}

CBlueVelvet4* InitBluefish(int CardId, EBlueVideoChannel VideoChannel, EUpdateMethod UpdFmt, EMemoryFormat MemoryFormat)
{
	CBlueVelvet4* pSDK = NULL;
	EVideoMode VideoMode = VID_FMT_1080I_6000;

	int iDevices = 0;
	VARIANT varVal;

	pSDK = BlueVelvetFactory4();
	pSDK->device_enumerate(iDevices);

	if(iDevices > 0 && CardId <= iDevices)
		pSDK->device_attach(CardId, 0);
	else
	{
		BlueVelvetDestroy(pSDK);
		return NULL;
	}

	varVal.vt = VT_UI4;
	if(IsInputChannel(VideoChannel))
	{
		varVal.ulVal = VideoChannel;
		pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

		varVal.ulVal = MemoryFormat;
		pSDK->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);

		varVal.ulVal = UpdFmt;
		pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);

		varVal.ulVal = VIDEO_ENGINE_FRAMESTORE;
		pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);

		pSDK->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
		ULONG InvalidVideoModeFlag = varVal.ulVal;

		pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
		VideoMode = (EVideoMode)varVal.ulVal;

		if(VideoMode >= InvalidVideoModeFlag)
		{
			cout << "No valid input video mode" << endl;
			return NULL;
		}

		g_VideoWidth = BlueVelvetLinePixels(VideoMode);
		g_VideoHeight = BlueVelvetFrameLines(VideoMode, UpdFmt);

		varVal.ulVal = BLUE_AUDIO_EMBEDDED;
		pSDK->SetCardProperty(AUDIO_INPUT_PROP, varVal);
	}
	else
	{
		cout << "Wrong channel: " << VideoChannel << endl;
		pSDK->device_detach();
		BlueVelvetDestroy(pSDK);
		return NULL;
	}

	return pSDK;
}

//Actual thread
unsigned int __stdcall CaptureThread(void* pArg)
{
	ThreadArgs* pArgs = (ThreadArgs*)pArg;
	CBlueVelvet4* pSDK = pArgs->pSDK;

	unsigned int nCardType = (unsigned int)pSDK->has_video_cardtype();

	wglMakeCurrent(hDC, hGLRC);

	GLuint glInputBuffers[NUMBER_OGL_TEXTURES];
	GLuint glWindowBuffer;

	GLuint tmp = glGetError();
	if(GL_NO_ERROR != tmp)
	{
		cout << "GL Error in FifoThread start: " << tmp << endl;
		return FALSE;
	}

	GLenum glType = GL_RGBA;
	BOOL bIsYUV = FALSE;
	switch(pArgs->MemoryFormat)
	{
		case MEM_FMT_BGRA:
		case MEM_FMT_RGBA:
			glType = GL_RGBA8;
			break;
		case MEM_FMT_BGR:
			glType = GL_RGB8;
			break;
		case MEM_FMT_BGR_16_16_16:
			glType = GL_RGB16;
			break;
		case MEM_FMT_BGRA_16_16_16_16:
			glType = GL_RGBA16;
			break;
		case MEM_FMT_CINEON_LITTLE_ENDIAN:
			glType = GL_RGB10;
			break;
		case MEM_FMT_YUVS:
		case MEM_FMT_2VUY:
			glType = GL_RGBA8;
			bIsYUV = TRUE;
			break;
		default:
			cout << "Not supported pixel format!" << endl;
			return 0;
	}

	if(!InitGlBuffers(NUMBER_OGL_TEXTURES, glInputBuffers, glType, bIsYUV) || !InitGlBuffers(1, &glWindowBuffer, GL_RGBA8, FALSE))
	{
		cout << "Error initialising OpenGL buffers" << endl;
		return 0;
	}

	g_pAudioScratch = new unsigned int[2002*16];

	BLUE_GPUDIRECT_HANDLE pGpuDirectIn = NULL;
	pGpuDirectIn = bfGpuDirect_Init(1, pArgs->nVideoInputChannel, NULL, GPUDIRECT_CONTEXT_TYPE_OPENGL, glInputBuffers, NUMBER_OGL_TEXTURES, NUMBER_CHUNKS);
	if(!pGpuDirectIn)
	{
		cout << "Error initialising BlueGpuDirect" << endl;
		return 0;
	}
	int GpuDirectError = BGD_NO_ERROR;
	int GpuDirectLowLevelError = 0;
	GpuDirectError = bfGpuDirect_GetLastError(pGpuDirectIn, &GpuDirectLowLevelError);
	if(GpuDirectError != BGD_NO_ERROR)
	{
		cout << "Error initialising BlueGpuDirect: " << GpuDirectError << ", LowLevelError: " << GpuDirectLowLevelError << endl;
		return 0;
	}

	unsigned long FieldCount = 0;
	unsigned long LastFieldCount = 0;
	unsigned long ScheduleID = 0;
	unsigned long CapturingID = 0;
	unsigned long DoneID = 0;
	unsigned long BufferSelect = 0;
	unsigned long DMABufferIdVideo = 0;
	unsigned long DMABufferIdHanc = 0;
	unsigned long DMABufferIdVanc = 0;
	unsigned int nOglTexID = 0;
	int nVancBufferSize = 0;

	g_pAudioScratch = new unsigned int[2002*16];
	g_pHancFrame = (BLUE_UINT8*)VirtualAlloc(NULL, 256*1024, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(g_pHancFrame, 256*1024);

	nVancBufferSize = BlueVelvetVANCGoldenValue(nCardType, pArgs->VideoMode, pArgs->MemoryFormat, (pArgs->UpdateFormat == UPD_FMT_FRAME)?BLUE_DATA_FRAME:BLUE_DATA_FIELD1);
	g_pVancData = (BLUE_UINT8*)VirtualAlloc(NULL, nVancBufferSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(g_pVancData, nVancBufferSize);

	int bits = 8;
	if(pArgs->MemoryFormat == MEM_FMT_CINEON_LITTLE_ENDIAN)
		bits = 10;
	else if(pArgs->MemoryFormat == MEM_FMT_BGRA_16_16_16_16)
		bits = 16;
	init_dummy_video_setup(bits, pArgs->MemoryFormat);
	if(pGpuDirectIn)
	{
		//sync with card by waiting for the next video output interrupt
		pSDK->wait_input_video_synch(pArgs->UpdateFormat, FieldCount);
		if(pArgs->UpdateFormat == UPD_FMT_FIELD && !(FieldCount & 0x1))
			pSDK->wait_input_video_synch(pArgs->UpdateFormat, FieldCount);	//start on correct field

		pSDK->wait_input_video_synch(pArgs->UpdateFormat, FieldCount);	//this call just synchronises us to the card
		pSDK->render_buffer_capture(BlueBuffer_Image_VBI_HANC(ScheduleID), 0);
		CapturingID = ScheduleID;
		ScheduleID = (++ScheduleID % NUMBER_BF_CARD_BUFFERS);
		LastFieldCount = FieldCount;

		pSDK->wait_input_video_synch(pArgs->UpdateFormat, FieldCount);	//the first buffer starts to be captured now; this is it's field count
		pSDK->render_buffer_capture(BlueBuffer_Image_VBI_HANC(ScheduleID), 0);
		DoneID = CapturingID;
		CapturingID = ScheduleID;
		ScheduleID = (++ScheduleID % NUMBER_BF_CARD_BUFFERS);
		LastFieldCount = FieldCount;

		cout << "Entering loop...press any key to stop..." << endl;
		while(!g_bStopThread)
		{
			pSDK->wait_input_video_synch(pArgs->UpdateFormat, FieldCount);
			pSDK->render_buffer_capture(BlueBuffer_Image_VBI_HANC(ScheduleID), 0);

			//transfer the video frame from the Bluefish card to the GPU's memory
			if(bfGpuDirect_TransferInputFrameToGPU(pGpuDirectIn, BlueImage_VBI_HANC_DMABuffer(DoneID, BLUE_DATA_FRAME), (void*)(&glInputBuffers[nOglTexID])) != 0)
			{
				cout << __FUNCTION__ << ": Error in Transfer" << endl;
				g_bStopThread = true;
				break;
			}
			pSDK->system_buffer_read_async(g_pHancFrame, 256*1024, NULL, BlueImage_VBI_HANC_DMABuffer(DoneID, BLUE_DATA_HANC));
			pSDK->system_buffer_read_async(g_pVancData, nVancBufferSize, NULL, BlueImage_VBI_HANC_DMABuffer(DoneID, BLUE_DATA_VBI));

			assert(bfGpuDirect_BeginProcessing(pGpuDirectIn, (void*)(&glInputBuffers[nOglTexID])) == 0);
			draw_dummy_video(glWindowBuffer, glInputBuffers[nOglTexID]);
			assert(bfGpuDirect_EndProcessing(pGpuDirectIn, (void*)(&glInputBuffers[nOglTexID])) == 0);
			renderToWindow(glWindowBuffer);
		
			//in field mode we get a whole HANC frame every second field
			processAudioInput(nCardType, g_pHancFrame);

			if(LastFieldCount + ((pArgs->UpdateFormat == UPD_FMT_FRAME)?2:1) < FieldCount)
			{
				int DroppedFrames = FieldCount - (LastFieldCount + ((pArgs->UpdateFormat == UPD_FMT_FRAME)?2:1));
				if(pArgs->UpdateFormat == UPD_FMT_FRAME)
					DroppedFrames /=2;
				cout << "Dropped Frames: " << DroppedFrames << endl;
			}

			DoneID = CapturingID;
			CapturingID = ScheduleID;
			ScheduleID = (++ScheduleID % NUMBER_BF_CARD_BUFFERS);
			LastFieldCount = FieldCount;

			nOglTexID = (++nOglTexID % NUMBER_OGL_TEXTURES);
		}
	}
	else
		cout << "Init failed!" << endl;

	if(g_pAudioScratch)
		delete [] g_pAudioScratch;

	destroy_dummy_video_setup();
	CleanupGlBuffers(NUMBER_OGL_TEXTURES, glInputBuffers);
	CleanupGlBuffers(1, &glWindowBuffer);

	bfGpuDirect_Destroy(pGpuDirectIn);
	wglMakeCurrent(NULL, NULL);

	if(g_pHancFrame)
	{
		VirtualUnlock(g_pHancFrame, 256*1024);
		VirtualFree(g_pHancFrame, 0, MEM_RELEASE);
		g_pHancFrame = NULL;
	}

	if(g_pVancData)
	{
		VirtualUnlock(g_pVancData, nVancBufferSize);
		VirtualFree(g_pVancData, 0, MEM_RELEASE);
		g_pHancFrame = NULL;
	}

	_endthreadex(0);
    return 0;
}

int CaptureSampleDmaOnly()
{
	EBlueVideoChannel nVideoInputChannel;
	EUpdateMethod UpdateFormat = UPD_FMT_FRAME;
	//EUpdateMethod UpdateFormat = UPD_FMT_FIELD;
	EMemoryFormat MemoryFormat = MEM_FMT_BGRA;
	int MemFmtSelection = 0;

	if(UpdateFormat == UPD_FMT_FIELD)
	{
		g_VideoHeight /= 2;
		g_WindowHeight /= 2;
	}

	printf("OGL BlueGpuDirect Capture Sample Application\n");
	printf("Select Video Input Channel :\n");
	printf("BLUE_VIDEO_INPUT_CHANNEL_A --> %d\n",BLUE_VIDEO_INPUT_CHANNEL_A);
	printf("BLUE_VIDEO_INPUT_CHANNEL_B --> %d\n",BLUE_VIDEO_INPUT_CHANNEL_B);
	scanf_s("%d", &nVideoInputChannel);

	printf("Select Pixel Format:\n");
	printf("MEM_FMT_BGRA (1)\n");
	printf("MEM_FMT_RGBA (2)\n");
	printf("MEM_FMT_BGR (3)\n");
	printf("MEM_FMT_BGR_16_16_16 (4)\n");
	printf("MEM_FMT_BGRA_16_16_16_16 (5)\n");
	printf("MEM_FMT_CINEON_LITTLE_ENDIAN (6)\n");
	printf("MEM_FMT_YUVS (7)\n");
	printf("MEM_FMT_2VUY (8)\n");
	scanf_s("%d", &MemFmtSelection);

	switch(MemFmtSelection)
	{
		case 1:
			MemoryFormat = MEM_FMT_BGRA;
			break;
		case 2:
			MemoryFormat = MEM_FMT_RGBA;
			break;
		case 3:
			MemoryFormat = MEM_FMT_BGR;
			break;
		case 4:
			MemoryFormat = MEM_FMT_BGR_16_16_16;
			break;
		case 5:
			MemoryFormat = MEM_FMT_BGRA_16_16_16_16;
			break;
		case 6:
			MemoryFormat = MEM_FMT_CINEON_LITTLE_ENDIAN;
			break;
		case 7:
			MemoryFormat = MEM_FMT_YUVS;
			break;
		case 8:
			MemoryFormat = MEM_FMT_2VUY;
			break;
		default:
			cout << "Not supported pixel format!" << endl;
			return 0;
	}

	CBlueVelvet4* pSDKIn = NULL;
	pSDKIn = InitBluefish(1, nVideoInputChannel, UpdateFormat, MemoryFormat);
	if(!pSDKIn)
	{
		cout << "Error initialising Bluefish card" << endl;
		return 0;
	}

	AdjustProcessWorkingSet();
	InitWindow();

	VARIANT varVal;
	varVal.vt = VT_UI4;

	pSDKIn->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	EVideoMode VideoMode = (EVideoMode)varVal.ulVal;

	ThreadArgs args;
	args.pSDK = pSDKIn;
	args.nVideoInputChannel = nVideoInputChannel;
	args.VideoMode = VideoMode;
	args.UpdateFormat = UpdateFormat;
	args.MemoryFormat = MemoryFormat;

	wglMakeCurrent(NULL, NULL);

	unsigned int ThreadId = 0;
	g_hThread = (HANDLE)_beginthreadex(NULL, 0, &CaptureThread, &args, CREATE_SUSPENDED, &ThreadId);
	if(!g_hThread)
	{
		cout << "Error starting thread" << endl;
		return 0;
	}
	g_bStopThread = FALSE;
 
	//Start thread
	ResumeThread(g_hThread);
 
	MSG uMsg;
	memset(&uMsg, 0, sizeof(uMsg));
	BOOL bSuccess = TRUE;
	while(bSuccess)
	{
		if(GetMessage(&uMsg, NULL, 0, 0))
		{
			TranslateMessage(&uMsg);
			DispatchMessage(&uMsg);
		}
		else
		{
			if(uMsg.message == WM_QUIT)
			{
				bSuccess = FALSE;
				cout << "Quitting..." << endl;
				break;
			}
		}
	}
	
	//Stopping the thread, if it's not stopped yet
	cout << "Stopping thread..." << endl;
	g_bStopThread = TRUE;
	DWORD dw = WaitForSingleObject(g_hThread, -1);

	CloseHandle(g_hThread);

	if(hGLRC)
	{
        wglMakeCurrent(hDC, hGLRC);
        ExitGL();
        wglMakeCurrent(NULL, NULL);
        wglDeleteContext(hGLRC);
    }

    ReleaseDC(hWnd, hDC);
	DestroyWindow(hWnd);

	pSDKIn->device_detach();
	BlueVelvetDestroy(pSDKIn);

	system("pause");
	return 0;
}

int main(int argc, char *argv[])
{
	return CaptureSampleDmaOnly();
}
