// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	BlueGpuDirectPlaybackGL
// Written by:			Tim Bragulla
// Date:				09 October 2012
//
// Brief description:	This sample application shows how to use the NVIDIA GpuDirect feature to cut down the latency caused by
//						memory transfers between the graphics card, system memory and the Bluefish card
//						This application plays back SDI video that is generated on the graphics card before and renders it also to a desktop window
//
// Supported hardware:	NVIDIA Quadro 4000, NVIDIA Quadro 5000 and NVIDIA Quadro 6000
//						Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):				must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_GPUDIRECT_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//
//		32 bit libraries:		BlueGpuDirect.dll		ships with Bluefish's BlueGpuDirect package; available upon request
//								dvp.dll					ships with Bluefish's BlueGpuDirect package; available upon request
//								glew32.dll				ships with Bluefish's BlueGpuDirect package; available upon request
//
//		64 bit libraries:		BlueGpuDirect64.dll		ships with Bluefish's BlueGpuDirect package; available upon request
//								dvp.dll					ships with Bluefish's BlueGpuDirect package; available upon request
//								glew64.dll				ships with Bluefish's BlueGpuDirect package; available upon request
//

#include <windows.h>
#include <conio.h>

#include <GL/glew.h>
#include <GL/wglew.h>
#include <GL/glu.h>
#include <math.h>
#include <assert.h>

#include <iostream>
#include <fstream>
#include <process.h>

#include "teapot.h"
#include "fbo.h"

#include "BlueVelvet4.h"
#include "BlueHancUtils.h"
#include "BlueGpuDirect.h"


using namespace std;

void Fill50(unsigned short* pAudio16, unsigned int Samples, unsigned int Channels);

int g_WindowWidth	= 1280;
int g_WindowHeight	= 720;
int g_VideoWidth	= 1920;
int g_VideoHeight	= 1080;

#define NUMBER_OGL_TEXTURES 3
#define NUMBER_BF_CARD_BUFFERS 3
#define NUMBER_CHUNKS 2

unsigned int* g_pAudioScratch;
BLUE_UINT8* g_pHancFrame;
BLUE_UINT8* g_pVancData;

static HWND hWnd;
HDC hDC;
HGLRC hGLRC;
//const GLenum glType = GL_RGBA;
static CFBO dummy_video_fbo;

HANDLE			g_hThread = NULL;
volatile BOOL   g_bStopThread = TRUE;

struct ThreadArgs
{
	CBlueVelvet4* pSDK;
	EBlueVideoChannel nVideoOutputChannel;
	EVideoMode VideoMode;
	EUpdateMethod UpdateFormat;
	EMemoryFormat MemoryFormat;
};


void AdjustProcessWorkingSet()
{
	// Increase the process working set size to allow pinning of more memory.
    static SIZE_T  dwMin = 0, dwMax = 0;
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA, FALSE, GetCurrentProcessId());

    if(!hProcess)
    {
        printf( "OpenProcess failed (%d)\n", GetLastError() );
    }

    // Retrieve the working set size of the process.
    if (!dwMin && !GetProcessWorkingSetSize(hProcess, &dwMin, &dwMax))
    {
        printf("GetProcessWorkingSetSize failed (%d)\n",
            GetLastError());
    }

	int size = g_VideoWidth*g_VideoHeight*4;
	BOOL res = SetProcessWorkingSetSize(hProcess, size*NUMBER_OGL_TEXTURES*4 + dwMin, size*NUMBER_OGL_TEXTURES*4 + (dwMax-dwMin));
	if(!res)
		printf("SetProcessWorkingSetSize failed (%d)\n", GetLastError());

    CloseHandle(hProcess);
}

void setupPixelformat(HDC hDC)
{
    PIXELFORMATDESCRIPTOR pfd = {	sizeof(PIXELFORMATDESCRIPTOR),	/* size of this pfd */
									1,				/* version num */
									PFD_DRAW_TO_WINDOW |		/* support window */
									PFD_DOUBLEBUFFER |              /* double buffered */
									PFD_SUPPORT_OPENGL,		/* support OpenGL */
									PFD_TYPE_RGBA,			/* color type */
									8,				/* 8-bit color depth */
									0, 0, 0, 0, 0, 0,		/* color bits (ignored) */
									0,				/* no alpha buffer */
									0,				/* alpha bits (ignored) */
									0,				/* no accumulation buffer */
									0, 0, 0, 0,			/* accum bits (ignored) */
									0,				/* depth buffer (filled below)*/
									0,				/* no stencil buffer */
									0,				/* no auxiliary buffers */
									PFD_MAIN_PLANE,			/* main layer */
									0,				/* reserved */
									0, 0, 0,			/* no layer, visible, damage masks */
									};
    int SelectedPixelFormat;
    BOOL retVal;

    SelectedPixelFormat = ChoosePixelFormat(hDC, &pfd);
    if (SelectedPixelFormat == 0)
        fprintf(stderr, "ChoosePixelFormat failed\n");

    retVal = SetPixelFormat(hDC, SelectedPixelFormat, &pfd);
    if(retVal != TRUE)
        fprintf(stderr, "SetPixelFormat failed\n");
}

void InitGL(void)
{
    const char *renderer = (const char *) glGetString(GL_RENDERER);
    const char *version = (const char *) glGetString(GL_VERSION);

    // Init glew
    glewInit();
    if (!glewIsSupported("GL_VERSION_2_0 "
                         "GL_ARB_pixel_buffer_object "
                         "GL_EXT_framebuffer_object "))
	{
		fprintf(stderr, "Support for necessary OpenGL extensions missing.\n");
    }
    assert (GL_NO_ERROR == glGetError());

    // Hack to detect the presence of G7x. While GL_EXT_geometry_shader4 is not required
    // for this test, it's an easy way to check if the HW is GL 3.0 capable or not.
    if (!strstr((const char *)glGetString(GL_EXTENSIONS), "GL_EXT_geometry_shader4"))
	{
        printf("Found unsupported config for interop.\n");
    }
    assert (GL_NO_ERROR == glGetError());
    if (!strstr(renderer, "Quadro") || strstr(renderer, "Quadro NVS") || !wglewIsSupported("WGL_NV_gpu_affinity "))
	{
    }
    assert (GL_NO_ERROR == glGetError());
}

void ExitGL(void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
}

LRESULT APIENTRY WndProc(HWND hWnd,
						UINT message,
						WPARAM wParam,
						LPARAM lParam)
{
    GLuint res = 0;
    switch (message)
	{
    case WM_CREATE:
        hDC = GetDC(hWnd);
        setupPixelformat(hDC);
        hGLRC = wglCreateContext(hDC);
        wglMakeCurrent(hDC, hGLRC);
        res = glGetError();
        InitGL();
        assert(GL_NO_ERROR == glGetError());
        return 0;
    case WM_DESTROY:
        return 0;
    case WM_CHAR:
        switch ((int)wParam)
		{
        case VK_ESCAPE:
			g_bStopThread = TRUE;
			PostQuitMessage(0);
            return 0;
        default:
            break;
        }
        break;
    default:
        break;
    }

    /* Deal with any unprocessed messages */
    return DefWindowProc(hWnd, message, wParam, lParam);
}

void InitWindow(void)
{
    WNDCLASS wndClass;
    static wchar_t *className = L"GLinterop";
    HINSTANCE hInstance = GetModuleHandle(NULL);
    RECT rect;
    DWORD dwStyle = WS_OVERLAPPED | WS_CLIPCHILDREN | WS_CLIPSIBLINGS;

    /* Define and register the window class */
    wndClass.style = CS_OWNDC;
    wndClass.lpfnWndProc = WndProc;
    wndClass.cbClsExtra = 0;
    wndClass.cbWndExtra = 0;
    wndClass.hInstance = hInstance,
    wndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
    wndClass.hbrBackground = NULL;
    wndClass.lpszMenuName = NULL;
    wndClass.lpszClassName = className;
    RegisterClass(&wndClass);

    /* Figure out a default size for the window */
    SetRect(&rect, 0, 0, g_WindowWidth, g_WindowHeight);
    AdjustWindowRect(&rect, dwStyle, TRUE);
	SIZE size;
	size.cx = rect.right - rect.left;
	size.cy = rect.bottom - rect.top;
    /* Create a window of the previously defined class */
    hWnd = CreateWindow(className,
						L"GPUDirect for Video with OpenGL - Press ESC to quit",
						dwStyle,
						50,
						50,
						size.cx,
						size.cy,
						NULL,
						NULL,
						hInstance,
						NULL);
	ShowWindow(hWnd, SW_SHOW);
}

BOOL InitGlBuffers(GLsizei Count, GLuint* pBuffers, GLenum InternalFormat)
{
	glGenTextures(Count, pBuffers);
	GLuint tmp = glGetError();
	if(GL_NO_ERROR != tmp)
	{
		cout << "GL Gen Tex Error: " << tmp << endl;
		return FALSE;
	}

	GLenum pixeltype = GL_UNSIGNED_INT_10_10_10_2;
	GLenum ExternalFormat = GL_RGBA;

	switch(InternalFormat)
	{
		case GL_RGB8:
		case GL_RGBA8:
			pixeltype = GL_UNSIGNED_BYTE;
			break;
		case GL_RGB10:
			pixeltype = GL_UNSIGNED_INT_10_10_10_2;
			break;
		case GL_RGB16:
		case GL_RGBA16:
			pixeltype = GL_UNSIGNED_SHORT;
			break;
		default:
			cout << "Wrong GL type: " << InternalFormat << endl;
			return FALSE;
	}

	for(int i=0; i<Count; i++)
	{
		glBindTexture(GL_TEXTURE_2D, pBuffers[i]);
		tmp = glGetError();
		if(GL_NO_ERROR != tmp)
		{
			cout << "GL Bind Tex Error: " << tmp << endl;
			return FALSE;
		}
		//type = GL_RGB10;
		glTexImage2D(GL_TEXTURE_2D, 0, InternalFormat, g_VideoWidth, g_VideoHeight, 0, ExternalFormat, pixeltype, NULL);
		tmp = glGetError();
		if(GL_NO_ERROR != tmp)
		{
			cout << "GL TexImage2D Error: " << tmp << endl;
			return FALSE;
		}

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		tmp = glGetError();
		if(GL_NO_ERROR != tmp)
		{
			cout << "GL tex filter Error: " << tmp << endl;
			return FALSE;
		}
	}

	cout << "GL textures created: " << Count << endl;
	return TRUE;
}

void CleanupGlBuffers(GLsizei Count, GLuint* pBuffers) 
{
	glDeleteTextures(Count, pBuffers);
}

void init_dummy_video_setup(int bits)
{
    dummy_video_fbo.create(g_VideoWidth, g_VideoHeight, bits, 1,GL_TRUE, GL_TRUE);

	glEnable(GL_DEPTH_TEST); 
	
	// Initialize lighting for render to texture
	GLfloat spot_ambient[] = {1.0, 1.0, 1.0, 1.0};
	GLfloat spot_position[] = {0.0, 3.0, 3.0, 0.0};
	GLfloat local_view[] = {0.0};
	GLfloat ambient[] = {0.01175f, 0.01175f, 0.1745f};
	GLfloat diffuse[] = {0.04136f, 0.04136f, 0.61424f};
	GLfloat specular[] = {0.626959f, 0.626959f, 0.727811f};

	glLightfv(GL_LIGHT0, GL_POSITION, spot_position);
	glLightfv(GL_LIGHT0, GL_AMBIENT, spot_ambient);
	glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, local_view);

	glFrontFace(GL_CCW);
	//glEnable(GL_CULL_FACE);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_AUTO_NORMAL);
	glEnable(GL_NORMALIZE);
	glDisable(GL_TEXTURE_1D);
	glDisable(GL_TEXTURE_2D);

	glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
	glMaterialf(GL_FRONT, GL_SHININESS, 0.6f*128.0f);

	glDisable(GL_LIGHTING);

	glColor3f(1.0, 1.0, 1.0);
	
	glClearColor(.2f, .2f, .2f, 1.0f);
	glClearDepth( 1.0 ); 
	// Create teapot
	createTeapot(10);

	//turn off VSYNC as this costs us valuable processing time by blocking until the next VSYNC
	//this app is primarily for video processing and pushing it out the Bluefish SDI card rather than rendering to the desktop
	wglSwapIntervalEXT(0);
}

void destroy_dummy_video_setup()
{
	dummy_video_fbo.destroy();	
}

void draw_dummy_video(int target, int source)
{
    int width  = g_VideoWidth;
    int height = g_VideoHeight;

	static 	float angle = 0.0;
	static int frame_count_per_rotation = 360;
	static int frame_count = 0;
	
	// Increment rotation angle
	frame_count += 1;
	angle = (GLfloat) (frame_count % frame_count_per_rotation);
	angle /= (GLfloat) frame_count_per_rotation;
	angle = 359 - angle*360;
	// bind fbo to the texture
	dummy_video_fbo.bind(g_VideoWidth, g_VideoHeight, target);

	double halfWinWidth = width / 2.0;
	double halfWinHeight = height / 2.0;

	glClear(GL_COLOR_BUFFER_BIT);	
	glViewport(0, 0, width, height);
	glClear(GL_DEPTH_BUFFER_BIT);	

	// draw the teapot	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-halfWinWidth, halfWinWidth, halfWinHeight, -halfWinHeight, -1000.0, 1000.0), 
	gluLookAt(0, 0.5, 1, 0, 0, 0, 0, 1, 0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glScaled(75.0, 75.0, 75.0);
	glTranslated(0.0, -1.0, 0.0);
	glRotated(angle, 0.0, 1.0, 0.0);

 	// Draw texture
	glEnable(GL_LIGHTING);	
	drawTeapot();
	glDisable(GL_LIGHTING);	
	dummy_video_fbo.unbind(target);
}

void renderToWindow(int target)
{
	//
	// Draw texture contents to graphics window.
	//	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Reset view parameters
	glViewport(0, 0, g_WindowWidth, g_WindowHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(1.0, -1.0, -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Draw contents of each video texture
	glEnable(GL_TEXTURE_2D);  	
	// Bind texture object 	
	glBindTexture(GL_TEXTURE_2D, target);

	// Draw textured quad in lower left quadrant of graphics window.
	glBegin(GL_QUADS);	
		glTexCoord2f(0.0f, 0.0f); glVertex2f(1.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex2f(1.0f, -1.0f); 
		glTexCoord2f(1.0f, 1.0f); glVertex2f(-1.0f, -1.0f); 
		glTexCoord2f(1.0f, 0.0f); glVertex2f(-1.0f, 1.0f);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, 0);  
	glDisable(GL_TEXTURE_2D);
	SwapBuffers(hDC);
}

void processAudioOutput(unsigned int nCardType, void* pAudioOut, unsigned int VideoMode)
{
	if(!pAudioOut)
	{
		cout << "AUDIO ERROR: Out: " << (unsigned int)pAudioOut << endl; 
		return;
	}

	hanc_stream_info_struct HancEncodeStruct;
	memset(&HancEncodeStruct, 0, sizeof(HancEncodeStruct));

	//encode audio
	HancEncodeStruct.AudioDBNArray[0] = -1;
	HancEncodeStruct.AudioDBNArray[1] = -1;
	HancEncodeStruct.AudioDBNArray[2] = -1;
	HancEncodeStruct.AudioDBNArray[3] = -1;
	HancEncodeStruct.hanc_data_ptr = (unsigned int*)pAudioOut;
	HancEncodeStruct.video_mode = VideoMode;

	encode_hanc_frame_ex(nCardType, &HancEncodeStruct, (void*)g_pAudioScratch, 2, 1600, AUDIO_CHANNEL_16BIT, blue_emb_audio_enable | blue_emb_audio_group1_enable);
}

BOOL IsInputChannel(EBlueVideoChannel VideoChannel)
{
	if(VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_A ||
		VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_B ||
		VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_C ||
		VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_D)
		return TRUE;

	return FALSE;
}

BOOL IsOutputChannel(EBlueVideoChannel VideoChannel)
{
	if(VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_A ||
		VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_B ||
		VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_C ||
		VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_D)
		return TRUE;

	return FALSE;
}

CBlueVelvet4* InitBluefish(int CardId, EBlueVideoChannel VideoChannel, EVideoMode VideoMode, EUpdateMethod UpdFmt, EMemoryFormat MemoryFormat, EEngineMode VideoEngine)
{
	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;
	VARIANT varVal;

	pSDK = BlueVelvetFactory4();
	pSDK->device_enumerate(iDevices);

	if(iDevices > 0 && CardId <= iDevices)
		pSDK->device_attach(CardId, 0);
	else
	{
		BlueVelvetDestroy(pSDK);
		return NULL;
	}

	varVal.vt = VT_UI4;
	if(IsOutputChannel(VideoChannel))
	{
		varVal.ulVal = VideoChannel;
		pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

		varVal.ulVal = VideoMode;
		pSDK->SetCardProperty(VIDEO_MODE, varVal);

		varVal.ulVal = MemoryFormat;
		pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

		varVal.ulVal = UpdFmt;
		pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

		g_VideoWidth = BlueVelvetLinePixels(VideoMode);
		g_VideoHeight = BlueVelvetFrameLines(VideoMode, UpdFmt);

		varVal.ulVal = 0;
		pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

		varVal.ulVal = VideoEngine;
		pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);
	}
	else
	{
		cout << "Wrong channel: " << VideoChannel << endl;
		pSDK->device_detach();
		BlueVelvetDestroy(pSDK);
		return NULL;
	}

	return pSDK;
}
//Actual thread
unsigned int __stdcall PlaybackThreadFifoMode(void* pArg)
{
	ThreadArgs* pArgs = (ThreadArgs*)pArg;
	CBlueVelvet4* pSDK = pArgs->pSDK;
	VARIANT varVal;

	unsigned int nCardType = (unsigned int)pSDK->has_video_cardtype();

	wglMakeCurrent(hDC, hGLRC);

	GLuint glOutputBuffers[NUMBER_OGL_TEXTURES];
	GLuint glWindowBuffer;

	GLuint tmp = glGetError();
	if(GL_NO_ERROR != tmp)
	{
		cout << "GL Error in FifoThread start: " << tmp << endl;
		return FALSE;
	}

	GLenum glType = GL_RGBA;

	switch(pArgs->MemoryFormat)
	{
		case MEM_FMT_BGRA:
		case MEM_FMT_RGBA:
			glType = GL_RGBA8;
			break;
		case MEM_FMT_BGR:
			glType = GL_RGB8;
			break;
		case MEM_FMT_BGR_16_16_16:
			glType = GL_RGB16;
			break;
		case MEM_FMT_BGRA_16_16_16_16:
			glType = GL_RGBA16;
			break;
		case MEM_FMT_CINEON_LITTLE_ENDIAN:
			glType = GL_RGB10;
			break;
		case MEM_FMT_YUVS:
		case MEM_FMT_2VUY:
			glType = GL_RGBA8;
			break;
		default:
			cout << "Not supported pixel format!" << endl;
			return 0;
	}

	if(!InitGlBuffers(NUMBER_OGL_TEXTURES, glOutputBuffers, glType) || !InitGlBuffers(1, &glWindowBuffer, GL_RGBA8))
	{
		cout << "Error initialising OpenGL buffers" << endl;
		return 0;
	}

	BLUE_GPUDIRECT_HANDLE pGpuDirectOut = bfGpuDirect_Init(1, pArgs->nVideoOutputChannel, NULL, GPUDIRECT_CONTEXT_TYPE_OPENGL, glOutputBuffers, NUMBER_OGL_TEXTURES, NUMBER_CHUNKS);
	if(!pGpuDirectOut)
	{
		cout << "Error initialising BlueGpuDirect" << endl;
		return 0;
	}
	int GpuDirectError = BGD_NO_ERROR;
	int GpuDirectLowLevelError = 0;
	GpuDirectError = bfGpuDirect_GetLastError(pGpuDirectOut, &GpuDirectLowLevelError);
	if(GpuDirectError != BGD_NO_ERROR)
	{
		cout << "Error initialising BlueGpuDirect: " << GpuDirectError << ", LowLevelError: " << GpuDirectLowLevelError << endl;
		return 0;
	}

	int bits = 8;
	if(pArgs->MemoryFormat == MEM_FMT_CINEON_LITTLE_ENDIAN)
		bits = 10;
	else if(pArgs->MemoryFormat == MEM_FMT_BGRA_16_16_16_16)
		bits = 16;
	init_dummy_video_setup(bits);

	unsigned long FieldCount = 0;
	unsigned long BufferSelect = 0;
	unsigned long TextureSelect = 0;
	unsigned long DMABufferIdVideo = 0;
	unsigned long DMABufferIdHanc = 0;
	unsigned long DMABufferIdVanc = 0;
	unsigned int nOglTexID = 0;
	int nVancBufferSize = 0;
	BOOL bUseAudio = TRUE;
	BOOL bUseVanc = FALSE;

	if(bUseAudio)
	{
		g_pAudioScratch = new unsigned int[2002*16];
		Fill50((unsigned short*)g_pAudioScratch, 1600, 2);
		g_pHancFrame = (BLUE_UINT8*)VirtualAlloc(NULL, 256*1024, MEM_COMMIT, PAGE_READWRITE);
		VirtualLock(g_pHancFrame, 256*1024);
	}

	if(bUseVanc)
	{
		nVancBufferSize = BlueVelvetVANCGoldenValue(nCardType, pArgs->VideoMode, MEM_FMT_BGRA, (pArgs->UpdateFormat == UPD_FMT_FRAME)?BLUE_DATA_FRAME:BLUE_DATA_FIELD1);
		g_pVancData = (BLUE_UINT8*)VirtualAlloc(NULL, nVancBufferSize, MEM_COMMIT, PAGE_READWRITE);
		VirtualLock(g_pVancData, nVancBufferSize);

		unsigned int PixelsPerLine = BlueVelvetLinePixels(pArgs->VideoMode);
		unsigned int VbiVancLineCount = BlueVelvetFrameLines(pArgs->VideoMode, pArgs->UpdateFormat);
		blue_init_vanc_buffer(nCardType, pArgs->VideoMode, PixelsPerLine, VbiVancLineCount, (UINT32*)g_pVancData);
	}

	if(pGpuDirectOut)
	{
		cout << "Entering loop...press any key to stop..." << endl;

		int iFramesToBuffer = 2;
		while(!g_bStopThread)
		{
			BOOL bDoHanc = TRUE;
			void* pAddress = NULL;
			unsigned long ulUnderrun = 0;
			unsigned long ulUniqueId = 0;

			if(BLUE_OK(pSDK->video_playback_allocate(&pAddress, BufferSelect, ulUnderrun)))
			{
				//select proper card buffer ID
				if(bUseAudio && bDoHanc && bUseVanc)
				{
					DMABufferIdVideo = BlueImage_VBI_HANC_DMABuffer(BufferSelect, BLUE_DATA_FRAME);
					DMABufferIdHanc = BlueImage_VBI_HANC_DMABuffer(BufferSelect, BLUE_DATA_HANC);
					DMABufferIdVanc = BlueImage_VBI_HANC_DMABuffer(BufferSelect, BLUE_DATA_VBI);
				}
				else if(bUseAudio && bDoHanc)
				{
					DMABufferIdVideo = BlueImage_HANC_DMABuffer(BufferSelect, BLUE_DATA_FRAME);
					DMABufferIdHanc = BlueImage_HANC_DMABuffer(BufferSelect, BLUE_DATA_HANC);
				}
				else if(bUseVanc)
				{
					DMABufferIdVideo = BlueImage_VBI_DMABuffer(BufferSelect, BLUE_DATA_FRAME);
					DMABufferIdVanc = BlueImage_VBI_DMABuffer(BufferSelect, BLUE_DATA_VBI);
				}
				else
					DMABufferIdVideo = BlueImage_DMABuffer(BufferSelect, BLUE_DATA_FRAME);

				GLuint glFrameTexOut = glOutputBuffers[nOglTexID];
				if(glFrameTexOut)
				{
					//HANC
					if(bUseAudio && bDoHanc)
					{
						if((pArgs->UpdateFormat == UPD_FMT_FIELD) && (FieldCount & 0x1) || (pArgs->UpdateFormat == UPD_FMT_FRAME))
							processAudioOutput(nCardType, g_pHancFrame, pArgs->VideoMode);

						pSDK->system_buffer_write_async((unsigned char*)g_pHancFrame,
															256*1024,
															NULL,
															DMABufferIdHanc,
															0);
					}

					//VANC
					if(bUseVanc)
					{
						pSDK->system_buffer_write_async((unsigned char*)g_pVancData,
															nVancBufferSize,
															NULL,
															DMABufferIdVanc,
															0);
					}

					//VIDEO
					draw_dummy_video(glFrameTexOut, glWindowBuffer);
					renderToWindow(glFrameTexOut);
					if(bfGpuDirect_TransferOutputFrameToSDI(pGpuDirectOut, DMABufferIdVideo, (void*)(&glOutputBuffers[nOglTexID])) != 0)
					{
						cout << __FUNCTION__ << ": Error in Transfer" << endl;
						g_bStopThread = true;
						break;
					}
				}
				else
				{
					cout << "No valid texture: "<< glFrameTexOut << endl;
					break;
				}

				if(bUseAudio && bDoHanc && bUseVanc)
					pSDK->video_playback_present(ulUniqueId, BlueBuffer_Image_VBI_HANC(BufferSelect), 1, 0);
				else if(bUseAudio && bDoHanc)
					pSDK->video_playback_present(ulUniqueId, BlueBuffer_Image_HANC(BufferSelect), 1, 0);
				else if(bUseVanc)
					pSDK->video_playback_present(ulUniqueId, BlueBuffer_Image_VBI(BufferSelect), 1, 0);
				else
					pSDK->video_playback_present(ulUniqueId, BlueBuffer_Image(BufferSelect), 1, 0);

				nOglTexID = (++nOglTexID)%NUMBER_OGL_TEXTURES;

				if(iFramesToBuffer)
				{
					iFramesToBuffer--;
					if(iFramesToBuffer == 0)
						pSDK->video_playback_start(0, 0);
				}
			}
			else
				pSDK->wait_output_video_synch(pArgs->UpdateFormat, FieldCount);
		}

		cout << "Stopping playback" << endl;
		pSDK->video_playback_stop(0, 0);
	}
	else
		cout << "Init failed!" << endl;

	if(g_pAudioScratch)
	{
		delete [] g_pAudioScratch;
		g_pAudioScratch = NULL;
	}

	if(g_pHancFrame)
	{
		VirtualUnlock(g_pHancFrame, 256*1024);
		VirtualFree(g_pHancFrame, 0, MEM_RELEASE);
		g_pHancFrame = NULL;
	}

	if(g_pVancData)
	{
		VirtualUnlock(g_pVancData, nVancBufferSize);
		VirtualFree(g_pVancData, 0, MEM_RELEASE);
		g_pHancFrame = NULL;
	}

	destroy_dummy_video_setup();
	CleanupGlBuffers(NUMBER_OGL_TEXTURES, glOutputBuffers);

	bfGpuDirect_Destroy(pGpuDirectOut);
	wglMakeCurrent(NULL, NULL);

	_endthreadex(0);
    return 0;
}

//Actual thread
unsigned int __stdcall PlaybackThreadFramestoreMode(void* pArg)
{
	ThreadArgs* pArgs = (ThreadArgs*)pArg;
	CBlueVelvet4* pSDK = pArgs->pSDK;

	unsigned int nCardType = (unsigned int)pSDK->has_video_cardtype();

	wglMakeCurrent(hDC, hGLRC);

	GLuint glOutputBuffers[NUMBER_OGL_TEXTURES];
	GLuint glWindowBuffer;

	GLuint tmp = glGetError();
	if(GL_NO_ERROR != tmp)
	{
		cout << "GL Error in FifoThread start: " << tmp << endl;
		return FALSE;
	}

	GLenum glType = GL_RGBA;

	switch(pArgs->MemoryFormat)
	{
		case MEM_FMT_BGRA:
		case MEM_FMT_RGBA:
			glType = GL_RGBA8;
			break;
		case MEM_FMT_BGR:
			glType = GL_RGB8;
			break;
		case MEM_FMT_BGR_16_16_16:
			glType = GL_RGB16;
			break;
		case MEM_FMT_BGRA_16_16_16_16:
			glType = GL_RGBA16;
			break;
		case MEM_FMT_CINEON_LITTLE_ENDIAN:
			glType = GL_RGB10;
			break;
		case MEM_FMT_YUVS:
		case MEM_FMT_2VUY:
			glType = GL_RGBA8;
			break;
		default:
			cout << "Not supported pixel format!" << endl;
			return 0;
	}

	if(!InitGlBuffers(NUMBER_OGL_TEXTURES, glOutputBuffers, glType) || !InitGlBuffers(1, &glWindowBuffer, GL_RGBA8))
	{
		cout << "Error initialising OpenGL buffers" << endl;
		return 0;
	}

	BLUE_GPUDIRECT_HANDLE pGpuDirectOut = bfGpuDirect_Init(1, pArgs->nVideoOutputChannel, NULL, GPUDIRECT_CONTEXT_TYPE_OPENGL, glOutputBuffers, NUMBER_OGL_TEXTURES, NUMBER_CHUNKS);
	if(!pGpuDirectOut)
	{
		cout << "Error initialising BlueGpuDirect" << endl;
		return 0;
	}
	int GpuDirectError = BGD_NO_ERROR;
	int GpuDirectLowLevelError = 0;
	GpuDirectError = bfGpuDirect_GetLastError(pGpuDirectOut, &GpuDirectLowLevelError);
	if(GpuDirectError != BGD_NO_ERROR)
	{
		cout << "Error initialising BlueGpuDirect: " << GpuDirectError << ", LowLevelError: " << GpuDirectLowLevelError << endl;
		return 0;
	}

	int bits = 8;
	if(pArgs->MemoryFormat == MEM_FMT_CINEON_LITTLE_ENDIAN)
		bits = 10;
	else if(pArgs->MemoryFormat == MEM_FMT_BGRA_16_16_16_16)
		bits = 16;
	init_dummy_video_setup(bits);

	unsigned long FieldCount = 0;
	unsigned long BufferSelect = 0;
	unsigned long DMABufferIdVideo = 0;
	unsigned long DMABufferIdHanc = 0;
	unsigned long DMABufferIdVanc = 0;
	unsigned int nOglTexID = 0;
	int nVancBufferSize = 0;
	BOOL bUseAudio = TRUE;
	BOOL bUseVanc = FALSE;

	if(bUseAudio)
	{
		g_pAudioScratch = new unsigned int[2002*16];
		Fill50((unsigned short*)g_pAudioScratch, 1600, 2);
		g_pHancFrame = (BLUE_UINT8*)VirtualAlloc(NULL, 256*1024, MEM_COMMIT, PAGE_READWRITE);
		VirtualLock(g_pHancFrame, 256*1024);
	}

	if(bUseVanc)
	{
		nVancBufferSize = BlueVelvetVANCGoldenValue(nCardType, pArgs->VideoMode, MEM_FMT_BGRA, (pArgs->UpdateFormat == UPD_FMT_FRAME)?BLUE_DATA_FRAME:BLUE_DATA_FIELD1);
		g_pVancData = (BLUE_UINT8*)VirtualAlloc(NULL, nVancBufferSize, MEM_COMMIT, PAGE_READWRITE);
		VirtualLock(g_pVancData, nVancBufferSize);

		unsigned int PixelsPerLine = BlueVelvetLinePixels(pArgs->VideoMode);
		unsigned int VbiVancLineCount = BlueVelvetFrameLines(pArgs->VideoMode, pArgs->UpdateFormat);
		blue_init_vanc_buffer(nCardType, pArgs->VideoMode, PixelsPerLine, VbiVancLineCount, (UINT32*)g_pVancData);
	}

	if(pGpuDirectOut)
	{
		cout << "Entering loop...press any key to stop..." << endl;

		//sync with card by waiting for the next video output interrupt
		pSDK->wait_output_video_synch(pArgs->UpdateFormat, FieldCount);
		if(pArgs->UpdateFormat == UPD_FMT_FIELD && !(FieldCount & 0x1))
			pSDK->wait_output_video_synch(pArgs->UpdateFormat, FieldCount);	//start on correct field

		while(!g_bStopThread)
		{
			BOOL bDoHanc = TRUE;
			if((pArgs->UpdateFormat == UPD_FMT_FIELD) && !(FieldCount & 0x1))
				bDoHanc = FALSE;

			//select proper card buffer ID
			if(bUseAudio && bDoHanc && bUseVanc)
			{
				DMABufferIdVideo = BlueImage_VBI_HANC_DMABuffer(BufferSelect, BLUE_DATA_FRAME);
				DMABufferIdHanc = BlueImage_VBI_HANC_DMABuffer(BufferSelect, BLUE_DATA_HANC);
				DMABufferIdVanc = BlueImage_VBI_HANC_DMABuffer(BufferSelect, BLUE_DATA_VBI);
			}
			else if(bUseAudio && bDoHanc)
			{
				DMABufferIdVideo = BlueImage_HANC_DMABuffer(BufferSelect, BLUE_DATA_FRAME);
				DMABufferIdHanc = BlueImage_HANC_DMABuffer(BufferSelect, BLUE_DATA_HANC);
			}
			else if(bUseVanc)
			{
				DMABufferIdVideo = BlueImage_VBI_DMABuffer(BufferSelect, BLUE_DATA_FRAME);
				DMABufferIdVanc = BlueImage_VBI_DMABuffer(BufferSelect, BLUE_DATA_VBI);
			}
			else
				DMABufferIdVideo = BlueImage_DMABuffer(BufferSelect, BLUE_DATA_FRAME);

			GLuint glFrameTexOut = glOutputBuffers[BufferSelect];
			if(glFrameTexOut)
			{
				//HANC
				if(bUseAudio && bDoHanc)
				{
					if((pArgs->UpdateFormat == UPD_FMT_FIELD) && (FieldCount & 0x1) || (pArgs->UpdateFormat == UPD_FMT_FRAME))
						processAudioOutput(nCardType, g_pHancFrame, pArgs->VideoMode);

					pSDK->system_buffer_write_async((unsigned char*)g_pHancFrame,
														256*1024,
														NULL,
														DMABufferIdHanc,
														0);
				}

				//VANC
				if(bUseVanc)
				{
					pSDK->system_buffer_write_async((unsigned char*)g_pVancData,
														nVancBufferSize,
														NULL,
														DMABufferIdVanc,
														0);
				}

				//VIDEO
				assert(bfGpuDirect_BeginProcessing(pGpuDirectOut, (void*)(&glFrameTexOut)) == 0);
				draw_dummy_video(glFrameTexOut, glWindowBuffer);
				renderToWindow(glFrameTexOut);
				assert(bfGpuDirect_EndProcessing(pGpuDirectOut, (void*)(&glFrameTexOut)) == 0);
				if(bfGpuDirect_TransferOutputFrameToSDI(pGpuDirectOut, DMABufferIdVideo, (void*)(&glFrameTexOut)) != 0)
				{
					cout << __FUNCTION__ << ": Error in Transfer" << endl;
					g_bStopThread = true;
					break;
				}
			}
			else
			{
				cout << "No valid texture: "<< glFrameTexOut << endl;
				break;
			}

			if(bUseAudio && bDoHanc && bUseVanc)
				pSDK->render_buffer_update(BlueBuffer_Image_VBI_HANC(BufferSelect));
			else if(bUseAudio && bDoHanc)
				pSDK->render_buffer_update(BlueBuffer_Image_HANC(BufferSelect));
			else if(bUseVanc)
				pSDK->render_buffer_update(BlueBuffer_Image_VBI(BufferSelect));
			else
				pSDK->render_buffer_update(BlueBuffer_Image(BufferSelect));

			//sync with card by waiting for the next video output interrupt
			unsigned long lastFieldCount = FieldCount;
			pSDK->wait_output_video_synch(pArgs->UpdateFormat, FieldCount);
			if(lastFieldCount + ((pArgs->UpdateFormat == UPD_FMT_FRAME)?2:1) < FieldCount)
			{
				int DroppedFrames = FieldCount - (lastFieldCount + ((pArgs->UpdateFormat == UPD_FMT_FRAME)?2:1));
				if(pArgs->UpdateFormat == UPD_FMT_FRAME)
					DroppedFrames /=2;
				cout << "Dropped Frames: " << DroppedFrames << endl;
			}
			BufferSelect = (++BufferSelect)%NUMBER_BF_CARD_BUFFERS;
			nOglTexID = (++nOglTexID)%NUMBER_OGL_TEXTURES;
		}

		//turn off audio
		pSDK->render_buffer_update(BlueBuffer_Image(BufferSelect));
		cout << "Stopping playback" << endl;
	}
	else
		cout << "Init failed!" << endl;

	if(g_pAudioScratch)
	{
		delete [] g_pAudioScratch;
		g_pAudioScratch = NULL;
	}

	if(g_pHancFrame)
	{
		VirtualUnlock(g_pHancFrame, 256*1024);
		VirtualFree(g_pHancFrame, 0, MEM_RELEASE);
		g_pHancFrame = NULL;
	}

	if(g_pVancData)
	{
		VirtualUnlock(g_pVancData, nVancBufferSize);
		VirtualFree(g_pVancData, 0, MEM_RELEASE);
		g_pHancFrame = NULL;
	}

	destroy_dummy_video_setup();
	CleanupGlBuffers(NUMBER_OGL_TEXTURES, glOutputBuffers);

	wglMakeCurrent(NULL, NULL);		//context needs to be made non-current before destroying the BlueGpuDirect instance
	bfGpuDirect_Destroy(pGpuDirectOut);

	_endthreadex(0);
    return 0;
}

int PlaybackFifoMode()
{
	EBlueVideoChannel nVideoOutputChannel;
	EVideoMode VideoMode = VID_FMT_1080I_6000;
	//EVideoMode VideoMode = VID_FMT_PAL;
	//EVideoMode VideoMode = VID_FMT_NTSC;
	EUpdateMethod UpdateFormat = UPD_FMT_FRAME;
	//EUpdateMethod UpdateFormat = UPD_FMT_FIELD;
	EMemoryFormat MemoryFormat = MEM_FMT_BGRA;
	int MemFmtSelection = 0;

	if(UpdateFormat == UPD_FMT_FIELD)
	{
		g_VideoHeight /= 2;
		g_WindowHeight /= 2;
	}

	printf("OGL BlueGpuDirect Playback Sample Application\n");
	printf("Select Video Output Channel :\n");
	printf("BLUE_VIDEO_OUTPUT_CHANNEL_A --> %d\n",BLUE_VIDEO_OUTPUT_CHANNEL_A);
	printf("BLUE_VIDEO_OUTPUT_CHANNEL_B --> %d\n",BLUE_VIDEO_OUTPUT_CHANNEL_B);
	scanf_s("%d", &nVideoOutputChannel);

	printf("Select Pixel Format:\n");
	printf("MEM_FMT_BGRA (1)\n");
	printf("MEM_FMT_RGBA (2)\n");
	printf("MEM_FMT_BGR (3)\n");
	printf("MEM_FMT_CINEON_LITTLE_ENDIAN (4)\n");
	scanf_s("%d", &MemFmtSelection);

	switch(MemFmtSelection)
	{
		case 1:
			MemoryFormat = MEM_FMT_BGRA;
			break;
		case 2:
			MemoryFormat = MEM_FMT_RGBA;
			break;
		case 3:
			MemoryFormat = MEM_FMT_BGR;
			break;
		case 4:
			MemoryFormat = MEM_FMT_CINEON_LITTLE_ENDIAN;
			break;
		default:
			cout << "Not supported pixel format!" << endl;
			return 0;
	}

	CBlueVelvet4* pSDKOut = NULL;
	pSDKOut = InitBluefish(1, nVideoOutputChannel, VideoMode, UpdateFormat, MemoryFormat, VIDEO_ENGINE_PLAYBACK);
	if(!pSDKOut)
	{
		cout << "Error initialising Bluefish card" << endl;
		return 0;
	}

	AdjustProcessWorkingSet();
	InitWindow();

	ThreadArgs args;
	args.pSDK = pSDKOut;
	args.nVideoOutputChannel = nVideoOutputChannel;
	args.VideoMode = VideoMode;
	args.UpdateFormat = UpdateFormat;
	args.MemoryFormat = MemoryFormat;

	wglMakeCurrent(NULL, NULL);

	unsigned int ThreadId = 0;
	g_hThread = (HANDLE)_beginthreadex(NULL, 0, &PlaybackThreadFifoMode, &args, CREATE_SUSPENDED, &ThreadId);
	if(!g_hThread)
	{
		cout << "Error starting thread" << endl;
		return 0;
	}
	g_bStopThread = FALSE;
 
	//Start thread
	ResumeThread(g_hThread);
 
	MSG uMsg;
	memset(&uMsg, 0, sizeof(uMsg));
	BOOL bSuccess = TRUE;
	while(bSuccess)
	{
		if(GetMessage(&uMsg, NULL, 0, 0))
		{
			TranslateMessage(&uMsg);
			DispatchMessage(&uMsg);
		}
		else
		{
			if(uMsg.message == WM_QUIT)
			{
				bSuccess = FALSE;
				cout << "Quitting..." << endl;
				break;
			}
		}
	}

	//Stopping the thread, if it's not stopped yet
	cout << "Stopping thread..." << endl;
	g_bStopThread = TRUE;
	DWORD dw = WaitForSingleObject(g_hThread, -1);

	CloseHandle(g_hThread);

	if(hGLRC)
	{
        wglMakeCurrent(hDC, hGLRC);
        ExitGL();
        wglMakeCurrent(NULL, NULL);
        wglDeleteContext(hGLRC);
    }

    ReleaseDC(hWnd, hDC);
	DestroyWindow(hWnd);

	pSDKOut->device_detach();
	BlueVelvetDestroy(pSDKOut);

	system("pause");
	return 0;
}

int PlaybackFramestoreMode()
{
	EBlueVideoChannel nVideoOutputChannel;
	EVideoMode VideoMode = VID_FMT_1080I_6000;
	//EVideoMode VideoMode = VID_FMT_PAL;
	//EVideoMode VideoMode = VID_FMT_NTSC;
	EUpdateMethod UpdateFormat = UPD_FMT_FRAME;
	//EUpdateMethod UpdateFormat = UPD_FMT_FIELD;
	EMemoryFormat MemoryFormat = MEM_FMT_BGRA;
	int MemFmtSelection = 0;

	if(UpdateFormat == UPD_FMT_FIELD)
	{
		g_VideoHeight /= 2;
		g_WindowHeight /= 2;
	}

	printf("OGL BlueGpuDirect Playback Sample Application\n");
	printf("Select Video Output Channel :\n");
	printf("BLUE_VIDEO_OUTPUT_CHANNEL_A --> %d\n",BLUE_VIDEO_OUTPUT_CHANNEL_A);
	printf("BLUE_VIDEO_OUTPUT_CHANNEL_B --> %d\n",BLUE_VIDEO_OUTPUT_CHANNEL_B);
	scanf_s("%d", &nVideoOutputChannel);

	printf("Select Pixel Format:\n");
	printf("MEM_FMT_BGRA (1)\n");
	printf("MEM_FMT_RGBA (2)\n");
	printf("MEM_FMT_BGR (3)\n");
	printf("MEM_FMT_BGR_16_16_16 (4)\n");
	printf("MEM_FMT_BGRA_16_16_16_16 (5)\n");
	printf("MEM_FMT_CINEON_LITTLE_ENDIAN (6)\n");
	printf("MEM_FMT_YUVS (7)\n");
	printf("MEM_FMT_2VUY (8)\n");
	scanf_s("%d", &MemFmtSelection);

	switch(MemFmtSelection)
	{
		case 1:
			MemoryFormat = MEM_FMT_BGRA;
			break;
		case 2:
			MemoryFormat = MEM_FMT_RGBA;
			break;
		case 3:
			MemoryFormat = MEM_FMT_BGR;
			break;
		case 4:
			MemoryFormat = MEM_FMT_BGR_16_16_16;
			break;
		case 5:
			MemoryFormat = MEM_FMT_BGRA_16_16_16_16;
			break;
		case 6:
			MemoryFormat = MEM_FMT_CINEON_LITTLE_ENDIAN;
			break;
		case 7:
			MemoryFormat = MEM_FMT_YUVS;
			break;
		case 8:
			MemoryFormat = MEM_FMT_2VUY;
			break;
		default:
			cout << "Not supported pixel format!" << endl;
			return 0;
	}

	CBlueVelvet4* pSDKOut = NULL;
	pSDKOut = InitBluefish(1, nVideoOutputChannel, VideoMode, UpdateFormat, MemoryFormat, VIDEO_ENGINE_FRAMESTORE);
	if(!pSDKOut)
	{
		cout << "Error initialising Bluefish card" << endl;
		return 0;
	}

	AdjustProcessWorkingSet();
	InitWindow();

	ThreadArgs args;
	args.pSDK = pSDKOut;
	args.nVideoOutputChannel = nVideoOutputChannel;
	args.VideoMode = VideoMode;
	args.UpdateFormat = UpdateFormat;
	args.MemoryFormat = MemoryFormat;

	wglMakeCurrent(NULL, NULL);

	unsigned int ThreadId = 0;
	g_hThread = (HANDLE)_beginthreadex(NULL, 0, &PlaybackThreadFramestoreMode, &args, CREATE_SUSPENDED, &ThreadId);
	if(!g_hThread)
	{
		cout << "Error starting thread" << endl;
		return 0;
	}
	g_bStopThread = FALSE;
 
	//Start thread
	ResumeThread(g_hThread);
 
	MSG uMsg;
	memset(&uMsg, 0, sizeof(uMsg));
	BOOL bSuccess = TRUE;
	while(bSuccess)
	{
		if(GetMessage(&uMsg, NULL, 0, 0))
		{
			TranslateMessage(&uMsg);
			DispatchMessage(&uMsg);
		}
		else
		{
			if(uMsg.message == WM_QUIT)
			{
				bSuccess = FALSE;
				cout << "Quitting..." << endl;
				break;
			}
		}
	}

	//Stopping the thread, if it's not stopped yet
	cout << "Stopping thread..." << endl;
	g_bStopThread = TRUE;
	DWORD dw = WaitForSingleObject(g_hThread, -1);

	CloseHandle(g_hThread);

	if(hGLRC)
	{
        wglMakeCurrent(hDC, hGLRC);
        ExitGL();
        wglMakeCurrent(NULL, NULL);
        wglDeleteContext(hGLRC);
    }

	ReleaseDC(hWnd, hDC);
	DestroyWindow(hWnd);

	pSDKOut->device_detach();
	BlueVelvetDestroy(pSDKOut);

	system("pause");
	return 0;
}

int main(int argc, char *argv[])
{
	//return PlaybackFramestoreMode();
	return PlaybackFifoMode();
}
