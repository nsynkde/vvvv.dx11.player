unsigned short sine_wave_const_50[]={	0x0000, 0x0197, 0x0327, 0x04AC, 0x061D, 0x0775,
										0x08B0, 0x09C7, 0x0AB7, 0x0B7B, 0x0C11, 0x0C77,
										0x0CAA, 0x0CAA, 0x0C77, 0x0C11, 0x0B7B, 0x0AB7,
										0x09C7, 0x08B0, 0x0775, 0x061D, 0x04AC, 0x0327,
										0x0197, 0x0000, 0xFE68, 0xFCD8, 0xFB53, 0xF9E2,
										0xF88A, 0xF74F, 0xF638, 0xF548, 0xF484, 0xF3EE,
										0xF388, 0xF355, 0xF355, 0xF388, 0xF3EE, 0xF484,
										0xF548, 0xF638, 0xF74F, 0xF88A, 0xF9E2, 0xFB53,
										0xFCD8, 0xFE68};


void Fill50(unsigned short* pAudio16, unsigned int Samples, unsigned int Channels)
{
	unsigned short data = 0;
	for(unsigned short i=0; i<Samples/50; i++)
	{
		for(unsigned short k=0; k<50; k++)
		{
			data = sine_wave_const_50[k];
			// 16 channels
			if(Channels > 0)  { *pAudio16 = data; pAudio16++; }
			if(Channels > 1)  { *pAudio16 = data; pAudio16++; }
			if(Channels > 2)  { *pAudio16 = data; pAudio16++; }
			if(Channels > 3)  { *pAudio16 = data; pAudio16++; }
			if(Channels > 4)  { *pAudio16 = data; pAudio16++; }
			if(Channels > 5)  { *pAudio16 = data; pAudio16++; }
			if(Channels > 6)  { *pAudio16 = data; pAudio16++; }
			if(Channels > 7)  { *pAudio16 = data; pAudio16++; }
			if(Channels > 8)  { *pAudio16 = data; pAudio16++; }
			if(Channels > 9)  { *pAudio16 = data; pAudio16++; }
			if(Channels > 10) { *pAudio16 = data; pAudio16++; }
			if(Channels > 11) { *pAudio16 = data; pAudio16++; }
			if(Channels > 12) { *pAudio16 = data; pAudio16++; }
			if(Channels > 13) { *pAudio16 = data; pAudio16++; }
			if(Channels > 14) { *pAudio16 = data; pAudio16++; }
			if(Channels > 15) { *pAudio16 = data; pAudio16++; }
		}
	}
}
