// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	BlueGpuDirectCaptureDX9
// Written by:			Tim Bragulla
// Date:				10 October 2012
//
// Brief description:	This sample application shows how to use the NVIDIA GpuDirect feature to cut down the latency caused by
//						memory transfers between the graphics card, system memory and the Bluefish card
//						This application captures SDI video and processes the frame on the graphics card before rendering in a desktop window
//
// Supported hardware:	NVIDIA Quadro 4000, NVIDIA Quadro 5000 and NVIDIA Quadro 6000
//						Bluefish Epoch and SuperNova cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):				must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_GPUDIRECT_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//
//		32 bit libraries:		BlueGpuDirect.dll		ships with Bluefish's BlueGpuDirect package; available upon request
//								dvp.dll					ships with Bluefish's BlueGpuDirect package; available upon request
//
//		64 bit libraries:		BlueGpuDirect64.dll		ships with Bluefish's BlueGpuDirect package; available upon request
//								dvp.dll					ships with Bluefish's BlueGpuDirect package; available upon request
//

#include <windows.h>
#include <conio.h>

#include <mmsystem.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <atlstr.h>

#include <math.h>
#include <assert.h>

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "BlueVelvet4.h"
#include "BlueHancUtils.h"
#include "BlueGpuDirect.h"


using namespace std;


int g_WindowWidth	= 1280;
int g_WindowHeight	= 720;
int g_VideoWidth	= 1920;
int g_VideoHeight	= 1080;

#define NUMBER_DX_TEXTURES 2		//any number of textures; however, the more textures the more RAM will be used as well!
#define NUMBER_BF_CARD_BUFFERS 3	//3 minimum, but for especially for HD modes not more than 4
#define NUMBER_CHUNKS 4				//split the video frames into chunks for interleaved DMA

unsigned int* g_pAudioScratch;
BLUE_UINT8* g_pHancFrame;
BLUE_UINT8* g_pVancData;

//#define USE_BUFFER	//this uses a slower vertex buffer

class BlueTimer
{
private:
	LARGE_INTEGER m_liStartTime;
	LARGE_INTEGER m_liEndTime;
	LARGE_INTEGER m_liFrequency;
public:
	BlueTimer() {	m_liStartTime.QuadPart = 0LL;
					m_liEndTime.QuadPart = 0LL;
					QueryPerformanceFrequency(&m_liFrequency);
					QueryPerformanceCounter(&m_liEndTime);
				};
	double GetTime() {	m_liStartTime = m_liEndTime;
						QueryPerformanceCounter(&m_liEndTime);
						if(!m_liFrequency.QuadPart)
							return 0.0;
						return (double)( (m_liEndTime.QuadPart - m_liStartTime.QuadPart)* (double)1000.0/(double)m_liFrequency.QuadPart );
					};
};


HWND                    g_hWnd                  = NULL;
LPDIRECT3D9             g_pD3D                  = NULL;
LPDIRECT3DDEVICE9       g_pd3dDevice            = NULL;
LPDIRECT3DVERTEXBUFFER9 g_pVertexBuffer         = NULL;
LPDIRECT3DTEXTURE9      g_pVidTex               = NULL;
LPDIRECT3DTEXTURE9      g_pSysmemTex            = NULL;
LPDIRECT3DVERTEXBUFFER9 g_pQuadVertexBuffer     = NULL;
LPDIRECT3DTEXTURE9      g_pTextureNVIDIA        = NULL;
LPDIRECT3DTEXTURE9		g_pTextureQUADRO        = NULL;
LPD3DXFONT				g_pStatsFont            = NULL;
BOOL                    g_bIsD3D9Ex             = FALSE;
BOOL                    g_bNoShareHandlesOnWDDM = FALSE;
BOOL					g_bDone                 = FALSE;	

//int bufferStride = g_VideoWidth*4;
//int size = bufferStride*g_VideoHeight;

#ifdef USE_BUFFER
LPDIRECT3DVERTEXBUFFER9  g_renderTargetTexture[NUMBER_DX_TEXTURES];
IDirect3DVertexBuffer9* g_renderTargetTextureOutput;
#else
IDirect3DTexture9*	g_renderTargetTexture[NUMBER_DX_TEXTURES];
IDirect3DTexture9*	g_renderTargetTextureOutput;
#endif

#define D3DFVF_CUSTOMVERTEX ( D3DFVF_XYZ | D3DFVF_TEX1 )

struct Vertex
{
    float x, y, z;
    float tu, tv;
};

Vertex g_cubeVertices[] =
{
	{-1.0f, 1.0f,-1.0f,  0.0f,0.0f },
	{ 1.0f, 1.0f,-1.0f,  1.0f,0.0f },
	{-1.0f,-1.0f,-1.0f,  0.0f,1.0f },
	{ 1.0f,-1.0f,-1.0f,  1.0f,1.0f },
	
	{-1.0f, 1.0f, 1.0f,  1.0f,0.0f },
	{-1.0f,-1.0f, 1.0f,  1.0f,1.0f },
	{ 1.0f, 1.0f, 1.0f,  0.0f,0.0f },
	{ 1.0f,-1.0f, 1.0f,  0.0f,1.0f },
	
	{-1.0f, 1.0f, 1.0f,  0.0f,0.0f },
	{ 1.0f, 1.0f, 1.0f,  1.0f,0.0f },
	{-1.0f, 1.0f,-1.0f,  0.0f,1.0f },
	{ 1.0f, 1.0f,-1.0f,  1.0f,1.0f },
	
	{-1.0f,-1.0f, 1.0f,  0.0f,0.0f },
	{-1.0f,-1.0f,-1.0f,  1.0f,0.0f },
	{ 1.0f,-1.0f, 1.0f,  0.0f,1.0f },
	{ 1.0f,-1.0f,-1.0f,  1.0f,1.0f },

	{ 1.0f, 1.0f,-1.0f,  0.0f,0.0f },
	{ 1.0f, 1.0f, 1.0f,  1.0f,0.0f },
	{ 1.0f,-1.0f,-1.0f,  0.0f,1.0f },
	{ 1.0f,-1.0f, 1.0f,  1.0f,1.0f },
	
	{-1.0f, 1.0f,-1.0f,  1.0f,0.0f },
	{-1.0f,-1.0f,-1.0f,  1.0f,1.0f },
	{-1.0f, 1.0f, 1.0f,  0.0f,0.0f },
	{-1.0f,-1.0f, 1.0f,  0.0f,1.0f }
};

Vertex g_quadVertices[] = 
{
#if 1
	{-1.0f, 1.0f,-1.0f,  1.0f, 1.0f },
	{ 1.0f, 1.0f,-1.0f,  0.0f, 1.0f },
	{-1.0f,-1.0f,-1.0f,  1.0f, 0.0f },
	{ 1.0f,-1.0f,-1.0f,  0.0f, 0.0f }
#else
	{-1.0f, 1.0f,-1.0f,  0.0f,0.0f },
	{ 1.0f, 1.0f,-1.0f,  1.0f,0.0f },
	{-1.0f,-1.0f,-1.0f,  0.0f,1.0f },
	{ 1.0f,-1.0f,-1.0f,  1.0f,1.0f }
#endif
};


#define SAFE_RELEASE(x) if(x){ (x)->Release(); (x) = NULL; }


void AdjustProcessWorkingSet()
{
	// Increase the process working set size to allow pinning of more memory.
    static SIZE_T  dwMin = 0, dwMax = 0;
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA, FALSE, GetCurrentProcessId());

    if(!hProcess)
    {
        printf( "OpenProcess failed (%d)\n", GetLastError() );
    }

    // Retrieve the working set size of the process.
    if (!dwMin && !GetProcessWorkingSetSize(hProcess, &dwMin, &dwMax))
    {
        printf("GetProcessWorkingSetSize failed (%d)\n",
            GetLastError());
    }

	int size = g_VideoWidth*g_VideoHeight*4;
	BOOL res = SetProcessWorkingSetSize(hProcess, size*NUMBER_BF_CARD_BUFFERS*4 + dwMin, size*NUMBER_BF_CARD_BUFFERS*4 + (dwMax-dwMin));
	if(!res)
		printf("SetProcessWorkingSetSize failed (%d)\n", GetLastError());

    CloseHandle(hProcess);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch( msg )
	{	
        case WM_KEYDOWN:
		{
			switch( wParam )
			{
				case VK_ESCAPE:
					DestroyWindow(hWnd);
					return 0;
			}
		}
        break;

		case WM_SIZE:
		{
			RECT rect;
			GetClientRect(hWnd, &rect);

			// Initialize projection matrix.
			D3DXMATRIX matProj;
			D3DXMatrixPerspectiveFovLH( &matProj, D3DXToRadian( 45.0f ), 
                                        (float)(rect.right - rect.left) / (float)(rect.bottom - rect.top), 
		   					             0.1f, 100.0f );
			g_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );
			return 0;
		}
		break;

		case WM_DESTROY:
		{
			g_bDone = TRUE;	
			PostQuitMessage(0);
			return 0;
		}

		break;
	}

	return DefWindowProc( hWnd, msg, wParam, lParam );
}

wchar_t* g_className = L"Bluefish GpuDirect DX class";
void InitWindow(void)
{
    WNDCLASSEX wndClass;
    HINSTANCE hInstance = GetModuleHandle(NULL);
    RECT rect;
	DWORD dwStyle = WS_OVERLAPPED | WS_CAPTION | WS_CLIPCHILDREN | WS_CLIPSIBLINGS;
	DWORD dwExStyle = 0;

    /* Define and register the window class */
	memset(&wndClass, 0, sizeof(WNDCLASSEX));
	wndClass.cbSize = sizeof(WNDCLASSEX);
    wndClass.lpfnWndProc = WndProc;
    wndClass.cbClsExtra = 0;
    wndClass.cbWndExtra = 0;
    wndClass.hInstance = hInstance,
    wndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
    wndClass.hbrBackground = NULL;
    wndClass.lpszMenuName = NULL;
    wndClass.lpszClassName = g_className;

    RegisterClassEx(&wndClass);

    /* Figure out a default size for the window */
    SetRect(&rect, 0, 0, g_WindowWidth, g_WindowHeight);
    //AdjustWindowRect(&rect, dwStyle, FALSE);
	AdjustWindowRectEx(&rect, dwStyle, FALSE, dwExStyle);
	SIZE size;
	size.cx = rect.right - rect.left;
	size.cy = rect.bottom - rect.top;
    /* Create a window of the previously defined class */
    g_hWnd = CreateWindow(	g_className,
							L"GPUDirect for Video with Directx Hello World",
							dwStyle,
							0,
							0,
							size.cx,
							size.cy,
							GetDesktopWindow(),
							NULL,
							hInstance,
							NULL);
	ShowWindow(g_hWnd, SW_SHOW);
}

HRESULT loadTexture( void )	
{
    // Use D3DX to create textures from a file based images
    if( FAILED( D3DXCreateTextureFromFile( g_pd3dDevice, L"NVLogo_3D.png", &g_pTextureNVIDIA ) ) )
    {
		MessageBox( NULL, L"Could not find NVLogo_3D.png", L"dx9sdi.exe", MB_OK );
        return E_FAIL;
    }

	g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

	return S_OK;
}

unsigned int *defBuf;
unsigned int *tmpBuf, *tmpBuf2;
unsigned int gtmpBufSize;

static void InitDefaultBuffers()
{
	gtmpBufSize = g_VideoWidth*g_VideoHeight*4;
    defBuf = (unsigned int *)VirtualAlloc( NULL, gtmpBufSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE );
	VirtualLock(defBuf, gtmpBufSize);
    tmpBuf = (unsigned int *)VirtualAlloc( NULL, gtmpBufSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE );
	VirtualLock(tmpBuf, gtmpBufSize);
    tmpBuf2 = (unsigned int *)VirtualAlloc( NULL, gtmpBufSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE );
	VirtualLock(tmpBuf2, gtmpBufSize);
    for ( int j = 0; j < g_VideoWidth; j++)
        for ( int k = 0; k < g_VideoHeight; k++)
        {
            if (j > 0.666*g_VideoWidth)
                defBuf[k*g_VideoWidth+j] = 0x00ff0000;
            else if (j > 0.3333*g_VideoWidth)
                defBuf[k*g_VideoWidth+j] = 0x0000ff00;
            else 
                defBuf[k*g_VideoWidth+j] = 0x000000ff;
            //defBuf[j] = 0x0000ffff;
        }
}

static void FreeDefaultBuffers()
{
	VirtualUnlock(defBuf, gtmpBufSize);
	VirtualUnlock(tmpBuf, gtmpBufSize);
	VirtualUnlock(tmpBuf2, gtmpBufSize);

    VirtualFree(defBuf, 0, MEM_RELEASE);
    VirtualFree(tmpBuf, 0, MEM_RELEASE);
    VirtualFree(tmpBuf2, 0, MEM_RELEASE);
}

bool initBuffers()
{
    InitDefaultBuffers();

	// Create 2D texture for video data from buffer
#ifdef USE_BUFFER
	g_pd3dDevice->CreateTexture(g_VideoWidth, g_VideoHeight, 1, D3DUSAGE_DYNAMIC, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &g_pVidTex, NULL);
	g_pd3dDevice->CreateTexture(g_VideoWidth, g_VideoHeight, 1, D3DUSAGE_DYNAMIC, D3DFMT_X8R8G8B8, D3DPOOL_SYSTEMMEM, &g_pSysmemTex, (HANDLE*)&tmpBuf);
#endif
	
	for (unsigned int j=0; j<NUMBER_DX_TEXTURES; j++)
    {
		// Create the render target texture.            
		if (!g_renderTargetTexture[j])
		{

#ifdef USE_BUFFER
			g_pd3dDevice->CreateVertexBuffer(g_VideoWidth * g_VideoHeight * 4, D3DUSAGE_DYNAMIC, NULL, D3DPOOL_DEFAULT, &g_renderTargetTexture[j], NULL);
#else
			g_pd3dDevice->CreateTexture(g_VideoWidth, g_VideoHeight, 0, D3DUSAGE_RENDERTARGET, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &g_renderTargetTexture[j], NULL);
#endif
		}
    }

#ifdef USE_BUFFER
	g_pd3dDevice->CreateVertexBuffer(g_VideoWidth * g_VideoHeight * 4, D3DUSAGE_DYNAMIC, NULL, D3DPOOL_DEFAULT, &g_renderTargetTextureOutput, NULL);
#else
	g_pd3dDevice->CreateTexture(g_VideoWidth, g_VideoHeight, 0, D3DUSAGE_RENDERTARGET, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &g_renderTargetTextureOutput, NULL);
#endif

    return true;
}

void cleanupBuffers()
{
	for(unsigned int j=0; j<NUMBER_DX_TEXTURES; j++)
	{
		if (g_renderTargetTexture[j])
		{
			ULONG ref = g_renderTargetTexture[j]->Release();
			g_renderTargetTexture[j] = NULL;
		}
	}

	if(g_renderTargetTextureOutput)
		g_renderTargetTextureOutput->Release();
	g_renderTargetTextureOutput = NULL;

#ifdef USE_BUFFER
	SAFE_RELEASE(g_pVidTex);
	SAFE_RELEASE(g_pSysmemTex);
#endif

    FreeDefaultBuffers();
}

void InitDX()
{
    HRESULT hr = E_FAIL;
    HMODULE libHandle = NULL;

	// Load the d3d9.dll library
    libHandle = LoadLibrary(L"d3d9.dll");
    if (libHandle != NULL)
	{
		typedef HRESULT (WINAPI *LPDIRECT3DCREATE9EX)(UINT, IDirect3D9Ex **);
		LPDIRECT3DCREATE9EX Direct3DCreate9ExPtr = NULL;

		// On Vista/Win7 use D3DCreate9Ex().
		Direct3DCreate9ExPtr = (LPDIRECT3DCREATE9EX) GetProcAddress(libHandle, "Direct3DCreate9Ex");
		if (Direct3DCreate9ExPtr)
		{
			hr = Direct3DCreate9ExPtr(D3D_SDK_VERSION, (IDirect3D9Ex **)&g_pD3D);
			if (hr == S_OK && g_pD3D != NULL) {
				g_bIsD3D9Ex = TRUE;
			}
		}
	}

	if (!g_bIsD3D9Ex)
	{
		g_pD3D = Direct3DCreate9(D3D_SDK_VERSION);
		if (g_pD3D == NULL)
		{
			MessageBox(NULL, L"Failed Direct3DCreate9. DX9 is not supported", L"Error", MB_OK);
			exit(1);
		}
	}

	// Get size of window client rectangle.
	RECT rect;
	GetClientRect(g_hWnd, &rect);

    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.BackBufferCount = 1;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.BackBufferWidth = rect.right - rect.left; 
    d3dpp.BackBufferHeight = rect.bottom - rect.top; 
    //d3dpp.BackBufferFormat = D3DFMT_A8R8G8B8;
	d3dpp.BackBufferFormat = D3DFMT_X8R8G8B8;
	d3dpp.hDeviceWindow = g_hWnd;
	d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_ONE;
    d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE;

    g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, g_hWnd,
                          D3DCREATE_HARDWARE_VERTEXPROCESSING | D3DCREATE_PUREDEVICE,
                          &d3dpp, &g_pd3dDevice );

	// Load textures
	if (FAILED(loadTexture()))
	{
		MessageBox(g_hWnd, L"Could not load texture data", NULL, MB_OK);
		exit(1);
	}

	// Create vertext buffer for rotating cube
	g_pd3dDevice->CreateVertexBuffer(24*sizeof(Vertex), 0, D3DFVF_CUSTOMVERTEX, D3DPOOL_DEFAULT, &g_pVertexBuffer, NULL);
	void* pVertices = NULL;

    g_pVertexBuffer->Lock( 0, sizeof(g_cubeVertices), (void**)&pVertices, 0 );
    memcpy( pVertices, g_cubeVertices, sizeof(g_cubeVertices) );
    g_pVertexBuffer->Unlock();

	// Create vertex buffer for video input background
	g_pd3dDevice->CreateVertexBuffer( 4*sizeof(Vertex),0, D3DFVF_CUSTOMVERTEX, D3DPOOL_DEFAULT, &g_pQuadVertexBuffer, NULL );
	void* pQuadVertices = NULL;

    g_pQuadVertexBuffer->Lock( 0, sizeof(g_quadVertices), (void**)&pQuadVertices, 0 );
    memcpy( pQuadVertices, g_quadVertices, sizeof(g_quadVertices) );
    g_pQuadVertexBuffer->Unlock();

	// Set render state.  Disable lighting.  Enable depth test.
    g_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
	//TIM removed:
    //g_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );

	// Initialize font for onscreen statistics display.
    D3DXCreateFont( g_pd3dDevice, 15, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET,
                    OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
					L"Arial", &g_pStatsFont );

	// Initialize buffers for GPU Direct for Video transfers.
	initBuffers();
}

void shutDown( void )
{
	// Cleanup GPU Direct for Video transfer buffers
	cleanupBuffers();

	SAFE_RELEASE(g_pStatsFont);
	SAFE_RELEASE(g_pTextureNVIDIA);
	SAFE_RELEASE(g_pTextureQUADRO);
	SAFE_RELEASE(g_pVertexBuffer);
	SAFE_RELEASE(g_pQuadVertexBuffer);
	SAFE_RELEASE(g_pd3dDevice);
	SAFE_RELEASE(g_pD3D);
}

BOOL IsInputChannel(EBlueVideoChannel VideoChannel)
{
	if(VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_A ||
		VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_B ||
		VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_C ||
		VideoChannel == BLUE_VIDEO_INPUT_CHANNEL_D)
		return TRUE;

	return FALSE;
}

BOOL IsOutputChannel(EBlueVideoChannel VideoChannel)
{
	if(VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_A ||
		VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_B ||
		VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_C ||
		VideoChannel == BLUE_VIDEO_OUTPUT_CHANNEL_D)
		return TRUE;

	return FALSE;
}

CBlueVelvet4* InitBluefish(int CardId, EBlueVideoChannel VideoChannel, EUpdateMethod UpdFmt)
{
	CBlueVelvet4* pSDK = NULL;
	EMemoryFormat MemFmt = MEM_FMT_BGRA;
	//EMemoryFormat MemFmt = MEM_FMT_RGBA;
	EVideoMode VideoMode = VID_FMT_1080I_6000;

	int iDevices = 0;
	VARIANT varVal;

	pSDK = BlueVelvetFactory4();
	pSDK->device_enumerate(iDevices);

	if(iDevices > 0 && CardId <= iDevices)
		pSDK->device_attach(CardId, 0);
	else
	{
		BlueVelvetDestroy(pSDK);
		return NULL;
	}

	varVal.vt = VT_UI4;
	if(IsInputChannel(VideoChannel))
	{
		pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

		//Get VID_FMT_INVALID flag; this enum has changed over time and might be different depending on which driver this application runs on
		pSDK->QueryCardProperty(INVALID_VIDEO_MODE_FLAG, varVal);
		ULONG InvalidVideoModeFlag = varVal.ulVal;

		//Check if we have a valid input signal
		ULONG FieldCount = 0;
		pSDK->wait_input_video_synch(UPD_FMT_FRAME, FieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
		pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
		if(varVal.ulVal >= InvalidVideoModeFlag)
		{
			cout << "No valid input signal on channel A" << endl;
			system("pause");
			exit(0);
		}
		VideoMode = (EVideoMode)varVal.ulVal;

		varVal.ulVal = MemFmt;
		pSDK->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);

		varVal.ulVal = UpdFmt;
		pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);

		g_VideoWidth = BlueVelvetLinePixels(VideoMode);
		g_VideoHeight = BlueVelvetFrameLines(VideoMode, UpdFmt);

		varVal.ulVal = VIDEO_ENGINE_FRAMESTORE;
		pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);

		varVal.ulVal = BLUE_AUDIO_EMBEDDED;
		pSDK->SetCardProperty(AUDIO_INPUT_PROP, varVal);
	}
	else
	{
		cout << "Wrong channel: " << VideoChannel << endl;
		pSDK->device_detach();
		BlueVelvetDestroy(pSDK);
		return NULL;
	}

	return pSDK;
}

#ifdef USE_BUFFER
void render(IDirect3DVertexBuffer9* dxTexture)
#else
void render(IDirect3DTexture9* dxTexture)
#endif
{
	if(!g_renderTargetTextureOutput)
		return;

	IDirect3DSurface9* pTextureSurface;

#ifdef USE_BUFFER
	LPDIRECT3DTEXTURE9  pRendTex = NULL;
	g_pd3dDevice->CreateTexture(g_VideoWidth, g_VideoHeight, 0, D3DUSAGE_RENDERTARGET, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &pRendTex, NULL);
	pRendTex->GetSurfaceLevel(0, &pTextureSurface);
#else
	g_renderTargetTextureOutput->GetSurfaceLevel(0, &pTextureSurface);
#endif

	// Render to video output device buffer
	g_pd3dDevice->SetRenderTarget(0, pTextureSurface);

	if (SUCCEEDED(g_pd3dDevice->BeginScene()))
	{
		if (!SUCCEEDED(g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_COLORVALUE(0.5f, 0.5f, 0.5f, 1.0f), 1.0f, 0 )))
		{
				std::cout << "Clear of Render Target Failed" << std::endl;
		}

		D3DXMATRIX matProj;
		D3DXMATRIX matWorld;
		D3DXMATRIX matTrans;
		D3DXMATRIX matRot;
		D3DXMATRIX matScale;
		D3DXMATRIX matIdent;

		// Get size of window client rectangle.
		RECT rect;
		GetClientRect(g_hWnd, &rect);

		// Draw video input background

		// Set orthographic projection
		D3DXMatrixOrthoLH( &matProj, -2.0f, -2.0f, -1.0f, 1.0f );
        g_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );
		D3DXMatrixIdentity(&matIdent);
		g_pd3dDevice->SetTransform( D3DTS_WORLD, &matIdent );
		g_pd3dDevice->SetTransform( D3DTS_VIEW, &matIdent );

		g_pd3dDevice->SetStreamSource( 0, g_pQuadVertexBuffer, 0, sizeof(Vertex) );
		g_pd3dDevice->SetFVF( D3DFVF_CUSTOMVERTEX );
#ifdef USE_BUFFER
		HRESULT hr;

		// Get pointer to input video data in vertex buffer
		void *indata = NULL;
		hr = dxTexture->Lock( 0, 0, (void **)&indata, D3DLOCK_READONLY );

		// Get pointer to texture in system memory
		D3DLOCKED_RECT lockedRect;
		hr = g_pSysmemTex->LockRect(0,&lockedRect, NULL, D3DLOCK_DISCARD);

		// Copy input video data into system memory texture
		memcpy(lockedRect.pBits, indata, g_VideoWidth*g_VideoHeight*4);
	
		// Unlock system memory texture
		hr = g_pSysmemTex->UnlockRect(0);

		// Unlock input video data buffer
		hr = dxTexture->Unlock();
				
		// Update video memory texture
		g_pd3dDevice->UpdateTexture(g_pSysmemTex, g_pVidTex);

		g_pd3dDevice->SetTexture( 0, g_pVidTex );
#else
		HRESULT hr = g_pd3dDevice->SetTexture( 0, dxTexture );
		//g_pd3dDevice->SetTexture( 0, g_pTextureNVIDIA );
#endif
		g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP,  0, 2 );

		// Set perspective project
		D3DXMatrixPerspectiveFovLH( &matProj, D3DXToRadian( 45.0f ), (float)(rect.right - rect.left) / (float)(rect.bottom - rect.top), 0.1f, 100.0f );
        g_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );

		// Draw rotating cube.
		static double fXrot = 0.0f;
		static double fYrot = 0.0f;
		static double fZrot = 0.0f;

		/*fXrot += (10.1f * g_dElapsedTime);
		fYrot += (10.2f * g_dElapsedTime);
		fZrot += (10.3f * g_dElapsedTime);*/

		fXrot += (10.1f * 0.01f);
		fYrot += (10.2f * 0.01f);
		fZrot += (10.3f * 0.01f);
	
		//std::cout << "xrot: " << fXrot << " yrot: " << fYrot << " zrot: " << fZrot << std::endl;  

		D3DXMatrixTranslation( &matTrans, 0.0f, 0.0f, 5.0f );

		D3DXMatrixRotationYawPitchRoll( &matRot, 
			                            D3DXToRadian(fXrot), 
				                        D3DXToRadian(fYrot), 
					                    D3DXToRadian(fZrot) );

		matWorld = matRot * matTrans;
		g_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );

		g_pd3dDevice->SetStreamSource( 0, g_pVertexBuffer, 0, sizeof(Vertex) );
		g_pd3dDevice->SetFVF( D3DFVF_CUSTOMVERTEX );

		// Top
		//g_pd3dDevice->SetTexture( 0, dxTexture );
		g_pd3dDevice->SetTexture( 0, g_pTextureNVIDIA );
		
		g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP,  0, 2 );

		// Bottom
		g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP,  4, 2 );

		g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP,  8, 2 );

		g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 12, 2 );

		g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 16, 2 );

		g_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 20, 2 );

		g_pd3dDevice->EndScene();

	} else
	{
		std::cout << "BeginScene Failed." << std::endl;
	}

	// Blit to back buffer
	LPDIRECT3DSURFACE9 pBackBuffer = NULL;

	if (g_pd3dDevice->GetBackBuffer( 0, 0, D3DBACKBUFFER_TYPE_MONO, &pBackBuffer ) == S_OK )
	{
		g_pd3dDevice->SetRenderTarget(0, pBackBuffer);

		g_pd3dDevice->StretchRect(pTextureSurface, NULL, pBackBuffer, NULL, D3DTEXF_LINEAR);

		// Annotate
		if( SUCCEEDED( g_pd3dDevice->BeginScene() ) )
		{
			// Draw frame count.
			static UINT l_uiFrameCount = 0;
			RECT rc;
			wstring strFrameCount;
			wstringstream ss;

			// Display frame count
			ss << l_uiFrameCount;
			ss >> strFrameCount;
			l_uiFrameCount++;
			SetRect( &rc, 2, 15, 0, 0 );
#ifdef USE_BUFFER
			strFrameCount.append(L" (Buffer)");
#else
			strFrameCount.append(L" (Texture)");
#endif
			g_pStatsFont->DrawText( NULL, strFrameCount.c_str(), -1, &rc, DT_NOCLIP, D3DXCOLOR( 1.0f, 1.0f, 0.0f, 1.0f ) );

			g_pd3dDevice->EndScene();
		}
		else
		{
			std::cout << "BeginScene Failed." << std::endl;
		}
	}

    IDirect3DSwapChain9* pSwapChain;
    g_pd3dDevice->GetSwapChain(0, &pSwapChain);
    HRESULT hr;

    while ((hr = pSwapChain->Present(NULL, NULL, NULL, NULL, D3DPRESENT_DONOTWAIT)) == D3DERR_WASSTILLDRAWING)
    {
        SwitchToThread();
    }

#ifdef USE_BUFFER
	SAFE_RELEASE(pRendTex);
#endif
	SAFE_RELEASE(pSwapChain);
	SAFE_RELEASE(pBackBuffer);
	SAFE_RELEASE(pTextureSurface);
}

int main(int argc, char *argv[])
{
	EBlueVideoChannel nVideoInputChannel;
	EUpdateMethod UpdateFormat = UPD_FMT_FRAME;
	//EUpdateMethod UpdateFormat = UPD_FMT_FIELD;

	if(UpdateFormat == UPD_FMT_FIELD)
	{
		g_VideoHeight /= 2;
		g_WindowHeight /= 2;
	}

	printf("DirectX BlueGpuDirect Capture Sample Application\n");
	printf("Select Video Input Channel :\n");
	printf("BLUE_VIDEO_INPUT_CHANNEL_A --> %d\n",BLUE_VIDEO_INPUT_CHANNEL_A);
	printf("BLUE_VIDEO_INPUT_CHANNEL_B --> %d\n",BLUE_VIDEO_INPUT_CHANNEL_B);
	scanf_s("%d", &nVideoInputChannel);

	CBlueVelvet4* pSDKIn = NULL;
	pSDKIn = InitBluefish(1, nVideoInputChannel, UpdateFormat);
	if(!pSDKIn)
	{
		cout << "Error initialising Bluefish card" << endl;
		return 0;
	}
	unsigned int nCardType = (unsigned int)pSDKIn->has_video_cardtype();
	VARIANT varVal;
	varVal.vt = VT_UI4;
	unsigned int VideoMode = pSDKIn->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);

	AdjustProcessWorkingSet();
	InitWindow();

	InitDX();
	UpdateWindow(g_hWnd);

	BLUE_GPUDIRECT_HANDLE pGpuDirectIn = NULL;
#ifdef USE_BUFFER
	pGpuDirectIn = bfGpuDirect_Init(1, nVideoInputChannel, g_pd3dDevice, GPUDIRECT_CONTEXT_TYPE_DX9, g_renderTargetTexture, NUMBER_DX_TEXTURES, NUMBER_CHUNKS, GPUDIRECT_TEXTURE_TYPE_BUFFER);
	if(!pGpuDirectOut)
	{
		cout << "Error initialising BlueGpuDirect" << endl;
		return 0;
	}
	int GpuDirectError = BGD_NO_ERROR;
	int GpuDirectLowLevelError = 0;
	GpuDirectError = bfGpuDirect_GetLastError(pGpuDirectOut, &GpuDirectLowLevelError);
	if(GpuDirectError != BGD_NO_ERROR)
	{
		cout << "Error initialising BlueGpuDirect: " << GpuDirectError << ", LowLevelError: " << GpuDirectLowLevelError << endl;
		return 0;
	}
#else
	pGpuDirectIn = bfGpuDirect_Init(1, nVideoInputChannel, g_pd3dDevice, GPUDIRECT_CONTEXT_TYPE_DX9, g_renderTargetTexture, NUMBER_DX_TEXTURES, NUMBER_CHUNKS, GPUDIRECT_TEXTURE_TYPE_TEXTURE);
	if(!pGpuDirectIn)
	{
		cout << "Error initialising BlueGpuDirect" << endl;
		return 0;
	}
	int GpuDirectError = BGD_NO_ERROR;
	int GpuDirectLowLevelError = 0;
	GpuDirectError = bfGpuDirect_GetLastError(pGpuDirectIn, &GpuDirectLowLevelError);
	if(GpuDirectError != BGD_NO_ERROR)
	{
		cout << "Error initialising BlueGpuDirect: " << GpuDirectError << ", LowLevelError: " << GpuDirectLowLevelError << endl;
		return 0;
	}
#endif

	unsigned long FieldCount = 0;
	unsigned long LastFieldCount = 0;
	unsigned long ScheduleID = 0;
	unsigned long CapturingID = 0;
	unsigned long DoneID = 0;
	unsigned long BufferSelect = 0;
	unsigned long DMABufferIdVideo = 0;
	unsigned long DMABufferIdHanc = 0;
	unsigned long DMABufferIdVanc = 0;
	unsigned int nDXTexID = 0;

	BlueTimer bm;
	double dTime1 = 0.0;
	double dTime2 = 0.0;

    if(pGpuDirectIn)
	{
		//sync with card by waiting for the next video output interrupt
		pSDKIn->wait_input_video_synch(UpdateFormat, FieldCount);
		if(UpdateFormat == UPD_FMT_FIELD && !(FieldCount & 0x1))
			pSDKIn->wait_input_video_synch(UpdateFormat, FieldCount);	//start on correct field

		pSDKIn->wait_input_video_synch(UpdateFormat, FieldCount);	//this call just synchronises us to the card
		pSDKIn->render_buffer_capture(BlueBuffer_Image_VBI_HANC(ScheduleID), 0);
		CapturingID = ScheduleID;
		ScheduleID = (++ScheduleID % NUMBER_BF_CARD_BUFFERS);
		LastFieldCount = FieldCount;

		pSDKIn->wait_input_video_synch(UpdateFormat, FieldCount);	//the first buffer starts to be captured now; this is it's field count
		pSDKIn->render_buffer_capture(BlueBuffer_Image(ScheduleID), 0);
		DoneID = CapturingID;
		CapturingID = ScheduleID;
		ScheduleID = (++ScheduleID % NUMBER_BF_CARD_BUFFERS);
		LastFieldCount = FieldCount;

		cout << "Entering loop...press any key to stop..." << endl;
		BOOL bSuccess = TRUE;
		while(bSuccess)
		{
			//we shouldn't be processing the message pump in the same thread that we handle the video processing as it stalls our real time processing
			MSG uMsg;
			while(PeekMessage(&uMsg, NULL, 0, 0, PM_NOREMOVE) == TRUE)
			{ 
				if(GetMessage(&uMsg, NULL, 0, 0) )
				{ 
					TranslateMessage(&uMsg); 
					DispatchMessage(&uMsg);
				}
				else
				{ 
					bSuccess = FALSE;
					break;
				} 
			}

			pSDKIn->wait_input_video_synch(UpdateFormat, FieldCount);
			pSDKIn->render_buffer_capture(BlueBuffer_Image_VBI_HANC(ScheduleID), 0);

			bm.GetTime();
			//transfer the video frame from the Bluefish card to the GPU's memory
			if(bfGpuDirect_TransferInputFrameToGPU(pGpuDirectIn, BlueImage_DMABuffer(DoneID, BLUE_DATA_FRAME), (void*)(g_renderTargetTexture[nDXTexID])) != 0)
			{
				cout << __FUNCTION__ << ": Error in Transfer" << endl;
				break;
			}
			
			dTime1 = bm.GetTime();

			render(g_renderTargetTexture[nDXTexID]);
			dTime2 = bm.GetTime();
		
			//in field mode we get a whole HANC frame every second field
			//processAudioInput(nCardType, g_pHancFrame);

			if(LastFieldCount + ((UpdateFormat == UPD_FMT_FRAME)?2:1) < FieldCount)
			{
				int DroppedFrames = FieldCount - (LastFieldCount + ((UpdateFormat == UPD_FMT_FRAME)?2:1));
				if(UpdateFormat == UPD_FMT_FRAME)
					DroppedFrames /=2;
				cout << "Dropped Frames: " << DroppedFrames << endl;
			}

			DoneID = CapturingID;
			CapturingID = ScheduleID;
			ScheduleID = (++ScheduleID % NUMBER_BF_CARD_BUFFERS);
			LastFieldCount = FieldCount;

			nDXTexID = (++nDXTexID % NUMBER_DX_TEXTURES);

			cout << "DMA: " << (float)dTime1 << ", Render: " << (float)dTime2 << endl;
		}
	}
	else
		cout << "Init failed!" << endl;

	bfGpuDirect_Destroy(pGpuDirectIn);

	shutDown();

	DestroyWindow(g_hWnd);

	pSDKIn->device_detach();
	BlueVelvetDestroy(pSDKIn);

	system("pause");
	return 0;
}
