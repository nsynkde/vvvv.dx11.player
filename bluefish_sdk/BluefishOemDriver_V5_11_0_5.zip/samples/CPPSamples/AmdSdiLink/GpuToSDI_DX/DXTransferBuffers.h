#pragma once



class DXTransferBuffers
{
public:

    DXTransferBuffers(void);
    ~DXTransferBuffers(void);

    // Creates synchronized buffers.
    bool createBuffers(unsigned int uiNumBuffers, unsigned int uiBufferSize);
    bool assignRemoteMemory(unsigned int uiNumBuffers, unsigned long long* pBufferBusAddress, unsigned long long* pMarkerBusAddress);

    void   waitMarker(unsigned int uiMarkerValue);
    void   writeMarker(unsigned long long ulBufferBusAddress, unsigned long long ulMarkerBusAddress, unsigned int uiMarkerValue);

    // In case of bus addressable memory, returns the bus address of the buffer memory used by
    // the buffer with id:  uiIdx
    unsigned long long  getBufferBusAddress(unsigned int uiIdx);
    // In case of bus addressable memory, returns a pointer to the array that contains the buffer
    // bus addresses. The array length is m_uiNumBuffers
    unsigned long long*  getBufferBusAddresses()        { return m_pBufferBusAddress; };
    // In case of bus addressable memory, returns the bus address of the marker memory used by
    // the buffer with id:  uiIdx
    unsigned long long  getMarkerBusAddress(unsigned int uiIdx);
    // In case of bus addressable memory, returns a pointer to the array that contains the marker
    // bus addresses. The array length is m_uiNumBuffers
    unsigned long long*  getMarkerBusAddresses()        { return m_pMarkerBusAddress; };

    unsigned int         getNumBuffers()                { return m_uiNumBuffers; };

private:
    bool                    m_bBufferReady;
    unsigned int            m_uiNumBuffers;
    unsigned int            m_uiBufferSize;
    unsigned int            m_uiBufferIdx;
    unsigned int*           m_pBuffer;

 /*   AlignedMem*             m_pBufferMemory;*/
    unsigned long long*     m_pBufferBusAddress;
    unsigned long long*     m_pMarkerBusAddress;
};
