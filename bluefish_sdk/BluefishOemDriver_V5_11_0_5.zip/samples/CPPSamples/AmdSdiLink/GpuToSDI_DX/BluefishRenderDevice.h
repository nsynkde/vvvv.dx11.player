#include <Windows.h>
#include <iostream>
#include <BlueVelvet4.h>
#include "SyncedBuffer.h"
#include "defines.h"


class CBlueRenderDevice
{
public:
	CBlueRenderDevice(int iDevNumber, unsigned int nVideoChannel);
	~CBlueRenderDevice();

	BOOL Init(unsigned int VideoMode);
	unsigned long long* getBufferBusAddress()   { return m_n64DataBusAddress; };
    unsigned long long* getMarkerBusAddress()   { return m_n64MarkerAddress; };
	void setSyncBuffer(SyncedBuffer* pSyncBuffer);
	SyncedBuffer* getSyncBuffer() { return (SyncedBuffer*) m_pSyncBuffer; };

	void RenderVideoFrame();
	unsigned int WaitForOutputClock();

public:
	CBlueVelvet4*	m_pSDK;
	int				m_iDevices;
	int				m_iDevNumber;
	unsigned int	m_nVideoChannel;
	unsigned int	m_nVideoMode;
	unsigned int	m_nUpdateFormat;
	unsigned int	m_nMemoryFormat;
	unsigned int	m_nFrameSize;
	unsigned int	m_nBytesPerLine;
	unsigned int	m_nBytesPerFrame;
	unsigned int	m_nPixelsPerLine;
	unsigned long	m_ulLastFieldCount;
	unsigned long	m_ulCurrentFieldCount;
	unsigned long	m_ulBufferID;

	int				m_iDroppedFields;
	int				m_iDroppedFrames;

	unsigned __int64 m_n64DataBusAddress[2];
	unsigned __int64 m_n64MarkerAddress[2];
	unsigned int	m_nCurrentBufferNumber;

	FrameData*		m_pFrameData;
	SyncedBuffer*	m_pSyncBuffer;
};

class BlueTimer
{
private:
	LARGE_INTEGER m_liStartTime;
	LARGE_INTEGER m_liEndTime;
	LARGE_INTEGER m_liFrequency;
public:
	void Init() {	m_liStartTime.QuadPart = 0LL;
					m_liEndTime.QuadPart = 0LL;
					QueryPerformanceFrequency(&m_liFrequency);
					QueryPerformanceCounter(&m_liEndTime);
				};
	double GetTime() {	m_liStartTime = m_liEndTime;
						QueryPerformanceCounter(&m_liEndTime);
						if(!m_liFrequency.QuadPart)
							return 0.0;
						return (double)( (m_liEndTime.QuadPart - m_liStartTime.QuadPart)* (double)1000.0/(double)m_liFrequency.QuadPart );
					};
};
