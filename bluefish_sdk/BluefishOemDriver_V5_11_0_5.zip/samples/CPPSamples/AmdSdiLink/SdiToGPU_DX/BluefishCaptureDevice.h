
#include <Windows.h>
#include <iostream>
#include <BlueVelvet4.h>

#include "SyncedBuffer.h"
#include "defines.h"


class CBlueCaptureDevice
{
public:
	CBlueCaptureDevice();
	~CBlueCaptureDevice();

	BOOL Init();
	bool setRemoteMemory(unsigned __int64* pBusAddress, unsigned __int64* pMarker);
	void setSyncBuffer(SyncedBuffer* pSyncBuffer);
	SyncedBuffer* getSyncBuffer() { return (SyncedBuffer*) m_pSyncBuffer; };

	unsigned int WaitForInputClock();
	void ScheduleCapture();
	void TransferCapturedVideoFrame();

public:
	CBlueVelvet4*	m_pSDK;
	int				m_iDevices;
	unsigned int	m_nVideoEngine;
	unsigned int	m_nVideoMode;
	unsigned int	m_nUpdateFormat;
	unsigned int	m_nMemoryFormat;
	unsigned int	m_nFrameSize;
	unsigned int	m_nBytesPerLine;
	unsigned int	m_nBytesPerFrame;
	unsigned int	m_nPixelsPerLine;
	unsigned long	m_ulLastFieldCount;
	unsigned long	m_ulCurrentFieldCount;
	unsigned long	m_ulBufferID;

	int				m_iDroppedFields;
	int				m_iDroppedFrames;

	unsigned long	m_ScheduleID;
	unsigned long	m_CapturingID;
	unsigned long	m_DoneID;

	//AMD SDI Link related
	unsigned __int64 m_ui64BusAddress[2];
	unsigned __int64 m_ui64Marker[2];
	unsigned int	m_nCurrentBuffer;

	SyncedBuffer*	m_pSyncBuffer;
};

class BlueTimer
{
private:
	LARGE_INTEGER m_liStartTime;
	LARGE_INTEGER m_liEndTime;
	LARGE_INTEGER m_liFrequency;
public:
	void Init() {	m_liStartTime.QuadPart = 0LL;
					m_liEndTime.QuadPart = 0LL;
					QueryPerformanceFrequency(&m_liFrequency);
					QueryPerformanceCounter(&m_liEndTime);
				};
	double GetTime() {	m_liStartTime = m_liEndTime;
						QueryPerformanceCounter(&m_liEndTime);
						if(!m_liFrequency.QuadPart)
							return 0.0;
						return (double)( (m_liEndTime.QuadPart - m_liStartTime.QuadPart)* (double)1000.0/(double)m_liFrequency.QuadPart );
					};
};
