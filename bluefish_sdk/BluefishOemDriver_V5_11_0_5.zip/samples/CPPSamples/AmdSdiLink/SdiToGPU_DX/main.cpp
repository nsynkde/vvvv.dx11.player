// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	SdiToGPU_DX
// Written by:			Tim Bragulla
// Date:				25 October 2012
//
// Brief description:	This sample application shows how to DMA video frames straight from the Bluefish card to the AMD FirePro V7900 SDI card
//						without going through system memory by using the AMD SDI Link feature 
//
// Further information:	Please see the following application notes:
//						- AN_AMD_SDI_Link_Support.pdf
//						- AMD_SDI_Link.txt
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//						AMD FirePro V7900 SDI card
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include <windows.h>
#include <string>
#include <iostream>
// For adding console
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
// end adding console

#include "d3d9.h"
#include "DXWindow.h"
#include "DXSink.h"
#include "SDIHelper.h"
#include "BluefishCaptureDevice.h"

using namespace std;

// Size of the frames
unsigned int g_uiWidth  = 1280;
unsigned int g_uiHeight =  720;


typedef struct
{
    bool        bRunning;               // Indicates that the thread is running
    bool        bResizeSource;          // if true, the source window was resized
    bool        bResizeSink;            // if true, the sink window was resized
    DXWindow*   pSinkWin;				// Pointer to the sink window
	DXSink*		pSink;	                // DirectX Sink
	CBlueCaptureDevice* pBlue;			// CBlueCaptureDevice produces frames for DirectX Sink
} ThreadData;

ThreadData* g_pThreadData = NULL;

HANDLE  g_hSinkReady;
HANDLE  g_hSourceReady;
HANDLE  g_hSourceDone;


LRESULT CALLBACK    WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);


DWORD WINAPI SourceThreadFunc(LPVOID lpArgs)
{
    ThreadData* pThreadData = (ThreadData*)lpArgs;
	DXWindow*   pMyWin      = NULL;

	if (!pThreadData || !pThreadData->pSinkWin || !pThreadData->pBlue)
    {
        ReleaseSemaphore(g_hSourceDone, 1, 0);
        return 0;
    }

	BlueTimer bm;
	int bmFrameCount = 0;
	bm.Init();
	double dTimeDelta;
	double dMax = 0.0;
	double dMin = 999999.0;
	double dSum = 0.0;

	CBlueCaptureDevice* pBlue = pThreadData->pBlue;
	unsigned int nBufferNumber = 1;
	bool bRenderInFieldMode = (pThreadData->pBlue->m_nUpdateFormat == UPD_FMT_FIELD);

    // The CBlueRenderDevice class that is created will allocate the buffers
    // the source needs to wait until the Sink is created and initialized.
    if (WaitForSingleObject(g_hSinkReady, THREAD_WAIT_TIMEOUT) == WAIT_TIMEOUT)
    {
        ReleaseSemaphore(g_hSourceDone, 1, 0);
        PostMessage(g_pThreadData->pSinkWin->getWnd(), WM_QUIT, 0, 0);
        return 0;
    }

    // Get input buffer of Sink, this buffer will be used to synchonize
    // Sink and source
    SyncedBuffer* pBuffer = g_pThreadData->pSink->getInputBuffer();
    if(!pBuffer)
    {
        ReleaseSemaphore(g_hSourceDone, 1, 0);
        PostMessage(g_pThreadData->pSinkWin->getWnd(), WM_QUIT, 0, 0);
        return 0;
    }

    // Now the buffers on sink GPU are created and the addresses can be obtained
	unsigned long long* pBufferBusAddress = pThreadData->pSink->getBufferBusAddress();
	unsigned long long* pMarkerBusAddress = pThreadData->pSink->getMarkerBusAddress();

	// Pass the bus addresses of the buffer on the remote device to my local data source
	if (!pBuffer || !pBlue->setRemoteMemory(pBufferBusAddress, pMarkerBusAddress))
	{
		cout << __FUNCTION__ << ": Error setting remote memory" << endl;
		g_pThreadData->bRunning = false;
	}

	// Set the input buffer of the Sink as output buffer of the Source
	// This is just a synchonization object to control when a given buffer object can be reused
	pBlue->setSyncBuffer(pBuffer);
	ReleaseSemaphore(g_hSourceReady, 1, 0);
	
	//Prolog for capturing
	//Step 1
	pBlue->WaitForInputClock();	//synch with the card
	pBlue->ScheduleCapture();		//schedule to capture a video frame

	//Step 2
	pBlue->WaitForInputClock();	//the first buffer starts to be captured now; this is it's field count; will be available at the next interrupt
	pBlue->ScheduleCapture();		//schedule the next frame to be captured

	cout << "Entering loop..." << endl;
	//start in synch with the video input interrupt; in FIELD mode we have to wait for the field 2 interrupt
	unsigned int FieldCount = pBlue->WaitForInputClock();
	if(pBlue->m_nUpdateFormat == UPD_FMT_FIELD && !(FieldCount & 0x1))
		pBlue->WaitForInputClock();

	while(g_pThreadData->bRunning)
	{
		pBlue->ScheduleCapture();				//schedule the next frame to be captured
		
		bm.GetTime();
		pBlue->TransferCapturedVideoFrame();	//DMA video frame that was scheduled for capture at step 1 above
		dTimeDelta = bm.GetTime();
		nBufferNumber++;
		
		bmFrameCount++;
		if(dTimeDelta > dMax) dMax = dTimeDelta;
		if(dTimeDelta < dMin) dMin = dTimeDelta;
		dSum += dTimeDelta;
		if(bmFrameCount >= 100)
		{
			cout << "Avg: " << (float)(dSum/bmFrameCount) << ", Min: " << (float)(dMin) << ", Max: " << (float)(dMax) <<
				", Fi " << pBlue->m_iDroppedFields << ", Fr " << pBlue->m_iDroppedFrames << endl;
			bmFrameCount = 0;
			dSum = 0.0;
			dMax = 0.0;
			dMin = 999999.0;
		}

		pBlue->WaitForInputClock();
	}

	cout << __FUNCTION__ << ": ...Exiting thread" << endl;
	g_pThreadData->bRunning = false;

    // If createUpStream failed, make sure that the Sink does not stay blocked
    ReleaseSemaphore(g_hSourceReady, 1, 0);

    // Indicate that the Source is done and does no longer need the
    // input buffer of the sink.
    ReleaseSemaphore(g_hSourceDone, 1, 0);

    return 0;
}

DWORD WINAPI SinkThreadFunc(LPVOID lpArgs)
{
    ThreadData* pThreadData = (ThreadData*)lpArgs;

    if(!pThreadData || !pThreadData->pBlue)
        return 0;

	BlueTimer bm;
	int bmFrameCount = 0;
	bm.Init();
	double dTimeDelta;
	double dMax = 0.0;
	double dMin = 999999.0;
	double dSum = 0.0;

	DXWindow* pMyWin = NULL;

	if (!pThreadData || !pThreadData->pBlue)
        return 0;

    pMyWin = pThreadData->pSinkWin;

	DXSink* pSink = pThreadData->pSink;
    pSink->resize(g_uiWidth, g_uiHeight);
    
    // Create bus addressable buffer on the GPU that the GLSink is running. This buffer will
    // be used as destination buffer for the frames produced by GLSource
    if (pSink->createDownStream(g_uiWidth, g_uiHeight, 2))
    {
        ReleaseSemaphore(g_hSinkReady, 1, NULL);

        // Wait until Source thread is initialized
        if (WaitForSingleObject(g_hSourceReady, THREAD_WAIT_TIMEOUT) == WAIT_TIMEOUT)
        {
			cout << __FUNCTION__ << ": Timeout wait source ready" << endl;
            g_pThreadData->bRunning = false;
        }
        
        while (g_pThreadData->bRunning)
        {
            // Resize only affects the window and viewport size. The received frames
            // are not affected they are still g_uiWidth x g_uiHeight.
            if (pThreadData->bResizeSink)
            {
                pSink->resize(pMyWin->getWidth(), pMyWin->getHeight());
                g_pThreadData->bResizeSink = false;
            }

            // Copies the data out of the bus addressable memory buffer into a 
            // texture object and draws a quad with this texture mapped
            pSink->draw();
        }   
    }

    g_pThreadData->bRunning = false;
	pSink->release();

    // Since the Souce is using the input buffer of the Sink as output buffer
    // the Sink can only be deleted once the Source is done.
    WaitForSingleObject(g_hSourceDone, INFINITE);

    // Make sure WinMain is not blocked in GetMessage
    PostMessage(g_pThreadData->pSinkWin->getWnd(), WM_QUIT, 0, 0);
    delete pSink;

	return 0;
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nShowCmd)
{
	WNDCLASSEX      wndclass;
    const LPCSTR    cClassName  = "DirectX";
    const LPCSTR    cWindowName = "BLUEFISH SDI to GPU DX P2P Copy";

    // Register WindowClass
    wndclass.cbSize         = sizeof(WNDCLASSEX);
    wndclass.style          = CS_OWNDC;
    wndclass.lpfnWndProc    = WndProc;
    wndclass.cbClsExtra     = 0;
    wndclass.cbWndExtra     = 0;
    wndclass.hInstance      = (HINSTANCE)GetModuleHandle(NULL);
    wndclass.hIcon          = LoadIcon(NULL, IDI_APPLICATION); 
    wndclass.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wndclass.hbrBackground  = NULL;
    wndclass.lpszMenuName   = NULL;
    wndclass.lpszClassName  = cClassName;
    wndclass.hIconSm        = LoadIcon(NULL, IDI_APPLICATION);

    if (!RegisterClassEx(&wndclass))
        return WM_QUIT;

	//Create console for stdout:
	if(AllocConsole())
	{
		HANDLE handle_out = GetStdHandle(STD_OUTPUT_HANDLE);
		int hCrt = _open_osfhandle((long)handle_out, _O_TEXT);
		FILE* hf_out = _fdopen(hCrt, "w");
		setvbuf(hf_out, NULL, _IONBF, 1);
		*stdout = *hf_out;

		HANDLE handle_in = GetStdHandle(STD_INPUT_HANDLE);
		hCrt = _open_osfhandle((long) handle_in, _O_TEXT);
		FILE* hf_in = _fdopen(hCrt, "r");
		setvbuf(hf_in, NULL, _IONBF, 128);
		*stdin = *hf_in;
	}

	DXWindow* pSinkWin = new DXWindow("DX Sink", cClassName);
	CBlueCaptureDevice* pBlue = new CBlueCaptureDevice();

	if(!pBlue->Init())
    {
		cout << "Error on Bluedevice init" << endl;
		system("pause");
		return 0;
    }

	if(!pSinkWin->init())
	{
        MessageBox(NULL, "Could not init Window", cWindowName, MB_ICONERROR | MB_OK);
        return WM_QUIT;
	}

	if(pSinkWin->getNumDisplaysOnGPU(0) == 0)
    {
        MessageBox(NULL, "GPU does not have a Display mapped!", cWindowName, MB_ICONERROR | MB_OK);
        return WM_QUIT;
    }

    // Create window on first Dsiplay of GPU 0
    unsigned int uiDsp = pSinkWin->getDisplayOnGPU(0, 0);
    
    pSinkWin->create(g_uiWidth, g_uiHeight, uiDsp);
    pSinkWin->open();

	DXSink* pSink = new DXSink;
	pSink->initDX(pSinkWin->getWnd());

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	g_pThreadData = new ThreadData;
    g_pThreadData->bRunning      = true;
    g_pThreadData->bResizeSink   = false;
    g_pThreadData->bResizeSource = false;
    g_pThreadData->pSinkWin      = pSinkWin;
	g_pThreadData->pBlue         = pBlue;
	g_pThreadData->pSink		 = pSink;

	// Create semaphore to indicate that the init of the Sink is ready
    g_hSinkReady   = CreateSemaphore(NULL, 0, 1, NULL);
    // Create semaphore to indicate that the init of the source is done
    g_hSourceReady = CreateSemaphore(NULL, 0, 1, NULL);
    // Create semaphore to indicate that the Source has terminated
    g_hSourceDone  = CreateSemaphore(NULL, 0, 1, NULL);

	DWORD dwSourceThreadId;
    DWORD dwSinkThreadId;

    HANDLE hSourceThread = CreateThread(NULL, 0, SourceThreadFunc, g_pThreadData,   0, &dwSourceThreadId);
    HANDLE hSinkThread   = CreateThread(NULL, 0, SinkThreadFunc,   g_pThreadData,   0, &dwSinkThreadId);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Run message loop
    MSG Msg;
    while(GetMessage(&Msg, NULL, 0, 0))
    {
	    TranslateMessage(&Msg);
		DispatchMessage(&Msg);
    }

	g_pThreadData->bRunning = false;

    WaitForSingleObject(hSourceThread, INFINITE);
    WaitForSingleObject(hSinkThread,   INFINITE);

	delete pSinkWin;
	delete pBlue;

	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    static int nLastx = 0;
    static int nLasty = 0;

    switch (uMsg)
    {
        char c;

        case WM_CHAR:
            c = (char)wParam;

            switch (c)
            {
            case VK_ESCAPE:
                PostQuitMessage(0);
		        break;
            }
            return 0;

        case WM_CREATE:
            return 0;

        case WM_SIZE:
            return 0;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
