#pragma once


#include "d3d9.h"
#include "amddx9extsdi.h"
#include "defines.h"


class SyncedBuffer;


#define D3DFVF_CUSTOMVERTEX ( D3DFVF_XYZ | D3DFVF_TEX1 )

struct Vertex
{
    float x, y, z;
    float tu, tv;
};


class DXSink
{
public:

    DXSink();
    ~DXSink();

    BOOL            initDX(HWND hWnd);
    void            resize(unsigned int w, unsigned int h);
    bool            createDownStream(unsigned int w, unsigned int h, unsigned int NumBuffers);

	unsigned long long* getBufferBusAddress();
    unsigned long long* getMarkerBusAddress();

    void            draw();
	void			FlushAndWaitForGPUIdle();

    void            release();

	SyncedBuffer*   getInputBuffer() { return m_pSyncBuffer; };

private:
	LPDIRECT3D9				m_pD3D;
	LPDIRECT3DDEVICE9		m_pd3dDevice;
	D3DPRESENT_PARAMETERS	m_d3dpp;

	HWND					m_hWnd;
	LPDIRECT3DQUERY9        m_pEventQuery;

	LPDIRECT3DVERTEXDECLARATION9 m_pVDecl1;
	LPDIRECT3DVERTEXSHADER9      m_pVS1;
	LPDIRECT3DPIXELSHADER9       m_pPS1;

	LPDIRECT3DSURFACE9           m_pRTSurf1;
	LPDIRECT3DTEXTURE9           m_pTexAMDLogo;


	LPDIRECT3DVERTEXBUFFER9 m_pVertexBuffer;
	LPDIRECT3DVERTEXBUFFER9 m_pQuadVertexBuffer;

	PAMDDX9SDISURFACEATTRIBUTES m_pAttribGfx;
	LPDIRECT3DTEXTURE9*		m_ppTexGfx;

	PAMDDX9SDISURFACEATTRIBUTES m_pAttribBlue;
	LPDIRECT3DTEXTURE9*		m_ppTexBlue;

	ULONG64*     m_pBufferBusAddress;
    ULONG64*     m_pMarkerBusAddress;

    unsigned int            m_uiWindowWidth;
    unsigned int            m_uiWindowHeight;

    unsigned int            m_uiBufferWidth;
    unsigned int            m_uiBufferHeight;

    unsigned int            m_uiCube;

    float                   m_fRotationAngle;

    SyncedBuffer*   m_pSyncBuffer;
	FrameData*		m_pFrameData;
};
