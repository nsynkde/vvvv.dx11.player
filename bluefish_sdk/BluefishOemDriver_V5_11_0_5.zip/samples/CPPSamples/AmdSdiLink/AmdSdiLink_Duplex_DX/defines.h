#pragma once


#define OneSecond 1000*1000*1000L

#define NUM_BUFFERS 2
//#define THREAD_WAIT_TIMEOUT 5000
#define THREAD_WAIT_TIMEOUT 15000
