#include <windows.h>
#include <iostream>
#include "FifoBuffer.h"
#include "DXProcess.h"
#include "SDIHelper.h"
#include "defines.h"


using namespace std;


extern unsigned int g_uiWidth;
extern unsigned int g_uiHeight;
DWORD g_ColorCnt = 0;

extern CFifoBuffer	g_FifoCapture;
extern CFifoBuffer	g_FifoRender;
extern BlueLock g_DmaLock;


void ErrorMessage_MessageBox(HRESULT hr)
{
	MessageBoxA(NULL,"error","Information_",NULL);
}

#define TEST_FAIL_ERROR(x) { hr=x; if(hr!=S_OK) { ErrorMessage_MessageBox(hr); } }

typedef struct _VtxStruct
{
    FLOAT x, y;
    FLOAT tu, tv;
} VtxStruct;

D3DVERTEXELEMENT9 g_vtxDecl[] = 
{
    {0,  0,  D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_DEFAULT,    D3DDECLUSAGE_POSITION, 0},
    {0,  8,  D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_DEFAULT,    D3DDECLUSAGE_TEXCOORD, 0},
    D3DDECL_END() 
};

char g_strVS[] =
"vs_3_0\n"
"def c0, 1, 0, 0, 0\n"
"dcl_position v0\n"
"dcl_texcoord v1\n"
"dcl_position o0\n"
"dcl_texcoord o1.xy\n"
"mov o0.xy, v0\n" 
"mov o0.zw, c0.yx\n"
"mov o1.xy, v1\n";

char g_strPS[] =
"ps_3_0\n"
"dcl_texcoord0 v0.xy\n" 
"dcl_2d s0\n"
"texld oC0, v0, s0\n";

VtxStruct g_vtxData1[] =
{
    { -0.95f, -0.95f, 0, 1},
    { -0.95f,  0.95f, 0, 0},
    {  0.95f,  0.95f, 1, 0},
    {  0.95f, -0.95f, 1, 1},
};

VtxStruct g_vtxData2[] =
{
    { -0.95f, -0.95f, 0, 1},
    { -0.95f, -0.60f, 0, 0},
    { -0.75f, -0.60f, 1, 0},
    { -0.75f, -0.95f, 1, 1},
};

USHORT g_idxData[] =
{
    0, 1, 2, 0, 2, 3,
};

DXProcess::DXProcess() :
	m_pD3D(NULL),
	m_pd3dDevice(NULL),
	m_pAttribGfx(NULL),
	m_ppTexGfx(NULL),
	m_pAttribBlue(NULL),
	m_ppTexBlue(NULL),
	m_pEventQuery(NULL),
	m_pVDecl1(NULL),
	m_pVS1(NULL),
	m_pPS1(NULL),
	m_pTexAMDLogo(NULL),
	m_pRTSurf1(NULL),
	m_pBufferBusAddress(NULL),
    m_pMarkerBusAddress(NULL),
	m_bIsProcessing(FALSE)
{
    m_uiWindowWidth  = 0;
    m_uiWindowHeight = 0;

    m_uiBufferWidth  = 0;
    m_uiBufferHeight = 0;

    m_fRotationAngle = 0.0f;

	m_ppTexBlue = new LPDIRECT3DTEXTURE9[2];
	m_ppTexGfx = new LPDIRECT3DTEXTURE9[2];

	m_pAttribGfx = new AMDDX9SDISURFACEATTRIBUTES[2];
	m_pAttribBlue = new AMDDX9SDISURFACEATTRIBUTES[2];

	m_pBufferBusAddress = new ULONG64[2];
	m_pMarkerBusAddress = new ULONG64[2];
}

DXProcess::~DXProcess()
{
	if(m_pAttribGfx)
		delete [] m_pAttribGfx;
	if(m_pAttribBlue)
		delete [] m_pAttribBlue;
	if(m_ppTexGfx)
		delete [] m_ppTexGfx;
	if(m_ppTexBlue)
		delete [] m_ppTexBlue;

	if(m_pEventQuery)
		m_pEventQuery->Release();

	delete [] m_pBufferBusAddress;
	delete [] m_pMarkerBusAddress;
}

BOOL DXProcess::initDX(HWND hWnd)
{	
	HRESULT hr;

	m_hWnd = hWnd;

	//CREATE DX INSTANCE
	if(NULL == (m_pD3D = Direct3DCreate9( D3D_SDK_VERSION)))
	{
		MessageBox(NULL, "No DirectX support!", "Error", MB_OK);
		return FALSE;
	}

	ZeroMemory(&m_d3dpp, sizeof(m_d3dpp));
	m_d3dpp.Windowed = TRUE;
	m_d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	m_d3dpp.BackBufferFormat = D3DFMT_X8R8G8B8;
	m_d3dpp.BackBufferWidth = g_uiWidth;
	m_d3dpp.BackBufferHeight = g_uiHeight;
	m_d3dpp.EnableAutoDepthStencil = FALSE;
	m_d3dpp.Flags = 0;
	m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

	//CREATE D3D DEVICE HANDLE
	hr = m_pD3D->CreateDevice( D3DADAPTER_DEFAULT,
								D3DDEVTYPE_HAL,
								hWnd,
								D3DCREATE_HARDWARE_VERTEXPROCESSING,
								&m_d3dpp,
								&m_pd3dDevice);

	if(FAILED(hr))
	{
		MessageBox(hWnd, "D3D Device creation failed", NULL, MB_OK );
		return FALSE;
	}

	//CHECK IF SDI IS SUPPORTED
	hr = m_pD3D->CheckDeviceFormat( D3DADAPTER_DEFAULT,
									D3DDEVTYPE_HAL,
									D3DFMT_X8R8G8B8,0,
									D3DRTYPE_SURFACE,
									(D3DFORMAT)FOURCC_SDIF);
	if(FAILED(hr))
	{
		MessageBox(hWnd, "SDI Format Not Supported!", NULL, MB_OK );
		return FALSE;
	}


	m_pd3dDevice->CreateVertexDeclaration(g_vtxDecl, &m_pVDecl1);
    LPD3DXBUFFER pCode;
    if(SUCCEEDED(D3DXAssembleShader(g_strVS, strlen(g_strVS), NULL, NULL, 0, &pCode, NULL)))
    {
        m_pd3dDevice->CreateVertexShader((DWORD*)pCode->GetBufferPointer(), &m_pVS1);
        pCode->Release();
    }
    if(SUCCEEDED(D3DXAssembleShader(g_strPS, strlen(g_strPS), NULL, NULL, 0, &pCode, NULL)))
    {
        m_pd3dDevice->CreatePixelShader((DWORD*)pCode->GetBufferPointer(), &m_pPS1);
        pCode->Release();
    }

    if(!SUCCEEDED(D3DXCreateTextureFromFileEx(m_pd3dDevice,
								"AMD_FirePro.jpg",
								250,
								250,
								D3DX_FROM_FILE,
								D3DUSAGE_RENDERTARGET,
								D3DFMT_X8R8G8B8,
								D3DPOOL_DEFAULT,
								D3DX_DEFAULT,
								D3DX_DEFAULT,
								0,
								NULL,
								NULL,
								&m_pTexAMDLogo)))
	{
		MessageBox(NULL, "AMD LOGO not found", "Error", MB_OK);
		return FALSE;
	}

	m_pd3dDevice->GetRenderTarget(0, &m_pRTSurf1);
	m_pd3dDevice->CreateQuery(D3DQUERYTYPE_EVENT, &m_pEventQuery);

	return TRUE;
}

// Resize only the window. Since we are rendering into a FBO the
// projection matrix does not change on a window resize
void DXProcess::resize(unsigned int w, unsigned int h)
{
    m_uiWindowWidth  = w;
    m_uiWindowHeight = h;
}

bool DXProcess::createDownStream(unsigned int w, unsigned int h, unsigned int NumBuffers)
{
    m_uiBufferWidth  = w;
    m_uiBufferHeight = h;

	for(int i=0; i<2; i++)
	{
		if(!SUCCEEDED(CreateP2PLocalTexture(m_pd3dDevice, w, h, D3DUSAGE_RENDERTARGET, D3DFMT_X8R8G8B8, &m_ppTexGfx[i], &m_pAttribGfx[i])))
		{
			MessageBox(NULL, "Can't create P2P Local Texture", "Error", MB_OK);
			return false;
		}

		m_pBufferBusAddress[i] = m_pAttribGfx[i].surfaceAddr.surfaceBusAddr;
		m_pMarkerBusAddress[i] = m_pAttribGfx[i].surfaceAddr.markerBusAddr;
	}

	g_FifoCapture.Init(NUM_BUFFERS, m_pBufferBusAddress, m_pMarkerBusAddress);

	return true;
}

bool DXProcess::setRemoteMemory(unsigned long long* pBufferBusAddress, unsigned long long* pMarkerBusAddress)
{
	for(int i=0; i<2; i++)
	{
		m_pAttribBlue[i].surfaceAddr.surfaceBusAddr = *(pBufferBusAddress+i);
		m_pAttribBlue[i].surfaceAddr.markerBusAddr = *(pMarkerBusAddress+i);

		if(SUCCEEDED(CreateP2PRemoteTexture(m_pd3dDevice, m_uiBufferWidth, m_uiBufferHeight, D3DUSAGE_RENDERTARGET, D3DFMT_X8R8G8B8, &m_pAttribBlue[i], &m_ppTexBlue[i])))
		{
		}
		else
		{
			MessageBox(NULL, "Can't set remote addresses" , "Error", MB_OK);
			return false;
		}
	}

	g_FifoRender.Init(2, pBufferBusAddress, pMarkerBusAddress);

	return true;    
}

unsigned long long* DXProcess::getBufferBusAddress()
{
	return m_pBufferBusAddress;
}

unsigned long long* DXProcess::getMarkerBusAddress()
{
	return m_pMarkerBusAddress;
}

void DXProcess::FlushAndWaitForGPUIdle()
{
    // Add an end marker to the command buffer queue.
    m_pEventQuery->Issue(D3DISSUE_END);

    // Force the driver to execute the commands from the command buffer.
    // Empty the command buffer and wait until the GPU is idle.
    while(S_FALSE == m_pEventQuery->GetData( NULL, 0, D3DGETDATA_FLUSH ));
}

void DXProcess::draw()
{
	static DWORD nColorStatic = 0xFF000000;
	DWORD nColor = 0;
    HRESULT hr = S_OK;

	IDirect3DSurface9* pDstTextureSurface = NULL;
	IDirect3DSurface9* pSrcTextureSurface = NULL;
    CFrameData* pFrameIn = NULL;
	CFrameData* pFrameOut = NULL;

	do
	{
		pFrameIn = g_FifoCapture.GetLiveBuffer();
	}while(!pFrameIn && m_bIsProcessing);

	while(!pFrameOut && m_bIsProcessing)
		pFrameOut = g_FifoRender.GetFreeBuffer();

	if(!m_bIsProcessing)
		return;

	//wait marker
	if(FAILED(P2PWaitMarker(m_pd3dDevice, m_pAttribGfx[pFrameIn->uiBufferId].surfaceHandle, pFrameIn->uiBufferId)))
		MessageBox(NULL, "P2PWriteMarker failed", "Error", MB_OK);

	if(SUCCEEDED(m_pd3dDevice->BeginScene()))
	{
		TEST_FAIL_ERROR(m_ppTexBlue[pFrameOut->uiBufferId]->GetSurfaceLevel(0, &pDstTextureSurface));
		TEST_FAIL_ERROR(m_ppTexGfx[pFrameIn->uiBufferId]->GetSurfaceLevel(0, &pSrcTextureSurface));
		TEST_FAIL_ERROR(m_pd3dDevice->SetRenderTarget(0, pSrcTextureSurface));

		TEST_FAIL_ERROR(m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE));
        TEST_FAIL_ERROR(m_pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE, FALSE ));
        TEST_FAIL_ERROR(m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE ));

        TEST_FAIL_ERROR(m_pd3dDevice->SetVertexDeclaration(m_pVDecl1));
        TEST_FAIL_ERROR(m_pd3dDevice->SetVertexShader(m_pVS1));
        TEST_FAIL_ERROR(m_pd3dDevice->SetPixelShader(m_pPS1));

		TEST_FAIL_ERROR(SyncSurfData(*&m_pd3dDevice, m_pAttribGfx[pFrameIn->uiBufferId].surfaceHandle, FALSE));

		hr = m_pd3dDevice->SetTexture(0, m_ppTexGfx[pFrameIn->uiBufferId]);
		hr = m_pd3dDevice->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 4, 2, g_idxData, D3DFMT_INDEX16, g_vtxData1, sizeof(VtxStruct));

		static float var = 0.9f;
		memcpy(g_vtxData1, g_vtxData2, sizeof(g_vtxData2));
		for (int i=0; i<4; i++)
		{
			g_vtxData1[i].x *= var;
			g_vtxData1[i].y *= var;
		}

		// Draw AMD Logo
		hr = m_pd3dDevice->SetTexture(0, m_pTexAMDLogo);
		hr = m_pd3dDevice->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 4, 2, g_idxData, D3DFMT_INDEX16, g_vtxData1, sizeof(VtxStruct));

		//copy to desktop preview
		TEST_FAIL_ERROR(m_pd3dDevice->StretchRect( pSrcTextureSurface, NULL, m_pRTSurf1, NULL, D3DTEXF_NONE));
		TEST_FAIL_ERROR(SyncSurfData(*&m_pd3dDevice, m_pAttribBlue[pFrameOut->uiBufferId].surfaceHandle, TRUE));

		g_DmaLock.lock();
		//DMA from Gfx to Bluefish memory
		TEST_FAIL_ERROR(m_pd3dDevice->StretchRect( pSrcTextureSurface, NULL, pDstTextureSurface, NULL, D3DTEXF_NONE));
		TEST_FAIL_ERROR(SyncSurfData(*&m_pd3dDevice, m_pAttribBlue[pFrameOut->uiBufferId].surfaceHandle, TRUE));

		FlushAndWaitForGPUIdle();
		g_DmaLock.unlock();

		m_pd3dDevice->EndScene();
	}
	else
		MessageBox(NULL, "m_pd3dDevice->BeginScene() failed", "Error", MB_OK);

	TEST_FAIL_ERROR(m_pd3dDevice->Present(NULL, NULL, NULL, NULL));

	++pFrameOut->uiTransferId;
	if(FAILED(P2PWriteMarker(m_pd3dDevice, m_pAttribBlue[pFrameOut->uiBufferId].surfaceHandle, pFrameOut->ullMarkerBusAddress & 0xFFF, pFrameOut->uiTransferId)))
		MessageBox(NULL, "P2PWriteMarker failed", "Error", MB_OK);

	g_FifoCapture.PutFreeBuffer(pFrameIn);
	g_FifoRender.PutLiveBuffer(pFrameOut);

    // Mark the buffer as ready to be consumed. No need to wait for the transfer to terminate
    // since the consumer will call waitMarker that will block the GPU until the transfer is done.
}
