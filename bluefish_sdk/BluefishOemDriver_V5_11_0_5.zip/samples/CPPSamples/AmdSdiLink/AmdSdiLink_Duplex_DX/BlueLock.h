#ifndef H_GUARD_BLUELOCK
#define H_GUARD_BLUELOCK


class BlueLock
{
public:
	BlueLock();
	~BlueLock();

	void lock();
	void unlock();

private:
	HANDLE	m_hMutex;
};

#endif //H_GUARD_BLUELOCK
