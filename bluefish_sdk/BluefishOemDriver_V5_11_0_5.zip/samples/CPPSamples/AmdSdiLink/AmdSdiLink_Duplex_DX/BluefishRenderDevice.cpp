#include "BluefishRenderDevice.h"

using namespace std;

extern unsigned int g_uiWidth;
extern unsigned int g_uiHeight;
extern struct blue_videomode_info gVideoModeInfo[];
extern CFifoBuffer	g_FifoRender;


struct blue_videomode_info
{
	bool	bIs3G;
	float fFrameAspectRatioX;
	float fFrameAspectRatioY;	
	std::string strVideoModeFriendlyName;
	unsigned int nVideoMode;
	unsigned int nHeight;
	unsigned int nWidth;
	unsigned int nFrameRate;
	bool	bIs1001FrameRate;
	bool	bIsProgressive;
	unsigned int nAudioFrameSequence[5];
};

CBlueRenderDevice::CBlueRenderDevice(int iDevNumber, unsigned int nVideoChannel) :
	m_pSDK(NULL),
	m_iDevices(0),
	m_iDevNumber(iDevNumber),
	m_nVideoChannel(nVideoChannel),
	m_nVideoMode(VID_FMT_INVALID),
	m_nUpdateFormat(UPD_FMT_FRAME),
	m_nMemoryFormat(MEM_FMT_BGRA),
	m_nFrameSize(0),
	m_nBytesPerLine(0),
	m_nBytesPerFrame(0),
	m_nPixelsPerLine(0),
	m_ulLastFieldCount(0),
	m_ulCurrentFieldCount(0),
	m_ulBufferID(0),
	m_nCurrentBufferNumber(0),
	m_iDroppedFields(0),
	m_iDroppedFrames(0),
	m_bIsPlaying(FALSE)
{
	m_n64DataBusAddress[0] = 0LL;
	m_n64DataBusAddress[1] = 0LL;
	m_n64MarkerAddress[0] = 0LL;
	m_n64MarkerAddress[1] = 0LL;
}

CBlueRenderDevice::~CBlueRenderDevice()
{
	if(m_pSDK)
	{
		VARIANT varVal;
		varVal.vt = VT_UI4;
		varVal.ulVal = 1;
		m_pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

		m_pSDK->device_detach();
		BlueVelvetDestroy(m_pSDK);
		m_pSDK = NULL;
	}
}

//#define USE_SECOND_CARD
BOOL CBlueRenderDevice::Init(unsigned int VideoMode)
{
	m_pSDK = BlueVelvetFactory4();
	if(!m_pSDK)
	{
		cout << "No Bluefish SDK" << endl;
		return FALSE;
	}

	if(m_pSDK)
	{
		m_pSDK->device_enumerate(m_iDevices);
#ifdef USE_SECOND_CARD
		if(m_iDevices < 2)
		{
			cout << "Can't find second Bluefish card" << endl;
			BlueVelvetDestroy(m_pSDK);
			m_pSDK = NULL;
			return FALSE;
		}

		m_pSDK->device_attach(2, 0);
#else
		if(!m_iDevices)
		{
			cout << "No Bluefish card" << endl;
			BlueVelvetDestroy(m_pSDK);
			m_pSDK = NULL;
			return FALSE;
		}

		m_pSDK->device_attach(1, 0);
#endif
		int card_type = m_pSDK->has_video_cardtype();
		if(card_type != CRD_BLUE_EPOCH_HORIZON &&
			card_type != CRD_BLUE_EPOCH_CORE &&
			card_type != CRD_BLUE_EPOCH_ULTRA &&
			card_type != CRD_BLUE_EPOCH_2K_HORIZON &&
			card_type != CRD_BLUE_EPOCH_2K_CORE &&
			card_type != CRD_BLUE_EPOCH_2K_ULTRA &&
			card_type != CRD_BLUE_SUPER_NOVA &&
			card_type != CRD_BLUE_SUPER_NOVA_S_PLUS)
		{
			cout << "Not an Epoch/SuperNova card" << endl;
			m_pSDK->device_detach();
			BlueVelvetDestroy(m_pSDK);
			m_pSDK = NULL;
		}
	}

	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = m_nVideoChannel;
	m_pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	m_nVideoMode = VideoMode;
	varVal.ulVal = m_nVideoMode;
	m_pSDK->SetCardProperty(VIDEO_MODE, varVal);
	m_pSDK->QueryCardProperty(VIDEO_MODE, varVal);
	m_nVideoMode = varVal.ulVal;
	if(varVal.ulVal == VID_FMT_INVALID)
	{
		cout << "Couldn't set video mode " << gVideoModeInfo[m_nVideoMode].strVideoModeFriendlyName.c_str() <<  endl;
		m_pSDK->device_detach();
		BlueVelvetDestroy(m_pSDK);
		m_pSDK = NULL;
		return FALSE;
	}

	cout << "Video mode: " << gVideoModeInfo[m_nVideoMode].strVideoModeFriendlyName.c_str() << endl;

	BOOL bDoFieldMode = FALSE;
	if(gVideoModeInfo[m_nVideoMode].bIsProgressive)	//we can't FIELD mode for progressive video modes
		bDoFieldMode = FALSE;
	else	//for interlaced video formats we have the choice of using FRAME or FIELD mode
	{
		int iRet = MessageBox(NULL, "Process output in field mode?", "Update type", MB_YESNO);
		if(iRet == 6) //yes
			bDoFieldMode = TRUE;
		else	//7 == no
			bDoFieldMode = FALSE;
	}

	if(bDoFieldMode)
		m_nUpdateFormat = UPD_FMT_FIELD;
	else
		m_nUpdateFormat = UPD_FMT_FRAME;

	varVal.ulVal = m_nUpdateFormat;
	m_pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = m_nMemoryFormat;
	m_pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	varVal.ulVal = VIDEO_ENGINE_FRAMESTORE;
	m_pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);

	varVal.ulVal = 0;
	m_pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

	m_nFrameSize = BlueVelvetGolden(m_nVideoMode, m_nMemoryFormat, m_nUpdateFormat);
	m_nBytesPerLine = BlueVelvetLineBytes(m_nVideoMode, m_nMemoryFormat);
	m_nBytesPerFrame = BlueVelvetFrameBytes(m_nVideoMode, m_nMemoryFormat, m_nUpdateFormat);
	m_nPixelsPerLine = BlueVelvetLinePixels(m_nVideoMode);

	g_uiWidth = m_nPixelsPerLine;
	g_uiHeight = m_nBytesPerFrame/m_nBytesPerLine;

	cout << "Frame size:   " << m_nFrameSize << endl;
	cout << "Frame width:  " << g_uiWidth << endl;
	cout << "Frame height: " << g_uiHeight << endl;

	for(unsigned int n=0; n<2; n++)
	{
		bfGetVideoBusAddressAndMarkerBusAddress(m_pSDK, m_nVideoChannel, n, m_n64DataBusAddress[n], m_n64MarkerAddress[n]);
	}

	cout << "DataBusAddress 0: 0x" << hex << m_n64DataBusAddress[0] << ", MarkerAddress 0x" << m_n64MarkerAddress[0] << endl;
	cout << "DataBusAddress 1: 0x" << hex << m_n64DataBusAddress[1] << ", MarkerAddress 0x" << m_n64MarkerAddress[1] << endl;

	return TRUE;
}

void CBlueRenderDevice::RenderVideoFrame()
{
	CFrameData* pFrame = NULL;

	do
	{
		pFrame = g_FifoRender.GetLiveBuffer();
	}while(!pFrame && m_bIsPlaying);

	if(!m_bIsPlaying)
		return;

	//wait for frame to be fully written to the bluefish card memory
	cout << "bfDmaWaitMarker: " << pFrame->uiTransferId << endl;
	bfDmaWaitMarker(m_pSDK, NULL, m_nVideoChannel, pFrame->uiBufferId, pFrame->uiTransferId);

	//now schedule this frame to be rendered at the next interrupt
	m_pSDK->render_buffer_update(pFrame->uiBufferId);

	g_FifoRender.PutFreeBuffer(pFrame);
}

unsigned int CBlueRenderDevice::WaitForOutputClock()
{
	unsigned long ulFieldCount = 0;
	static unsigned long ulLastFieldCount = 0;

	if(m_pSDK)
		m_pSDK->wait_output_video_synch(m_nUpdateFormat, ulFieldCount);

	if(ulLastFieldCount != 0)
	{
		if(m_nUpdateFormat == UPD_FMT_FIELD)
		{
			if(ulLastFieldCount+1 < ulFieldCount)
			{
				//cout << "Frame dropped (capture). Should be " << dec << (ulLastFieldCount+1) << ", is " << ulFieldCount << endl;
				m_iDroppedFields++;
			}
		}
		else
		{
			if(ulLastFieldCount+2 < ulFieldCount)
			{
				//cout << "Frame dropped (capture). Should be " << dec << (ulLastFieldCount+2) << ", is " << ulFieldCount << endl;
				m_iDroppedFrames++;
			}
		}
	}
	ulLastFieldCount = ulFieldCount;

	return ulFieldCount;
}
