#pragma once

#include <string>
#include <vector>
#include "amddx9extsdi.h"


class DXWindow
{
public:
    DXWindow(const char* strWinName, const char* strClsaaName);
    ~DXWindow();

    // setups ADL and enumerates Disp�lays
    bool            init();

    void            setFullScreen(bool bFullScreen);
    void            setInitialPosition(unsigned int uiPosX, unsigned int uiPosY);

    // create a window but does not open it
    bool            create(unsigned int uiWidth, unsigned int uiHeight, unsigned int uiDspIndex = 1, bool bDecoration = true);
    
    // Opens window
    void            open();

    // stores the new window size
    void            resize(unsigned int uiWidth, unsigned int uiHeight);

    HWND            getWnd()            { return m_hWnd;};

    unsigned int    getWidth()          { return m_uiWidth; };
    unsigned int    getHeight()         { return m_uiHeight; };

    // returns the number of GPUs in the system
    unsigned int    getNumGPUs()        { return m_uiNumGPU; };
    // returns the number of displays mapped on GPU uiGPU
    unsigned int    getNumDisplaysOnGPU(unsigned int uiGPU);
    // returns the DisplayID of Display n on GPU uiGPU
    // n=0 will return the first display on GPU uiGPU if available
    // n=1 will return the second display on GPU uiGPU if available ...
    unsigned int    getDisplayOnGPU(unsigned int uiGPU, unsigned int n=0);

private:

    typedef struct
    {
        unsigned int    uiGPUId;
        unsigned int    uiDisplayId;
        unsigned int    uiDisplayLogicalId;
        unsigned int    uiOriginX;
        unsigned int    uiOriginY;
        unsigned int    uiWidth;
        unsigned int    uiHeight;
        std::string     strDisplayname;
    } DisplayData;


    bool            setupADL();
    DisplayData*    getDisplayData(unsigned int uiDspId);

	HWND                        m_hWnd;

    unsigned int                m_uiWidth;
    unsigned int                m_uiHeight;
    unsigned int                m_uiPosX;
    unsigned int                m_uiPosY;

    bool                        m_bADLReady;
    bool                        m_bFullScreen;

    unsigned int                m_uiNumGPU;
    std::vector<DisplayData*>   m_DisplayInfo;

    std::string                 m_strWinName;
    std::string                 m_strClassName; 
};
