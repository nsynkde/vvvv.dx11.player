#include <windows.h>

#include "adl_prototypes.h"
#include "DXWindow.h"


using namespace std;


// Handle to ADL DLL
static HINSTANCE hDLL = NULL;

// Memory Allocation function needed for ADL
void* __stdcall ADL_Alloc ( int iSize )
{
    void* lpBuffer = malloc ( iSize );
    return lpBuffer;
}

// Memory Free function needed for ADL
void __stdcall ADL_Free ( void* lpBuffer )
{
    if ( NULL != lpBuffer )
    {
        free ( lpBuffer );
        lpBuffer = NULL;
    }
}

DXWindow::DXWindow(const char* strWinName, const char* strClsaaName)
{
    m_strClassName = strClsaaName;
    m_strWinName   = strWinName;

    m_hWnd = NULL;

    m_uiWidth = 1280;
    m_uiHeight = 720;

    m_uiPosX = 0;
    m_uiPosY = 0;

    m_uiNumGPU = 0;

    m_bADLReady   = false;
    m_bFullScreen = false;
}

DXWindow::~DXWindow(void)
{
    vector<DisplayData*>::iterator itr;

    for (itr = m_DisplayInfo.begin(); itr != m_DisplayInfo.end(); ++itr)
    {
        if ((*itr))
        {
            delete (*itr);
        }
    }
}

bool DXWindow::init()
{
    int				nNumDisplays = 0;
	int				nNumAdapters = 0;
    int             nCurrentBusNumber = 0;
	LPAdapterInfo   pAdapterInfo = NULL;
    unsigned int    uiCurrentGPUId     = 0;
    unsigned int    uiCurrentDisplayId = 0;

    // load all required ADL functions
    if (!setupADL())
        return false;

    // Determine how many adapters and displays are in the system
	ADL_Adapter_NumberOfAdapters_Get(&nNumAdapters);

	if (nNumAdapters > 0)
	{
		pAdapterInfo = (LPAdapterInfo)malloc ( sizeof (AdapterInfo) * nNumAdapters );
        memset ( pAdapterInfo,'\0', sizeof (AdapterInfo) * nNumAdapters );
	}

	ADL_Adapter_AdapterInfo_Get (pAdapterInfo, sizeof (AdapterInfo) * nNumAdapters);

    // Loop through all adapters 
	for (int i = 0; i < nNumAdapters; ++i)
	{
		int				nAdapterIdx; 
		int				nAdapterStatus;
		
		nAdapterIdx = pAdapterInfo[i].iAdapterIndex;

		ADL_Adapter_Active_Get(nAdapterIdx, &nAdapterStatus);

		if (nAdapterStatus)
		{
			LPADLDisplayInfo	pDisplayInfo = NULL;

			ADL_Display_DisplayInfo_Get(nAdapterIdx, &nNumDisplays, &pDisplayInfo, 0);

			for (int j = 0; j < nNumDisplays; ++j)
			{
				// check if display is connected and mapped
				if (pDisplayInfo[j].iDisplayInfoValue & ADL_DISPLAY_DISPLAYINFO_DISPLAYCONNECTED)
				{
                    DEVMODE DevMode;

					// check if display is mapped on adapter
					if (pDisplayInfo[j].iDisplayInfoValue & ADL_DISPLAY_DISPLAYINFO_DISPLAYMAPPED && pDisplayInfo[j].displayID.iDisplayLogicalAdapterIndex == nAdapterIdx)
					{
                        if (nCurrentBusNumber == 0)
                        {
                            // Found first GPU in the system
                            ++m_uiNumGPU;
                            nCurrentBusNumber = pAdapterInfo[nAdapterIdx].iBusNumber;
                        }
                        else if (nCurrentBusNumber != pAdapterInfo[nAdapterIdx].iBusNumber)
                        {
                            // found new GPU
                            ++m_uiNumGPU;
                            ++uiCurrentGPUId;
                            nCurrentBusNumber = pAdapterInfo[nAdapterIdx].iBusNumber;
                        }

                        ++uiCurrentDisplayId;

                        EnumDisplaySettings(pAdapterInfo[i].strDisplayName, ENUM_CURRENT_SETTINGS, &DevMode);

                        // Found first mapped display
                        DisplayData* pDsp = new DisplayData;

                        pDsp->uiGPUId               = uiCurrentGPUId;
                        pDsp->uiDisplayId           = uiCurrentDisplayId;
                        pDsp->uiDisplayLogicalId    = pDisplayInfo[j].displayID.iDisplayLogicalAdapterIndex;
                        pDsp->uiOriginX             = DevMode.dmPosition.x;
                        pDsp->uiOriginY             = DevMode.dmPosition.y;
                        pDsp->uiWidth               = DevMode.dmPelsWidth;
                        pDsp->uiHeight              = DevMode.dmPelsHeight;
                        pDsp->strDisplayname        = string(pAdapterInfo[i].strDisplayName);

                        m_DisplayInfo.push_back(pDsp);
                    }
                }
            }
        }
    }

    return true;
}

unsigned int DXWindow::getNumDisplaysOnGPU(unsigned int uiGPU)
{
    unsigned int uiNumDsp = 0;

    vector<DisplayData*>::iterator itr;

    for (itr = m_DisplayInfo.begin(); itr != m_DisplayInfo.end(); ++itr)
    {
        if ((*itr)->uiGPUId == uiGPU)
        {
            ++uiNumDsp;
        }
    }

    return uiNumDsp;
}

unsigned int DXWindow::getDisplayOnGPU(unsigned int uiGPU, unsigned int n)
{
    unsigned int uiCurrentDsp = 0;

    vector<DisplayData*>::iterator itr;

    for (itr = m_DisplayInfo.begin(); itr != m_DisplayInfo.end(); ++itr)
    {
        if ((*itr)->uiGPUId == uiGPU)
        {
            if (uiCurrentDsp == n)
            {
                return (*itr)->uiDisplayId;
            }

            ++uiCurrentDsp;
        }
    }

    return 0;
}

bool DXWindow::create(unsigned int uiWidth, unsigned int uiHeight, unsigned int uiDspIndex, bool bDecoration)
{
    RECT        WinSize;
    DWORD		dwExStyle;
	DWORD		dwStyle;
	int			nPixelFormat;

    // Get information for the display with id uiDspId. This is the ID
    // shown by CCC. Use the origin of this display as base position for
    // opening the window. Like this a window can be opened on a particular
    // GPU.
    DisplayData* pDsp = getDisplayData(uiDspIndex);

    if (pDsp)
    {
        m_uiPosX += pDsp->uiOriginX;
        m_uiPosY += pDsp->uiOriginY;
    }


	if (m_bFullScreen)
	{
		dwExStyle = WS_EX_APPWINDOW;								
		dwStyle   = WS_POPUP;										
		//ShowCursor(FALSE);	
	}
	else
	{
        m_uiWidth  = uiWidth;
        m_uiHeight = uiHeight;

		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;	

        if (bDecoration)
        {
		    dwStyle   = WS_OVERLAPPEDWINDOW;

            // Adjust window size so that the ClientArea has the initial size
            // of uiWidth and uiHeight
            WinSize.bottom = uiHeight; 
            WinSize.left   = 0;
            WinSize.right  = uiWidth;
            WinSize.top    = 0;

            AdjustWindowRect(&WinSize, WS_OVERLAPPEDWINDOW, false);

            m_uiWidth  = WinSize.right  - WinSize.left;
            m_uiHeight = WinSize.bottom - WinSize.top;    
        }
        else
            dwStyle   = WS_POPUP;
	}

	m_hWnd = CreateWindowEx( dwExStyle,
						     m_strClassName.c_str(), 
						     m_strWinName.c_str(),
						     dwStyle,
						     m_uiPosX,
						     m_uiPosY,
						     m_uiWidth,
						     m_uiHeight,
						     NULL,
						     NULL,
						    (HINSTANCE)GetModuleHandle(NULL),
						     NULL);

	if (!m_hWnd)
		return FALSE;

	return true;
}

void DXWindow::open()
{
    ShowWindow(m_hWnd, SW_SHOW);
	SetForegroundWindow(m_hWnd);
	SetFocus(m_hWnd);

	UpdateWindow(m_hWnd);
}

void DXWindow::resize(unsigned int uiWidth, unsigned int uiHeight)
{
    m_uiWidth  = uiWidth;
    m_uiHeight = uiHeight;
}

// Load ADL library and get function pointers
bool DXWindow::setupADL()
{
    // check if ADL was already loaded
    if (hDLL)
    {
        return true;
    }

	hDLL = LoadLibrary("atiadlxx.dll");

	 if (hDLL == NULL)
       hDLL = LoadLibrary("atiadlxy.dll");

	if (!hDLL)
		return false;

	// Get proc address of needed ADL functions
	ADL_Main_Control_Create = (ADL_MAIN_CONTROL_CREATE)GetProcAddress(hDLL,"ADL_Main_Control_Create");
	if (!ADL_Main_Control_Create)
		return false;

	ADL_Main_Control_Destroy         = (ADL_MAIN_CONTROL_DESTROY)GetProcAddress(hDLL, "ADL_Main_Control_Destroy");
	if (!ADL_Main_Control_Destroy)
		return false;

	ADL_Adapter_NumberOfAdapters_Get = (ADL_ADAPTER_NUMBEROFADAPTERS_GET)GetProcAddress(hDLL,"ADL_Adapter_NumberOfAdapters_Get");
	if (!ADL_Adapter_NumberOfAdapters_Get)
		return false;

	ADL_Adapter_AdapterInfo_Get = (ADL_ADAPTER_ADAPTERINFO_GET)GetProcAddress(hDLL,"ADL_Adapter_AdapterInfo_Get");
	if (!ADL_Adapter_AdapterInfo_Get)
		return false;

	ADL_Display_DisplayInfo_Get = (ADL_DISPLAY_DISPLAYINFO_GET)GetProcAddress(hDLL,"ADL_Display_DisplayInfo_Get");
	if (!ADL_Display_DisplayInfo_Get)
		return false;

	ADL_Adapter_Active_Get = (ADL_ADAPTER_ACTIVE_GET)GetProcAddress(hDLL,"ADL_Adapter_Active_Get");
	if (!ADL_Adapter_Active_Get)
		return false;

	ADL_Display_Position_Get = (ADL_DISPLAY_POSITION_GET)GetProcAddress(hDLL,"ADL_Display_Position_Get");
	if (!ADL_Display_Position_Get)
		return false;

	ADL_Display_Property_Get = (ADL_DISPLAY_PROPERTY_GET)GetProcAddress(hDLL,"ADL_Display_Property_Get");
	if (!ADL_Display_Property_Get)
		return false;

	// Init ADL
	if (ADL_Main_Control_Create(ADL_Alloc, 0) != ADL_OK)
		return false;

	return true;
}

DXWindow::DisplayData* DXWindow::getDisplayData(unsigned int uiDspId)
{
    vector<DisplayData*>::iterator itr;

    for (itr = m_DisplayInfo.begin(); itr != m_DisplayInfo.end(); ++itr)
    {
        if ((*itr)->uiDisplayId == uiDspId)
        {
            return (*itr);
        }
    }

    return NULL;
}
