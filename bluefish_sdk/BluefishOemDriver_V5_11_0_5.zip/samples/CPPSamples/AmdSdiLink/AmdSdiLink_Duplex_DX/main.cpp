// (c) 2012 Bluefish Technologies Pty Ltd
//
// Sample application:	SdiToGPU_DX
// Written by:			Tim Bragulla
// Date:				08 November 2012
//
// Brief description:	This sample application shows how to DMA video frames straight from the Bluefish card to the AMD FirePro V7900 SDI card, processing it in DX
//						and DMA it back to the Bluefish card for playback without going through system memory by using the AMD SDI Link feature 
//
// Further information:	Please see the following application notes:
//						- AN_AMD_SDI_Link_Support.pdf
//						- AMD_SDI_Link.txt
//
// Supported hardware:	Bluefish Epoch and SuperNova cards
//						AMD FirePro V7900 SDI card
//
// Requirements:
//		Software:				Bluefish Driver 5.10.1.12 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_1_12\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include <windows.h>
#include <string>
#include <iostream>
// For adding console
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
// end adding console

#include "d3d9.h"
#include "DXWindow.h"
#include "DXProcess.h"
#include "SDIHelper.h"
#include "BluefishCaptureDevice.h"
#include "BluefishRenderDevice.h"
#include "FifoBuffer.h"

using namespace std;

// Size of the frames
unsigned int g_uiWidth  = 1280;
unsigned int g_uiHeight =  720;

CFifoBuffer	g_FifoCapture;
CFifoBuffer	g_FifoRender;

BlueLock g_DmaLock;


typedef struct
{
    bool        bRunning;               // Indicates that the thread is running
    bool        bResizeSource;          // if true, the source window was resized
    bool        bResizeSink;            // if true, the sink window was resized
    DXWindow*   pSinkWin;				// Pointer to the sink window
	DXProcess*	pProcess;	            // DirectX Processing
	CBlueCaptureDevice* pBlueCapture;	// CBlueCaptureDevice produces frames for DirectX Sink
	CBlueRenderDevice* pBlueRender;		// CBlueRenderDevice receives process frames from DX
} ThreadData;

ThreadData* g_pThreadData = NULL;

HANDLE  g_hSinkReady;
HANDLE  g_hSinkDone;
HANDLE  g_hProcessReady;
HANDLE  g_hProcessDone;
HANDLE  g_hSourceReady;
HANDLE  g_hSourceDone;


LRESULT CALLBACK    WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);


DWORD WINAPI SourceThreadFunc(LPVOID lpArgs)
{
    ThreadData* pThreadData = (ThreadData*)lpArgs;
	DXWindow*   pMyWin      = NULL;

	if (!pThreadData || !pThreadData->pSinkWin || !pThreadData->pBlueCapture)
    {
		cout << __FUNCTION__ << ": BAIL: pointers not set!" << endl;
        ReleaseSemaphore(g_hSourceDone, 1, 0);
		g_pThreadData->bRunning = false;
        return 0;
    }

	BlueTimer bm;
	int bmFrameCount = 0;
	bm.Init();
	double dTimeDelta;
	double dMax = 0.0;
	double dMin = 999999.0;
	double dSum = 0.0;

	CBlueCaptureDevice* pBlue = pThreadData->pBlueCapture;
	unsigned int nBufferNumber = 1;
	bool bRenderInFieldMode = (pBlue->m_nUpdateFormat == UPD_FMT_FIELD);

	if (WaitForSingleObject(g_hProcessReady, THREAD_WAIT_TIMEOUT) == WAIT_TIMEOUT)
    {
		cout << __FUNCTION__ << ": BAIL: Wait timeout" << endl;
        ReleaseSemaphore(g_hSourceDone, 1, 0);
		g_pThreadData->bRunning = false;
        PostMessage(g_pThreadData->pSinkWin->getWnd(), WM_QUIT, 0, 0);
        return 0;
    }

	cout << __FUNCTION__ << ": g_hSourceReady" << endl;
	ReleaseSemaphore(g_hSourceReady, 1, 0);

	pBlue->m_bIsCapturing = TRUE;
	
	//Prolog for capturing
	//Step 1
	pBlue->WaitForInputClock();	//synch with the card
	pBlue->ScheduleCapture();		//schedule to capture a video frame

	//Step 2
	pBlue->WaitForInputClock();	//the first buffer starts to be captured now; this is it's field count; will be available at the next interrupt
	pBlue->ScheduleCapture();		//schedule the next frame to be captured

	cout << "Entering loop..." << endl;
	//start in synch with the video input interrupt; in FIELD mode we have to wait for the field 2 interrupt
	unsigned int FieldCount = pBlue->WaitForInputClock();
	if(pBlue->m_nUpdateFormat == UPD_FMT_FIELD && !(FieldCount & 0x1))
		pBlue->WaitForInputClock();

	while(g_pThreadData->bRunning)
	{
		pBlue->ScheduleCapture();				//schedule the next frame to be captured
		
		bm.GetTime();
		pBlue->TransferCapturedVideoFrame();	//DMA video frame that was scheduled for capture at step 1 above
		dTimeDelta = bm.GetTime();
		nBufferNumber++;
		
		bmFrameCount++;
		if(dTimeDelta > dMax) dMax = dTimeDelta;
		if(dTimeDelta < dMin) dMin = dTimeDelta;
		dSum += dTimeDelta;
		if(bmFrameCount >= 100)
		{
			cout << "Avg: " << (float)(dSum/bmFrameCount) << ", Min: " << (float)(dMin) << ", Max: " << (float)(dMax) <<
				", Fi " << pBlue->m_iDroppedFields << ", Fr " << pBlue->m_iDroppedFrames << endl;
			bmFrameCount = 0;
			dSum = 0.0;
			dMax = 0.0;
			dMin = 999999.0;
		}

		pBlue->WaitForInputClock();
	}

	cout << __FUNCTION__ << ": ...Exiting thread" << endl;
	g_pThreadData->bRunning = false;

	pThreadData->pBlueCapture->m_bIsCapturing = FALSE;
	pThreadData->pBlueRender->m_bIsPlaying = FALSE;
	pThreadData->pProcess->m_bIsProcessing = FALSE;

    // If createUpStream failed, make sure that the Sink does not stay blocked
    ReleaseSemaphore(g_hSourceReady, 1, 0);

    // Indicate that the Source is done and does no longer need the
    // input buffer of the sink.
    ReleaseSemaphore(g_hSourceDone, 1, 0);

    return 0;
}

DWORD WINAPI ProcessThreadFunc(LPVOID lpArgs)
{
    ThreadData* pThreadData = (ThreadData*)lpArgs;

    if(!pThreadData || !pThreadData->pBlueCapture)
	{
		cout << __FUNCTION__ << ": BAIL: pointers not set!" << endl;
		g_pThreadData->bRunning = false;
		ReleaseSemaphore(g_hProcessDone, 1, 0);
        return 0;
	}

	pThreadData->pProcess->m_bIsProcessing = TRUE;

	BlueTimer bm;
	int bmFrameCount = 0;
	bm.Init();
	double dTimeDelta;
	double dMax = 0.0;
	double dMin = 999999.0;
	double dSum = 0.0;

	DXWindow* pMyWin = NULL;
    pMyWin = pThreadData->pSinkWin;

	DXProcess* pProcess = pThreadData->pProcess;
    pProcess->resize(g_uiWidth, g_uiHeight);

	CBlueRenderDevice* pSink = pThreadData->pBlueRender;
    
    if (pProcess->createDownStream(g_uiWidth, g_uiHeight, 2))
    {
		unsigned long long* pBufferBusAddress = pSink->getBufferBusAddress();
        unsigned long long* pMarkerBusAddress = pSink->getMarkerBusAddress();
		pProcess->setRemoteMemory(pBufferBusAddress, pMarkerBusAddress);

		cout << __FUNCTION__ << ": g_hProcessReady" << endl;
		ReleaseSemaphore(g_hProcessReady, 1, NULL);
        
        while (g_pThreadData->bRunning)
        {
            if (pThreadData->bResizeSink)
            {
                pProcess->resize(pMyWin->getWidth(), pMyWin->getHeight());
                g_pThreadData->bResizeSink = false;
            }

            pProcess->draw();
        }   
    }

    g_pThreadData->bRunning = false;

	pThreadData->pBlueCapture->m_bIsCapturing = FALSE;
	pThreadData->pBlueRender->m_bIsPlaying = FALSE;
	pThreadData->pProcess->m_bIsProcessing = FALSE;

    WaitForSingleObject(g_hSourceDone, INFINITE);
	WaitForSingleObject(g_hSinkDone, INFINITE);

    // Make sure WinMain is not blocked in GetMessage
    PostMessage(g_pThreadData->pSinkWin->getWnd(), WM_QUIT, 0, 0);
    delete pProcess;

	return 0;
}

DWORD WINAPI SinkThreadFunc(LPVOID lpArgs)
{
	ThreadData* pThreadData = (ThreadData*)lpArgs;

	if(!pThreadData || !pThreadData->pBlueRender)
	{
		cout << __FUNCTION__ << ": BAIL: pointers not set!" << endl;
		g_pThreadData->bRunning = false;
		ReleaseSemaphore(g_hSinkDone, 1, 0);
        return 0;
	}

	BlueTimer bm;
	int bmFrameCount = 0;
	bm.Init();
	double dTimeDelta;
	double dMax = 0.0;
	double dMin = 999999.0;
	double dSum = 0.0;

	CBlueRenderDevice* pSink = pThreadData->pBlueRender;
	pSink->m_bIsPlaying = TRUE;
   
	cout << __FUNCTION__ << ": g_hSinkReady" << endl;
	ReleaseSemaphore(g_hSinkReady, 1, NULL);

	// Wait until Source thread is initialized
	if(WaitForSingleObject(g_hSourceReady, THREAD_WAIT_TIMEOUT) == WAIT_TIMEOUT)
	{
		cout << __FUNCTION__ << ": BAIL: Wait time out" << endl;
		g_pThreadData->bRunning = false;
	}

	cout << "Entering loop..." << endl;
	//start in synch with the video output interrupt; in FIELD mode we have to wait for the field 2 interrupt
	pSink->WaitForOutputClock();
	unsigned int FieldCount = pSink->WaitForOutputClock();
	if(pSink->m_nUpdateFormat == UPD_FMT_FIELD && !(FieldCount & 0x1))
		pSink->WaitForOutputClock();
	while(g_pThreadData->bRunning)
	{
		bm.GetTime();
		pSink->RenderVideoFrame();
		dTimeDelta = bm.GetTime();

		bmFrameCount++;
		if(dTimeDelta > dMax) dMax = dTimeDelta;
		if(dTimeDelta < dMin) dMin = dTimeDelta;
		dSum += dTimeDelta;
		if(bmFrameCount >= 100)
		{
			/*cout << "Avg: " << (float)(dSum/bmFrameCount) << ", Min: " << (float)(dMin) << ", Max: " << (float)(dMax) <<
				", Fi " << pSink->m_iDroppedFields << ", Fr " << pSink->m_iDroppedFrames << endl;*/
			cout << "Dropped Fields: " << pSink->m_iDroppedFields << ", Dropped Frames: " << pSink->m_iDroppedFrames << endl;
			bmFrameCount = 0;
			dSum = 0.0;
			dMax = 0.0;
			dMin = 999999.0;
		}



		pSink->WaitForOutputClock();
	}
	cout << "...Exiting thread" << endl;

    g_pThreadData->bRunning = false;
	pThreadData->pBlueCapture->m_bIsCapturing = FALSE;
	pThreadData->pBlueRender->m_bIsPlaying = FALSE;
	pThreadData->pProcess->m_bIsProcessing = FALSE;

	ReleaseSemaphore(g_hSinkDone, 1, 0);

    return 0;
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nShowCmd)
{
	WNDCLASSEX      wndclass;
    const LPCSTR    cClassName  = "DirectX";
    const LPCSTR    cWindowName = "BLUEFISH SDI to GPU DX P2P Copy";

	MessageBox(NULL, "", "", MB_OK);

    // Register WindowClass
    wndclass.cbSize         = sizeof(WNDCLASSEX);
    wndclass.style          = CS_OWNDC;
    wndclass.lpfnWndProc    = WndProc;
    wndclass.cbClsExtra     = 0;
    wndclass.cbWndExtra     = 0;
    wndclass.hInstance      = (HINSTANCE)GetModuleHandle(NULL);
    wndclass.hIcon          = LoadIcon(NULL, IDI_APPLICATION); 
    wndclass.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wndclass.hbrBackground  = NULL;
    wndclass.lpszMenuName   = NULL;
    wndclass.lpszClassName  = cClassName;
    wndclass.hIconSm        = LoadIcon(NULL, IDI_APPLICATION);

    if (!RegisterClassEx(&wndclass))
        return WM_QUIT;

	//Create console for stdout:
#if 1
	if(AllocConsole())
	{
		HANDLE handle_out = GetStdHandle(STD_OUTPUT_HANDLE);
		int hCrt = _open_osfhandle((long)handle_out, _O_TEXT);
		FILE* hf_out = _fdopen(hCrt, "w");
		setvbuf(hf_out, NULL, _IONBF, 1);
		*stdout = *hf_out;

		HANDLE handle_in = GetStdHandle(STD_INPUT_HANDLE);
		hCrt = _open_osfhandle((long) handle_in, _O_TEXT);
		FILE* hf_in = _fdopen(hCrt, "r");
		setvbuf(hf_in, NULL, _IONBF, 128);
		*stdin = *hf_in;
	}
#endif
	DXWindow* pSinkWin = new DXWindow("DX Sink", cClassName);
	CBlueCaptureDevice* pBlueCapture = new CBlueCaptureDevice();
	CBlueRenderDevice* pBlueRender = new CBlueRenderDevice(1, BLUE_VIDEO_OUTPUT_CHANNEL_A);

	if(!pBlueCapture->Init() || !pBlueCapture->IsVideoInputValid())
    {
		cout << "Error on BlueCapturedevice init" << endl;
		system("pause");
		return 0;
    }

	unsigned int iVideoMode = pBlueCapture->m_nVideoMode;
	if(!pBlueRender->Init(iVideoMode))
    {
		cout << "Error on Bluedevice init" << endl;
		system("pause");
		return 0;
    }

	if(!pSinkWin->init())
	{
        MessageBox(NULL, "Could not init Window", cWindowName, MB_ICONERROR | MB_OK);
        return WM_QUIT;
	}

	if(pSinkWin->getNumDisplaysOnGPU(0) == 0)
    {
        MessageBox(NULL, "GPU does not have a Display mapped!", cWindowName, MB_ICONERROR | MB_OK);
        return WM_QUIT;
    }

    // Create window on first Dsiplay of GPU 0
    unsigned int uiDsp = pSinkWin->getDisplayOnGPU(0, 0);
    
    pSinkWin->create(g_uiWidth, g_uiHeight, uiDsp);
    pSinkWin->open();

	DXProcess* pProcess = new DXProcess;
	pProcess->initDX(pSinkWin->getWnd());

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	g_pThreadData = new ThreadData;
    g_pThreadData->bRunning      = true;
    g_pThreadData->bResizeSink   = false;
    g_pThreadData->bResizeSource = false;
    g_pThreadData->pSinkWin      = pSinkWin;
	g_pThreadData->pBlueCapture  = pBlueCapture;
	g_pThreadData->pBlueRender   = pBlueRender;
	g_pThreadData->pProcess		 = pProcess;

	// Create semaphore to indicate that the init of the Sink is ready
    g_hSinkReady = CreateSemaphore(NULL, 0, 1, NULL);
	// Create semaphore to indicate that the Sink has terminated
	g_hSinkDone = CreateSemaphore(NULL, 0, 1, NULL);
	// Create semaphore to indicate that the init of the Process is ready
    g_hProcessReady = CreateSemaphore(NULL, 0, 1, NULL);
	// Create semaphore to indicate that the Process has terminated
	g_hProcessDone = CreateSemaphore(NULL, 0, 1, NULL);
    // Create semaphore to indicate that the init of the source is done
    g_hSourceReady = CreateSemaphore(NULL, 0, 1, NULL);
    // Create semaphore to indicate that the Source has terminated
    g_hSourceDone  = CreateSemaphore(NULL, 0, 1, NULL);

	DWORD dwSourceThreadId;
    DWORD dwSinkThreadId;
	DWORD dwProcessThreadId;

    HANDLE hSourceThread = CreateThread(NULL, 0, SourceThreadFunc, g_pThreadData,   0, &dwSourceThreadId);
	HANDLE hProcessThread = CreateThread(NULL, 0, ProcessThreadFunc, g_pThreadData,   0, &dwProcessThreadId);
    HANDLE hSinkThread   = CreateThread(NULL, 0, SinkThreadFunc,   g_pThreadData,   0, &dwSinkThreadId);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Run message loop
    MSG Msg;
    while(GetMessage(&Msg, NULL, 0, 0))
    {
	    TranslateMessage(&Msg);
		DispatchMessage(&Msg);
    }

	g_pThreadData->bRunning = false;

    WaitForSingleObject(hSourceThread, INFINITE);
	WaitForSingleObject(hProcessThread, INFINITE);
    WaitForSingleObject(hSinkThread,   INFINITE);

	CloseHandle(g_hSinkReady);
	CloseHandle(g_hSinkDone);
	CloseHandle(g_hProcessReady);
	CloseHandle(g_hProcessDone);
	CloseHandle(g_hSourceReady);
	CloseHandle(g_hSourceDone);

	delete pSinkWin;
	delete pBlueCapture;
	delete pBlueRender;

	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    static int nLastx = 0;
    static int nLasty = 0;

    switch (uMsg)
    {
        char c;

        case WM_CHAR:
            c = (char)wParam;

            switch (c)
            {
            case VK_ESCAPE:
                PostQuitMessage(0);
		        break;
            }
            return 0;

        case WM_CREATE:
            return 0;

        case WM_SIZE:
            return 0;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
