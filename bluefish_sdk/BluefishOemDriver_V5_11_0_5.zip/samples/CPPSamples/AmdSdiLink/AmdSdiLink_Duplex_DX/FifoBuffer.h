#ifndef H_GUARD_FIFOBUFFER
#define H_GUARD_FIFOBUFFER

#include <queue>
#include "BlueLock.h"
using namespace std;


class CFrameData
{
public:
	CFrameData();
	~CFrameData();

public:
	unsigned int       uiBufferId;
    unsigned int       uiTransferId;
    unsigned long long ullBufferBusAddress;
    unsigned long long ullMarkerBusAddress;
};
/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
class CFifoBuffer
{
public:
	CFifoBuffer();
	~CFifoBuffer();

	void	Init(unsigned int Count, ULONG64* pBusAddress, ULONG64* pMarkerAddress);

	void	PutFreeBuffer(CFrameData* pFrame);
	void	PutLiveBuffer(CFrameData* pFrame);
	CFrameData* GetFreeBuffer();
	CFrameData* GetLiveBuffer();

private:
	queue<CFrameData*>	m_qFreeBuffers;
	queue<CFrameData*>	m_qLiveBuffers;
	queue<CFrameData*>	m_qBuffers;
	HANDLE			m_hFreeMutexEmpty;
	HANDLE			m_hFreeMutexLive;
	HANDLE			m_hLiveMutexEmpty;
	HANDLE			m_hLiveMutexLive;
	BlueLock		m_FreeLock;
	BlueLock		m_LiveLock;
};


#endif	//H_GUARD_FIFOBUFFER
