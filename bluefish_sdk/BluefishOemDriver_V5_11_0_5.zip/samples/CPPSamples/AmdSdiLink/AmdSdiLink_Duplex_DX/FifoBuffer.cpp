#include <Windows.h>
#include "FifoBuffer.h"

CFrameData::CFrameData() :
	uiBufferId(0),
    uiTransferId(0),
    ullBufferBusAddress(0),
    ullMarkerBusAddress(0)
{
}

CFrameData::~CFrameData()
{
}
/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
CFifoBuffer::CFifoBuffer() :
	m_hFreeMutexEmpty(NULL),
	m_hFreeMutexLive(NULL),
	m_hLiveMutexEmpty(NULL),
	m_hLiveMutexLive(NULL)
{
}

CFifoBuffer::~CFifoBuffer()
{
	while(!m_qFreeBuffers.empty())
	{
		m_FreeLock.lock();
		m_qFreeBuffers.front();
		m_qFreeBuffers.pop();
		m_FreeLock.unlock();
	}

	while(!m_qLiveBuffers.empty())
	{
		m_LiveLock.lock();
		m_qLiveBuffers.front();
		m_qLiveBuffers.pop();
		m_LiveLock.unlock();
	}

	CFrameData* pFrame = NULL;
	while(!m_qBuffers.empty())
	{
		pFrame = m_qBuffers.front();
		m_qBuffers.pop();
		delete pFrame;
		pFrame = NULL;
	}

	if(m_hFreeMutexEmpty)	CloseHandle(m_hFreeMutexEmpty);	m_hFreeMutexEmpty = NULL;
	if(m_hFreeMutexLive)	CloseHandle(m_hFreeMutexLive);	m_hFreeMutexLive = NULL;
	if(m_hLiveMutexEmpty)	CloseHandle(m_hLiveMutexEmpty);	m_hLiveMutexEmpty = NULL;
	if(m_hLiveMutexLive)	CloseHandle(m_hLiveMutexLive);	m_hLiveMutexLive = NULL;
}

void CFifoBuffer::Init(unsigned int Count, ULONG64* pBusAddress, ULONG64* pMarkerAddress)
{
	CFrameData* pFrame = NULL;
	for(unsigned int n=0; n<Count; n++)
	{
		pFrame = new CFrameData();

		pFrame->uiBufferId = n;
		pFrame->uiTransferId = 0;
		pFrame->ullBufferBusAddress = pBusAddress[n];
		pFrame->ullMarkerBusAddress = pMarkerAddress[n];

		m_qBuffers.push(pFrame);
		m_qFreeBuffers.push(pFrame);
	}

	if(m_hFreeMutexEmpty)	CloseHandle(m_hFreeMutexEmpty);	m_hFreeMutexEmpty = NULL;
	if(m_hFreeMutexLive)	CloseHandle(m_hFreeMutexLive);	m_hFreeMutexLive = NULL;
	if(m_hLiveMutexEmpty)	CloseHandle(m_hLiveMutexEmpty);	m_hLiveMutexEmpty = NULL;
	if(m_hLiveMutexLive)	CloseHandle(m_hLiveMutexLive);	m_hLiveMutexLive = NULL;

	m_hFreeMutexEmpty = CreateSemaphore(NULL, 0, (LONG)Count, NULL);	//signal that we can't add any buffers to the free queue
    m_hFreeMutexLive = CreateSemaphore(NULL, (LONG)Count, (LONG)Count, NULL);	//signal that we can add a buffer to the live queue as
																				//there are no buffers in the live queue
	m_hLiveMutexEmpty = CreateSemaphore(NULL, (LONG)Count, (LONG)Count, NULL);
    m_hLiveMutexLive = CreateSemaphore(NULL, 0, (LONG)Count, NULL);
}

void CFifoBuffer::PutFreeBuffer(CFrameData* pFrame)
{
	if(!pFrame)
		return;

	DWORD dwWaitResult = WaitForSingleObject(m_hFreeMutexEmpty, 100);	//decreases the semaphore
	if(dwWaitResult == WAIT_OBJECT_0)
	{
		m_FreeLock.lock();
		m_qFreeBuffers.push(pFrame);
		m_FreeLock.unlock();
		ReleaseSemaphore(m_hFreeMutexLive, 1, NULL);
	}
}

void CFifoBuffer::PutLiveBuffer(CFrameData* pFrame)
{
	if(!pFrame)
		return;

	DWORD dwWaitResult = WaitForSingleObject(m_hLiveMutexEmpty, 100);
	if(dwWaitResult == WAIT_OBJECT_0)
	{
		m_LiveLock.lock();
		m_qLiveBuffers.push(pFrame);
		m_LiveLock.unlock();
		ReleaseSemaphore(m_hLiveMutexLive, 1, NULL);
	}
}

CFrameData* CFifoBuffer::GetFreeBuffer()
{
	CFrameData* pFrame = NULL;
	//cout << "GetFreeBuffer" << endl;
	//DWORD dwWaitResult = WaitForSingleObject(m_hFreeMutexLive, 100);	//decreases the semaphore
	DWORD dwWaitResult = WaitForSingleObject(m_hFreeMutexLive, 5);	//decreases the semaphore
	if(dwWaitResult == WAIT_OBJECT_0)
	{
		m_FreeLock.lock();
		if(!m_qFreeBuffers.empty())
		{
			pFrame = m_qFreeBuffers.front();
			m_qFreeBuffers.pop();
		}
		m_FreeLock.unlock();
		ReleaseSemaphore(m_hFreeMutexEmpty, 1, NULL);
	}

	return pFrame;
}

CFrameData* CFifoBuffer::GetLiveBuffer()
{
	CFrameData* pFrame = NULL;
	//cout << "GetLiveBuffer" << endl;
	//DWORD dwWaitResult = WaitForSingleObject(m_hLiveMutexLive, 100);	//decreases the semaphore
	DWORD dwWaitResult = WaitForSingleObject(m_hLiveMutexLive, 0);	//decreases the semaphore
	if(dwWaitResult == WAIT_OBJECT_0)
	{
		m_LiveLock.lock();
		if(!m_qLiveBuffers.empty())
		{
			pFrame = m_qLiveBuffers.front();
			m_qLiveBuffers.pop();
		}
		m_LiveLock.unlock();
		ReleaseSemaphore(m_hLiveMutexEmpty, 1, NULL);
	}

	return pFrame;
}
