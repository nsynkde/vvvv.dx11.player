#ifndef _AMD_SDI_HELPER_H_
#define _AMD_SDI_HELPER_H_

// This sample needs 
// - The version of SDI DDI/API header files           >= 1.1
// - The version of atiumdag.dll/atiumd64.dll binaries >= 9.14.10.926 

#include <d3d9.h>
#include <d3dx9.h>
#include <d3d9types.h>
#include <assert.h>
#include <stdio.h>

#include "amddx9extsdi.h"

#ifdef _DEBUG
#pragma warning( disable : 4996 ) // disable deprecated warning
static inline int PrintDebugMsg( const char *fmt, ...)
{
    int rslt = 0;
    va_list va;
    char sErrBuf[1024];
    va_start(va, fmt);
    rslt = vsnprintf( sErrBuf, 1024, fmt, va );
    va_end(va);
    ::OutputDebugStringA( sErrBuf );
    return rslt;
}
#else
#define PrintDebugMsg
#endif

#define SDI_ASSERT assert
#define TEST_FAIL(x) if (FAILED(x)) { assert(0); return E_FAIL; }
#define REL(x) {if(x) {(x)->Release(); (x) = NULL;}}

#define MEM_PITCH_ALIGNMENT 64
#define GET_ALIGNED_WIDTH(w) ((w + (MEM_PITCH_ALIGNMENT - 1))&(~(MEM_PITCH_ALIGNMENT - 1)))

// SDI fundamental functions
HRESULT RunSDICommand(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  AMDDX9SDICMD sdiCmd,
    IN  PBYTE pInBuf,
    IN  DWORD dwInBufSize,
    IN  PBYTE pOutBuf,
    IN  DWORD dwOutBufSize);

HRESULT GetAMDDX9SDICaps(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    OUT AMDDX9SDICAPS *sdiCaps);

HRESULT SetAMDDX9SDICaps(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DWORD dwSDICaps);

HRESULT SyncSurfData(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DX9RES_HANDLE surfaceHandle,
    IN  BOOL bSurfaceToPixelBuffer = FALSE);

// SDI pinned mode
HRESULT CreatePinnedSysMemTextureEx(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DWORD width,
    IN  DWORD height,
    IN  DWORD bytesPerPixel,
    IN  DWORD usage,
    IN  D3DFORMAT format,
    OUT LPDIRECT3DTEXTURE9 *ppTex,
    OUT PVOID *ppSysMem,
    OUT DX9RES_HANDLE *pResHandle);

HRESULT DestroyPinnedSysMemTextureEx(
    OUT LPDIRECT3DTEXTURE9 *ppTex,
    OUT PVOID *ppSysMem);

// SDI p2p mode
HRESULT CreateP2PLocalTexture(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DWORD width,
    IN  DWORD height,
    IN  DWORD usage,
    IN  D3DFORMAT format,
    OUT LPDIRECT3DTEXTURE9 *ppTex,
    OUT PAMDDX9SDISURFACEATTRIBUTES pAttrib);

HRESULT DestroyP2PLocalTexture (
    OUT LPDIRECT3DTEXTURE9 *ppTex);

HRESULT CreateP2PRemoteTexture(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DWORD width,
    IN  DWORD height,
    IN  DWORD usage,
    IN  D3DFORMAT format,
    IN  PAMDDX9SDISURFACEATTRIBUTES pAttrib,
    OUT LPDIRECT3DTEXTURE9 *ppTex);

HRESULT DestroyP2PRemoteTexture (
    OUT LPDIRECT3DTEXTURE9 *ppTex);

HRESULT DestroyP2PRemoteTexture (
    OUT LPDIRECT3DTEXTURE9 *ppTex);

HRESULT QueryP2PLocalTextureAttributes (
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DX9RES_HANDLE surfaceHandle,
    OUT PAMDDX9SDISURFACEADDRESS pSurfaceAddress);

HRESULT P2PWaitMarker(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DX9RES_HANDLE surfaceHandle,
    IN  DWORD markerValue);

HRESULT P2PWriteMarker(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DX9RES_HANDLE surfaceHandle,
    IN  ULONG64 markerOffset,
    IN  DWORD markerValue);

#endif