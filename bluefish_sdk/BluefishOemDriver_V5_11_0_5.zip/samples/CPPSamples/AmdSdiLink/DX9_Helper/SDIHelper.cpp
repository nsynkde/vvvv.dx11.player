#pragma warning( disable : 4996 ) // disable deprecated warning
#include "SDIHelper.h"

inline void* aligned_malloc(size_t bytes, size_t start_addr_alignment, size_t size_alignment)
{
    void *pMalloc = NULL;
    void *pAlign = NULL;
    if (bytes <= 0) {
        PrintDebugMsg("Exception: input bytes should greater than 0\n");
        return NULL;
    }

    bytes = (bytes + (size_alignment-1)) & (~(size_alignment-1));

    // check whether the alignment is a power of 2.
    if (start_addr_alignment & (start_addr_alignment - 1)) {
        PrintDebugMsg("Exception: input alignment should be a power of 2.\n");
        return NULL;
    }
    // force the alignment to sizeof(void *), otherwise there might be some problem with free
    start_addr_alignment = (start_addr_alignment < sizeof (void *)) ? sizeof (void *) : start_addr_alignment;

    bytes += start_addr_alignment;

    if (NULL == (pMalloc = malloc (bytes)))
    {
        PrintDebugMsg("Exception: malloc fail!\n");
        return NULL;
    }
    else
    {
        memset(pMalloc, 0, bytes);
        // ensure there are (1,2,...,alignment) slots before malloc result pointer
        pAlign = (void *) (((size_t) pMalloc + start_addr_alignment) & ~(start_addr_alignment-1));
        // store real malloc pointer's addr
        *(void **) ((size_t)pAlign - sizeof(void *)) = pMalloc;
        return pAlign;
    }
    return NULL;
}

void aligned_free(void *p)
{
    if (p != NULL) {
        free (*(void **) ((size_t)p - sizeof(void *)));
    }
}

// By default, 256B starting address alignment, and 4KB size alignment
#define SDI_MALLOC(x) aligned_malloc(x, 256, 4096)

#define SDI_FREE(x) aligned_free(x)

/*
****************************************************************************
*
* RunSDICommand
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   sdiCmd         - command id defined in AMDDX9SDICMD
*   pInBuf         - pointer to the input buffer
*   dwInBufSize    - size the input buffer
*   pOutBuf        - pointer to the output buffer
*   dwOutBufSize   - size the output buffer
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Assemble SDI command the call driver to execute
*
****************************************************************************
*/
HRESULT RunSDICommand(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  AMDDX9SDICMD sdiCmd,
    IN  PBYTE pInBuf,
    IN  DWORD dwInBufSize,
    IN  PBYTE pOutBuf,
    IN  DWORD dwOutBufSize)
{
    HRESULT hr;
    PAMDDX9SDICOMMPACKET pCommPacket;
    D3DLOCKED_RECT lockedRect;
    LPDIRECT3DSURFACE9 pCommSurf    = NULL;

    hr = pd3dDevice->CreateOffscreenPlainSurface(1, 1, (D3DFORMAT) FOURCC_SDIF, D3DPOOL_DEFAULT, &pCommSurf, NULL);

    hr = pCommSurf->LockRect(&lockedRect, NULL, 0);
    if(FAILED(hr) || lockedRect.pBits == NULL)
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] comm surface locking failed hr:0x%X.\n", (DWORD)hr);
    }
    pCommPacket = (PAMDDX9SDICOMMPACKET)(lockedRect.pBits);
    pCommPacket->dwSign = 'SDIF';
    pCommPacket->pResult = &hr;
    pCommPacket->sdiCmd = sdiCmd;
    pCommPacket->pOutBuf = pOutBuf;
    pCommPacket->dwOutBufSize = dwOutBufSize;
    pCommPacket->pInBuf = pInBuf;
    pCommPacket->dwInBufSize = dwInBufSize;
    pCommSurf->UnlockRect();

    REL(pCommSurf);

    return hr;
}

/*
****************************************************************************
*
* GetAMDDX9SDICaps
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   sdiCaps        - pointer to the output AMDDX9SDICAPS
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Get SDI caps from driver
*
****************************************************************************
*/
HRESULT GetAMDDX9SDICaps(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    OUT AMDDX9SDICAPS *sdiCaps)
{
    HRESULT hr = E_FAIL;

    SDI_ASSERT (sdiCaps != NULL);

    hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_GET_CAPS_DATA, NULL, 0, (PBYTE)sdiCaps, sizeof(AMDDX9SDICAPS));
    if (FAILED(hr))
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] Get AMD DX9 SDI Caps failed hr:0x%X.\n", (DWORD)hr);
    }
    else
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] AMD DX9 SDI Ver:%d.%d, Caps: Pinned-P2P:%s, Direct-P2P: %s, MaxCmdNum:%d\n",
            (sdiCaps->dwVersion >> 16),
            (sdiCaps->dwVersion & 0xFFFF),
            (sdiCaps->dwCaps & AMD_DX9_SDI_CAPS_PINNED_P2P)? "Y":"N",
            (sdiCaps->dwCaps & AMD_DX9_SDI_CAPS_DIRECT_P2P)? "Y":"N",
            sdiCaps->dwMaxCommand);

        if (sdiCaps->dwVersion > AMD_DX9_SDI_VERSION)
        {
            // DDI_SDI_Ver > API_SDI_Ver
            // SDI driver backward compatibility check, for new drivers, 
            // In general, we provide backward compatibility, unless there would be major/critical
            // changes on existing commands although the frequency/possibility of such should be low
            // result = E_NOTIMPL;
            SDI_ASSERT(0);
        }
        else if (sdiCaps->dwVersion < AMD_DX9_SDI_VERSION)
        {
            // DDI_SDI_Ver < API_SDI_Ver
            // SDI driver forward compatibility check, returns DDERR_UNSUPPORTED/E_NOTIMPL here for old drivers.
            hr = E_NOTIMPL;
        }
    }
    return hr;
}

/*
****************************************************************************
*
* SetAMDDX9SDICaps
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   dwSDICaps      - input AMDDX9SDICAPS
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Set SDI caps from driver
*
****************************************************************************
*/
HRESULT SetAMDDX9SDICaps(
    IN LPDIRECT3DDEVICE9 pd3dDevice,
    IN DWORD dwSDICaps)
{
    HRESULT hr = E_FAIL;

    hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_SET_CAPS, (PBYTE)&dwSDICaps, sizeof(DWORD), NULL, 0);
    if (FAILED(hr))
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] Set AMD DX9 SDI Caps failed hr:0x%X.\n", (DWORD)hr);
    }
    return S_OK;
}

/*
****************************************************************************
*
* SyncSurfData
*
* Args:
*   pd3dDevice              - pointer to DIRECT3DDEVICE9
*   surfaceHandle           - input surface handle
*   bSurfaceToPixelBuffer   - input bool to control the sync direction
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Sync the surface data from/to the attached pixel buffer, especially
*   for unpacked-pitch surfaces.
*
****************************************************************************
*/
HRESULT SyncSurfData(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DX9RES_HANDLE surfaceHandle,
    IN  BOOL bSurfaceToPixelBuffer)
{
    HRESULT hr = S_OK;
    AMDDX9SDISURFSYNCPARAM sync;

    sync.surfaceHandle = surfaceHandle;
    sync.surfaceToPixelBuffer = bSurfaceToPixelBuffer;

    hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_SYNC_SURFACE_DATA, (PBYTE)&sync, sizeof(AMDDX9SDISURFSYNCPARAM), NULL, 0);

    if (SUCCEEDED(hr))
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] SDI surface is synchronized.\n");
        PrintDebugMsg("[SDITest]["__FUNCTION__"] surfaceHandle:0x%I64X, bSurfaceToPixelBuffer:%d.\n",
            sync.surfaceHandle,
            sync.surfaceToPixelBuffer);
    }
    else
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] SDI surface synchronization failed hr:0x%X.\n", (DWORD)hr);
    }
    return hr;
}

/*
****************************************************************************
*
* MakeAllocDoneViaDumpDraw
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   pTex           - pointer the texture backing store in which we want to
*                    get the allocation really done in OS VidMem, so the
*                    bus address can be obtained successfully at once
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Make the allocation done via a dump and quick draw
*
****************************************************************************
*/
HRESULT MakeAllocDoneViaDumpDraw(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  LPDIRECT3DTEXTURE9 pTex)
{
    HRESULT hr = S_OK;

    if( pd3dDevice != NULL && SUCCEEDED( pd3dDevice->BeginScene() ) )
    {
        LPDIRECT3DSURFACE9    pRTSurf     = NULL;

        D3DXVECTOR4 vDummyPoint(0.0f, 0.0f, 0.0f, 1.0f);
        pd3dDevice->SetFVF(D3DFVF_XYZW);
        pd3dDevice->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE);
        pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE, FALSE );
        pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE, 0x0 );
        hr = pd3dDevice->SetTexture(0, pTex);
        // TBD.
        pd3dDevice->GetRenderTarget(0, &pRTSurf);
        hr = pd3dDevice->SetRenderTarget(0, pRTSurf);
        hr = pd3dDevice->DrawPrimitiveUP(D3DPT_POINTLIST, 1, vDummyPoint, sizeof(D3DXVECTOR4));
        pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
        pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
        pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE, 0xF);

        REL(pRTSurf);
        pd3dDevice->EndScene();
    }

    return hr;
}

/*
****************************************************************************
*
* CreateP2PLocalTexture
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   width          - input width of the texture
*   height         - input height of the texture
*   usage          - input usage of the texture
*   format         - input format of the texture
*   ppTex          - output pointer to the created texture
*   pAttrib        - output pointer to the attribute of created SDI surface
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Create SDI p2p local buffer
*
****************************************************************************
*/
HRESULT CreateP2PLocalTexture(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DWORD width,
    IN  DWORD height,
    IN  DWORD usage,
    IN  D3DFORMAT format,
    OUT LPDIRECT3DTEXTURE9 *ppTex,
    OUT PAMDDX9SDISURFACEATTRIBUTES pAttrib)
{
    HRESULT hr = S_OK;

    SDI_ASSERT(pAttrib != NULL);

    hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_CREATE_SURFACE_LOCAL_BEGIN, NULL, 0, NULL, 0);
    if (FAILED(hr))
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] Start creating SDI_LOCAL resources failed hr:0x%X.\n", (DWORD)hr);
    }
    else
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] Start creating SDI_LOCAL resources succeeded.\n");
        // Create SDI_LOCAL resources here
        hr = pd3dDevice->CreateTexture(width, height, 1, usage, format, D3DPOOL_DEFAULT, ppTex, NULL);

        if (SUCCEEDED(hr))
        {
            hr = MakeAllocDoneViaDumpDraw( pd3dDevice, *ppTex );
            hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_CREATE_SURFACE_LOCAL_END, NULL, 0, (PBYTE)pAttrib, sizeof(AMDDX9SDISURFACEATTRIBUTES));
            if (SUCCEEDED(hr))
            {
                PrintDebugMsg("[SDITest]["__FUNCTION__"] Complete creating SDI_LOCAL resources succeeded.\n");
                PrintDebugMsg("[SDITest]["__FUNCTION__"] surfaceHandle:0x%I64X, surfaceBusAddr: 0x%I64X, markerBusAddr: 0x%I64X.\n",
                    pAttrib->surfaceHandle,
                    pAttrib->surfaceAddr.surfaceBusAddr,
                    pAttrib->surfaceAddr.markerBusAddr);
            }
            else
            {
                PrintDebugMsg("[SDITest]["__FUNCTION__"] Complete creating SDI_LOCAL resources failed hr:0x%X.\n", (DWORD)hr);
            }
        }
    }
    return hr;
}

/*
****************************************************************************
*
* DestroyP2PLocalTexture
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   ppTex          - input/output pointer to the texture
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Destroy SDI p2p local buffer
*
****************************************************************************
*/
HRESULT DestroyP2PLocalTexture (
    OUT LPDIRECT3DTEXTURE9 *ppTex)
{
    REL(*ppTex);
    return S_OK;
}

/*
****************************************************************************
*
* CreateP2PRemoteTexture
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   width          - input width of the texture
*   height         - input height of the texture
*   usage          - input usage of the texture
*   format         - input format of the texture
*   pAttrib        - input pointer to the attribute of created SDI surface
*   ppTex          - output pointer to the created texture
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Create SDI p2p remote buffer
*
****************************************************************************
*/
HRESULT CreateP2PRemoteTexture(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DWORD width,
    IN  DWORD height,
    IN  DWORD usage,
    IN  D3DFORMAT format,
    IN  PAMDDX9SDISURFACEATTRIBUTES pAttrib,
    OUT LPDIRECT3DTEXTURE9 *ppTex)
{
    HRESULT hr = S_OK;

    SDI_ASSERT(pAttrib != NULL);

    hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_CREATE_SURFACE_REMOTE_BEGIN, NULL, 0, NULL, 0);
    if (FAILED(hr))
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] Start creating SDI_REMOTE resources failed hr:0x%X.\n", (DWORD)hr);
    }
    else
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] Start creating SDI_REMOTE resources succeeded.\n");
        // Create SDI_REMOTE resources here
        hr = pd3dDevice->CreateTexture(width, height, 1, usage, format, D3DPOOL_DEFAULT, ppTex, NULL);

        if (SUCCEEDED(hr))
        {
            hr = MakeAllocDoneViaDumpDraw( pd3dDevice, *ppTex );
            hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_CREATE_SURFACE_REMOTE_END, (PBYTE)&(pAttrib->surfaceAddr), sizeof(AMDDX9SDISURFACEADDRESS), (PBYTE)&(pAttrib->surfaceHandle), sizeof(DX9RES_HANDLE));

            if (SUCCEEDED(hr))
            {
                PrintDebugMsg("[SDITest]["__FUNCTION__"] Complete creating SDI_REMOTE resources succeeded.\n");
                PrintDebugMsg("[SDITest]["__FUNCTION__"] surfaceHandle:0x%I64X, surfaceBusAddr: 0x%I64X, markerBusAddr: 0x%I64X.\n",
                    pAttrib->surfaceHandle,
                    pAttrib->surfaceAddr.surfaceBusAddr,
                    pAttrib->surfaceAddr.markerBusAddr);
            }
            else
            {
                PrintDebugMsg("[SDITest]["__FUNCTION__"] Complete creating SDI_REMOTE resources failed hr:0x%X.\n", (DWORD)hr);
            }
        }
    }
    return hr;
}

/*
****************************************************************************
*
* DestroyP2PRemoteTexture
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   ppTex          - input/output pointer to the texture
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Destroy SDI p2p remote buffer
*
****************************************************************************
*/
HRESULT DestroyP2PRemoteTexture (
    OUT LPDIRECT3DTEXTURE9 *ppTex)
{
    REL(*ppTex);
    return S_OK;
}

/*
****************************************************************************
*
* QueryP2PLocalTextureAttributes
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   surfaceHandle  - input surface handle
*   pSurfaceAddress- output pointer to surface address info
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Query the attributes of created p2p local buffer/texture
*
****************************************************************************
*/
HRESULT QueryP2PLocalTextureAttributes (
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DX9RES_HANDLE surfaceHandle,
    OUT PAMDDX9SDISURFACEADDRESS pSurfaceAddress)
{
    HRESULT hr = S_OK;

    SDI_ASSERT (pSurfaceAddress != NULL);

    hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_QUERY_PHY_ADDRESS_LOCAL, (PBYTE)&surfaceHandle, sizeof(DX9RES_HANDLE), (PBYTE)pSurfaceAddress, sizeof(AMDDX9SDISURFACEADDRESS));

    if (SUCCEEDED(hr))
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] Query SDI surface attributes succeeded.\n");
        PrintDebugMsg("[SDITest]["__FUNCTION__"] surfaceHandle:0x%I64X, surfaceBusAddr: 0x%I64X, markerBusAddr: 0x%I64X.\n",
            surfaceHandle,
            pSurfaceAddress->surfaceBusAddr,
            pSurfaceAddress->markerBusAddr);
    }
    else
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] Query SDI surface attributes failed hr:0x%X.\n", (DWORD)hr);
    }

    return hr;
}

/*
****************************************************************************
*
* P2PWaitMarker
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   surfaceHandle  - input surface handle
*   markerValue    - input SDI marker value to be awaited.
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Perform p2p marker wait
*
****************************************************************************
*/
HRESULT P2PWaitMarker(
    IN LPDIRECT3DDEVICE9 pd3dDevice,
    IN DX9RES_HANDLE surfaceHandle,
    IN DWORD markerValue)
{
    HRESULT hr = S_OK;
    AMDDX9SDIWAITMARKERPARAM markerWait;

    markerWait.surfaceHandle = surfaceHandle;
    markerWait.markerValue = markerValue;
    hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_SYNC_WAIT_MARKER, (PBYTE)&markerWait, sizeof(AMDDX9SDIWAITMARKERPARAM), NULL, 0);

    if (SUCCEEDED(hr))
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] SDI wait marker succeeded.\n");
        PrintDebugMsg("[SDITest]["__FUNCTION__"] surfaceHandle:0x%I64X, markerValue: 0x%X.\n",
            markerWait.surfaceHandle,
            markerWait.markerValue);
    }
    else
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] SDI wait marker failed hr:0x%X.\n", (DWORD)hr);
    }
    return hr;
}

/*
****************************************************************************
*
* P2PWriteMarker
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   surfaceHandle  - input surface handle
*   markerOffset   - input address offset of the location of SDI marker
*   markerValue    - input SDI marker value to be awaited.
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Perform p2p marker write
*
****************************************************************************
*/
HRESULT P2PWriteMarker(
    IN LPDIRECT3DDEVICE9 pd3dDevice,
    IN DX9RES_HANDLE surfaceHandle,
    IN ULONG64 markerOffset,
    IN DWORD markerValue)
{
    HRESULT hr = S_OK;
    AMDDX9SDIWRITEMARKERPARAM markerWrite;

    markerWrite.surfaceHandle = surfaceHandle;
    markerWrite.markerOffset = markerOffset;
    markerWrite.markerValue = markerValue;
    hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_SYNC_WRITE_MARKER, (PBYTE)&markerWrite, sizeof(AMDDX9SDIWRITEMARKERPARAM), NULL, 0);

    if (SUCCEEDED(hr))
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] SDI write marker succeeded.\n");
        PrintDebugMsg("[SDITest]["__FUNCTION__"] surfaceHandle:0x%I64X, markerOffset: 0x%I64X, markerValue: 0x%X.\n",
            markerWrite.surfaceHandle,
            markerWrite.markerOffset,
            markerWrite.markerValue);
    }
    else
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] SDI write marker failed hr:0x%X, surfaceHandle:0x%I64X, markerOffset: 0x%I64X, markerValue: 0x%X.\n",
			(DWORD)hr,
            markerWrite.surfaceHandle,
            markerWrite.markerOffset,
            markerWrite.markerValue);
    }
    return hr;
}

/*
****************************************************************************
*
* CreatePinnedSysMemTextureEx
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   width          - input width of the texture
*   height         - input height of the texture
*   bytesPerPixel  - input bytesPerPixel of the texture
*   usage          - input usage of the texture
*   format         - input format of the texture
*   ppTex          - output pointer to the created texture
*   ppSysMem       - output pointer to pinned system memory
*   pResHandle     - output pointer to the resource handle of the created texture
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Create SDI pinned buffer
*
****************************************************************************
*/
HRESULT CreatePinnedSysMemTextureEx(
    IN  LPDIRECT3DDEVICE9 pd3dDevice,
    IN  DWORD width,
    IN  DWORD height,
    IN  DWORD bytesPerPixel,
    IN  DWORD usage,
    IN  D3DFORMAT format,
    OUT LPDIRECT3DTEXTURE9 *ppTex,
    OUT PVOID *ppSysMem,
    OUT DX9RES_HANDLE *pResHandle)
{
    HRESULT hr                      = E_FAIL;
    LPDIRECT3DTEXTURE9 pTex         = NULL;
    PBYTE   pTexSysMem              = NULL;
    ULONG64 sysMemAddr              = 0;

    SDI_ASSERT((width > 0) &&
        (height > 0) &&
        (bytesPerPixel > 0) &&
        (ppTex != NULL)  &&
        (ppSysMem != NULL) &&
        (pResHandle != NULL));

    if (*ppSysMem)
    {
        sysMemAddr = (ULONG64)*ppSysMem;
    }
    else
    {
        pTexSysMem = (PBYTE) SDI_MALLOC( GET_ALIGNED_WIDTH(width) * height * bytesPerPixel );
        if (pTexSysMem == NULL)
        {
            return E_FAIL;
        }
        sysMemAddr = (ULONG64)pTexSysMem;
    }

    hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_CREATE_SURFACE_PINNED_SYSMEM_BEGIN, (PBYTE)&sysMemAddr, sizeof(ULONG64), NULL, 0);
    if (SUCCEEDED(hr))
    {

        hr = pd3dDevice->CreateTexture(width, height, 1, usage, format, D3DPOOL_DEFAULT, &pTex, NULL);
        if (SUCCEEDED(hr) && pTex != NULL)
        {
            hr = MakeAllocDoneViaDumpDraw(pd3dDevice, pTex );
            hr = RunSDICommand(pd3dDevice, AMD_SDI_CMD_CREATE_SURFACE_PINNED_SYSMEM_END, NULL, 0, (PBYTE)pResHandle, sizeof(DX9RES_HANDLE));
            if (SUCCEEDED(hr))
            {
                PrintDebugMsg("[SDITest]["__FUNCTION__"] Complete creating SDI_PINNED resources succeeded.\n");
                PrintDebugMsg("[SDITest]["__FUNCTION__"] surfaceHandle:0x%I64X.\n", *pResHandle);
            }
            else
            {
                PrintDebugMsg("[SDITest]["__FUNCTION__"] Complete creating SDI_PINNED resources failed hr:0x%X.\n", (DWORD)hr);
            }
        }
        else
        {
            PrintDebugMsg("[SDITest]["__FUNCTION__"] Create pinned sysmem failed hr:0x%X.\n", (DWORD)hr);
        }
    }
    else
    {
        PrintDebugMsg("[SDITest]["__FUNCTION__"] Send command: CREATE_PINNED_SYSMEM_BEGIN failed hr:0x%X.\n", (DWORD)hr);
    }

    if (SUCCEEDED(hr))
    {
        *ppTex = pTex;
        *ppSysMem = pTexSysMem;
    }
    return hr;
}

/*
****************************************************************************
*
* DestroyPinnedSysMemTextureEx
*
* Args:
*   pd3dDevice     - pointer to DIRECT3DDEVICE9
*   ppTex          - input/output pointer to the texture
*   ppSysMem       - input/output pointer to the pinned system memory
*
* Returns:
*   HRESULT        - the status of this function call
*
* Description:
*   Destroy SDI pinned buffer
*
****************************************************************************
*/
HRESULT DestroyPinnedSysMemTextureEx(
    OUT LPDIRECT3DTEXTURE9 *ppTex,
    OUT PVOID *ppSysMem)
{
    REL(*ppTex);
    if ( *ppSysMem != NULL )
    {
        SDI_FREE(*ppSysMem);
        *ppSysMem = NULL;
    }
    return S_OK;
}
