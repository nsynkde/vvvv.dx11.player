/**************************************************************

 This include file contains all the DX9 SDI extension definitions
 (structures, enums, constants) shared between the driver and the
 application.

 (c) Copyright AMD 2011.

***************************************************************/
#ifndef _AMD_DX9EXT_SDI_H_
#define _AMD_DX9EXT_SDI_H_

#define AMD_DX9_SDI_VERSION_MAJOR   1
#define AMD_DX9_SDI_VERSION_MINOR   1

#define AMD_DX9_SDI_VERSION     ((AMD_DX9_SDI_VERSION_MAJOR << 16) | AMD_DX9_SDI_VERSION_MINOR)
#define AMD_DX9_SDI_VERSION_STR AMD_DX9_SDI_VERSION_MAJOR "." AMD_DX9_SDI_VERSION_MINOR

#pragma pack(push, amd_dx9ext_sdi_h, 4)

// AMD DX9 SDI feature support indicator format
#define FOURCC_SDIF  MAKEFOURCC('S','D','I','F')

// This is the enum for all the commands that can be sent to the driver in the
// communication surface packet
typedef enum _AMDDX9SDICMD
{
    // Get SDI capability info
    AMD_SDI_CMD_GET_CAPS_DATA = 0,
    // Create surface on GPU - section begins, all surfaces created between begin and end
    // will be flagged as local SDI surface on GPU
    AMD_SDI_CMD_CREATE_SURFACE_LOCAL_BEGIN,
    // Create surface on GPU - section ends
    AMD_SDI_CMD_CREATE_SURFACE_LOCAL_END,
    // Create backing store for surfaces on SDI device - section begins, all surfaces created
    // between begin and end will be flagged as remote SDI surface on SDI device
    AMD_SDI_CMD_CREATE_SURFACE_REMOTE_BEGIN,
    // Create backing store for surfaces on SDI device - section ends
    AMD_SDI_CMD_CREATE_SURFACE_REMOTE_END,
    // Query the physical bus address of the memory, mapped with the surface created previously
    // Query the physical bus address of the marker, which was generated and mapped when creating
    // the bound surface. This is used to synchronize operations on the surface.
    AMD_SDI_CMD_QUERY_PHY_ADDRESS_LOCAL,
    // Indicates that DX9 will write marker to specified address of the surface, which locates
    // at an external SDI device, as remote surface created previously. This operation will be
    // executed when the write from GPU to the SDI device is complete.
    AMD_SDI_CMD_SYNC_WRITE_MARKER,
    // Indicates that DX9 wait until the marker owned by the specified surface which locates at
    // GPU, as local surface created previously. Before issuing next command, the value in the
    // marker address is supposed to be updated as the input desired marker value.
    AMD_SDI_CMD_SYNC_WAIT_MARKER,
    // Indicates pinned memory surfaces will be created
    AMD_SDI_CMD_CREATE_SURFACE_PINNED_SYSMEM_BEGIN,
    // Get the handle of the pinned memory surface just created
    AMD_SDI_CMD_CREATE_SURFACE_PINNED_SYSMEM_END,
    // Synchronize the data between surface and the attached pixel buffer, this serves for
    // the requirement of arbitrary pitches which are limited by specific GPU hardware; surface with
    // well-aligned pitch can have better performance when working with SDI flows.
    AMD_SDI_CMD_SYNC_SURFACE_DATA,
    // Enable apps to configure some SDI caps
    AMD_SDI_CMD_SET_CAPS,
    // Max command index
    AMD_SDI_CMD_MAX,
    AMD_SDI_FORCEDWORD                             = 0xffffffff
} AMDDX9SDICMD;


// Structure used to send commands and get data from the driver through the FOURCC_SDIF surface.
// When a FOURCC_SDIF surface is created and locked, a pointer to this structure is returned.
// If properly filled in, it will process the appropriate command when the surface is unlocked
typedef struct _AMDDX9SDICOMMPACKET
{
    DWORD               dwSign;         // Signature, the valid value is 'SDIF'
    DWORD               dwSize;         // Size of this structure.  Passed to the app on lock
    AMDDX9SDICMD        sdiCmd;         // Command given to the driver
    HRESULT             *pResult;       // Pointer to buffer where error code will be written to.
                                        // D3D_OK if successful
    DWORD               dwInBufSize;    // Size of optional buffer to place incoming parameters
    PBYTE               pInBuf;         // Pointer to buffer for incoming data
    DWORD               dwOutBufSize;   // Size of optional buffer to place outgoing data into
                                        // (in bytes).  Must be set if data is returned
    PBYTE               pOutBuf;        // Pointer to buffer for outgoing data.
} AMDDX9SDICOMMPACKET;

typedef AMDDX9SDICOMMPACKET* PAMDDX9SDICOMMPACKET;

#define AMD_DX9_SDI_CAPS_PINNED_P2P         0x00000001
#define AMD_DX9_SDI_CAPS_DIRECT_P2P         0x00000002
#define AMD_DX9_SDI_CAPS_UNPACKED_PITCH     0x00000004

// SDI version data struct
typedef struct _AMDDX9SDICAPS
{
    DWORD   dwSize;                     // Size of this structure
    union
    {
        DWORD   dwVersion;              // SDI version, major.minor (16.16)
        DWORD   dwVersionMajor;         // Major Version
    };
    union
    {
        DWORD   dwReserved0;            // Reserved bytes
        DWORD   dwVersionMinor;         // Minor Version
    };
    DWORD   dwMaxCommand;               // Max command enum
    DWORD   dwCaps;                     // SDI Caps
    DWORD   dwReserved[11];
} AMDDX9SDICAPS;
typedef AMDDX9SDICAPS* PAMDDX9SDICAPS;

#ifndef DX9RES_HANDLE
typedef ULONG64 DX9RES_HANDLE;
#endif

// SDI surface address attributes
typedef struct _AMDDX9SDISURFACEADDRESS
{
    ULONG64         surfaceBusAddr;     // Bus-relative address for surface
    ULONG64         markerBusAddr;      // Bus-relative address for marker
} AMDDX9SDISURFACEADDRESS;
typedef AMDDX9SDISURFACEADDRESS* PAMDDX9SDISURFACEADDRESS;

// SDI surface attributes
typedef struct _AMDDX9SDISURFACEATTRIBUTES
{
    DX9RES_HANDLE           surfaceHandle;      // Handle for surface
    AMDDX9SDISURFACEADDRESS surfaceAddr;        // Address properties for surfaces
} AMDDX9SDISURFACEATTRIBUTES;
typedef AMDDX9SDISURFACEATTRIBUTES* PAMDDX9SDISURFACEATTRIBUTES;

// SDI marker awaiting parameters
typedef struct _AMDDX9SDIWAITMARKERPARAM
{
    DX9RES_HANDLE surfaceHandle;                // Handle for surface
    DWORD         markerValue;                  // Value of marker
} AMDDX9SDIWAITMARKERPARAM;
typedef AMDDX9SDIWAITMARKERPARAM* PAMDDX9SDIWAITMARKERPARAM;

// SDI marker writing parameters
typedef struct _AMDDX9SDIWRITEMARKERPARAM
{
    DX9RES_HANDLE surfaceHandle;                // Handle for surface
    ULONG64       markerOffset;                 // Offset of marker
    DWORD         markerValue;                  // Value of marker
} AMDDX9SDIWRITEMARKERPARAM;
typedef AMDDX9SDIWRITEMARKERPARAM* PAMDDX9SDIWRITEMARKERPARAM;

// SDI synchronize surface data from/to the attached pixel buffer
typedef struct _AMDDX9SDISURFSYNCPARAM
{
    DX9RES_HANDLE surfaceHandle;                // Handle for surface
    BOOL          surfaceToPixelBuffer;         // Update the pixel buffer from surface, or reversed
} AMDDX9SDISURFSYNCPARAM;
typedef AMDDX9SDISURFSYNCPARAM* PAMDDX9SDISURFSYNCPARAM;

#pragma pack(pop, amd_dx9ext_sdi_h)

#endif // _AMD_DX9EXT_SDI_H_
