

#include <windows.h>
#include <assert.h>
#include <GL/glew.h>
#include <GL/wglew.h>

#include "defines.h"
#include "FormatInfo.h"
#include "SyncedBuffer.h"
#include "GLTransferBuffers.h"
#include "GLSink.h"
#include <iostream>



GLSink::GLSink()
{
    m_uiWindowWidth  = 0;
    m_uiWindowHeight = 0;

    m_uiTextureWidth  = 0;
    m_uiTextureHeight = 0;
    m_uiTexture       = 0;
    m_uiTextureSize   = 0;

    m_nIntFormat = GL_RGB8;
    m_nExtFormat = GL_RGB;
    m_nType      = GL_UNSIGNED_BYTE;

    m_uiQuad = 0;
 
    m_fAspectRatio = 1.0f;

    m_pInputBuffer      = NULL;
    m_pSyncBuffer       = NULL;
    m_pFrameData        = NULL;
}


GLSink::~GLSink()
{
    // make sure now other thread is blocked
    release();

    if (m_pFrameData)
        delete [] m_pFrameData;
  
    if (m_pInputBuffer)
        delete m_pInputBuffer;

    if (m_pSyncBuffer)
        delete m_pSyncBuffer;
}


void GLSink::initGL()
{
    const float pArray [] = { -0.5f, -0.5f, 0.0f,       0.0f, 0.0f,
                               0.5f, -0.5f, 0.0f,       1.0f, 0.0f,
                               0.5f,  0.5f, 0.0f,       1.0f, 1.0f,
                              -0.5f,  0.5f, 0.0f,       0.0f, 1.0f 
                            };
    
    glClearColor(0.3f, 0.3f, 0.3f, 1.0f);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_TEXTURE_2D);

    glShadeModel(GL_SMOOTH);

    glPolygonMode(GL_FRONT, GL_FILL);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

    // create quad that is used to map SDi texture to
    glGenBuffers(1, &m_uiQuad);
    glBindBuffer(GL_ARRAY_BUFFER, m_uiQuad);

    glBufferData(GL_ARRAY_BUFFER, 20*sizeof(float), pArray, GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, m_uiQuad);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    glVertexPointer(3, GL_FLOAT,   5*sizeof(float), 0);
    glTexCoordPointer(2, GL_FLOAT, 5*sizeof(float), (char*)NULL + 3*sizeof(float));

    glBindBuffer(GL_ARRAY_BUFFER, 0);

    // Activate Sync to VBlank to avoid tearing
    //wglSwapIntervalEXT(1);	//enable VSYNC
	//cout << "VSYNC ENABLED!" << endl;
	wglSwapIntervalEXT(0);
	std::cout << "VSYNC DISABLED!" << std::endl;
}


void GLSink::resize(unsigned int w, unsigned int h)
{
    m_uiWindowWidth  = w;
    m_uiWindowHeight = h;

    glViewport(0, 0, w, h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glOrtho(-(double)w/(double)h*0.5, (double)w/(double)h*0.5, -0.5, 0.5, -1.0, 1.0);
    
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}


bool GLSink::createDownStream(unsigned int w, unsigned int h, int nIntFormat, int nExtFormat, int nType)
{
    unsigned int uiBufferSize = 0;

    m_uiTextureWidth  = w;
    m_uiTextureHeight = h;

    m_nIntFormat = nIntFormat;
    m_nExtFormat = nExtFormat;
    m_nType      = nType;

    m_fAspectRatio = (float)w/(float)h;

    uiBufferSize = FormatInfo::getInternalFormatSize(m_nIntFormat) * m_uiTextureWidth * m_uiTextureHeight;

    if (uiBufferSize == 0)
        return false;

    // check if format is supported
    if (FormatInfo::getExternalFormatSize(m_nExtFormat, m_nType) == 0)
        return false;

    // Create texture that will be used to store frames from remote device
    glGenTextures(1, &m_uiTexture);

    glBindTexture(GL_TEXTURE_2D, m_uiTexture);

    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);

    glTexImage2D(GL_TEXTURE_2D, 0, m_nIntFormat, m_uiTextureWidth, m_uiTextureHeight, 0, m_nExtFormat, m_nType, NULL);

    glBindTexture(GL_TEXTURE_2D, 0);

    m_uiTextureSize = m_uiTextureWidth*m_uiTextureHeight*FormatInfo::getExternalFormatSize(m_nExtFormat, m_nType);

    // Create transfer buffer
    m_pInputBuffer = new GLTransferBuffers;

    if (!m_pInputBuffer->createBuffers(NUM_BUFFERS, uiBufferSize, GL_PIXEL_UNPACK_BUFFER, true))
    {
        return false;
    }

    glPixelStorei(GL_UNPACK_ALIGNMENT, FormatInfo::getAlignment(m_uiTextureWidth, m_nExtFormat, m_nType));

    // Create synchronization buffers
    m_pSyncBuffer = new SyncedBuffer;
    m_pSyncBuffer->createSyncedBuffer(NUM_BUFFERS);

    // Allocate memory to store frame data
    m_pFrameData = new FrameData[NUM_BUFFERS];
   
    for (unsigned int i = 0; i < NUM_BUFFERS; i++)
    {
        m_pFrameData[i].uiTransferId        = 0;
        m_pFrameData[i].ullBufferBusAddress = m_pInputBuffer->getBufferBusAddress(i);
        m_pFrameData[i].ullMarkerBusAddress = m_pInputBuffer->getMarkerBusAddress(i);

        m_pSyncBuffer->setBufferMemory(i, (void*)(&m_pFrameData[i]));
    }

    return true;
}


void GLSink::draw()
{
    unsigned int        uiBufferIdx;

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Update stream 
    glBindTexture(GL_TEXTURE_2D, m_uiTexture);

    FrameData* pFrame = NULL;

    // block until new frame is available
    uiBufferIdx = m_pSyncBuffer->getBufferForReading((void*&)pFrame);

    m_pInputBuffer->bindBuffer(uiBufferIdx);

    // This is a non-blocking call, but the GPU is instructed to wait until
    // the marker value is pFrame->uiTransferId before processsing the subsequent
    // instructions
    m_pInputBuffer->waitMarker(pFrame->uiTransferId);

    // Copy bus addressable buffer into texture object
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, m_uiTextureWidth, m_uiTextureHeight, m_nExtFormat, m_nType, NULL);

    // Insert fence to determine when the buffer was copied into the texture
    // and we can release the buffer
    GLsync Fence = glFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE, 0);

    // Draw quad with mapped texture
    glPushMatrix();
   
    // Scale quad to the AR of the incoming texture
    glScalef(m_fAspectRatio, -1.0f, 1.0f);
   
    // Draw quad with mapped texture
    glBindBuffer(GL_ARRAY_BUFFER, m_uiQuad);
    glDrawArrays(GL_QUADS, 0, 4);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    
    glPopMatrix();

    glBindTexture(GL_TEXTURE_2D, 0);

    // Wait until buffer is no longer needed and release it
    if (glIsSync(Fence))
    {
        glClientWaitSync(Fence, GL_SYNC_FLUSH_COMMANDS_BIT, OneSecond);
        glDeleteSync(Fence);
    }

    m_pSyncBuffer->releaseReadBuffer();
}



unsigned long long* GLSink::getBufferBusAddress()
{
    if (m_pInputBuffer)
    {
        return m_pInputBuffer->getBufferBusAddresses();
    }

    return NULL;
}


unsigned long long* GLSink::getMarkerBusAddress()
{
    if (m_pInputBuffer)
    {
        return m_pInputBuffer->getMarkerBusAddresses();
    }

    return NULL;
}


void GLSink::release()
{
    if (m_pSyncBuffer)
        m_pSyncBuffer->releaseReadBuffer();

}
