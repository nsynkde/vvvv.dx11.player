
#pragma once


#include "defines.h"

class SyncedBuffer;
class GLTransferBuffers;


class GLSink
{
public:

    GLSink();
    ~GLSink();

    void            initGL();
    void            resize(unsigned int w, unsigned int h);
    bool            createDownStream(unsigned int w, unsigned int h, int nIntFormat, int nExtFormat, int nType);

    void            draw();

    void            release();

    unsigned long long* getBufferBusAddress();
    unsigned long long* getMarkerBusAddress();

    SyncedBuffer*       getInputBuffer() { return m_pSyncBuffer; };

private:

    
    unsigned int            m_uiWindowWidth;
    unsigned int            m_uiWindowHeight;

    unsigned int            m_uiTextureWidth;
    unsigned int            m_uiTextureHeight;
    unsigned int            m_uiTextureSize;
    unsigned int            m_uiTexture;

    float                   m_fAspectRatio;

    int                     m_nIntFormat;
    int                     m_nExtFormat;
    int                     m_nType;

    unsigned int            m_uiQuad;

    FrameData*              m_pFrameData;
    SyncedBuffer*           m_pSyncBuffer;  
    GLTransferBuffers*      m_pInputBuffer;
};
