
#include "BluefishCaptureDevice.h"

using namespace std;

extern unsigned int g_uiWidth;
extern unsigned int g_uiHeight;


struct blue_videomode_info
{
	bool	bIs3G;
	float fFrameAspectRatioX;
	float fFrameAspectRatioY;	
	std::string strVideoModeFriendlyName;
	unsigned int nVideoMode;
	unsigned int nHeight;
	unsigned int nWidth;
	unsigned int nFrameRate;
	bool	bIs1001FrameRate;
	bool	bIsProgressive;
	unsigned int nAudioFrameSequence[5];
};

struct blue_videomode_info gVideoModeInfo[] = {
	{false,4.0,3.0,("PAL"),VID_FMT_PAL,576,720,25,false,false,{1920,1920,1920,1920,1920}},
	{false,4.0,3.0,("NTSC"),VID_FMT_NTSC,486,720,30,true,false,{1602,1601,1602,1601,1602}},
	{false,16.0,9.0,("720P 59.94"),VID_FMT_720P_5994,720,1280,60,true,true,{801,800,801,801,801}},
	{false,16.0,9.0,("720P 60"),VID_FMT_720P_6000,720,1280,60,false,true,{800,800,800,800,800}},
	{false,16.0,9.0,("1080PSF 23.97"),VID_FMT_1080PSF_2397,1080,1920,24,true,false,{2002,2002,2002,2002,2002}},
	{false,16.0,9.0,("1080PSF 24.00"),VID_FMT_1080PSF_2400,1080,1920,24,false,false,{2000,2000,2000,2000,2000}},
	{false,16.0,9.0,("1080P 23.97"),VID_FMT_1080P_2397,1080,1920,24,true,true,{2002,2002,2002,2002,2002}},
	{false,16.0,9.0,("1080P 24"),VID_FMT_1080P_2400,1080,1920,24,false,true,{2000,2000,2000,2000,2000}},
	{false,16.0,9.0,("1080I 50"),VID_FMT_1080I_5000,1080,1920,25,false,false,{1920,1920,1920,1920,1920}},
	{false,16.0,9.0,("1080I 59.94"),VID_FMT_1080I_5994,1080,1920,30,true,false,{1602,1601,1602,1601,1602}},
	{false,16.0,9.0,("1080I 60"),VID_FMT_1080I_6000,1080,1920,30,false,false,{1600,1600,1600,1600,1600}},
	{false,16.0,9.0,("1080P 25"),VID_FMT_1080P_2500,1080,1920,25,false,true,{1920,1920,1920,1920,1920}},
	{false,16.0,9.0,("1080P 29.97"),VID_FMT_1080P_2997,1080,1920,30,true,true,{1602,1601,1602,1601,1602}},
	{false,16.0,9.0,("1080P 30"),VID_FMT_1080P_3000,1080,1920,30,false,true,{1600,1600,1600,1600,1600}},
	{false,4.0,3.0,("HSDL 14"),VID_FMT_HSDL_1498,1556,2048,15,true,false,{1602,1601,1602,1601,1602}},
	{false,4.0,3.0,("HSDL 15"),VID_FMT_HSDL_1500,1556,2048,15,false,false,{1602,1601,1602,1601,1602}},
	{false,16.0,9.0,("720P 50"),VID_FMT_720P_5000,720,1280,50,false,true,{960,960,960,960,960}},
	{false,16.0,9.0,("720P 23.98"),VID_FMT_720P_2398,720,1280,24,true,true,{2002,2002,2002,2002,2002}},
	{false,16.0,9.0,("720P 24"),VID_FMT_720P_2400,720,1280,24,false,true,{2000,2000,2000,2000,2000}},
	{false,16.0,9.0,("2Kx1080 PSF 23.97"),VID_FMT_2048_1080PSF_2397,1080,2048,24,true,false,{2002,2002,2002,2002,2002}},
	{false,16.0,9.0,("2Kx1080 PSF 24"),VID_FMT_2048_1080PSF_2400,1080,2048,24,false,false,{2000,2000,2000,2000,2000}},
	{false,16.0,9.0,("2Kx1080 P 23.97"),VID_FMT_2048_1080P_2397,1080,2048,24,true,true,{2002,2002,2002,2002,2002}},
	{false,16.0,9.0,("2Kx1080 P 24"),VID_FMT_2048_1080P_2400,1080,2048,24,false,true,{2000,2000,2000,2000,2000}},
	{false,16.0,9.0,("1080PSF 25"),VID_FMT_1080PSF_2500,1080,1920,25,false,false,{1920,1920,1920,1920,1920}},
	{false,16.0,9.0,("1080PSF 29.97"),VID_FMT_1080PSF_2997,1080,1920,30,true,false,{1602,1601,1602,1601,1602}},
	{false,16.0,9.0,("1080PSF 30"),VID_FMT_1080PSF_3000,1080,1920,30,false,false,{1600,1600,1600,1600,1600}},
	{true,16.0,9.0,("1080P 50"),VID_FMT_1080P_5000,1080,1920,50,false,true,{960,960,960,960,960}},
	{true,16.0,9.0,("1080P 59.94"),VID_FMT_1080P_5994,1080,1920,60,true,true,{801,800,801,801,801}},
	{true,16.0,9.0,("1080P 60"),VID_FMT_1080P_6000,1080,1920,60,false,true,{800,800,800,800,800}},
	{false,16.0,9.0,("720P 25"),VID_FMT_720P_2500,720,1280,25,false,true,{1920,1920,1920,1920,1920}},
	{false,16.0,9.0,("720P 29.97"),VID_FMT_720P_2997,720,1280,30,true,true,{1602,1601,1602,1601,1602}},
	{false,16.0,9.0,("720P 30"),VID_FMT_720P_3000,720,1280,30,false,true,{1600,1600,1600,1600,1600}},
	{false,16.0,9.0,("DVB-ASI"),VID_FMT_DVB_ASI,720,1280,50,false,true,{960,960,960,960,960}},
	{false,16.0,9.0,("2Kx1080 PSF 25"),VID_FMT_2048_1080PSF_2500,1080,2048,25,false,false,{1920,1920,1920,1920,1920}},
	{false,16.0,9.0,("2Kx1080 PSF 29.97"),VID_FMT_2048_1080PSF_2997,1080,2048,30,true,false,{1602,1601,1602,1601,1602}},
	{false,16.0,9.0,("2Kx1080 PSF 30"),VID_FMT_2048_1080PSF_3000,1080,2048,30,false,false,{1600,1600,1600,1600,1600}},
	{false,16.0,9.0,("2Kx1080 P 25"),VID_FMT_2048_1080P_2500,1080,2048,25,false,true,{1920,1920,1920,1920,1920}},
	{false,16.0,9.0,("2Kx1080 P 29.97"),VID_FMT_2048_1080P_2997,1080,2048,30,true,true,{1602,1601,1602,1601,1602}},
	{false,16.0,9.0,("2Kx1080 P 30"),VID_FMT_2048_1080P_3000,1080,2048,30,false,true,{1600,1600,1600,1600,1600}},
	{true,16.0,9.0,("2Kx1080 P 50"),VID_FMT_2048_1080P_5000,1080,2048,50,false,true,{960,960,960,960,960}},
	{true,16.0,9.0,("2Kx1080 P 59.94"),VID_FMT_2048_1080P_5994,1080,2048,60,true,true,{801,800,801,801,801}},
	{true,16.0,9.0,("2Kx1080 P 60"),VID_FMT_2048_1080P_6000,1080,2048,60,false,true,{800,800,800,800,800}},
	{false,1.0,1.0,("VID_FMT_INVALID"),VID_FMT_INVALID,0,0,0,false,true,{0,0,0,0,0}}
};

CBlueCaptureDevice::CBlueCaptureDevice() :
	m_pSDK(NULL),
	m_iDevices(0),
	m_nVideoEngine(VIDEO_ENGINE_FRAMESTORE),	//only use VIDEO_ENGINE_FRAMESTORE for this functionality
	m_nVideoMode(VID_FMT_INVALID),
	m_nUpdateFormat(UPD_FMT_FRAME),
	m_nMemoryFormat(MEM_FMT_RGBA),
	m_nFrameSize(0),
	m_nBytesPerLine(0),
	m_nBytesPerFrame(0),
	m_nPixelsPerLine(0),
	m_ulLastFieldCount(0),
	m_ulCurrentFieldCount(0),
	m_ulBufferID(0),
	m_nCurrentGlBuffer(0),
	m_pSyncBuffer(NULL),
	m_bDoSplitDma(FALSE),
	m_ScheduleID(0),
	m_CapturingID(0),
	m_DoneID(0),
	m_iDroppedFields(0),
	m_iDroppedFrames(0)
{
	m_ui64BusAddress[0] = 0LL;
	m_ui64BusAddress[1] = 0LL;
	m_ui64Marker[0] = 0LL;
	m_ui64Marker[1] = 0LL;
}

CBlueCaptureDevice::~CBlueCaptureDevice()
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	if(m_pSDK)
	{
		m_pSDK->video_capture_stop();

		//disable low latency DMA
		varVal.ulVal = 0;
		m_pSDK->SetCardProperty(EPOCH_LOW_LATENCY_DMA, varVal);

		m_pSDK->device_detach();
		BlueVelvetDestroy(m_pSDK);
		m_pSDK = NULL;
	}
}

//#define USE_SECOND_CARD
BOOL CBlueCaptureDevice::Init(BOOL bDoSplitDma)
{
	m_bDoSplitDma = bDoSplitDma;

	m_pSDK = BlueVelvetFactory4();
	if(!m_pSDK)
	{
		cout << "No Bluefish SDK" << endl;
		return FALSE;
	}

	if(m_pSDK)
	{
		m_pSDK->device_enumerate(m_iDevices);
#ifdef USE_SECOND_CARD
		if(m_iDevices < 2)
		{
			cout << "Can't find second Bluefish card" << endl;
			BlueVelvetDestroy(m_pSDK);
			m_pSDK = NULL;
			return FALSE;
		}

		m_pSDK->device_attach(2, 0);
#else
		if(m_iDevices < 1)
		{
			cout << "No Bluefish card" << endl;
			BlueVelvetDestroy(m_pSDK);
			m_pSDK = NULL;
			return FALSE;
		}

		m_pSDK->device_attach(1, 0);
#endif

		int card_type = m_pSDK->has_video_cardtype();
		if(card_type != CRD_BLUE_EPOCH_HORIZON &&
			card_type != CRD_BLUE_EPOCH_CORE &&
			card_type != CRD_BLUE_EPOCH_ULTRA &&
			card_type != CRD_BLUE_EPOCH_2K_HORIZON &&
			card_type != CRD_BLUE_EPOCH_2K_CORE &&
			card_type != CRD_BLUE_EPOCH_2K_ULTRA &&
			card_type != CRD_BLUE_SUPER_NOVA &&
			card_type != CRD_BLUE_SUPER_NOVA_S_PLUS)
		{
			cout << "Not an Epoch/SuperNova card" << endl;
			m_pSDK->device_detach();
			BlueVelvetDestroy(m_pSDK);
			m_pSDK = NULL;
		}
	}

	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = BLUE_VIDEO_INPUT_CHANNEL_A;
	m_pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

	m_pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	m_nVideoMode = varVal.ulVal;
	if(varVal.ulVal >= VID_FMT_INVALID)
	{
		cout << "No valid input signal" << endl;
		m_pSDK->device_detach();
		BlueVelvetDestroy(m_pSDK);
		m_pSDK = NULL;
		return FALSE;
	}
	
	cout << "Video Input mode: " << gVideoModeInfo[m_nVideoMode].strVideoModeFriendlyName.c_str() << endl;

	BOOL bDoFieldMode = FALSE;
	if(m_bDoSplitDma && !gVideoModeInfo[m_nVideoMode].bIsProgressive)	//we can't do LowLatency DMA in FRAME mode for interlaced video formats
		bDoFieldMode = TRUE;
	else if(!gVideoModeInfo[m_nVideoMode].bIsProgressive)	//for interlaced video formats we have the choice of using FRAME or FIELD mode (as long as we don't use LowLatency DMA)
	{
		int iRet = MessageBox(NULL, "Process input in field mode?", "Update type", MB_YESNO);
		if(iRet == 6) //yes
			bDoFieldMode = TRUE;
		else	//7 == no
			bDoFieldMode = FALSE;
	}

	if(bDoFieldMode)
		m_nUpdateFormat = UPD_FMT_FIELD;
	else
		m_nUpdateFormat = UPD_FMT_FRAME;
	varVal.ulVal = m_nUpdateFormat;
	m_pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);

	varVal.ulVal = m_nMemoryFormat;
	m_pSDK->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);

	varVal.ulVal = m_nVideoEngine;
	m_pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);

	m_nFrameSize = BlueVelvetGolden(m_nVideoMode, m_nMemoryFormat, m_nUpdateFormat);	//DMA friendly frame size
	m_nBytesPerLine = BlueVelvetLineBytes(m_nVideoMode, m_nMemoryFormat);
	m_nBytesPerFrame = BlueVelvetFrameBytes(m_nVideoMode, m_nMemoryFormat, m_nUpdateFormat);
	m_nPixelsPerLine = BlueVelvetLinePixels(m_nVideoMode);

	g_uiWidth = m_nPixelsPerLine;
	g_uiHeight = m_nBytesPerFrame/m_nBytesPerLine;

	cout << "Frame size:   " << m_nFrameSize << endl;
	cout << "Frame width:  " << g_uiWidth << endl;
	cout << "Frame height: " << g_uiHeight << endl;

	if(m_bDoSplitDma)
	{
		//Set to low latency mode: this mode will DMA the video frame in even numbered chunks
		//The DMA function call will return once the whole frame has been DMA'd, but it will start the DMA process earlier, i.e. it will DMA each
		//chunk of the video frame as soon as the chunk is available on the card
		varVal.ulVal = 2;
		m_pSDK->SetCardProperty(EPOCH_LOW_LATENCY_DMA, varVal);
		m_pSDK->QueryCardProperty(EPOCH_LOW_LATENCY_DMA, varVal);
		cout << "Number of LowLatency chunks set to " << varVal.ulVal << endl;
	}
	else
		cout << "Not doing split DMA" << endl;

	return TRUE;
}

//this function sets the target address (memory address on the GPU) which the Bluefish DMA engine will DMA the video frame to
bool CBlueCaptureDevice::setRemoteMemory(unsigned __int64* pBusAddress, unsigned __int64* pMarker)
{
	if(!pBusAddress || !pMarker)
		return false;

	m_ui64BusAddress[0] = pBusAddress[0];
	m_ui64Marker[0] = pMarker[0];
	cout << "Bus Addr: " << hex << m_ui64BusAddress[0] << ", Marker: " << hex << m_ui64Marker[0] << endl;
	
	m_ui64BusAddress[1] = pBusAddress[1];
	m_ui64Marker[1] = pMarker[1];
	cout << "Bus Addr: " << hex << m_ui64BusAddress[1] << ", Marker: " << hex << m_ui64Marker[1] << endl;

	return true;
}

void CBlueCaptureDevice::setSyncBuffer(SyncedBuffer* pSyncBuffer)
{
	if (pSyncBuffer)
		m_pSyncBuffer = pSyncBuffer;
}

unsigned int CBlueCaptureDevice::WaitForInputClock()
{
	unsigned long ulFieldCount = 0;
	static unsigned long ulLastFieldCount = 0;

	if(m_pSDK)
		m_pSDK->wait_input_video_synch(m_nUpdateFormat, ulFieldCount);

	if(!m_bDoSplitDma && ulLastFieldCount != 0)
	{
		if(m_nUpdateFormat == UPD_FMT_FIELD)
		{
			if(ulLastFieldCount+1 < ulFieldCount)
			{
				//cout << "Frame dropped (capture). Should be " << dec << (ulLastFieldCount+1) << ", is " << ulFieldCount << endl;
				m_iDroppedFields++;
			}
		}
		else
		{
			if(ulLastFieldCount+2 < ulFieldCount)
			{
				//cout << "Frame dropped (capture). Should be " << dec << (ulLastFieldCount+2) << ", is " << ulFieldCount << endl;
				m_iDroppedFrames++;
			}
		}
	}
	ulLastFieldCount = ulFieldCount;

	return ulFieldCount;
}

void CBlueCaptureDevice::ScheduleCapture()
{
	if(m_pSDK)
	{
		m_pSDK->render_buffer_capture(m_ScheduleID, 0);
		m_DoneID = m_CapturingID;
		m_CapturingID = m_ScheduleID;
		m_ScheduleID = (++m_ScheduleID%4);	//we use 4 internal buffers on the card
	}
}

void CBlueCaptureDevice::TransferCapturedVideoFrame()
{
	if(m_pSDK)
	{
		FrameData* pFrame = NULL;

		// get an empty buffer
		m_nCurrentGlBuffer = m_pSyncBuffer->getBufferForWriting((void*&)pFrame);
		++pFrame->uiTransferId;

		bfDmaReadToBusAddress(	m_pSDK,
								BLUE_VIDEO_INPUT_CHANNEL_A,
								m_ui64BusAddress[m_nCurrentGlBuffer],
								m_nFrameSize,
								NULL,
								m_DoneID, 0);

		bfDmaWriteMarker(	m_pSDK,
							m_ui64Marker[m_nCurrentGlBuffer],
							pFrame->uiTransferId);

		m_pSyncBuffer->releaseWriteBuffer();
		pFrame = NULL;
	}
}
