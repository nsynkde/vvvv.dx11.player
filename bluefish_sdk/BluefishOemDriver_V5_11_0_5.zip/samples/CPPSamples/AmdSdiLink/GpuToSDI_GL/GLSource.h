

#pragma once


class SyncedBuffer;
class GLTransferBuffers;
class RenderTarget;


class GLSource
{
public:

    GLSource();
    ~GLSource();

    void            initGL();
    void            resize(unsigned int w, unsigned int h);
    bool            createUpStream(unsigned int w, unsigned int h, int nIntFormat, int nExtFormat, int nType);

    bool            setRemoteMemory(unsigned long long* pBufferBusAddress, unsigned long long* pMarkerBusAddress);

    void            draw(bool bFieldMode);

    void            release();

    void            setSyncBuffer(SyncedBuffer* pSyncBuffer);
    SyncedBuffer*   getSyncBuffer() { return m_pSyncBuffer; };

private:


    unsigned int            m_uiWindowWidth;
    unsigned int            m_uiWindowHeight;

    unsigned int            m_uiBufferWidth;
    unsigned int            m_uiBufferHeight;

    int                     m_nIntFormat;
    int                     m_nExtFormat;
    int                     m_nType;

    unsigned int            m_uiCube;

    float                   m_fRotationAngle;

    RenderTarget*           m_pRenderTarget;
    GLTransferBuffers*      m_pOutputBuffer;
    SyncedBuffer*           m_pSyncBuffer;
};
