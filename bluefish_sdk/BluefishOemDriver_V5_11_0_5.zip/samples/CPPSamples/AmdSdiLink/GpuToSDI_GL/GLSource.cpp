
#include <windows.h>
#include <GL/glew.h>
#include <GL/wglew.h>

#include "SyncedBuffer.h"
#include "GLTransferBuffers.h"
#include "FormatInfo.h"
#include "RenderTarget.h"
#include "defines.h"

#include "GLSource.h"
#include <iostream>

GLSource::GLSource()
{
    m_uiWindowWidth  = 0;
    m_uiWindowHeight = 0;

    m_uiBufferWidth  = 0;
    m_uiBufferHeight = 0;

    m_nIntFormat = GL_RGB8;
    m_nExtFormat = GL_RGB;
    m_nType      = GL_UNSIGNED_BYTE;

    m_fRotationAngle = 0.0f;

    m_pRenderTarget = NULL;
    m_pOutputBuffer = NULL;
    m_pSyncBuffer   = NULL;
}


GLSource::~GLSource()
{
    release();

    if (m_pOutputBuffer)
        delete m_pOutputBuffer;

    if (m_pRenderTarget)
        delete m_pRenderTarget;
}



void GLSource::initGL()
{
    const float pVertices[] = { -0.5f, -0.5f,  0.5f,   0.5f, -0.5f,  0.5f,   0.5f,  0.5f,  0.5f,  -0.5f,  0.5f,  0.5f,
                                 0.5f, -0.5f,  0.5f,   0.5f, -0.5f, -0.5f,   0.5f,  0.5f, -0.5f,   0.5f,  0.5f,  0.5f,
                                -0.5f, -0.5f, -0.5f,   0.5f, -0.5f, -0.5f,   0.5f,  0.5f, -0.5f,  -0.5f,  0.5f, -0.5f,
                                -0.5f, -0.5f,  0.5f,  -0.5f, -0.5f, -0.5f,  -0.5f,  0.5f, -0.5f,  -0.5f,  0.5f,  0.5f,
                                -0.5f,  0.5f,  0.5f,   0.5f,  0.5f,  0.5f,   0.5f,  0.5f, -0.5f,  -0.5f,  0.5f, -0.5f,
                                -0.5f, -0.5f,  0.5f,   0.5f, -0.5f,  0.5f,   0.5f, -0.5f, -0.5f,  -0.5f, -0.5f, -0.5f };

    const float pColors[]   = { 1.0f, 0.0f, 0.0f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f, 0.0f,  1.0f, 1.0f, 0.0f,
                                0.0f, 1.0f, 0.0f,  0.0f, 1.0f, 1.0f,  1.0f, 0.0f, 1.0f,  1.0f, 1.0f, 1.0f,
                                1.0f, 1.0f, 0.0f,  0.0f, 1.0f, 1.0f,  1.0f, 0.0f, 0.0f,  1.0f, 1.0f, 0.0f,
                                1.0f, 0.0f, 0.0f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f, 0.0f,  1.0f, 1.0f, 0.0f,
                                0.0f, 1.0f, 0.0f,  0.0f, 1.0f, 1.0f,  1.0f, 0.0f, 1.0f,  1.0f, 1.0f, 1.0f,
                                1.0f, 1.0f, 0.0f,  0.0f, 1.0f, 1.0f,  1.0f, 0.0f, 0.0f,  1.0f, 1.0f, 0.0f };

    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);

    glEnable(GL_DEPTH_TEST);

    glShadeModel(GL_SMOOTH);

    glPolygonMode(GL_FRONT, GL_FILL);

    //wglSwapIntervalEXT(1);	//enable VSYNC
	//std::cout << "VSYNC ENABLED!" << std::endl;
	wglSwapIntervalEXT(0);
	std::cout << "VSYNC DISABLED!" << std::endl;

    // create cube
    glGenBuffers(1, &m_uiCube);
    glBindBuffer(GL_ARRAY_BUFFER, m_uiCube);

    glBufferData(GL_ARRAY_BUFFER, 144 * sizeof(float), pVertices, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 72 * sizeof(float), 72 * sizeof(float), pColors);

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);

    glVertexPointer(3, GL_FLOAT, 0, 0);
    glColorPointer( 3, GL_FLOAT, 0, ((char*)NULL + 72 * sizeof(float)));

    glBindBuffer(GL_ARRAY_BUFFER, 0);
}



// Resize only the window. Since we are rendering into a FBO the
// projection matrix does not change on a window resize
void GLSource::resize(unsigned int w, unsigned int h)
{
    m_uiWindowWidth  = w;
    m_uiWindowHeight = h;
}


// Create a FBO that will be used as render target and a synchronized PACK buffer to transfer
// FBO content to the other GPU
bool GLSource::createUpStream(unsigned int w, unsigned int h, int nIntFormat, int nExtFormat, int nType)
{
    unsigned int uiBufferSize = 0;

    m_uiBufferWidth  = w;
    m_uiBufferHeight = h;

    m_nIntFormat = nIntFormat;
    m_nExtFormat = nExtFormat;
    m_nType      = nType;

    uiBufferSize = FormatInfo::getInternalFormatSize(m_nIntFormat) * m_uiBufferWidth * m_uiBufferHeight;

    if (uiBufferSize == 0)
        return false;

    // check if external format is supported
    if (FormatInfo::getExternalFormatSize(m_nExtFormat, m_nType) == 0)
        return false;

    // Create FBO that is used as render target
    m_pRenderTarget = new RenderTarget;
    m_pRenderTarget->createBuffer(m_uiBufferWidth, m_uiBufferHeight, m_nIntFormat, m_nExtFormat, m_nType);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluPerspective(60.0f, (float)m_uiBufferWidth/(float)m_uiBufferHeight, 0.1f, 1000.0f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Create output Buffer
    m_pOutputBuffer = new GLTransferBuffers;

    if (!m_pOutputBuffer->createBuffers(NUM_BUFFERS, uiBufferSize, GL_PIXEL_PACK_BUFFER, true))
    {
        return false;
    }

    glPixelStorei(GL_PACK_ALIGNMENT, FormatInfo::getAlignment(m_uiBufferWidth, m_nExtFormat, m_nType));

    return true;
}


bool GLSource::setRemoteMemory(unsigned long long* pBufferBusAddress, unsigned long long* pMarkerBusAddress)
{
    // check if we received enough addresses
    if (!m_pOutputBuffer ||!pBufferBusAddress || !pMarkerBusAddress)
        return false;

    // assign remote buffer to local buffer objects
    if (!m_pOutputBuffer->assignRemoteMemory(NUM_BUFFERS, pBufferBusAddress, pMarkerBusAddress))
    {
        return false;
    }

    return true;    
}



void GLSource::draw(bool bFieldMode)
{
    unsigned int        uiBufferIdx;

	FrameData* pFrame = NULL;

    // Draw a rotating cube to FBO
    m_pRenderTarget->bind();
    glViewport(0, 0, m_uiBufferWidth, m_uiBufferHeight);

	uiBufferIdx = m_pSyncBuffer->getBufferForWriting((void*&)pFrame);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
    // Draw rotating cube
    glPushMatrix();

	if(bFieldMode)
		glScalef(2.0f, 1.0f, 1.0f);
    glTranslatef(0.0f, 0.0f, -2.0f);
    glRotatef(m_fRotationAngle, 1.0f, 0.0f, 1.0f);

    glBindBuffer(GL_ARRAY_BUFFER, m_uiCube);

    glDrawArrays(GL_QUADS, 0, 24);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glPopMatrix();

    m_fRotationAngle += 0.2f;
        
    // get an empty buffer
    //uiBufferIdx = m_pSyncBuffer->getBufferForWriting((void*&)pFrame);

    // update frame data
    ++pFrame->uiTransferId;

    m_pOutputBuffer->bindBuffer(pFrame->ullBufferBusAddress);

    // Copy local buffer into remote buffer
    glReadPixels(0, 0, m_uiBufferWidth, m_uiBufferHeight, m_nExtFormat, m_nType, NULL);

    // Write marker pFrame->uiTransferId into memory on remote gpu. The GLSink will
    // wait until the marker has the value indicated by pFrame before using the buffer
    m_pOutputBuffer->writeMarker(pFrame->ullBufferBusAddress, pFrame->ullMarkerBusAddress, pFrame->uiTransferId);

    // Mark the buffer as ready to be consumed. No need to wait for the transfer to terminate
    // since the consumer will call waitMarker that will block the GPU until the transfer is done.
    m_pSyncBuffer->releaseWriteBuffer();

    m_pRenderTarget->unbind();

    // copy FBO into window
    // comment this out to output drawing only on SDI
    glViewport(0, 0, m_uiWindowWidth, m_uiWindowHeight);
    m_pRenderTarget->draw();
}

void GLSource::setSyncBuffer(SyncedBuffer* pSyncBuffer)
{
    if (pSyncBuffer)
    {
        m_pSyncBuffer = pSyncBuffer;
    }
}

void GLSource::release()
{
    if (m_pSyncBuffer)
        m_pSyncBuffer->releaseWriteBuffer();
}
