#pragma once

#include "GL/glew.h"
#include "defines.h"


class GLTransferBuffers
{
public:

    GLTransferBuffers(void);
    ~GLTransferBuffers(void);

    // Creates synchronized buffers. For each buffer uiBufferSize bytes are allocated as pinned memory
    // Target spcifies if is is an PACK or UNPACK buffer
    bool createBuffers(unsigned int uiNumBuffers, unsigned int uiBufferSize, unsigned int uiTarget, bool bUseP2P = false);

    // In case of using a p2p PACK_BUFFER, the actual memory used by the buffer is located on a remote device. 
    // assignRemoteMemory passes the bus addresses of this memory to OpenGL and assigns it to the buffers used by this class.
    bool assignRemoteMemory(unsigned int uiNumBuffers, unsigned long long* pBufferBusAddress, unsigned long long* pMarkerBusAddress);

    void   waitMarker(unsigned int uiMarkerValue);
    void   writeMarker(unsigned long long ulBufferBusAddress, unsigned long long ulMarkerBusAddress, unsigned int uiMarkerValue);

    // Bind the buffer that is located at the bus address: ulBusAddress
    bool    bindBuffer(unsigned long long ulBusAddress);
    // Bind buffer with id: uiIdx
    bool    bindBuffer(unsigned int uiIdx);

    // In case of pinned memory buffers, returns the ponter to the pinned system memory
    // that is used by buffer id: uiIdx
    char*               getPinnedMemoryPtr(unsigned int uiIdx);
    // In case of bus addressable memory, returns the bus address of the buffer memory used by
    // the buffer with id:  uiIdx
    unsigned long long  getBufferBusAddress(unsigned int uiIdx);
    // In case of bus addressable memory, returns a pointer to the array that contains the buffer
    // bus addresses. The array length is m_uiNumBuffers
    unsigned long long*  getBufferBusAddresses()        { return m_pBufferBusAddress; };
    // In case of bus addressable memory, returns the bus address of the marker memory used by
    // the buffer with id:  uiIdx
    unsigned long long  getMarkerBusAddress(unsigned int uiIdx);
    // In case of bus addressable memory, returns a pointer to the array that contains the marker
    // bus addresses. The array length is m_uiNumBuffers
    unsigned long long*  getMarkerBusAddresses()        { return m_pMarkerBusAddress; };

    unsigned int         getNumBuffers()                { return m_uiNumBuffers; };

private:

    bool                    m_bUseP2P;
    bool                    m_bBufferReady;

    unsigned int            m_uiTarget;
    unsigned int            m_uiNumBuffers;
    unsigned int            m_uiBufferSize;
    unsigned int            m_uiBufferIdx;
    unsigned int*           m_pBuffer;

    AlignedMem*             m_pBufferMemory;
    unsigned long long*     m_pBufferBusAddress;
    unsigned long long*     m_pMarkerBusAddress;
};
