// (c) 2013 Bluefish Technologies Pty Ltd
//
// Sample application:	CaptureASI
// Written by:			Tim Bragulla
// Date:				30 July 2013
//
// Brief description:	This sample application shows how to capture an ASI stream and save it to a file (.ts)
//
// Supported hardware:	Bluefish Epoch cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.2.10 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_2_10\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"


#define PARSE_PKT

void BlueMemZero(void* pData, size_t size)
{
	size_t tmpsize = 0;
	if(size >=8)
	{
		tmpsize = size%8;
		size /= 8;

		UINT64* pTmpData = (UINT64*)pData;
		for(unsigned int i=0; i<size; i++)
		{
			*pTmpData = 0LL;
			pTmpData++;
		}

		if(tmpsize)
			memset(pTmpData, 0, tmpsize);
	}
	else
	{
		memset(pData, 0, size);
	}
}

enum mpeg2_pid_enum
{
	mpeg2_pid_pat =			0x0, // program access table 
	mpeg2_pid_cat =			0x1, // conditional access table 
	mpeg2_pid_pmt =			0x2, // 
	mpeg2_pid_nit =			0x40,
	mpeg2_pid_sdt =			0x42,
	mpeg2_pid_sdt_other =	0x43,
	mpeg2_pid_eit =			0x4e,
	mpeg2_pid_tdt =			0x70,
};

#pragma pack(push, mpeg2_struct, 1)
struct Mpeg2TsHeaderStruct
{
	unsigned int 	continuity_counter:4,
					adaption_field_control:2,
					scrambling_mode:2,
					PID:13,
					transport_priority:1,
					transport_error_indicator:1,
					payload_start_indicator:1,
					sync_byte:8;
};

union Mpeg2TsHeader
{
	struct Mpeg2TsHeaderStruct ts_header_st;
	unsigned int ts_header_int;
};

#pragma pack(pop, mpeg2_struct)

struct BluefishDvbTsStruct
{
	int pid;
	int continuity_counter;
	int pkt_count;

	BluefishDvbTsStruct()
	{
		pid = -1;
		continuity_counter = -1;
		pkt_count=0;
	}
};

std::map<int,struct BluefishDvbTsStruct> mapObjDVBParser;	
typedef std::pair <int, struct BluefishDvbTsStruct> bluefish_dvb_ts_parser_Pair;

BLUE_UINT32 AnalayzeTransportStream(BLUE_UINT8* pAsiPacket,
									BLUE_INT32 iPID,
									BLUE_UINT32& last_continuity_count,
									BLUE_UINT32 asi_pkt_size,
									BLUE_UINT32 asi_pkt_count,
									BLUE_UINT32& total_pkt_count)
{
	BLUE_UINT32 i = 0;
	union Mpeg2TsHeader ts_union;
	struct BluefishDvbTsStruct tempStructParser;

	map<int, struct BluefishDvbTsStruct>::iterator ts_iterator;

	while (i< asi_pkt_count)
	{
		ts_union.ts_header_int = htonl((*((BLUE_UINT32 *)(pAsiPacket+i*asi_pkt_size))));
		iPID = ts_union.ts_header_st.PID;

		if (ts_union.ts_header_st.PID == mpeg2_pid_pat)
		{
			//decode_mpeg2_ts_pat((pAsiPacket+i*asi_pkt_size)+sizeof(union mpeg2_transport_stream_header));
		}
		//if (ts_union.ts_header_st.PID == pid)
		else
		{
			ts_iterator = mapObjDVBParser.find(iPID);
			if (ts_iterator == mapObjDVBParser.end())
			{
				tempStructParser.pid = iPID;
				tempStructParser.continuity_counter = ts_union.ts_header_st.continuity_counter;
				tempStructParser.continuity_counter++;
				tempStructParser.continuity_counter %= 16;
				//printf("Adding a new PID %d \n",tempStructParser.pid);
				mapObjDVBParser.insert(bluefish_dvb_ts_parser_Pair(iPID, tempStructParser));
			}
			else
			{
				if (ts_iterator->second.continuity_counter != ts_union.ts_header_st.continuity_counter 
					&& 
					ts_union.ts_header_st.PID != 0x1FFF
					&& 
					ts_union.ts_header_st.adaption_field_control != 0x0
					&&
					ts_union.ts_header_st.adaption_field_control != 0x2
					)
					printf("pid = %d pkt count %d pkt CCounter %d Adaption field %x should have CCounter %d\n",
																	ts_iterator->second.pid,
																	ts_iterator->second.pkt_count,
																	ts_union.ts_header_st.continuity_counter,
																	ts_union.ts_header_st.adaption_field_control,
																	
																	ts_iterator->second.continuity_counter);
				ts_iterator->second.continuity_counter  = ts_union.ts_header_st.continuity_counter;
				ts_iterator->second.continuity_counter++;
				ts_iterator->second.continuity_counter %= 16;
				ts_iterator->second.pkt_count++;
				//mapObjDVBParser[ts_union.ts_header_st.PID].continuity_counter = ts_union.ts_header_st.continuity_counter;
			}
		}
		i++;
		total_pkt_count++;
	}
	return 0;	
}

void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

void InitInputChannel(CBlueVelvet4* pSDK, ULONG DefaultInputChannel, ULONG UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultInputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_INPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_capture_stop();

	RouteChannel(pSDK, EPOCH_SRC_SDI_INPUT_A, EPOCH_DEST_INPUT_MEM_INTERFACE_CHA, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_INPUT_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required update type and memory format and make sure that there is a valid input signal
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_INPUT_ENGINE, varVal);
}

bool GetOutputFileName(wchar_t* pszFileName)
{
    OPENFILENAME ofn;

    ZeroMemory(&ofn, sizeof(ofn));
	*pszFileName = L'\0';

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = 0;
    ofn.lpstrFilter = L"Transport Stream Files (*.ts)\0*.ts\0";
    ofn.lpstrFile = pszFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
    ofn.lpstrDefExt = L"ts";

    if(GetSaveFileName(&ofn))
		return true;

	return false;
}

int CaptureDvbAsiStream(wchar_t* pFileName, EBlueVideoChannel VideoChannel)
{
	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;
	FILE* pFile = NULL;
	VARIANT varVal;
	varVal.vt = VT_UI4;
	ULONG UpdateFormat = UPD_FMT_FRAME;
	ULONG MemoryFormat = MEM_FMT_BGRA;
	ULONG VideoEngine = VIDEO_ENGINE_DUPLEX;
	ULONG FieldCount = 0;
	ULONG LastFieldCount = 0;
	ULONG ulAsiBufferSize = 1280*720*4;
	blue_videoframe_info_ex	FrameInfo;
	unsigned int FifoSize = 0;

	//Create an SDK instance, one for each channel
	pSDK = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDK->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card, in this case card 1
	if(BLUE_FAIL(pSDK->device_attach(1, 0)))
	{
		cout << "Error on device attach (channel A)" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Get the card type and firmware type
	int iCardType = pSDK->has_video_cardtype();
	if(	iCardType != CRD_BLUE_EPOCH_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_CORE &&
		iCardType != CRD_BLUE_EPOCH_ULTRA &&
		iCardType != CRD_BLUE_EPOCH_2K_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_2K_CORE &&
		iCardType != CRD_BLUE_EPOCH_2K_ULTRA)
	{
		cout << "Card not supported for OEM ASI capture" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	varVal.ulVal = 0;
	if(BLUE_FAIL(pSDK->QueryCardProperty(CARD_FEATURE_STREAM_INFO, varVal)))
	{
		cout << "Function not supported; need driver 5.10.2.x or above" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	unsigned int nAsiOutputStreams = CARD_FEATURE_GET_ASI_OUTPUT_STREAM_COUNT(varVal.ulVal);
	unsigned int nAsiInputStreams = CARD_FEATURE_GET_ASI_INPUT_STREAM_COUNT(varVal.ulVal);
	if(!nAsiInputStreams)
	{
		cout << "Card does not support ASI input channels" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	InitInputChannel(pSDK, VideoChannel, UpdateFormat, MemoryFormat, VideoEngine);

	//Check if we have a valid input signal
	pSDK->wait_input_video_synch(UPD_FMT_FRAME, FieldCount); //synchronise with the card before querying VIDEO_INPUT_SIGNAL_VIDEO_MODE
	varVal.vt = VT_UI4;
	pSDK->QueryCardProperty(VIDEO_INPUT_SIGNAL_VIDEO_MODE, varVal);
	if(varVal.ulVal != VID_FMT_DVB_ASI)
	{
		cout << "No DVB ASI input signal found on video channel " << VideoChannel << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	//set packing format
	unsigned int nAsiPackingFormat = enum_blue_dvb_asi_packed_format;
	//unsigned int pkt_packing_format = enum_blue_dvb_asi_packed_format_with_timestamp;
	//unsigned int pkt_packing_format = enum_blue_dvb_asi_256byte_container_format;
	//unsigned int pkt_packing_format = enum_blue_dvb_asi_256byte_container_format_with_timestamp;
	varVal.vt  = VT_UI4;
	varVal.ulVal = nAsiPackingFormat;
	pSDK->SetCardProperty(EPOCH_DVB_ASI_INPUT_PACKING_FORMAT, varVal);
	pSDK->QueryCardProperty(EPOCH_DVB_ASI_INPUT_PACKING_FORMAT, varVal);
	assert(varVal.ulVal == nAsiPackingFormat);

	//set timeout
	cout << "Enter timeout in ms (10-255): ";	//should not be lower than 10ms
	unsigned int nDvbAsiInputTimeout = 12;
	cin >> nDvbAsiInputTimeout;
	if(nDvbAsiInputTimeout < 10 || nDvbAsiInputTimeout > 255)
		nDvbAsiInputTimeout = 12;

	varVal.vt  = VT_UI4;	
	varVal.ulVal = nDvbAsiInputTimeout;
	pSDK->SetCardProperty(EPOCH_DVB_ASI_INPUT_TIMEOUT, varVal);
	cout << "Timeout: " << nDvbAsiInputTimeout << "ms" << endl;

	//set packet count; packet count must be a multiple of 4
	cout << "Enter packet count (4-16000): ";
	unsigned int nDvbAsiInputPacketsPerInterrupt = 100;
	cin >> nDvbAsiInputPacketsPerInterrupt;
	if(nDvbAsiInputPacketsPerInterrupt == 0 || nDvbAsiInputPacketsPerInterrupt > 16000)
		nDvbAsiInputPacketsPerInterrupt = 100;

	nDvbAsiInputPacketsPerInterrupt = (nDvbAsiInputPacketsPerInterrupt / 4) * 4;
	varVal.vt = VT_UI4;	
	varVal.ulVal = (ULONG)nDvbAsiInputPacketsPerInterrupt;
	pSDK->SetCardProperty(EPOCH_DVB_ASI_INPUT_LATENCY_PACKET_COUNT, varVal);
	pSDK->QueryCardProperty(EPOCH_DVB_ASI_INPUT_LATENCY_PACKET_COUNT, varVal);
	if(varVal.ulVal != nDvbAsiInputPacketsPerInterrupt)
	{
		printf("Error: could not set packet count per interrupt: %d %d \n", nDvbAsiInputPacketsPerInterrupt, varVal.ulVal);
		system("pause");
		pSDK->device_detach();
		::BlueVelvetDestroy(pSDK);
		return 0;
	}
	cout << "Packet Count per interrupt: " << nDvbAsiInputPacketsPerInterrupt << endl;


	unsigned int* pAsiReadBuffer =(BLUE_UINT32*)VirtualAlloc(NULL, ulAsiBufferSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pAsiReadBuffer, ulAsiBufferSize);
	unsigned char* pAsiWriteBuffer = (BLUE_UINT8*)VirtualAlloc(NULL, ulAsiBufferSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pAsiWriteBuffer, ulAsiBufferSize);

	if(pFileName)
		_wfopen_s(&pFile, pFileName, L"wb");

	OVERLAPPED OverlapChA;
	OverlapChA.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	

	//synchronise with the card
	pSDK->wait_input_video_synch(UpdateFormat, LastFieldCount);

	if(BLUE_FAIL(pSDK->video_capture_start(0)))
		cout << "Error video capture start failed on channel A" << endl;

	cout << "Start field count: " << LastFieldCount << endl;

	__int64 CurTimeStamp = 0LL;
	__int64 LastTimeStamp = 0LL;
	unsigned int nTimeStampOffset = 0;
	BLUE_UINT32 nContinuityCounter = 0;
	BLUE_UINT32 nTotalPacketCount = 0;
	while(!_kbhit())
	{
		pSDK->wait_input_video_synch(UpdateFormat, FieldCount);
		
		if(BLUE_FAIL(GetVideo_CaptureFrameInfoEx(pSDK, &OverlapChA, FrameInfo, 0, &FifoSize)) ||
			(FrameInfo.nVideoSignalType != VID_FMT_DVB_ASI) ||
			(FrameInfo.BufferId == -1) ||
			!FrameInfo.nASIPktCount || !FrameInfo.nASIPktSize)
		{
			//cout << "continue: " << endl;
			printf("Mode: %d, ID: %d, PktCount: %d, PktSize: %d\n", FrameInfo.nVideoSignalType, FrameInfo.BufferId, FrameInfo.nASIPktCount, FrameInfo.nASIPktSize);
			continue;
		}

		BlueMemZero(pAsiReadBuffer, ulAsiBufferSize);
		if(nAsiPackingFormat == enum_blue_dvb_asi_packed_format_with_timestamp)
		{
			pSDK->system_buffer_read_async(	(unsigned char*)pAsiReadBuffer,
											(FrameInfo.nASIPktCount*(FrameInfo.nASIPktSize+8)),
											NULL,
											BlueImage_VBI_HANC_DMABuffer(FrameInfo.BufferId, BLUE_DATA_IMAGE));
		}
		else
		{
			pSDK->system_buffer_read_async(	(unsigned char*)pAsiReadBuffer,
											(FrameInfo.nASIPktCount*(FrameInfo.nASIPktSize)),
											NULL,
											BlueImage_VBI_HANC_DMABuffer(FrameInfo.BufferId, BLUE_DATA_IMAGE));
		}

#ifdef PARSE_PKT
		if((nAsiPackingFormat == enum_blue_dvb_asi_packed_format) ||
			(nAsiPackingFormat == enum_blue_dvb_asi_packed_format_with_timestamp))
		{
			unsigned int nAsiPacketSize = FrameInfo.nASIPktSize;
			if(nAsiPackingFormat == enum_blue_dvb_asi_packed_format_with_timestamp)
			{
				LastTimeStamp = CurTimeStamp;
				CurTimeStamp = (*((__int64*)(pAsiReadBuffer)));
				//cout << hex << "Timestamp: 0x" << CurTimeStamp << ", d: " << dec << (CurTimeStamp-LastTimeStamp) << endl;
				nAsiPacketSize += 8;
				nTimeStampOffset = 8;
			}

			unsigned int nIndex = 0;
			while((*(((BYTE*)pAsiReadBuffer + nTimeStampOffset) + nIndex) == 0x47) && ((nIndex) < (FrameInfo.nASIPktCount * nAsiPacketSize + nTimeStampOffset)))
				nIndex += nAsiPacketSize;

			if(nIndex != (FrameInfo.nASIPktCount * nAsiPacketSize))
				printf("\nDVB-ASI reading ERROR Got packets after parsing %d should be %d \n", nIndex/nAsiPacketSize, FrameInfo.nASIPktCount);

			if(nAsiPackingFormat == enum_blue_dvb_asi_packed_format_with_timestamp)
			{
				//AnalyzeTimeStamps((BYTE*)pAsiReadBuffer, FrameInfo.nASIPktCount, nAsiPacketSize);
			}

			if(pFile && FrameInfo.nASIPktCount && nAsiPacketSize)
				fwrite(pAsiReadBuffer, FrameInfo.nASIPktCount * (nAsiPacketSize), 1, pFile);

			//printf("[%d:%d]packed  Packets Per Frame %d \n", pkt_count, FrameInfo.nFrameTimeStamp, FrameInfo.nASIPktCount);
			if(nAsiPackingFormat == enum_blue_dvb_asi_packed_format)
			{
				AnalayzeTransportStream((unsigned char*)pAsiReadBuffer, 49, nContinuityCounter, nAsiPacketSize, FrameInfo.nASIPktCount, nTotalPacketCount);
			}
		}
#endif
 	}

	if(pFile)
		fclose(pFile);

	pSDK->video_capture_stop();
	CloseHandle(OverlapChA.hEvent);
	
	VirtualUnlock(pAsiWriteBuffer, ulAsiBufferSize);
	VirtualFree(pAsiWriteBuffer, 0, MEM_RELEASE);
	VirtualUnlock(pAsiReadBuffer, ulAsiBufferSize);
	VirtualFree(pAsiReadBuffer, 0, MEM_RELEASE);

	BailOut(pSDK);
	cout << "Done" << endl;
	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "CaptureASI sample app" << endl;

	EBlueVideoChannel VideoChannel = BLUE_VIDEO_INPUT_CHANNEL_A;	//we only ever support one asi input channel -> BLUE_VIDEO_INPUT_CHANNEL_A

	wchar_t FileName[MAX_PATH];
	bool bFlag = GetOutputFileName(FileName);
	CaptureDvbAsiStream((bFlag)?FileName:NULL, VideoChannel);

	system("pause");
	return 0;
}
