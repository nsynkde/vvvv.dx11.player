// (c) 2013 Bluefish Technologies Pty Ltd
//
// Sample application:	PlaybackASI
// Written by:			Tim Bragulla
// Date:				19 August 2013
//
// Brief description:	This sample application shows how to playback an ASI stream from a file (.ts)
//
// Supported hardware:	Bluefish Epoch cards
//
// Requirements:
//		Software:				Bluefish Driver 5.10.2.10 and above
//
//		Environment variables:	$(BLUE_LATEST_SDK):		must point to the Bluefish SDK directory (e.g. C:\MyDocuments\BluefishSDK\Driver_5_10_2_10\)
//								$(BLUE_SAMPLES_BIN):	must point to a directory where the output files (executable) will be copied to
//

#include "stdafx.h"


#define PARSE_PKT

void BlueMemZero(void* pData, size_t size)
{
	size_t tmpsize = 0;
	if(size >=8)
	{
		tmpsize = size%8;
		size /= 8;

		UINT64* pTmpData = (UINT64*)pData;
		for(unsigned int i=0; i<size; i++)
		{
			*pTmpData = 0LL;
			pTmpData++;
		}

		if(tmpsize)
			memset(pTmpData, 0, tmpsize);
	}
	else
	{
		memset(pData, 0, size);
	}
}

enum mpeg2_pid_enum
{
	mpeg2_pid_pat =			0x0, // program access table 
	mpeg2_pid_cat =			0x1, // conditional access table 
	mpeg2_pid_pmt =			0x2, // 
	mpeg2_pid_nit =			0x40,
	mpeg2_pid_sdt =			0x42,
	mpeg2_pid_sdt_other =	0x43,
	mpeg2_pid_eit =			0x4e,
	mpeg2_pid_tdt =			0x70,
};

#pragma pack(push, mpeg2_struct, 1)
struct Mpeg2TsHeaderStruct
{
	unsigned int 	continuity_counter:4,
					adaption_field_control:2,
					scrambling_mode:2,
					PID:13,
					transport_priority:1,
					transport_error_indicator:1,
					payload_start_indicator:1,
					sync_byte:8;
};

union Mpeg2TsHeader
{
	struct Mpeg2TsHeaderStruct ts_header_st;
	unsigned int ts_header_int;
};

#pragma pack(pop, mpeg2_struct)

struct BluefishDvbTsStruct
{
	int pid;
	int continuity_counter;
	int pkt_count;

	BluefishDvbTsStruct()
	{
		pid = -1;
		continuity_counter = -1;
		pkt_count=0;
	}
};

std::map<int,struct BluefishDvbTsStruct> mapObjDVBParser;	
typedef std::pair <int, struct BluefishDvbTsStruct> bluefish_dvb_ts_parser_Pair;

BLUE_UINT32 AnalayzeTransportStream(BLUE_UINT8* pAsiPacket,
									BLUE_INT32 iPID,
									BLUE_UINT32& last_continuity_count,
									BLUE_UINT32 asi_pkt_size,
									BLUE_UINT32 asi_pkt_count,
									BLUE_UINT32& total_pkt_count)
{
	BLUE_UINT32 i = 0;
	union Mpeg2TsHeader ts_union;
	struct BluefishDvbTsStruct tempStructParser;

	map<int, struct BluefishDvbTsStruct>::iterator ts_iterator;

	while (i< asi_pkt_count)
	{
		ts_union.ts_header_int = htonl((*((BLUE_UINT32 *)(pAsiPacket+i*asi_pkt_size))));
		iPID = ts_union.ts_header_st.PID;

		if (ts_union.ts_header_st.PID == mpeg2_pid_pat)
		{
			//decode_mpeg2_ts_pat((pAsiPacket+i*asi_pkt_size)+sizeof(union mpeg2_transport_stream_header));
		}
		//if (ts_union.ts_header_st.PID == pid)
		else
		{
			ts_iterator = mapObjDVBParser.find(iPID);
			if (ts_iterator == mapObjDVBParser.end())
			{
				tempStructParser.pid = iPID;
				tempStructParser.continuity_counter = ts_union.ts_header_st.continuity_counter;
				tempStructParser.continuity_counter++;
				tempStructParser.continuity_counter %= 16;
				//printf("Adding a new PID %d \n",tempStructParser.pid);
				mapObjDVBParser.insert(bluefish_dvb_ts_parser_Pair(iPID, tempStructParser));
			}
			else
			{
				if (ts_iterator->second.continuity_counter != ts_union.ts_header_st.continuity_counter 
					&& 
					ts_union.ts_header_st.PID != 0x1FFF
					&& 
					ts_union.ts_header_st.adaption_field_control != 0x0
					&&
					ts_union.ts_header_st.adaption_field_control != 0x2
					)
					printf("pid = %d pkt count %d pkt CCounter %d Adaption field %x should have CCounter %d\n",
																	ts_iterator->second.pid,
																	ts_iterator->second.pkt_count,
																	ts_union.ts_header_st.continuity_counter,
																	ts_union.ts_header_st.adaption_field_control,
																	
																	ts_iterator->second.continuity_counter);
				ts_iterator->second.continuity_counter  = ts_union.ts_header_st.continuity_counter;
				ts_iterator->second.continuity_counter++;
				ts_iterator->second.continuity_counter %= 16;
				ts_iterator->second.pkt_count++;
				//mapObjDVBParser[ts_union.ts_header_st.PID].continuity_counter = ts_union.ts_header_st.continuity_counter;
			}
		}
		i++;
		total_pkt_count++;
	}
	return 0;	
}

void BailOut(CBlueVelvet4* pSDK)
{
	pSDK->device_detach();
	BlueVelvetDestroy(pSDK);
}

void RouteChannel(CBlueVelvet4* pSDK, ULONG Source, ULONG Destination, ULONG LinkType)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	varVal.ulVal = EPOCH_SET_ROUTING(Source, Destination, LinkType);
	pSDK->SetCardProperty(MR2_ROUTING, varVal);
}

void InitOutputChannel(CBlueVelvet4* pSDK, ULONG DefaultOutputChannel, ULONG VideoMode, ULONG UpdateFormat, ULONG MemoryFormat, ULONG VideoEngine)
{
	VARIANT varVal;
	varVal.vt = VT_UI4;

	//MOST IMPORTANT: as the first step set the channel that we want to work with
	varVal.ulVal = DefaultOutputChannel;
	pSDK->SetCardProperty(DEFAULT_VIDEO_OUTPUT_CHANNEL, varVal);

	//make sure the FIFO hasn't been left running (e.g. application crash before), otherwise we can't change card properties
	pSDK->video_playback_stop(0, 0);

	if(DefaultOutputChannel == BLUE_VIDEO_OUTPUT_CHANNEL_B)
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHB, EPOCH_DEST_SDI_OUTPUT_B, BLUE_CONNECTOR_PROP_SINGLE_LINK);
	else
		RouteChannel(pSDK, EPOCH_SRC_OUTPUT_MEM_INTERFACE_CHA, EPOCH_DEST_SDI_OUTPUT_A, BLUE_CONNECTOR_PROP_SINGLE_LINK);

	varVal.ulVal = VideoMode;
	pSDK->SetCardProperty(VIDEO_MODE, varVal);

	varVal.ulVal = UpdateFormat;
	pSDK->SetCardProperty(VIDEO_UPDATE_TYPE, varVal);

	varVal.ulVal = MemoryFormat;
	pSDK->SetCardProperty(VIDEO_MEMORY_FORMAT, varVal);

	//Only set the Video Engine after setting up the required update type and memory format and make sure that there is a valid input signal
	varVal.ulVal = VideoEngine;
	pSDK->SetCardProperty(VIDEO_OUTPUT_ENGINE, varVal);
}

bool GetInputFileName(wchar_t* pszFileName)
{
    OPENFILENAME ofn;

    ZeroMemory(&ofn, sizeof(ofn));
	*pszFileName = L'\0';

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = 0;
    ofn.lpstrFilter = L"Transport Stream Files (*.ts)\0*.ts\0";
    ofn.lpstrFile = pszFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
    ofn.lpstrDefExt = L"ts";

    if(GetOpenFileName(&ofn))
		return true;

	return false;
}

int PlaybackDvbAsiStream(wchar_t* pFileName, EBlueVideoChannel VideoChannel)
{
	CBlueVelvet4* pSDK = NULL;
	int iDevices = 0;
	FILE* pFile = NULL;
	VARIANT varVal;
	varVal.vt = VT_UI4;
	ULONG VideoMode = VID_FMT_DVB_ASI;
	ULONG UpdateFormat = UPD_FMT_FRAME;
	ULONG MemoryFormat = MEM_FMT_BGRA;
	ULONG VideoEngine = VIDEO_ENGINE_DUPLEX;
	ULONG FieldCount = 0;
	ULONG LastFieldCount = 0;
	ULONG ulAsiBufferSize = 1280*720*4;
	blue_videoframe_info_ex	FrameInfo;
	unsigned int FifoSize = 0;

	if(pFileName)
		pFile = _wfopen(pFileName, L"rb");

	if(!pFile)
	{
		wcout << L"Can't find file";
		if(pFileName)
			wcout << pFileName;
		wcout << endl;

		system("pause");
		return 0;
	}

	//Create an SDK instance, one for each channel
	pSDK = BlueVelvetFactory4();
	
	//Check if there are any cards available
	pSDK->device_enumerate(iDevices);
	if(iDevices < 1)
	{
		cout << "No Bluefish card detected" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Attach the SDK object to a specific card, in this case card 1
	if(BLUE_FAIL(pSDK->device_attach(1, 0)))
	{
		cout << "Error on device attach (channel A)" << endl;
		BlueVelvetDestroy(pSDK);
		system("pause");
		return 0;
	}

	//Get the card type and firmware type
	int iCardType = pSDK->has_video_cardtype();
	if(	iCardType != CRD_BLUE_EPOCH_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_CORE &&
		iCardType != CRD_BLUE_EPOCH_ULTRA &&
		iCardType != CRD_BLUE_EPOCH_2K_HORIZON &&
		iCardType != CRD_BLUE_EPOCH_2K_CORE &&
		iCardType != CRD_BLUE_EPOCH_2K_ULTRA)
	{
		cout << "Card not supported for OEM ASI playback" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	varVal.ulVal = 0;
	if(BLUE_FAIL(pSDK->QueryCardProperty(CARD_FEATURE_STREAM_INFO, varVal)))
	{
		cout << "Function not supported; need driver 5.10.2.x or above" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	unsigned int nAsiOutputStreams = CARD_FEATURE_GET_ASI_OUTPUT_STREAM_COUNT(varVal.ulVal);
	unsigned int nAsiInputStreams = CARD_FEATURE_GET_ASI_INPUT_STREAM_COUNT(varVal.ulVal);
	if(!nAsiOutputStreams)
	{
		cout << "Card does not support ASI output channels" << endl;
		system("pause");
		BailOut(pSDK);
		return 0;
	}

	InitOutputChannel(pSDK, VideoChannel, VideoMode, UpdateFormat, MemoryFormat, VideoEngine);

	//set packet size
	unsigned int nPacketSize = 188;
	if(nPacketSize == 204)
		varVal.ulVal = enum_blue_dvb_asi_packet_size_204_bytes;
	else
		varVal.ulVal = enum_blue_dvb_asi_packet_size_188_bytes;
	pSDK->SetCardProperty(EPOCH_DVB_ASI_OUTPUT_PACKET_SIZE, varVal);

	ULONG nPacketsPerFrame = 0;
	cout << "Enter number of Packets per frame (default = 400): ";
	cin >> nPacketsPerFrame;
	if(nPacketsPerFrame == 0)
		nPacketsPerFrame = 400;

	varVal.vt = VT_UI4;
	varVal.ulVal = nPacketsPerFrame;
	pSDK->SetCardProperty(EPOCH_DVB_ASI_OUTPUT_PACKET_COUNT, varVal);
	cout << "Packet Count per frame: " << nPacketsPerFrame << endl;

	//set frame size
	ulAsiBufferSize = nPacketSize*nPacketsPerFrame;

	ULONG nBitRate = 0;
	cout << "Enter bit rate (default = 50,000,000): ";
	cin >> nBitRate;
	if(nBitRate == 0)
		nBitRate = 50000000;

	varVal.vt = VT_UI4;
	varVal.ulVal = nBitRate;
	pSDK->SetCardProperty(EPOCH_DVB_ASI_OUTPUT_BIT_RATE, varVal);
	cout << "Bit rate: " << nBitRate << endl;

	varVal.vt = VT_UI4;
	varVal.ulVal = ENUM_BLACKGENERATOR_OFF;
	pSDK->SetCardProperty(VIDEO_BLACKGENERATOR, varVal);

#if 0
	//turn on duplication:
	//setting EPOCH_DVB_ASI_DUPLICATE_OUTPUT_A will take the DVB ASI output from SDI A and duplicate it on SDI B
	varVal.vt = VT_UI4;
	varVal.ulVal = 1;
	pSDK->SetCardProperty(EPOCH_DVB_ASI_DUPLICATE_OUTPUT_A, varVal);
#else
#if 1
	//turn off duplication:
	varVal.vt = VT_UI4;
	varVal.ulVal = 0;
	pSDK->SetCardProperty(EPOCH_DVB_ASI_DUPLICATE_OUTPUT_A, varVal);
#endif
#endif

	unsigned char* pAsiWriteBuffer = (BLUE_UINT8*)VirtualAlloc(NULL, ulAsiBufferSize, MEM_COMMIT, PAGE_READWRITE);
	VirtualLock(pAsiWriteBuffer, ulAsiBufferSize);

	//synchronise with the card
	pSDK->wait_output_video_synch(UpdateFormat, LastFieldCount);
	cout << "Start field count: " << LastFieldCount << endl;

	void* pAddress_NotUsed = NULL;
	unsigned long ulBufferID = 0;
	unsigned long ulUniqueID = 0;
	unsigned long ulUnderrun = 0;
	unsigned long ulFrameIndex = 0;
	UINT32 nFirst = 1;
	while(!_kbhit())
	{
		if(BLUE_OK(pSDK->video_playback_allocate(&pAddress_NotUsed, ulBufferID, ulUnderrun)))
		{
			size_t iRead = fread(pAsiWriteBuffer, 1, ulAsiBufferSize, pFile);
			if(iRead < ulAsiBufferSize)
			{
				if(feof(pFile))
				{
					cout << "Rewinding file..." << endl;
					fseek(pFile, 0, SEEK_SET);
				}
				else
				{
					cout << "Error file reading: " << ferror(pFile) << endl;
					break;
				}

				int toRead = ulAsiBufferSize - iRead;
				int iReadDelta = fread(&pAsiWriteBuffer[iRead], 1, toRead, pFile);
				if(iReadDelta < toRead)
				{
					cout << "Error readagain: " << ferror(pFile) << endl;
					cout << "file too small: size " << ulAsiBufferSize << ", iRead: " << iRead << ", Delta: " << iReadDelta << ", toRead: " << toRead << endl;
					break;
				}
			}

			pSDK->system_buffer_write_async(pAsiWriteBuffer, ulAsiBufferSize, NULL, ulBufferID);
			pSDK->video_playback_present(ulUniqueID, ulBufferID, 1, 0);
			//printf("Video Buffer Id %d frame size 0x%x\n", ulBufferID, ulAsiBufferSize);
			ulFrameIndex++;
		}
		else
		{
			pSDK->wait_output_video_synch(UPD_FMT_FRAME, FieldCount);
			if(LastFieldCount + 2 != FieldCount)
				cout << "Dropped frame: should: " << (LastFieldCount + 2) << ", is: " << FieldCount << endl;
			LastFieldCount = FieldCount;
		}

		if(nFirst)
		{
			cout << "Starting playback" << endl;
			pSDK->video_playback_start(0,0);
			nFirst = 0;
		}
 	}

	pSDK->video_playback_stop(0,0);
	fclose(pFile);

	VirtualUnlock(pAsiWriteBuffer, ulAsiBufferSize);
	VirtualFree(pAsiWriteBuffer, 0, MEM_RELEASE);

	BailOut(pSDK);
	cout << "Done" << endl;
	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "PlaybackASI sample app" << endl;

	//EBlueVideoChannel VideoChannel = BLUE_VIDEO_OUTPUT_CHANNEL_A;	//we only support two asi output channels -> BLUE_VIDEO_OUTPUT_CHANNEL_A or BLUE_VIDEO_OUTPUT_CHANNEL_B
	EBlueVideoChannel VideoChannel = BLUE_VIDEO_OUTPUT_CHANNEL_B;	//we only support two asi output channels -> BLUE_VIDEO_OUTPUT_CHANNEL_A or BLUE_VIDEO_OUTPUT_CHANNEL_B

	wchar_t FileName[MAX_PATH];
	bool bFlag = GetInputFileName(FileName);
	PlaybackDvbAsiStream((bFlag)?FileName:NULL, VideoChannel);

	system("pause");
	return 0;
}
