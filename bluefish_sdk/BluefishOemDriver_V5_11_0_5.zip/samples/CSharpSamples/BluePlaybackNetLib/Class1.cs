using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace BluePlaybackNetLib
{
    public class BluePlaybackNet: IDisposable
    {
        private IntPtr pBluePlayback;

        public Int32 BluePlaybackInterfaceCreate()
        {
            Int32 error_code;
            pBluePlayback = BluePlaybackNativeInterface.BluePlaybackCreate();
            error_code = 0;
            return error_code;
        }

        public Int32 BluePlaybackInterfaceConfig(Int32 inDevNo, Int32 inChannel, Int32 inVidFmt, Int32 inMemFmt, Int32 inUpdFmt, Int32 inVideoDestination, Int32 inAudioDestination, Int32 inAudioChannelMask)
        {
            Int32 error_code = 0;
            error_code = BluePlaybackNativeInterface.BluePlaybackConfig(pBluePlayback, inDevNo, inChannel, inVidFmt, inMemFmt, inUpdFmt, inVideoDestination, inAudioDestination, inAudioChannelMask);
            return error_code;
        }

        public void BluePlaybackInterfaceStart()
        {
            BluePlaybackNativeInterface.BluePlaybackStart(pBluePlayback);
        }

        public void BluePlaybackInterfaceStop()
        {
            BluePlaybackNativeInterface.BluePlaybackStart(pBluePlayback);
        }

        public void BluePlaybackInterfaceRender(IntPtr pBuffer)
        {
            BluePlaybackNativeInterface.BluePlaybackRender(pBluePlayback, pBuffer);
        }

        public void BluePlaybackInterfaceDestroy()
        {
            BluePlaybackNativeInterface.BluePlaybackDestroy(pBluePlayback);
            pBluePlayback = IntPtr.Zero;
        }

        public void Dispose()
        {}
    }

    internal class BluePlaybackNativeInterface
    {
        [DllImport("BluePlayback.dll", SetLastError = false)]
        internal static extern IntPtr BluePlaybackCreate();

        [DllImport("BluePlayback.dll", SetLastError = false)]
        internal static extern Int32 BluePlaybackConfig(IntPtr pBluePlaybackObject, Int32 inDevNo,
                                                                                    Int32 inChannel,
                                                                                    Int32 inVidFmt,
                                                                                    Int32 inMemFmt,
                                                                                    Int32 inUpdFmt,
                                                                                    Int32 inVideoDestination,
                                                                                    Int32 inAudioDestination,
                                                                                    Int32 inAudioChannelMask);

        [DllImport("BluePlayback.dll", SetLastError = false)]
        internal static extern void BluePlaybackStart(IntPtr pBluePlaybackObject);

        [DllImport("BluePlayback.dll", SetLastError = false)]
        internal static extern void BluePlaybackStop(IntPtr pBluePlaybackObject);

        [DllImport("BluePlayback.dll", SetLastError = false)]
        internal static extern void BluePlaybackRender(IntPtr pBluePlaybackObject, IntPtr pBuffer);

        [DllImport("BluePlayback.dll", SetLastError = false)]
        internal static extern void BluePlaybackDestroy(IntPtr pBluePlaybackObject);


    }
}
