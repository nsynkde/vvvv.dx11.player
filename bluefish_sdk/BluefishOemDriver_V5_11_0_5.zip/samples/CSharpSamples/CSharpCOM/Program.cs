using System;
using System.Collections.Generic;
using System.Text;
using BLUEVELVETConstants;
using BLUEVELVETCOMLib;
using System.Runtime.InteropServices;
using System.IO;


namespace CSharpCOM
{
    public struct TGAHeader
    {   //TGA header
        public byte identsize;
        public byte colourmaptype;
        public byte imagetype;
        public short colourmapstart;
        public short colourmaplength;
        public byte colourmapbits;
        public short xstart;
        public short ystart;
        public short width;
        public short height;
        public byte bits;
        public byte descriptor;
    }

    class Program
    {
        static void Main(string[] args)
        {
            BlueVelvetInterfaceClass bluefishCOM;

            bluefishCOM = new BlueVelvetInterfaceClass();
            bluefishCOM.Initialize();
            int devicecount = bluefishCOM.device_enumerate();
            if (devicecount > 0)
            {
                bluefishCOM.device_attach(1, 0);
                ECardType cardtype = (ECardType)bluefishCOM.has_video_cardtype(1);
                if (cardtype != ECardType.CRD_BLUE_EPOCH_2K_HORIZON)
                {
                    //bluefishCOM.SetCardPropertyUInt32((int)EBlueCardProperty.DEFAULT_VIDEO_OUTPUT_CHANNEL, m_VideoChannel);
                    //bluefishCOM.QueryCardPropertyUInt32((int)EBlueCardProperty.DEFAULT_VIDEO_OUTPUT_CHANNEL, out m_VideoChannel);

                    bluefishCOM.SetCardPropertyUInt32((int)EBlueCardProperty.VIDEO_MODE, (uint)EVideoMode.VID_FMT_PAL);
                    bluefishCOM.SetCardPropertyUInt32((int)EBlueCardProperty.VIDEO_UPDATE_TYPE, (uint)EUpdateMethod.UPD_FMT_FRAME);
                    bluefishCOM.SetCardPropertyUInt32((int)EBlueCardProperty.VIDEO_OUTPUT_ENGINE, (uint)EEngineMode.VIDEO_ENGINE_FRAMESTORE);
                    bluefishCOM.SetCardPropertyUInt32((int)EBlueCardProperty.VIDEO_BLACKGENERATOR, 0);

                    TGAHeader FileHeader = new TGAHeader();
                    string filename = @"test.tga";
                    FileStream fs = File.OpenRead(filename);

                    byte[] Dummy = new byte[20];
                    fs.Read(Dummy, 0, 1);
                    FileHeader.identsize = Dummy[0];
                    fs.Read(Dummy, 1, 1);
                    FileHeader.colourmaptype = Dummy[1];
                    fs.Read(Dummy, 2, 1);
                    FileHeader.imagetype = Dummy[2];
                    fs.Read(Dummy, 3, 2);
                    FileHeader.colourmapstart = (short)((Dummy[4] << 8) | Dummy[3]);
                    fs.Read(Dummy, 5, 2);
                    FileHeader.colourmaplength = (short)((Dummy[6] << 8) | Dummy[5]);
                    fs.Read(Dummy, 7, 1);
                    FileHeader.colourmapbits = Dummy[7];
                    fs.Read(Dummy, 8, 2);
                    FileHeader.xstart = (short)((Dummy[9] << 8) | Dummy[8]);
                    fs.Read(Dummy, 10, 2);
                    FileHeader.ystart = (short)((Dummy[11] << 8) | Dummy[10]);
                    fs.Read(Dummy, 12, 2);
                    FileHeader.width = (short)((Dummy[13] << 8) | Dummy[12]);
                    fs.Read(Dummy, 14, 2);
                    FileHeader.height = (short)((Dummy[15] << 8) | Dummy[14]);
                    fs.Read(Dummy, 16, 1);
                    FileHeader.bits = Dummy[16];
                    fs.Read(Dummy, 17, 1);
                    FileHeader.descriptor = Dummy[17];

                    int BitsPerPixel = 0;
                    if (FileHeader.bits == 32)
                    {
                        bluefishCOM.SetCardPropertyUInt32((int)EBlueCardProperty.VIDEO_MEMORY_FORMAT, (uint)EMemoryFormat.MEM_FMT_ARGB_PC);
                        BitsPerPixel = 4;
                    }
                    else //24 bit
                    {
                        bluefishCOM.SetCardPropertyUInt32((int)EBlueCardProperty.VIDEO_MEMORY_FORMAT, (uint)EMemoryFormat.MEM_FMT_BGR);
                        BitsPerPixel = 3;
                    }

                    int frameSize = FileHeader.width * FileHeader.height * BitsPerPixel;
                    int ImageOrient = 0;
                    if ((FileHeader.descriptor & 0x10) != 0)
                        ImageOrient = 1;

                    byte[] TGAFrame = new byte[frameSize];
                    fs.Read(TGAFrame, 0, frameSize);
                    fs.Close();

                    if (ImageOrient == 1 && bluefishCOM.has_vertical_flip(1) != 0)
                        bluefishCOM.set_vertical_flip(1);

                    int[] BufAddrArray = new int[4];
                    if (frameSize > 0)
                    {
                        bluefishCOM.system_buffer_map(ref BufAddrArray[0], (int)EBufferId.BUFFER_ID_VIDEO0);
                        bluefishCOM.system_buffer_map(ref BufAddrArray[1], (int)EBufferId.BUFFER_ID_VIDEO1);
                        bluefishCOM.system_buffer_map(ref BufAddrArray[2], (int)EBufferId.BUFFER_ID_VIDEO2);
                        bluefishCOM.system_buffer_map(ref BufAddrArray[3], (int)EBufferId.BUFFER_ID_VIDEO3);
                    }
                    else
                    {
                        bluefishCOM.device_detach();
                        return;
                    }

                    int FieldCount = 0;
                    for (int i = 0; i < 250; i++)
                    {
                        Marshal.Copy(TGAFrame, 0, (IntPtr)(BufAddrArray[i%4]), frameSize);
                        bluefishCOM.wait_output_video_synch((int)EUpdateMethod.UPD_FMT_FRAME, ref FieldCount);
                        bluefishCOM.system_buffer_write_lng_ex(BufAddrArray[i % 4], i%4, frameSize, 0);
                        bluefishCOM.render_buffer_update(i%4);
                    }
                    bluefishCOM.SetCardPropertyUInt32((int)EBlueCardProperty.VIDEO_BLACKGENERATOR, 1);

                    System.Threading.Thread.Sleep(200);

                    bluefishCOM.system_buffer_unmap_lng(BufAddrArray[3]);
                    bluefishCOM.system_buffer_unmap_lng(BufAddrArray[2]);
                    bluefishCOM.system_buffer_unmap_lng(BufAddrArray[1]);
                    bluefishCOM.system_buffer_unmap_lng(BufAddrArray[0]);

                    bluefishCOM.device_detach();
                }
            }
        }
    }
}

