#pragma once 

#define BERR		int
#define BLUE_UINT32 unsigned int
#define BLUE_INT32	int
#define BLUE_UINT64	unsigned __int64
#define BLUE_UINT8	unsigned char
#define BLUE_INT8	char
#define BLUE_UINT16	unsigned short
